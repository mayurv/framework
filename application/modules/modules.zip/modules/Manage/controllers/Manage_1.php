<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Manage extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->library('Ajax_pagination');
        $this->load->helper(array('url', 'language', 'form'));
        $this->load->model(array('user_model', 'candidateskillset', 'users', 'CandidateDetails', 'priority', 'businessEntity', 'employment_status', 'menu', 'jobTitle', 'department'));
        $this->load->model(array('employeesummary', 'frontend/notification', 'candidatedetails', 'numbers', 'interviewrounddetails', 'interviewtype', 'skills', 'state', 'city', 'country', 'employees', 'common', 'personaldetails', 'requisition'));
        $this->load->library('grocery_CRUD');
        $this->load->language('recruitment');
        $this->load->language('hr_lang');
        $this->load->language(array('general_lang', 'profile_lang'));
        $this->perPage = 5;
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function ajaxPaginationInterviewList() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        //echo $this->uri->segment(4);
        $page = $this->input->post('page');
        // $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        //$offset = (int)$this->uri->segment(4) > 0 ? ($this->uri->segment(4) - 1) * $config['per_page'] : 0;
        if (!$page && $page == '') {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
        if (!empty($keywords)) {
            $conditions['search']['keywords'] = $keywords;
        }
        if (!empty($sortBy)) {
            $conditions['search']['sortBy'] = $sortBy;
        }

        //total rows count
        $totalRec = count($this->candidatedetails->get_schedule_interviews($user_id));

        //pagination configuration
        $config['first_link'] = 'First';
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'manage/ajaxPaginationInterviewList/';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['use_page_numbers'] = TRUE;
        $this->ajax_pagination->initialize($config);

//        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;

        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;

        //get the posts data
        $data['candidates'] = $this->candidatedetails->get_schedule_interviews($user_id, $conditions);

        //echo $this->db->last_query();
        // var_dump($data['employee']);
        //load the view
        $this->load->view('manage/_ajaxManagecandidates', $data, false);
    }

    public function interview() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //$data['candidates'] = $this->candidatedetails->get_schedule_interviews($user_id); 
        // var_dump($data['candidates']);

        $data['openings'] = $this->requisition->get_all_openings_byId($user_id);


        $totalRec = count($this->candidatedetails->get_schedule_interviews($user_id));
//echo $this->db->last_query();
        //pagination configuration
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'manage/ajaxPaginationInterviewList/';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['link_func'] = 'searchFilter';
        $this->ajax_pagination->initialize($config);

//        var_dump($config);die;

        $data['candidates'] = $this->candidatedetails->get_schedule_interviews($user_id, array('limit' => $this->perPage));



        $data['skills_list'] = (array('' => 'Select Skills')) + $this->skills->dropdown('skill_title');
        $data['req_code'] = $this->generate_requsition_id();
        $data['job_code1'] = $this->jobTitle->get_jobtitle();
        $data['job_code'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlecode'));
        $data['jobtitle'] = (array('' => 'Select Jobtitle') + $this->jobTitle->dropdown('jobtitlename'));
        $data['department'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['position_list'] = (array('' => 'Select Position') + $this->employees->get_positions());
        $data['reporting_manager_list'] = (array('' => 'Select Manager') + $this->employees->get_managers());
        $data['aprrover_list'] = (array('' => 'Select Aprrover') + $this->employees->get_managers());
        $data['emp_status'] = (array('' => 'Select Employment Status') + $this->employment_status->dropdown('emp_status'));
        $data['priority'] = (array('' => 'Select Prority') + $this->priority->dropdown('title'));
        $data['opening_status'] = array('0' => 'On going', '1' => 'Hold', '2' => 'Close');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        $dataHeader['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);

        $dataHeader['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
        $dataHeader['notification'] = $this->notification->get_by_id($dataHeader['user_summary']['department_id'], $dataHeader['user_summary']['emprole']);

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_managecandidates', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function generate_requsition_id() {
        $curId = $this->requisition->get_last_id();
        $new_var = (int) substr($curId->req_code, 4, strpos($curId->req_code, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'REQ-00' . $new_id;
        else if ($new_id >= 9 && $new_id <= 99)
            return 'REQ-0' . $new_id;
        else
            return 'REQ-' . $new_id;
    }

    function addd_feedback() {
        var_dump($_POST);
    }

    function add_opening() {
        $this->processForm('add');
    }

    /**
     * User Edit
     *
     * @id      int     id
     * @return void
     */
    function edit_opening($id = null) {
        $this->processForm('edit', $id);
    }

    function processForm($action = 'add', $id = null) {

        $data['action'] = $action;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        $this->data['action'] = $action;
//        $this->data['openings'] = null;
//        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
//            if ($action == 'edit' && $id == null) {
//                
//            } else if ($action == 'edit' && $id != null) {
//
//                $this->data['openings'] = $this->requisition->as_array()->get_by('id', $id);
//
//
//                if (empty($this->data['openings'])) {
//                    redirect('errors/404');
//                }
//            }//else not null
//        }

        $this->form_validation->set_rules('jobtitle', 'jobtitle', 'required');
        $this->form_validation->set_rules('req_no_positions', 'req_no_positions', 'required');
        $this->form_validation->set_rules('position_id', 'position_id', 'required');
        $this->form_validation->set_rules('department_id', 'department_id', 'required');
        $this->form_validation->set_rules('skills', 'skills', 'required');
//        $this->form_validation->set_rules('aprrover', 'aprrover', 'required');

        if ($this->form_validation->run() == true) {

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                //  var_dump($_POST);die;

                $update_id = $this->input->post('id');

                $input_date = preg_replace('/[.,]/', '', $this->input->post('close_date'));

                $DataJobOpening = array(
                    'req_code' => $this->input->post('req_code'),
                    'close_date' => date('d/m/Y H:i:s', strtotime($input_date)),
                    'position_id' => $this->input->post('position_id'),
                    'reporting_id' => $this->input->post('reporting_manager'),
                    'department_id' => $this->input->post('department_id'),
                    'jobtitle' => $this->input->post('jobtitle'),
                    'req_no_positions' => $this->input->post('req_no_positions'),
                    // 'selected_members' => $this->input->post('SelectedMemebers'),
                    // 'filled_positions' => $this->input->post('FilledPosition'),
                    'jobdescription' => $this->input->post('description'),
                    'req_skills' => $this->input->post('skills'),
                    'req_qualification' => $this->input->post('qualification'),
                    'req_exp_years_from' => $this->input->post('yearsFrom'),
                    'req_exp_years_to' => $this->input->post('yesrsTo'),
                    'emp_type' => $this->input->post('emp_status_id'),
                    'req_priority' => $this->input->post('emp_priority_id'),
                    // 'opening_status'  => $this->input->post('opening_status'),
                    'approver' => $this->input->post('approver'),
                    'post_by' => $user_id,
                    'client_interview_status' => $this->input->post('client_interview'),
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:i:s'),
                );
                if ($action == 'add') {
                    $insertAssoId = $this->requisition->insert($DataJobOpening);
                    //  echo $this->db->last_query();die;
                    $this->session->set_flashdata('msg', 'Opening added successfully.');
                    redirect('manager/activity');
                } else {

                    $insertAssoId = $this->requisition->update($update_id, $DataJobOpening);
                    //   echo $this->db->last_query();die;
                    $this->session->set_flashdata('msg', 'Opening updated successfully.');
                    redirect('manager/activity');
                }
            }
        } else {

            $this->session->set_flashdata('errors', validation_errors());
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $this->data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


    }
    
     function add_feedback() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $feedbackData = array(
                'interviewer_rating' => $this->input->post('interviewer_rating'),
                'interviewer_comments' => $this->input->post('interviewer_comment'),
                'interview_round_completed' => $this->input->post('interview_round_number')
            );

            $interview_round_number = $this->input->post('interview_round_number');
            $candidate_id = $this->input->post('candidate_id');
            $interviewer_id = $this->session->userdata('user_id');
        }
        $this->interviewrounddetails->add_feedback($interviewer_id, $candidate_id, $interview_round_number, $feedbackData);

        redirect('manage/interview/');
    }

    function getPositionName() {

        if (isset($_POST['jobtitle_id'])) {
//             echo $_POST['jobtitle_id'];

            $jobtitle_id = $_POST['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
//            echo $this->db->last_query();
//            var_dump($jobtitle);die;
            $st = '<option value="">Select Position</option>';
            foreach ($jobtitle as $title) {

                $st .= '<option value="' . $title['position_id'] . '">' . $title['positioname'] . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getReportingManager() {
        if (isset($_POST)) {

            $department_id = $_POST['department_id'];

            $rep_manager = $this->employeesummary->get_all_rep_mang_by_dept_id($department_id);
            $st = '<option value="">Select Manager</option>';
            foreach ($rep_manager as $title) {
                $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getJobTitle() {

        if (isset($_POST)) {

            //  echo '<pre>', print_r($_POST);die;
            $job_code = $_POST['job_code'];


            $job_title = $this->jobTitle->get_JobTitleById($job_code);
            $st = '';
            // foreach ($job_title as $title) {
//                  var_dump($job_title);die;
            $st .= '<option value="' . $job_title->id . '">' . $job_title->jobtitlename . '</option>';
            // }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

}
