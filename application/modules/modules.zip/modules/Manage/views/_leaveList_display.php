<?php $this->load->view('leave/edit_leaveType'); ?> 
<div class="tab-content">   
    <div role="tabpanel" class="tab-pane active" id="<?php echo $cur_year ?>">
        <div class="heading">
            Leave List <?php echo $cur_year ?>        
            <?php if ($publish_status == 1) { ?>
                <a class="pull-right" data-toggle="modal" href="<?php echo base_url(); ?>leave/publish_leaveList/<?php echo $cur_year ?>">  
                    <i class="fa fa-remove text-white font-size-18" title="Click here for Publish"></i>
                </a>
            <?php } else {
                ?>
                <a class="pull-right" data-toggle="modal" href="<?php echo base_url(); ?>leave/publish_leaveList/<?php echo $cur_year ?>"> 
                    <i class="fa fa-check text-white font-size-18" title="Already Published"></i>
                </a>
            <?php } ?>
        </div>
        <div class="tab-data user-back-slim">                               
            <table class="table table-responsive">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Code</th>
                        <th>Alloted</th>
                        <th>Delete</th>
                        <th>Edit</th>                                                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($leaveType_list as $list) { ?>
                        <tr id="deleteLeaveRow_<?php echo $list['id'] ?>">
                            <td><?php echo $list['leavetype']; ?></td>
                            <td> <?php echo $list['leavecode'] . '<br>'; ?></td>
                            <td><?php echo $list['leavepreallocated'] . '<br>'; ?></td>
                            <td>
                                <i class="fa fa-trash text-ccc " onclick="deleteLeaveDiv(<?php echo $list['id'] ?>);"></i>
                            </td>
                            <td><a data-toggle="modal" href="#edit-leave-Modal-<?php echo $list['id'] ?>">  
                                    <i class="fa fa-pencil text-ccc "></i>
                                </a>
                            </td>
                        </tr>

                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div> 
</div>
<script>
    function deleteLeaveDiv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            $('#deleteLeaveRow_' + dId).remove();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>leave/delete_leaveType',
                data: {'delete_id': dId},
                success: function (data) {
                    showSuccess("Record deleted successfully");
                }
            });
            return false;
        }
    }
</script>
