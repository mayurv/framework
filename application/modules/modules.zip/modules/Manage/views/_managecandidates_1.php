<?php if (isset($candidates)) { ?>
    <div class="row">
        <div class="col-sm-12 white-bg">
            <div class="table-responsive">
                <table class="table margin-bottom-0">
                    <thead>
                        <tr>
                            <th>Associate Name</th>
                            <th>Education</th>
                            <th>Interview Time</th>
                            <th>Comment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($candidates as $listData) { ?>   
                            <tr>

                                <td>
                                    <p><?php echo $listData['candidate_name'] ?></p>
                                    <p class="text-light-gray"><?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</p>
                                </td>
                                <td><?php echo $listData['education_summary'] ?></td>
                                <td>
                                    <p><span class="clr-999">Schedule on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span></p>
                                    <p><?php echo ($listData['interview_time']) ?> <?php echo ($listData['interview_mode']) ?></p>
                                </td>
                                <td>
                                    <p>
                                        <?php echo $listData['schedule_comment'] ?>                              </p>
                                </td>
                                <td>
                                    <span class="leave-app-ac-icon">
                                        <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>">Feedback</a>
                                    </span>

                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>


<?php } ?>
<?php foreach ($candidates as $listData) { ?>  
    <div class="modal fade" id="recruitment-feedback_<?php echo $listData['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-500">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Feedback</h4>
                </div>
                <div class="modal-body">
                    <div class="user-modal-slim">
                        <?php echo form_open('manage/add_feedback/', array('id' => 'interview_feedback_id', 'class' => 'interview_feedback_id form-horizontal')); ?> 

                        <div class="form-group">
                            <label for="name" class="col-sm-4 control-label"> 
                                <?php echo $listData['candidate_name'] ?>
                                <small class="text44-ccc"><?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</small>
                            </label>
                            <label for="name" class="col-sm-4 control-label">Round - <?php echo $listData['interview_round_number'] ?>   <?php echo $listData['interview_mode'] ?> </label>
                            <label for="name" class="col-sm-4 control-label">Interview Date: <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></label>
                        </div> 



                        <div class="form-group">
                            <div class="col-sm-6">                                          

                                <?php echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating', 'class' => 'control-label')); ?>                            
                            </div>
                            <div class="col-sm-6"> 
                                <?php
                                echo form_input(array(
                                    'name' => 'interviewer_rating',
                                    'id' => 'interviewer_rating',
                                    'class' => 'form-control',
                                    'placeholder' => 'Average Rating out of 10',
                                    'type' => 'text',
                                    'data-error' => '.feedback1',
                                ));
                                ?> 
                                <div class="input-field">  
                                    <div class="feedback1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-6">
                                <?php echo form_label(lang('interviewer_comment'), 'interviewer_comment', array('for' => 'interviewer_comment', 'class' => 'control-label')); ?>                            
                            </div> 
                            <div class="col-sm-6">
                                <?php
                                echo form_textarea(array(
                                    'name' => 'interviewer_comment',
                                    'id' => 'interviewer_comment',
                                    'class' => 'form-control',
                                    'placeholder' => 'Comment',
                                    'type' => 'text',
                                    'data-error' => '.feedback2',
                                    'rows' =>'3'
                                ));
                                ?> 
                                <div class="input-field">
                                    <div class="feedback2"></div>
                                </div> 
                            </div> 
                        </div>

                        <div class="form-group">
                            <div class="col-sm-12 text-right padding-top-10">
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                <!--onclick="return validate_feedback_form(<?php // echo $listData['id'] ?>)"-->
                                <button type="button" class="btn btn-warning2 btn-sm" id="id_feedback">Submit</button>
                            </div>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>
   
<?php } ?>
 <script>
    $('#id_feedback').click(function () {
        var res = $("#interview_feedback_id").valid();
        alert('test');
//        return false;
        
//                        if ($("#interview_feedback_id").valid())

                    });
    </script>
