<?php if (isset($candidates)) { ?>
    <div class="row">
        <div class="col-sm-12 white-bg">
            <div class="table-responsive">
                <table class="table margin-bottom-0">
                    <thead>
                        <tr>
                            <th>Associate Name</th>
                            <th>Education</th>
                             <th>Round Number</th>
                            <th>Interview Time</th>
                            <th>Comment</th>
                            <th>CV</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($candidates as $listData) { ?>   
                            <tr>

                                <td>
                                    <p><?php echo $listData['candidate_name'] ?></p>
                                    <p class="text-light-gray"><?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</p>
                                </td>
                                <td>
                                    <?php echo $listData['qualification'] ?>
                                    <p class="text-light-gray"><?php echo $listData['skillset'] ?></p>
                                </td>
                                
                                 <td>
                                    <p> Interview - 
                                        <?php echo $listData['interview_round_number'] ?>  </p>                            </p>
                                </td>
                                
                                <td>
                                    <p><span class="clr-999">Schedule on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span></p>
                                    <p><?php echo ($listData['interview_time']) ?> <?php echo ($listData['interview_mode']) ?></p>
                                </td>
                                <td>
                                    <p>
                                        <?php echo $listData['schedule_comment'] ?>                              </p>
                                </td>

                                <td>
                                    <p>
                                        <a class="fa fa-download text-ccc" href="<?php echo base_url(); ?>assets/uploads/<?php echo $listData['user_cv'] ?> " download> </a>
                                    </p>
                                </td>
                                <td>
                                    <span class="leave-app-ac-icon">
                                        <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>">Feedback</a>
                                    </span>

                                </td>
                            </tr>
                            
                             <div class="modal fade" id="recruitment-feedback_<?php echo $listData['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Feedback</h4>
                </div>
                <div class="modal-body">
                    <div class="user-normal-slim">
                        <?php echo form_open('manage/add_feedback/', array('id' => 'interview_feedback_id', 'class' => 'interview_feedback_id')); ?> 
                        <div class="row">
                            <div class="col-sm-12"> 
                                <p>
                                    <span class="font-size-15"><?php echo $listData['candidate_name'] ?> </span>
                                    <span><small class="text-light-gray"> <?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</small></span>
                                </p>
                            </div>
                            <!--                                <div class="col-sm-12">
                                                                <p><span class="">Interview Round</span> <?php echo $listData['interview_round_number'] ?> | 
                                                                    <span class="text-light-gray"><?php echo $listData['interview_mode'] ?></span>
                                                                </p>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <p class="">Interview Date: <span class="text-light-gray"><?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span> </p>
                                                            </div>-->
                            <div class="clearfix"></div>
                            <div class="margin-bottom-20"></div>
                            <div class="col-sm-12">                                          
                                <div class="input-field">                                        
                                    <?php echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'interviewer_rating',
                                        'id' => 'interviewer_rating',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Average Rating out of 10',
                                        'data-error' => '.feedback1',
                                    ));
                                    ?> 
                                    <div class="feedback1"></div>


                                    <div class="errorTxt107"></div>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <?php echo form_label(lang('interviewer_comment'), 'interviewer_comment', array('for' => 'interviewer_comment')); ?>                            <?php
                                    echo form_textarea(array(
                                        'name' => 'interviewer_comment',
                                        'id' => 'interviewer_comment',
                                        'class' => 'browser-default materialize-textarea',
                                        'placeholder' => 'Comment',
                                        'data-error' => '.feedback2',
                                    ));
                                    ?> 
                                    <div class="feedback2"></div>
                                </div>
                            </div>                                        
                            <div class="clearfix"></div>
                            <input type="hidden" name="interview_round_number" value="<?php echo $listData['interview_round_number'] ?>">
                            <input type="hidden" name="candidate_id" value="<?php echo $listData['candidate_id'] ?>">
                            <div class="col-sm-12 text-right padding-top-10">
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                <!--// onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"-->
                                <button type="submit"  class="btn btn-warning2 btn-sm">Submit</button>
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>
                            
                        <?php } ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>


<?php } ?>

<?php $this->load->view('_addfeedback');?>