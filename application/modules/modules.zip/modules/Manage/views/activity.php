<button class="btn btn-default btn-sm" data-toggle="modal" href="#addopening-1"><i class="fa fa-plus-circle"></i> Add Opening</button>

<?php  $this->load->view('_addOpening'); ?>
<?php   $this->load->view('_editOpening'); ?>

 <div class="main-bg all-padding-15">
        <div class="row">
            <div class="col-md-12">
                <?php foreach ($openings as $result) { 
                    
                ?>
                    <div class="col-lg-2 col-md-3 col-sm-4"> 
                        <div class="job-opening-bg">
                                 <?php if ($result['client_interview_status'] == 1) { ?>
                            <div class="lbl-position"><label class="label ">C</label></div>
                                   <?php } else { ?>
                                  <?php } ?>
                            <div class="close-right margin-top-5">
                                <i class="fa fa-trash text-ccc" title="Delete"></i>
                            </div>
                            <div class="media">
                                <h5 class="text-bold text-info text-center margin-bottom-0">
                                    <a id="editopening" href="#editopening-<?php echo $result['id']; ?>" data-toggle="modal" title="Opening For"><?php echo $result['jobtitlename']; ?></a>
                                  
                                   
                                </h5>
                                <p class="text-center">
                                    <small title="To Date"><?php echo $result['close_date']; ?></small>
                                </p>
                                <p class="text-center">                             
                                    <span title="Filled Position" style="cursor:pointer"><?php echo $result['filled_positions'] ?></span>
                                    /<span title="Required Position" style="cursor:pointer"><?php echo $result['req_no_positions'] ?></span>                                                  
                                </p>

                                <p class="text-center text-info">
                                    <a href="<?php echo base_url() ?>recruitment/screening/<?php echo $result['id']; ?>">Interview Procedure</a>
                                </p>
                                <p class="text-center">
                                    <label class="label label-warning">HOLD</label>
                                </p>
                                   <?php 
                                    $val = (100/$result['req_no_positions'])*$result['filled_positions'];                                    
                                    ?>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="<?php echo $result['filled_positions']  ?>" aria-valuemin="0" aria-valuemax="<?php  echo $result['req_no_positions'] ?>" style="width: <?php echo $val  ?>%; height: 30%; background-color: rgba(31, 181, 172, 1);"></div>

                                </div>                                                
                            </div>
                        </div>
                    </div> 
                
                
                <?php } ?>                
            </div>
           
        </div>
    </div>

<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
    </script>
    