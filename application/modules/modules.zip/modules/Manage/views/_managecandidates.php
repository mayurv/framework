<div class="main-bg all-padding-15 tab-data text-left">      
    <div class="row"> 
        <div class="col-sm-6">
            <h4>Candidate List</h4>
            <!--            <div id="idSort" class="left-float">
                            <i class="sort-data fa fa-sort-alpha-asc margin-top-15"><input type="hidden" value="asc" id="sortBy"></i>
                        </div>   
            
                        <div class="post-search-panel">
                            <input class="search-input" type="text" id="keywords" placeholder="Type keywords to filter Associate" onkeyup="searchFilter()"/>
                            <div class="search-i-bg" id="id_search"> 
                                <i class="fa fa-search text-light-gray"></i>
                            </div>             
                        </div>-->

        </div>        
    </div>
    <?php if (isset($candidates)) { ?>
        <div class="row"> 
            <div class="col-sm-12 tbl-padding-30">
                <div class="post-list" id="postList">

                    <table id="interviewer-list" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Associate Name</th>
                                <?php if ($user_summary['emprole'] == 4) { ?>
                                    <th>Job Title</th>
                                <?php } ?>
                                <th>Education</th>
                                <th>Round</th>
                                <th>Interview Time</th>
                                 <th>Interview Mode</th>
                                <th>Comment</th>
                                <th>CV</th>
                                <th>Actions/ Status</th>

                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Associate Name</th>
                                <?php if ($user_summary['emprole'] == 4) { ?>
                                    <th>Job Title</th>
                                <?php } ?>
                                <th>Education</th>
                                <th>Round</th>
                                <th>Interview Time</th>
                                <th>Interview Mode</th>
                                <th>Comment</th>
                                <th>CV</th>
                                <th>Actions/ Status</th>

                            </tr>
                        </tfoot>
                        <tbody>
                            <?php
                            foreach ($candidates as $listData) {
                                //var_dump($listData);
                                ?>   
                                <tr>

                                    <td>
                                        <p><a data-toggle="modal" href="#viewCandidateDetails_<?php echo $listData['id'] ?>"><?php echo $listData['candidate_name'] ?></a></p>
                                        <p class="text-light-gray"><?php echo $listData['years_exp'] ?>.<?php echo $listData['months_exp'] ?> years</p>
                                    </td>

                                    <?php if ($user_summary['emprole'] == 4) { ?>
                                        <td>
                                            <p><?php echo $listData['jobtitlename'] . '(' . $listData['deptname'] . ')'; ?></p>
                                        </td>
                                    <?php } ?>
                                    <td>
                                        <?php echo $listData['qualification'] ?>
                                        <p class="text-light-gray"><?php echo $listData['skillset'] ?></p>
                                    </td>

                                    <td>
                                        <p> Interview - 
                                            <?php echo $listData['interview_round_number'] ?>  </p>                            </p>
                                    </td>
                                    <td>
                                        <p><span class="clr-999">Schedule on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span></p>
                                        <p><?php echo date('h:i A', strtotime($listData['interview_time'])) ?> 
                                            
                                        </p>
                                    </td>
                                    <td>
                                        
                                         <span class="btn btn-default btn-xs">
                                            <?php //echo $listData['interview_mode'] ?>
                                             <i class="text-default  fa <?php echo ($listData['interview_mode'] == 'Telephonic' ? 'fa-phone-square' : ($listData['interview_mode'] == 'Face to Face' ? "fa-handshake-o" : ($listData['interview_mode'] == 'Skype' ? "fa-skype" : ""))); ?>"> </i> <?php echo ($listData['interview_mode']) ?> </span>
                                    </td>
                                    <td width="25%">
                                        <p>
                                            <?php echo $listData['schedule_comment'] ?>                              </p>
                                    </td>


                                    <td>
                                        <p>
                                            <a class="fa fa-download text-ccc" href="<?php echo base_url(); ?>assets/uploads/<?php echo $listData['user_cv'] ?> " download> </a>
                                        </p>
                                    </td>

                                    <td>
                                        <?php if (isset($listData['reschedule_details']) && !empty($listData['reschedule_details'])) { ?>
                                            <?php // var_dump($listData);die;?>
                                            <span class="leave-app-ac-icon">
                                                <span class="text-light-gray">Reschedule</span>
                                            </span>

                                        <?php } else if ($listData['interview_round_completed'] == $listData['interview_round_number']) { ?>
                                            <span class="leave-app-ac-icon">
                                                <a data-toggle="modal" href="#recruitment-viewfeedback_<?php echo $listData['id'] ?>">View</a>
                                            </span>
                                        <?php } else { ?>
                                            <?php
                                            $currentDate = new DateTime();
                                            $currentDate = $currentDate->format('Y-m-d H:i:s');

                                            $scheduleDate = $listData['interview_date'] . ' ' . $listData['interview_time'];
                                            $scheduleDate = new DateTime($scheduleDate);
                                            $scheduleDate = $scheduleDate->format('Y-m-d H:i:s');
                                            ?>
                                            <?php if ($currentDate > $scheduleDate) { ?>
                                                <span class="leave-app-ac-icon">
                                                    <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>" title="Click Here To Give Feedback">Feedback</a>
                                                </span>
                                            <?php } else { ?>
                                                <span class="leave-app-ac-icon">
                                                    <a  class="text-info" title="Scheduled on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?>">Scheduled</a>
                                                </span>
                                            <?php } ?>

                                        <?php } ?>

                                    </td>
                                </tr>
                                <?php if (($listData['reschedule_id'] == 1)) { ?>
                                    <?php foreach ($listData['reschedule_details'] as $key => $res) { ?>
                                        <tr style="border-top: dotted #fff;">
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <p> Interview - 
                                                    <?php echo $res['res_interview_round_number'] ?>  </p>                            </p>
                                            </td>
                                            <td>
                                                <p><span class="clr-999">Re-Schedule on <?php echo date('d M Y', strtotime($res['res_interview_date'])) ?></span></p>
                                                <p><?php echo ($res['res_interview_time']) ?> <?php echo ($res['res_interview_mode']) ?></p>
                                            </td>
                                            <td>
                                                <p>
                                                    <?php echo $res['schedule_comment'] ?>   </p>
                                            </td>
                                            <td></td>
                                            <td>
                                                <?php
                                                $count = count($listData['reschedule_details']);
                                                $id = $count - 1;
                                                if ($res['res_interview_round_completed'] == $res['res_interview_round_number']) {
                                                    ?>
                                                    <span class="leave-app-ac-icon">
                                                        <a data-toggle="modal" href="#recruitment-viewfeedback_<?php echo $listData['id'] ?>">View</a>
                                                    </span>
                                                <?php } else if ($key == $id) {
                                                    ?>
                                                    <?php
                                                    $currentDate = new DateTime();
                                                    $currentDate = $currentDate->format('Y-m-d H:i:s');

                                                    $rescheduleDate = $res['res_interview_date'] . ' ' . $res['res_interview_time'];
                                                    $rescheduleDate = new DateTime($rescheduleDate);
                                                    $rescheduleDate = $rescheduleDate->format('Y-m-d H:i:s');
                                                    ?>
                                                    <?php if ($currentDate > $rescheduleDate) { ?>
                                                        <span class="leave-app-ac-icon">
                                                            <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>" title="Click Here To Give Feedback">Feedback</a>
                                                        </span>
                                                    <?php } else { ?>
                                                        <span class="leave-app-ac-icon">
                                                            <a  href="" class="text-info" title="Rescheduled on <?php echo date('d M Y', strtotime($res['res_interview_date'])) ?>">Rescheduled</a>
                                                        </span>
                                                    <?php } ?>

                                                <?php } else { ?>
                                                    <span class="leave-app-ac-icon">
                                                        <span class="text-light-gray">Reschedule</span>
                                                    </span>
                                                    <?php
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php } ?>
<?php $this->load->view('modal/addFeedback'); ?>
<?php $this->load->view('modal/viewFeedback'); ?>
<?php $this->load->view('modal/viewDetails'); ?>



<script>
    function searchFilter(page_num) {
        page_num = page_num ? page_num : 0;
        var keywords = $('#keywords').val();
        var sortBy = $('#sortBy').val();
//        var screening_id = this.href.substr(this.href.lastIndexOf('/') + 1);
//        alert(screening_id);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>manage/ajaxPaginationInterviewList/' + page_num,
            data: 'page=' + page_num + '&keywords=' + keywords + '&sortBy=' + sortBy,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#postList').html(html);
                $('.loading').fadeOut("slow");
            }
        });
    }
</script>

<script>
    $(document).ready(function () {
        $(".sort-data").click(function () {
            $('.sort-data').toggleClass('fa-sort-alpha-desc text-info');
            if ($('#sortBy').val() == 'asc')
                $('#sortBy').val('desc');
            else
                $('#sortBy').val('asc');
            searchFilter();

//            $('.sort-data').addClass('fa-sort-alpha-desc');
        });
    });
</script>