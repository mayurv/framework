<?php ?>
<!-- modal start -->
<?php
foreach ($openings as $result) {
    //var_dump($result);die;
    ?>
    <div class="modal fade" id="editopening-<?php echo $result['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Edit Opening</h4>
                </div>
                <div class="modal-body">
                    <div class="user-modal-slim"> 
                        <?php echo form_open('manager/edit_opening', array('id' => 'form_editOpening_id', 'class' => 'form_editOpening_id')); ?>
                        <?php
                        if ($result['client_interview_status'] == '1') {
                            $ch = "checked";
                            $chval = 1;
                        } else {
                            $ch = "";
                            $chval = 0;
                        }
                        ?>
                        <div class="row">
                            <div class="col-sm-12">
                          <?php
                                echo form_checkbox(array(
                                    'id' => 'client_interview'. $result['id'],
                                    'name' => 'client_interview',
                                    'style' => 'left: 0 !important; opacity: 0 !important;',
                                    'checked' => $ch,
                                    'value' => $chval,
                                ));
                                ?>
                                <?php echo form_label(lang('client_interview'), 'client_interview'. $result['id'], array('for' => 'client_interview', 'style' => 'font-size:12px !important')); ?>                                
                                <?php echo form_error('req_code'); ?>                          
                            </div>

                            <div class="clearfix"> </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_code'), 'req_code', array('for' => 'req_code')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'req_code',
                                        'name' => 'req_code',
                                        'placeholder' => 'Requisition Code',
                                        'class' => 'browser-default',
                                        'type' => 'text',
                                        'data-error' => '.addOpening1',
                                        'value' => set_value('req_code', $result['req_code']),
                                    ));
                                    ?>
                                    <div class="addOpening1"></div>                                    
                                    <?php echo form_error('req_code'); ?>   
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('close_date'), 'close_date', array('for' => 'close_date')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'close_date',
                                        'name' => 'close_date',
                                        'placeholder' => 'Close Date',
                                        'data-format' => 'yyyy-mm-dd',
                                        'class' => 'close_date',
                                        'data-error' => '.addOpening2',
                                        'value' => set_value('close_date', $result['close_date']),
                                    ));
                                    ?>   
                                    <div class="addOpening2"></div>                                
                                    <?php echo form_error('close_date'); ?> 
                                </div>                                        
                            </div>

                            <div class="clearfix"> </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('job_title'), 'job_title', array('for' => 'jobtitle')); ?>                                
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'jobtitle' . $result['id'],
                                    'name' => 'jobtitle',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening3'
                                        ), $job_code, set_value('jobtitle', $result['jobtitle']));
                                ?> 
                                <div class="input-field">
                                    <div class="addOpening3"></div>
                                    <?php echo form_error('jobtitle'); ?> 
                                </div>                                        
                            </div>
                            <?php // var_dump($result['position_id1']);die;?>
                            <div class="col-sm-6">
                                <?php echo form_label(lang('position_id'), 'position_id', array('for' => 'position_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'position_id' . $result['id'],
                                    'name' => 'position_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening4'
                                        ), $position_list, set_value('position_id', $result['position_id']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening4"></div>
                                    <?php echo form_error('position_id'); ?> 
                                </div>                                        
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('department_id'), 'department_id', array('for' => 'department_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'department_id' . $result['id'],
                                    'name' => 'department_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening5',
                                        ), $department, set_value('department_id', $result['department_id']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening5"></div>
                                    <?php echo form_error('department_id'); ?> 
                                </div>                  
                            </div>
                            <?php //var_dump($reporting_manager_list); ?>
                            <div class="col-sm-6">
                                <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'reporting_manager' . $result['id'],
                                    'name' => 'reporting_manager',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening50'
                                        ), $reporting_manager_list, set_value('reporting_id', $result['reporting_id']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening50"></div>
                                    <?php echo form_error('reporting_manager'); ?> 
                                </div>                    
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_no_positions'), 'req_no_positions', array('for' => 'req_no_positions')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'req_no_positions',
                                        'id' => 'req_no_positions',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Required Position',
                                        'type' => 'text',
                                        'data-error' => '.addOpening6',
                                        'value' => set_value('req_no_positions', $result['req_no_positions']),
                                    ));
                                    ?>                       
                                    <div class="addOpening6"></div>
                                    <?php echo form_error('req_no_positions'); ?>
                                </div>         
                            </div>    

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('jobdescription'), 'jobdescription', array('for' => 'description')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'description',
                                        'id' => 'description',
                                        'placeholder' => 'Job Description',
                                        'type' => 'text',
                                        'class' => 'browser-default',
                                        'data-error' => '.addOpening7',
                                        'value' => set_value('jobdescription', $result['jobdescription']),
                                    ));
                                    ?>
                                    <div class="addOpening7"></div>
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_skills'), 'req_skills', array('for' => 'skills')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'skills',
                                        'name' => 'skills',
                                        'type' => 'text',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Required Skills',
                                        'data-error' => '.addOpening8',
                                        'value' => set_value('req_skills', $result['req_skills']),
                                    ));
                                    ?>                    
                                    <div class="addOpening8"></div>
                                    <?php echo form_error('skills'); ?> 
                                </div>     
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_qualification'), 'req_qualification', array('for' => 'qualification')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'qualification',
                                        'id' => 'qualification',
                                        'type' => 'text',
                                        'placeholder' => 'Required qualification',
                                        'class' => 'browser-default',
                                        'data-error' => '.addOpening9',
                                        'value' => set_value('req_qualification', $result['req_qualification']),
                                    ));
                                    ?>
                                    <div class="addOpening9"></div>
                                    <?php echo form_error('req_qualification'); ?> 
                                </div>                    
                            </div>                                       
                            <div class="clearfix"></div>


                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('from'), 'from', array('for' => 'yearsFrom')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'yearsFrom',
                                        'id' => 'yearsFrom',
                                        'type' => 'text',
                                        'placeholder' => 'From',
                                        'class' => 'browser-default',
                                        'data-error' => '.addOpening10',
                                        'value' => set_value('req_exp_years_from', $result['req_exp_years_from']),
                                    ));
                                    ?>
                                    <div class="addOpening10"></div>
                                    <?php echo form_error('req_exp_years_from'); ?> 
                                </div>                    
                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('to'), 'to', array('for' => 'yesrsTo')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'yesrsTo',
                                        'id' => 'yesrsTo',
                                        'type' => 'text',
                                        'placeholder' => 'To',
                                        'class' => 'browser-default',
                                        'data-error' => '.addOpening11',
                                        'value' => set_value('req_exp_years_to', $result['req_exp_years_to']),
                                    ));
                                    ?>
                                    <div class="addOpening11"></div>
                                    <?php echo form_error('req_exp_years_to'); ?> 
                                </div>                    
                            </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('for' => 'emp_status_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'emp_status_id',
                                    'name' => 'emp_status_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening12',
                                        ), $emp_status, set_value('emp_type', $result['emp_type']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening12"></div>
                                    <?php echo form_error('emp_type'); ?> 
                                </div>     
                            </div>
                            <div class="clearfix"></div>


                            <div class="col-sm-6">
                                <?php echo form_label(lang('emp_priority_id'), 'emp_priority_id', array('for' => 'emp_priority_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'emp_priority_id',
                                    'name' => 'emp_priority_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening13',
                                        ), $priority, set_value('req_priority', $result['req_priority']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening13"></div>
                                    <?php echo form_error('req_priority'); ?> 
                                </div>     
                            </div>


                            <div class="col-sm-6">
                                <?php echo form_label(lang('approver'), 'approver', array('for' => 'approver')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'approver' . $result['id'],
                                    'name' => 'approver',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening14',
                                        ), $aprrover_list, set_value('approver', $result['approver']));
                                ?>
                                <div class="input-field">
                                    <div class="addOpening14"></div>
                                    <?php echo form_error('approver1'); ?> 
                                </div>     
                            </div>

                            <div class="clearfix"></div>


                            <div class="col-sm-12 padding-top-10 text-right">
                                <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                            <input type="hidden" name="id" value="<?php echo $result['id'] ?>">
                        </div>
                        <?php echo form_close() ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>


    <!-- modal end -->
    <script type="text/javascript">

        //    $(window).on('load', function () {
        //        
        //       
        //        var jobtitle_id = $("#id_jobtitle").val();
        //        alert(jobtitle_id);
        //        $.ajax({
        //            type: "POST",
        //            url: '<?php //echo base_url();   ?>manager/getPositionName',
        //            data: {'jobtitle_id': jobtitle_id},
        //            success: function (data) {
        ////                alert(data.content);
        //                if (data) {
        //                    $('select[name="position_id1"]').html(data.content).trigger('liszt:updated').val(position_id1);
        //                    $('#position_id1').material_select();
        ////                    alert(data.content);
        //                }
        //            }
        //        });
        //    });
        //            onwindow load{
        //            $dept id =
        //                    getPosition(dept)
        //            }

        /* Date picker validation Fucntions */
        $(document).ready(function () {
            $(".close_date").click(function () {
                $('.close_date').pickadate({
                    selectYears: true,
                    selectMonths: true,
                });
            });
            $("#client_interview<?php echo $result['id'] ?>").click(function () {

                var isChecked = $("#client_interview<?php echo $result['id'] ?>").val();
                if (isChecked == 0) {

                    $("#client_interview<?php echo $result['id'] ?>").val('1');
                } else {

                    $("#client_interview<?php echo $result['id'] ?>").val('0');
                }

            });
        });
        /* Deopdown Functions */
        $('select[id="jobtitle<?php echo $result['id'] ?>"]').change(function () {
            var jobtitle = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getPositionName',
                data: {'jobtitle_id': jobtitle},
                success: function (data) {
                    if (data) {
                        $('select[id="position_id<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(position_id);
                        $("#position_id<?php echo $result['id'] ?>").val($("#position_id<?php echo $result['id'] ?> option:first").val());
                    }
                }
            });
        });

        $('select[id="department_id<?php echo $result['id'] ?>"]').change(function () {
            var department_id = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getReportingManager',
                data: {'department_id': department_id},
                success: function (data) {
                    $('select[id="reporting_manager<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $('#reporting_manager<?php echo $result['id'] ?>').material_select();
                    $("#reporting_manager<?php echo $result['id'] ?>").val($("#reporting_manager<?php echo $result['id'] ?> option:first").val());
                    $('select[id="approver<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $('#approver<?php echo $result['id'] ?>').material_select();
                    $("#approver<?php echo $result['id'] ?>").val($("#approver<?php echo $result['id'] ?> option:first").val());
                }
            });
        });
        //    $('select[name="jobtitle_id"]').change(function () {
        //        var jobtitle_id = $(this).val();
        //        $.ajax({
        //            type: "POST",
        //            url: '<?php echo base_url(); ?>manager/getPositionName',
        //            data: {'jobtitle_id': jobtitle_id},
        //            success: function (data) {
        //                if (data) {
        //                    $('select[name="position_id1"]').html(data.content).trigger('liszt:updated').val(position_id1);
        ////                    $('#position_id1').material_select();
        //                    $("#position_id1").val($("#position_id1 option:first").val());
        //                }
        //            }
        //        });
        //    });
        $('select[id="job_code<?php echo $result['id'] ?>"]').change(function () {
            var job_code = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getJobTitle',
                data: {'job_code': job_code},
                success: function (data) {
                    if (data) {
                        $('select[id="jobtitle_id<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(jobtitle_id);
                        $('#jobtitle_id<?php echo $result['id'] ?>').material_select();
                        $("#jobtitle_id<?php echo $result['id'] ?>").val($("#jobtitle_id<?php echo $result['id'] ?> option:first").val());
                    }
                }
            });
        });
    </script>   
<?php } ?>