<style>
    .timeline>li>.fa, .timeline>li>.glyphicon, .timeline>li>.ion {
        width: 45px;
        height: 45px;
        font-size: 10px;
        line-height: 45px;
        position: absolute;
        color: #666;
        background: #d2d6de;
        border-radius: 50%;
        text-align: center;
        left: 10px;
        top: 0;
    }
</style>
<?php
// var_dump($candidates); 
foreach ($candidates as $r => $result) {
    ?>  
    <!-- candidatetimeline modal -->
    <div class="modal fade" id="candidatetimeline_<?php echo $result['id'] ?>" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header all-padding-10">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                </div>
                <!-- modal body here --> 
                <div class="modal-body">  
                    <!-- modal slim scroll bar candidate-timeline-bg -->

                    <div class="candidate-timeline-bg">
                        <!-- row -->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- The time line -->
                                <div class="col-sm-6">   
                                    <ul class="timeline">

                                        <?php
                                        if (isset($result['firstround_details'])) {

                                            foreach ($result['firstround_details'] as $roundDetails) {
//var_dump($roundDetails); 
                                                ?>
                                                <?php //foreach ($candidate_firsttiemline as $r => $list) { ?>           

                                                <!-- timeline item interview_round_number -->
                                                <li>
                                                    <?php
                                                    if ($roundDetails['interview_round_number'] == 1)
                                                        $roundName = "Interview Round 1";

                                                    if ($roundDetails['interview_round_number'] == 2)
                                                        $roundName = "Interview Round 2";

                                                    if ($roundDetails['interview_round_number'] == 3)
                                                        $roundName = "Interview Round 3";

                                                    if ($roundDetails['interview_round_number'] == 4)
                                                        $roundName = "Client Round ";
                                                    ?>
                                                    <i class="fa bg-aqua">Round <?php echo $roundDetails['interview_round_number'] ?></i>
                                                  <!--<span class="label bg-blue text-center">Interview Round</span>-->

                                                    <div class="timeline-item">
                                                        <span class="time"><i class="fa fa-calendar"></i> 10 Feb. 2017</span>

                                                        <h3 class="timeline-header"><a href="#"></a> <?php echo $roundName ?></h3>
                                                        <div class="timeline-body">
                                                            <?php echo $roundDetails['schedule_comment'] ?>
                                                           
                                                        </div>                
                                                    </div>
                                                </li>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </ul>
                                </div>

                                <div class="col-sm-6">   
                                    <ul class="timeline">

                                        <?php
                                        if (isset($result['secondround_details'])) {

                                            foreach ($result['secondround_details'] as $roundDetails) {
//var_dump($roundDetails); 
                                                ?>
                                                <?php
                                                if ($roundDetails['interview_round_number'] == 5)
                                                    $roundName = "HR Round";

                                                if ($roundDetails['interview_round_number'] == 6)
                                                    $roundName = "OFFER";

                                                if ($roundDetails['interview_round_number'] == 7)
                                                    $roundName = "Joining";
                                                ?>
                                                <!-- timeline item -->
                                                <li>
                                                   <i class="fa bg-aqua">Round <?php echo $roundDetails['interview_round_number'] ?></i>

                                                    <div class="timeline-item">
                                                        <span class="time"><i class="fa fa-calendar"></i> 10 Feb. 2017</span>
                                                        <h3 class="timeline-header"><a href="#"></a> <?php echo $roundName ?></h3>
                                                        <div class="timeline-body">
                                                            <?php echo $roundDetails['schedule_comment'] ?>
                                                           
                                                        </div>                
                                                    </div>
                                                </li>
                                                <!-- END timeline item -->
                                                <?php
                                            }
                                        }
                                        ?>

                                    </ul>
                                </div>
                                <li>
                                    <i class="fa fa-clock-o bg-gray"></i>
                                </li>
                                </ul>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- modal slim scroll bar candidate-timeline-bg -->
                </div>     
            </div>      
        </div>
    </div>
    <!--candidatetimeline modal -->
<?php } ?>  
