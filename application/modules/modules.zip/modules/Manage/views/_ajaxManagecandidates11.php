 <table class="table margin-bottom-0">
                        <thead>
                            <tr>
                                <th>Associate Name</th>
                               <?php  if($user_summary['emprole'] == 4) {?>
                                <th>Job Title</th>
                               <?php }?>
                                <th>Education</th>
                                <th>Round</th>
                                <th>Interview Time</th>
                                <th>Comment</th>
                                <th>CV</th>
                                <th>Actions/ Status</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($candidates as $listData) {
                                //var_dump($listData);
                                ?>   
                                <tr>

                                    <td>
                                        <p><?php echo $listData['candidate_name'] ?></p>
                                        <p class="text-light-gray"><?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</p>
                                    </td>
                                    
                                     <?php if($user_summary['emprole'] == 4) {?>
                                    <td>
                                        <p><?php echo $listData['jobtitlename'].'('.$listData['deptname'].')'; ?></p>
                                    </td>
                               <?php }?>
                                    <td>
                                        <?php echo $listData['qualification'] ?>
                                        <p class="text-light-gray"><?php echo $listData['skillset'] ?></p>
                                    </td>
                                    <td>
                                        <p> Interview - 
                                            <?php echo $listData['interview_round_number'] ?>  </p>                            </p>
                                    </td>
                                    <td>
                                        <p><span class="clr-999">Schedule on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span></p>
                                        <p><?php echo ($listData['interview_time']) ?> <?php echo ($listData['interview_mode']) ?></p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $listData['schedule_comment'] ?>                              </p>
                                    </td>





                                    <td>
                                        <p>
                                            <a class="fa fa-download text-ccc" href="<?php echo base_url(); ?>assets/uploads/<?php echo $listData['user_cv'] ?> " download> </a>
                                        </p>
                                    </td>

                                    <td>
                                        <?php if (isset($listData['reschedule_details']) && !empty($listData['reschedule_details'])) { ?>
                                            <span class="leave-app-ac-icon">
                                                <span class="text-light-gray">Reschedule</span>
                                            </span>

                                        <?php } else if ($listData['interview_round_completed'] == $listData['interview_round_number']) { ?>
                                            <span class="leave-app-ac-icon">
                                                <a data-toggle="modal" href="#recruitment-viewfeedback_<?php echo $listData['id'] ?>">View</a>
                                            </span>
                                        <?php } else { ?>
                                            <span class="leave-app-ac-icon">
                                                <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>">Feedback</a>
                                            </span>
                                        <?php } ?>

                                    </td>
                                </tr>
                                <?php if (($listData['reschedule_id'] == 1) ) { ?>
                                 <?php foreach ($listData['reschedule_details'] as $key => $res) { ?>
                                        <tr style="border-top: dotted #fff;">
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <p> Interview - 
                                                    <?php echo $res['res_interview_round_number'] ?>  </p>                            </p>
                                            </td>
                                            <td>
                                                <p><span class="clr-999">Re-Schedule on <?php echo date('d M Y', strtotime($res['res_interview_date'])) ?></span></p>
                                                <p><?php echo ($res['res_interview_time']) ?> <?php echo ($res['res_interview_mode']) ?></p>
                                            </td>
                                            <td>
                                                <p>
                                                    <?php echo $res['schedule_comment'] ?>   </p>
                                            </td>
                                            <td></td>
                                            <td>
                                                <?php
                                                 $count = count($listData['reschedule_details']);
                                                $id = $count - 1;
                                                if ($res['res_interview_round_completed'] == $res['res_interview_round_number']) {
                                                    ?>
                                                    <span class="leave-app-ac-icon">
                                                        <a data-toggle="modal" href="#recruitment-viewfeedback_<?php echo $listData['id'] ?>">View</a>
                                                    </span>
                                                <?php } else if ($key == $id) {
                                                    ?>
                                                    <span class="leave-app-ac-icon">
                                                        <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>">Feedback</a>
                                                    </span>
                                                <?php } else  { ?>
                                                    <span class="leave-app-ac-icon">
                                                        <span class="text-light-gray">Reschedule</span>
                                                    </span>
                                                    <?php
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            <?php } ?>
                        </tbody>
                    </table>
<?php echo $this->ajax_pagination->create_links(); ?>

<?php foreach ($candidates as $listData) { ?>  
    <div class="modal fade" id="recruitment-feedback_<?php echo $listData['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Feedback</h4>
                </div>
                <div class="modal-body">
                    <div class="user-normal-slim">
                        <?php echo form_open('manage/add_feedback/', array('id' => 'interview_feedback_id' . $listData['id'], 'class' => 'interview_feedback_id')); ?> 
                        <div class="row">
                            <div class="col-sm-12"> 
                                <p>
                                    <span class="font-size-15"><?php echo $listData['candidate_name'] ?> </span>
                                    <span><small class="text-light-gray"> <?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</small></span>
                                </p>
                            </div>
                            <!--                                <div class="col-sm-12">
                                                                <p><span class="">Interview Round</span> <?php echo $listData['interview_round_number'] ?> | 
                                                                    <span class="text-light-gray"><?php echo $listData['interview_mode'] ?></span>
                                                                </p>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <p class="">Interview Date: <span class="text-light-gray"><?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span> </p>
                                                            </div>-->
                            <div class="clearfix"></div>
                            <div class="margin-bottom-20"></div>
                            <div class="col-sm-12">                                          
                                <div class="input-field">                                        
                                    <?php echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'interviewer_rating',
                                        'id' => 'interviewer_rating',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Average Rating out of 10',
                                        'data-error' => '.feedback1',
                                    ));
                                    ?> 
                                    <div class="feedback1"></div>


                                    <div class="errorTxt107"></div>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <?php echo form_label(lang('interviewer_comment'), 'interviewer_comment', array('for' => 'interviewer_comment')); ?>                            <?php
                                    echo form_textarea(array(
                                        'name' => 'interviewer_comment',
                                        'id' => 'interviewer_comment',
                                        'class' => 'browser-default materialize-textarea',
                                        'placeholder' => 'Comment',
                                        'data-error' => '.feedback2',
                                    ));
                                    ?> 
                                    <div class="feedback2"></div>
                                </div>
                            </div>                                        
                            <div class="clearfix"></div>
                            <input type="hidden" name="interview_round_number" value="<?php echo $listData['interview_round_number'] ?>">
                            <input type="hidden" name="candidate_id" value="<?php echo $listData['candidate_id'] ?>">
                            <div class="col-sm-12 text-right padding-top-10">
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                <!--// onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"-->
                                <button type="submit" onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>

<?php } ?>


<?php
if (isset($candidates)) {
    foreach ($candidates as $listData) {
        ?>  
        <div class="modal fade" id="recruitment-viewfeedback_<?php echo $listData['id'] ?>" role="dialog">
            <div class="modal-dialog modal-sm">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $listData['candidate_name'] ?>
                            <small class="text-light-gray">Interview Round  <?php echo $listData['interview_round_completed'] ?></small>
                        </h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-normal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="col-sm-6 margin-bottom-10">
                                        <span class="text-light-gray">Mode :</span> 
                                        <span><?php echo $listData['interview_mode'] ?></span>
                                    </div>
                                    <div class="col-sm-6 margin-bottom-10">
        <!--                                    <span class="clr-999">Interview Taken on:</span>-->
                                        <small class="text-light-gray pull-right"><i class="fa fa-calendar-o"></i> <?php echo date('y F, y', strtotime($listData['interview_date'])) ?></small>
                                    </div>
                                    <div class="clearfix"></div>


                                    <div class="col-sm-12 margin-bottom-10 text-center">
                                        <?php
                                        $x = 1;
                                        $rating = (int) $listData['interviewer_rating'];
                                        ?>
                                        <?php while ($x <= 10) { ?>

                                            <?php if ($x <= $rating) { ?>  
                                                <i class="fa fa-star text-green"></i>
                                            <?php } else { ?>
                                                <i class="fa fa-star text-light-gray"></i>
                                            <?php } ?>
                                            <?php
                                            $x++;
                                        }
                                        ?>



                                        <small class="text-light-gray">(<?php echo $listData['interviewer_rating'] ?>/10)</small>

                                    </div>

                                    <!--                                <div class="col-sm-6 margin-bottom-10 ">
                                                                        <p class="pull-right"> Rating:<span><?php echo $listData['interviewer_rating'] ?><i class="fa fa-star text-yellow"></i></span></p>
                                                                    </div>-->

                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                        <label class="control-label clr-999">Comment</label>
                                        <p>
                                            <?php echo $listData['interviewer_comments'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>  

        <?php
    }
}
?>


