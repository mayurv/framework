<?php
if (isset($candidates)) {
    foreach ($candidates as $listData) {
        ?>  
        <div class="modal fade" id="recruitment-feedback_<?php echo $listData['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

                        <?php //echo  $listData['interview_round_number'] == '1' ? 'Interview 1' : (($listData['interview_round_number'] == '2' ? 'Interview 2') : ($listData['interview_round_number'] == '3' ? 'Interview 3') : ($listData['interview_round_number'] == '4' ? 'Client Interview ' ) : ($listData['interview_round_number'] == '5' ? 'HR Roaund') : ($listData['interview_round_number'] == '6' ? 'Offer' ) : ($listData['interview_round_number'] == '7' ? 'Joining')) ; ?>
                        <?php //echo $listData['interview_round_number'] == '4' ? 'Client' : ($listData['interview_round_number'] == '5' ? 'HR' : $listData['interview_round_number'] == '6' ? 'HR' $blah);     ?>
                        <h4 class="modal-title">Feedback <?php echo $listData['interview_round_number'] == '1' ? 'Interview 1' : ($listData['interview_round_number'] == '2' ? 'Interview 2' : ($listData['interview_round_number'] == '3' ? 'Interview 3' : ($listData['interview_round_number'] == '4' ? 'Client Interview ' : ($listData['interview_round_number'] == '5' ? 'HR Roaund' : ($listData['interview_round_number'] == '6' ? 'Offer' : ($listData['interview_round_number'] == '7' ? 'Joining' : '')))))) ?></h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-modal-slim">
                            <?php echo form_open('manage/add_feedback/', array('id' => 'interview_feedback_id' . $listData['id'], 'class' => 'interview_feedback_id')); ?> 
                            <div class="row">
                                <div class="col-sm-12"> 
                                    <p>
                                        <span class="font-size-15"><?php echo $listData['candidate_name'] ?> </span>
                                        <span><small class="text-light-gray"> <?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</small></span>
                                    </p>
                                </div>
                                <!--                                <div class="col-sm-12">
                                                                    <p><span class="">Interview Round</span> <?php echo $listData['interview_round_number'] ?> | 
                                                                        <span class="text-light-gray"><?php echo $listData['interview_mode'] ?></span>
                                                                    </p>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <p class="">Interview Date: <span class="text-light-gray"><?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span> </p>
                                                                </div>-->
                                <div class="clearfix"></div>
                                <div class="margin-bottom-20"></div>

                                <?php if ($listData['interview_round_number'] == 5) { ?>

                                <?php } else { ?>

                                    <div class="skillRating">
                                        <?php
//                                                               var_dump($listData['skill_set']);
                                        $resultstr = array();
                                        foreach ($listData['skill_set'] as $skilldata) {
                                            ?>
                                            <?php if ($skilldata != '') { ?>
                                                <?php $resultstr[$skilldata] = $skills_list[$skilldata];
                                                ?>                                  
                                            <?php } ?>
                                        <?php }
                                        ?>

                                        <div class="col-sm-12">
                                            <table class="table table-responsive table-bordered">
                                                <thead>
                                                <th>Skill Set</th>
                                                <th>Rating</th>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($resultstr as $skillId => $inputData) { ?>
                                                        <tr>
                                                            <td width="30%"><span class="btn btn-sm btn-primary margin-top-20"><?php echo $inputData ?></span></td>
                                                            <td  width="70%">
                                                                <!--<input type="number" max="10" min="0" value="" id="skill_rating_<?php echo $skillId ?>" data-error=".error-<?php echo $skillId ?>" name="skill_rating[<?php echo $skillId ?>]" placeholder="Give Rating out of 10" onchange="calculaterating('<?php echo $skillId ?>', '<?php echo $listData['id'] ?>')" value="0">-->
                                                                <input type="number" max="10" min="0" class="txt" data-error=".error-<?php echo $skillId ?>" placeholder="Give Rating out of 10" name="skill_rating[<?php echo $skillId ?>]" onchange="calculaterating('<?php echo $skillId ?>', '<?php echo $listData['id'] ?>')"  id="skill_rating_<?php echo $skillId ?>">
                                                                <div class="error-<?php echo $skillId ?>"></div>
                                                            </td>
                                                        </tr>


                                                    <?php } ?>
                                                        
                                                        <tr class="border-top">
                                                        <td class="text-bold font-size-15">
                                                            Average Rating
                                                        </td>
                                                        <td class="text-bold">
                                                            <div id="avg_<?php echo $listData['id'] ?>"></div>
                                                        </td>
                                                    </tr>
                                                <input id="last_sum_<?php echo $listData['id'] ?>" value="0" hidden >
                                                </tbody>
                                            </table>
                                        </div>

<!--                                        <div id="sum"></div> <br>-->
<!--                                        <div id="avg"></div>-->
                                    </div>

                                <?php } ?>

                                <?php if ($listData['interview_round_number'] == 5) { ?>

                                    <div class="col-sm-12">                                          
                                        <div class="input-field">                                        
                                            <?php echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating')); ?>                            <?php
                                            echo form_input(array(
                                                'name' => 'interviewer_rating',
                                                'id' => 'interviewer_rating_' . $listData['id'],
                                                'class' => 'browser-default',
                                                'placeholder' => 'Average Rating ',
                                                'data-error' => '.feedback1',
                                            ));
                                            ?> 
                                            <div class="feedback1"></div>


                                            <div class="errorTxt107"></div>
                                        </div>
                                    </div>

                                <?php } else { ?>

                                    <div class="col-sm-12">                                          
                                        <div class="input-field">                                        
                                            <?php // echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating'));  ?>                            <?php
                                            echo form_input(array(
                                                'type' => 'hidden',
                                                'name' => 'interviewer_rating',
                                                'id' => 'interviewer_rating_' . $listData['id'],
                                                'class' => 'browser-default',
                                                'placeholder' => 'Average Rating ',
                                                'data-error' => '.feedback1',
                                            ));
                                            ?> 
                                            <div class="feedback1"></div>


                                            <div class="errorTxt107"></div>
                                        </div>
                                    </div>
                                <?php } ?>



                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('interviewer_comment'), 'interviewer_comment', array('for' => 'interviewer_comment')); ?>                            <?php
                                        echo form_textarea(array(
                                            'name' => 'interviewer_comment',
                                            'id' => 'interviewer_comment',
                                            'class' => 'browser-default materialize-textarea',
                                            'placeholder' => 'Comment',
                                            'data-error' => '.feedback2',
                                        ));
                                        ?> 
                                        <div class="feedback2"></div>
                                    </div>
                                </div> 

                                <div class="col-sm-12">
                                    <label for="projectnm">Interview Status</label>
                                    <select class="browser-default"  id="feedback_status" name="feedback_status" data-error=".errorTxt2001">
                                        <option value="" disabled selected>Select Status</option>
                                        <option value="Selected">Selected</option>
                                        <option value="Reject">Reject</option>                                        
                                    </select>       
                                    <div class="input-field">
                                        <div class="errorTxt2001"></div>
                                    </div> 
                                </div>
                                <div class="clearfix"></div>
                                <input type="hidden" name="interview_round_number" value="<?php echo $listData['interview_round_number'] ?>">
                                <input type="hidden" name="candidate_id" value="<?php echo $listData['candidate_id'] ?>">
                                <div class="col-sm-12 text-right padding-top-10">
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                    <!--// onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"-->
                                    <button type="submit" onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>
                                </div>
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>                                                    
                </div>
            </div>
        </div>

        <?php
    }
}
?>

<!--<script>
    var current_val = 0;
    var last_sum = 0;
    var new_sum = 0;
    var avg = 0;
    function calculaterating(skill_id, feedback_id) {

        var validateReuslt = $("#interview_feedback_id" + feedback_id).valid();

        if ($("#interview_feedback_id" + feedback_id).valid()) {
            var total_skills = <?php echo count($resultstr); ?>;
            for (i = 1; i <= total_skills; i++) {
                new_sum += parseInt($("#skill_rating_" + skill_id).val());
               
            }
//             avg = (parseInt(new_sum)/total_skills);
             
            $("#last_sum_" + feedback_id).val(new_sum);

//            var total_skills = <?php echo count($resultstr); ?>;
//            current_val = $("#skill_rating_" + skill_id).val();
//            last_sum = $("#last_sum_" + feedback_id).val();
//            new_sum = parseInt(last_sum) + parseInt(current_val);
////        alert(new_sum);
//
//            $("#last_sum_" + feedback_id).val(new_sum);
////        current_val = parseInt(total_skills) / parseInt(new_sum);
//    alert($("#last_sum_" + feedback_id).val());
             avg = (parseInt($("#last_sum_" + feedback_id).val()) / (total_skills));
//            avg = (parseInt($("#last_sum_" + feedback_id).val()) / parseInt(total_skills));
        
            $("#interviewer_rating_" + feedback_id).val(Math.ceil(avg));
        } else {
            $("#skill_rating_" + skill_id).focus();
            return false;

        }
    }
</script>-->

<script type="text/javascript">
    var total_skills = <?php echo count($resultstr); ?>;
    $(document).ready(function () {
        $('.txt').each(function () {
//            $(this).keyup(function () {
//                calcSumAndAverage();
//            });
        });
    });

    function calculaterating(skill_id, feedback_id) {
        var validateReuslt = $("#interview_feedback_id" + feedback_id).valid();

        if ($("#interview_feedback_id" + feedback_id).valid()) {
            calcSumAndAverage(skill_id, feedback_id);
        }
        else {
            $("#skill_rating_" + skill_id).val('a');
            $("#skill_rating_" + skill_id).focus();
            return false;

        }
    }

    function calcSumAndAverage(skill_id, feedback_id) {

        var total = 0;
        var average = 0;
        $('.txt').each(function () {
            if (!isNaN(this.value) && this.value.length != 0) {
                total += parseFloat(this.value);
            }
        });

        if (!isNaN(total) && total != 0) {
            var txtboxes = total_skills;
            average = parseFloat(total) / txtboxes;
        }

        $('#sum').html(total);
//        $('#avg').html(average.toFixed());
        $('#avg_' + feedback_id).html(average.toFixed(1));
        $('#interviewer_rating_' + feedback_id).val(average.toFixed(1));
    }
</script>