<?php
if (isset($candidates)) {
    foreach ($candidates as $listData) {
        ?>  
        <div class="modal fade" id="recruitment-viewfeedback_<?php echo $listData['id'] ?>" role="dialog">
            <div class="modal-dialog modal-md">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $listData['candidate_name'] ?>
                            <small class="text-light-gray">Interview Round  <?php echo $listData['interview_round_completed'] ?></small>
                        </h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-normal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="col-sm-6 margin-bottom-10">
                                        <span class="text-light-gray">Mode :</span> 
                                        <span><?php echo $listData['interview_mode'] ?></span>
                                    </div>
                                    <div class="col-sm-6 margin-bottom-10">
        <!--                                    <span class="clr-999">Interview Taken on:</span>-->
                                        <small class="text-light-gray pull-right"><i class="fa fa-calendar-o"></i> <?php echo date('d F, Y', strtotime($listData['interview_date'])) ?></small>
                                    </div>
                                    <div class="clearfix"></div>

                                    <?php
                                    $resultstr = array();
                                    foreach ($listData['skill_rating'] as $k => $skilldata) {
                                        ?>
                                        <?php if ($skilldata != '') { ?>
                                            <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                            <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                        <?php } ?>
                                    <?php }
                                    ?>

                                    <table class="table table-responsive table-bordered">
                                        <thead>
                                        <th>Skill Set</th>
                                        <th>Rating</th>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($resultstr as $k => $inputData) {
                                                ?>
                                                <tr>
                                                    <td width="30%"><span class="btn btn-sm btn-primary "><?php echo $inputData['name'] ?></span></td>
                                                    <td width="70%"><span class="btn btn-sm btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                </tr>


                                            <?php } ?>
                                        <input id="last_sum_<?php echo $listData['id'] ?>" value="0" hidden >
                                        </tbody>
                                    </table>
                                    <div class="col-sm-12 margin-bottom-10 text-center">
                                        <?php
                                        $x = 1;
                                        $rating = (float) $listData['interviewer_rating'];
                                        ?>
                                        <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                            <i class="fa fa-star text-green"></i>
                                        <?php } ?>
                                        <?php if (strpos($rating, '.')) { ?>
                                            <i class="fa fa-star-half-full text-green"></i>
                                            <?php $x++;
                                        }
                                        ?>
                                        <?php while ($x <= 10) { ?>
                                            <i class="fa fa-star text-light-gray"></i>
                                            <?php $x++;
                                        }
                                        ?>

                                        <small class="text-light-gray">(<?php echo $listData['interviewer_rating'] ?>/10)</small>

                                    </div>

                                    <!--                                <div class="col-sm-6 margin-bottom-10 ">
                                                                        <p class="pull-right"> Rating:<span><?php echo $listData['interviewer_rating'] ?><i class="fa fa-star text-yellow"></i></span></p>
                                                                    </div>-->

                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                        <label class="control-label clr-999">Comment</label>
                                        <p>
        <?php echo $listData['interviewer_comments'] ?>
                                        </p>
                                    </div>

                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                        <!--                                        <label class="control-label clr-999">Status</label>-->
                                        <div class="pull-right">
                                            <?php if ($listData['round_status'] == 'FeedbackReject') { ?>
                                                <a class="btn btn-sm btn-danger">Rejected</a>
                                            <?php } else { ?>
                                                <a class="btn btn-sm btn-success">Selected </a>
        <?php } ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>  

        <?php
    }
}
?>