<div class="main-bg all-padding-15 tab-data text-left">     
    <div class="row"> 
        <div class="col-sm-6">
            <div id="idSort" class="left-float">
                <i class="sort-data fa fa-sort-alpha-asc margin-top-15"><input type="hidden" value="asc" id="sortBy"></i>
            </div>   

            <div class="post-search-panel">
                <input class="search-input" type="text" id="keywords" placeholder="Type keywords to filter Associate" onkeyup="searchFilter()"/>
                <div class="search-i-bg" id="id_search"> 
                    <i class="fa fa-search text-light-gray"></i>
                </div>             
            </div>

        </div>        
    </div>
    <?php if (isset($candidates)) { ?>
        <div class="row"> 
            <div class="col-sm-12 tbl-padding-30">
                <div class="post-list" id="postList">

                    <table class="table margin-bottom-0">
                        <thead>
                            <tr>
                                <th>Associate Name</th>
                                <th>Education</th>
                                <th>Round</th>
                                <th>Interview Time</th>
                                <th>Comment</th>
                                <th>CV</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($candidates as $listData) { ?>   
                                <tr>

                                    <td>
                                        <p><?php echo $listData['candidate_name'] ?></p>
                                        <p class="text-light-gray"><?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</p>
                                    </td>
                                    <td>
                                        <?php echo $listData['qualification'] ?>
                                        <p class="text-light-gray"><?php echo $listData['skillset'] ?></p>
                                    </td>
                                    <td>
                                        <p> Interview - 
                                            <?php echo $listData['interview_round_number'] ?>  </p>                            </p>
                                    </td>
                                    <td>
                                        <p><span class="clr-999">Schedule on <?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span></p>
                                        <p><?php echo ($listData['interview_time']) ?> <?php echo ($listData['interview_mode']) ?></p>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo $listData['schedule_comment'] ?>                              </p>
                                    </td>

                                    <td>
                                        <p>
                                            <a class="fa fa-download text-ccc" href="<?php echo base_url(); ?>assets/uploads/<?php echo $listData['user_cv'] ?> " download> </a>
                                        </p>
                                    </td>
                                    <td>
                                        <?php if ($listData['interview_round_completed'] != 0) { ?>
                                            <span class="leave-app-ac-icon">
                                                <a data-toggle="modal" href="#recruitment-viewfeedback_<?php echo $listData['id'] ?>">View</a>
                                            </span>
                                        <?php } else { ?>
                                            <span class="leave-app-ac-icon">
                                                <a data-toggle="modal" href="#recruitment-feedback_<?php echo $listData['id'] ?>">Feedback</a>
                                            </span>
                                        <?php } ?>

                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <?php echo $this->ajax_pagination->create_links(); ?>


                </div>
            </div>
        </div>
    </div>



<?php } ?>
<?php
if (isset($candidates)) {
    foreach ($candidates as $listData) {
        ?>  
        <div class="modal fade" id="recruitment-feedback_<?php echo $listData['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        
                        <?php  //echo  $listData['interview_round_number'] == '1' ? 'Interview 1' : (($listData['interview_round_number'] == '2' ? 'Interview 2') : ($listData['interview_round_number'] == '3' ? 'Interview 3') : ($listData['interview_round_number'] == '4' ? 'Client Interview ' ) : ($listData['interview_round_number'] == '5' ? 'HR Roaund') : ($listData['interview_round_number'] == '6' ? 'Offer' ) : ($listData['interview_round_number'] == '7' ? 'Joining')) ;?>
                        <?php //echo $listData['interview_round_number'] == '4' ? 'Client' : ($listData['interview_round_number'] == '5' ? 'HR' : $listData['interview_round_number'] == '6' ? 'HR' $blah); ?>
                        <h4 class="modal-title">Feedback <?php  echo  $listData['interview_round_number'] == '1' ? 'Interview 1' : ($listData['interview_round_number'] == '2' ? 'Interview 2' :  ($listData['interview_round_number'] == '3' ? 'Interview 3' :  ($listData['interview_round_number'] == '4' ? 'Client Interview ': ($listData['interview_round_number'] == '5' ? 'HR Roaund' : ($listData['interview_round_number'] == '6' ? 'Offer'  : ($listData['interview_round_number'] == '7' ? 'Joining' : ''))))))?></h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-normal-slim">
        <?php echo form_open('manage/add_feedback/', array('id' => 'interview_feedback_id' . $listData['id'], 'class' => 'interview_feedback_id')); ?> 
                            <div class="row">
                                <div class="col-sm-12"> 
                                    <p>
                                        <span class="font-size-15"><?php echo $listData['candidate_name'] ?> </span>
                                        <span><small class="text-light-gray"> <?php echo $listData['years_exp'] ?>years - <?php echo $listData['months_exp'] ?> months</small></span>
                                    </p>
                                </div>
                                <!--                                <div class="col-sm-12">
                                                                    <p><span class="">Interview Round</span> <?php echo $listData['interview_round_number'] ?> | 
                                                                        <span class="text-light-gray"><?php echo $listData['interview_mode'] ?></span>
                                                                    </p>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <p class="">Interview Date: <span class="text-light-gray"><?php echo date('d M Y', strtotime($listData['interview_date'])) ?></span> </p>
                                                                </div>-->
                                <div class="clearfix"></div>
                                <div class="margin-bottom-20"></div>
                                <div class="col-sm-12">                                          
                                    <div class="input-field">                                        
                                        <?php echo form_label(lang('interviewer_rating'), 'interviewer_rating', array('for' => 'interviewer_rating')); ?>                            <?php
                                        echo form_input(array(
                                            'name' => 'interviewer_rating',
                                            'id' => 'interviewer_rating',
                                            'class' => 'browser-default',
                                            'placeholder' => 'Average Rating out of 10',
                                            'data-error' => '.feedback1',
                                        ));
                                        ?> 
                                        <div class="feedback1"></div>


                                        <div class="errorTxt107"></div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('interviewer_comment'), 'interviewer_comment', array('for' => 'interviewer_comment')); ?>                            <?php
                                        echo form_textarea(array(
                                            'name' => 'interviewer_comment',
                                            'id' => 'interviewer_comment',
                                            'class' => 'browser-default materialize-textarea',
                                            'placeholder' => 'Comment',
                                            'data-error' => '.feedback2',
                                        ));
                                        ?> 
                                        <div class="feedback2"></div>
                                    </div>
                                </div>                                        
                                <div class="clearfix"></div>
                                <input type="hidden" name="interview_round_number" value="<?php echo $listData['interview_round_number'] ?>">
                                <input type="hidden" name="candidate_id" value="<?php echo $listData['candidate_id'] ?>">
                                <div class="col-sm-12 text-right padding-top-10">
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                    <!--// onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"-->
                                    <button type="submit" onclick="return validate_feedback_form(<?php echo $listData['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>
                                </div>
                            </div>
        <?php echo form_close(); ?>
                        </div>
                    </div>                                                    
                </div>
            </div>
        </div>

    <?php }
} ?>


<?php
if (isset($candidates)) {
    foreach ($candidates as $listData) {
        ?>  
        <div class="modal fade" id="recruitment-viewfeedback_<?php echo $listData['id'] ?>" role="dialog">
            <div class="modal-dialog modal-sm">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $listData['candidate_name'] ?>
                            <small class="text-light-gray">Interview Round  <?php echo $listData['interview_round_completed'] ?></small>
                        </h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-normal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="col-sm-6 margin-bottom-10">
                                        <span class="text-light-gray">Mode :</span> 
                                        <span><?php echo $listData['interview_mode'] ?></span>
                                    </div>
                                    <div class="col-sm-6 margin-bottom-10">
        <!--                                    <span class="clr-999">Interview Taken on:</span>-->
                                        <small class="text-light-gray pull-right"><i class="fa fa-calendar-o"></i> <?php echo date('y F, y', strtotime($listData['interview_date'])) ?></small>
                                    </div>
                                    <div class="clearfix"></div>


                                    <div class="col-sm-12 margin-bottom-10 text-center">
                                        <?php
                                        $x = 1;
                                        $rating = (int) $listData['interviewer_rating'];
                                        ?>
                                        <?php while ($x <= 10) { ?>

                                            <?php if ($x <= $rating) { ?>  
                                                <i class="fa fa-star text-green"></i>
                                            <?php } else { ?>
                                                <i class="fa fa-star text-light-gray"></i>
            <?php } ?>
            <?php $x++;
        }
        ?>



                                        <small class="text-light-gray">(<?php echo $listData['interviewer_rating'] ?>/10)</small>

                                    </div>

                                    <!--                                <div class="col-sm-6 margin-bottom-10 ">
                                                                        <p class="pull-right"> Rating:<span><?php echo $listData['interviewer_rating'] ?><i class="fa fa-star text-yellow"></i></span></p>
                                                                    </div>-->

                                    <div class="clearfix"></div>
                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                        <label class="control-label clr-999">Comment</label>
                                        <p>
        <?php echo $listData['interviewer_comments'] ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>  

    <?php }
} ?>

<script>
    function searchFilter(page_num) {
        page_num = page_num ? page_num : 0;
        var keywords = $('#keywords').val();
        var sortBy = $('#sortBy').val();
//        var screening_id = this.href.substr(this.href.lastIndexOf('/') + 1);
//        alert(screening_id);
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>manage/ajaxPaginationInterviewList/' + page_num,
            data: 'page=' + page_num + '&keywords=' + keywords + '&sortBy=' + sortBy,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#postList').html(html);
                $('.loading').fadeOut("slow");
            }
        });
    }
</script>

<script>
    $(document).ready(function () {
        $(".sort-data").click(function () {
            $('.sort-data').toggleClass('fa-sort-alpha-desc text-info');
            if ($('#sortBy').val() == 'asc')
                $('#sortBy').val('desc');
            else
                $('#sortBy').val('asc');
            searchFilter();

//            $('.sort-data').addClass('fa-sort-alpha-desc');
        });
    });
</script>

