<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   Events
 * @package    Events
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Events extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));

        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'timelinecomment',  'holidaydates', 'years', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));

        //Event
        $this->load->model(array('blogdetail', 'frontend/eventsmain', 'frontend/eventscomments', 'frontend/eventsgallery', 'frontend/eventsgallerylikes', 'frontend/notification'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('event_lang');
        $this->load->language('holiday_lang');

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('box_template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        else if (!$this->ion_auth->in_group('hr')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {


//        var_dump($this->session->userdata());die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['user_summary'] = NULL;
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();


        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        $data['aItems'] = $this->eventsmain->get_all();

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_gallery', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function gallery($event_id = NULL) {

//        var_dump($this->session->userdata());die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole']);

        $data['user_summary'] = NULL;
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        if (isset($event_id))
            $data['aItems'] = $this->eventsgallery->get_by_event_id($event_id);
//        var_dump($data['aItems']);die;

        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);

        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_events', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function photoAjax() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
//        var_dump($_POST);die;    
        if ($_POST['action'] == 'get_info' && (int) $_POST['id'] > 0) {

            // get photo info
            $iPid = (int) $_POST['id'];
            $event_id = (int) $_POST['event_id'];
            $aImageInfo = $this->eventsgallery->get_by_id($iPid);
//            echo $iPid;;die;
            // prepare last 10 comments
//            $sCommentsBlock = $this->eventscomments->getComments($iPid);
//              $data['event_d'] = $this->eventscomments->getComments($iPid);
            $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $data['event_detail'] = $this->eventsgallery->get_by_id($iPid);
            $data['event_comments'] = $this->eventscomments->get_by_id($iPid);
            $data['like_count'] = $this->eventsgallery->like_count($iPid);
            $data['isalready_like'] = $this->eventsgallerylikes->get_by_id($iPid, $user_id);
//            var_dump($data['isalready_like']);die;
            $sCommentsBlock = $this->load->view('_events_comment', $data, TRUE);


            $aItems = $this->eventscomments->getAll(); // get photos info
            // Prev & Next navigation
            $sNext = $sPrev = '';
//            echo $iPid;
            $iPrev = $this->eventsgallery->get_by_greater_id($iPid, $event_id);
            $iNext = $this->eventsgallery->get_by_less_id($iPid, $event_id);
//            var_dump($iPrev);die;
            $sPrevBtn = ($iPrev) ? '<div class="preview_prev" onclick="getPhotoPreviewAjx(\'' . $iPrev['id'] . ',' . $event_id . '\')"><i class="fa fa-chevron-left"></i></div>' : '';
            $sNextBtn = ($iNext) ? '<div class="preview_next" onclick="getPhotoPreviewAjx(\'' . $iNext['id'] . ',' . $event_id . '\')"><i class="fa fa-chevron-right"></i></div>' : '';
            $url = base_url() . 'assets/uploads/';
            echo json_encode(array(
                'data1' => '<img class="img-responsive" src="' . $url . $aImageInfo['imagepath'] . '">' . $sPrevBtn . $sNextBtn,
                'data2' => $sCommentsBlock,
            ));
            die;
        }
    }

    public function test() {
        $this->load->library("phpoffice");
        $this->phpoffice->set_template("Template.docx");
        $data = array(
            array(
                "field" => 'Value1',
                "value" => 'Hi whats up?'
            )
        );

        if (($file = $this->phpoffice->create_document($data)) !== false) {
            if (($res = $this->phpoffice->save_document("mynewdoc.docx", APPPATH . "/../documents/word")) == true) {
                services::debug("Ok");
            } else {
                services::debug("NoK");
            }
        } else {
            services::debug("Something went wrong");
        }
    }

    public function uploadEventsImg($param = NULL, $tags = null, $edit = null) {
//        var_dump($_POST);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);


        $imagepath = '';
        /* to add event */
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $param == 'add') {
            //echo 'here';die;

            $date = $this->input->post('event_date');
            $date = str_replace(',', '', $date);
            $event_date = date('Y-m-d H:m:s', strtotime($date));


            $eventData = array(
                'title' => $this->input->post('event_title'),
                'event_date' => $event_date,
                'when' => $event_date,
                'blog_id' => $event_blog_insert_id,
                'description' => $this->input->post('edescription'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:i:s'),
            );


            $insert_id = $this->eventsmain->insert($eventData);

            /* BLOG ENTRY */
            $postBlogDetail = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'description' => $this->input->post('edescription') . '<span class=""> <u> <a href="' . base_url() . 'events/gallery/' . $insert_id . '"> view event</a> </u></span>',
                'title' => '<span class="text-warning">Event > </span>' . $this->input->post('event_title'), //substr($this->input->post('blog_detail'), 0, 25)
                'publish_group_id' => '0', //FOR ALL DEPARTMENT
                'image_url' => '',
                'video_url' => '',
                'blog_post_type' => '1',
                'blog_category_id' => '7',//event category
                'blog_date' => date("F d, Y"),
                'blog_time' => date('Y-m-d H:i:s'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:i:s'),
            );

            $event_blog_insert_id = $this->blogdetail->insert($postBlogDetail);

            /* BLOG ENTRY */

            $eventDataB = array(
                'blog_id' => $event_blog_insert_id,
            );
            $this->eventsmain->update($insert_id, $eventDataB);

            /* NOTIFICATION ENTRY */
            $notificationDetails = array(
                'user_id' => $user_id,
//            'show_user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'blog_post_type' => '1',
                'is_common' => '0',
                'publish_status' => '7',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Added Events',
                'notification_icon' => 'fa-calendar text-primary',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'events',
            );
            $this->notification->insert($notificationDetails);
            /* NOTIFICATION ENTRY */

            echo json_encode(array('event_id' => $insert_id, 'event_blog_id' => $event_blog_insert_id));
            die;
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $param == NULL) {

            /* Upload Image */
            if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
                $event_id = $this->input->post('event_id');
                $targetDir = "uploads/";
                $fileName = $_FILES['file']['name'];
                $targetFile = $targetDir . $fileName;

                $fileExt = pathinfo($_FILES['file']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $fileParts = pathinfo($_FILES['file']['name']);
                $fileName = $_FILES['file']['name'];
                $tempFile = $_FILES['file']['tmp_name'];

                $uploded_file_path = $this->handleUploadEvents($event_id, $fileParts, $tempFile, $fileName);
                if ($uploded_file_path != '')
                    $imagepath = '/events/' . $event_id . '/' . $uploded_file_path;
            }

//            $eventData = array(
//                'title' => $this->input->post('e_title'),
//                'filename' => $imagepath,
//                'description' => $this->input->post('e_description'),
//                'createdby' => $user_id,
//                'createddate' => date('Y-m-d H:i:s'),
//            );
//            $insert_id = $this->eventsmain->insert($eventData);

            $eventGhalleryData = array(
                'event_id' => $this->input->post('event_id'),
                'imagepath' => $imagepath,
                'createdby' => $user_id,
                'createddate' => date('Y-m-d h:i:s'),
            );
            $this->eventsgallery->insert($eventGhalleryData);
            $event_id = $this->input->post('event_id');
            $eventData = array(
                'filename' => $imagepath,
                'createddate' => date('Y-m-d h:i:s'),
            );
            $event_blog_id = $this->input->post('event_blog_id');
            $eventBlogData = array('image_url' => $imagepath);

            $this->eventsmain->update($event_id, $eventData);
            $this->blogdetail->update($event_blog_id, $eventBlogData);

            echo json_encode(array('event_id' => $event_id));
            die;
        }

        //UPDATE EVENT ENTRY
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $param == 'event' && $edit == null) {

            $event_id = $this->input->post('event_id');
            $date = $this->input->post('event_date');
            $date = str_replace(',', '', $date);
            $event_date = date('Y-m-d H:m:s', strtotime($date));

            $eventData = array(
                'title' => $this->input->post('event_title'),
                'description' => $this->input->post('edescription'),
                'when' => $event_date,
                'event_date' => $event_date,
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d h:i:s'),
            );

            $this->eventsmain->update($event_id, $eventData);

            $data['event_detail'] = $this->eventsgallery->get_by_event_id($event_id);
//            var_dump($data['event_detail']);
            if (isset($tags))
                $comment_data = $this->load->view('_event_image_tags', $data, TRUE);
            else
                $comment_data = $this->load->view('_edit_events_images', $data, TRUE);

            if ($comment_data) {
                echo json_encode(array('comment_data' => $comment_data, 'count' => count($data['event_detail'])));
                die;
            }

//            
//            echo json_encode(array('event_id' => $event_id, 'event_details' => $data['event_detail']));
//            die;
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $param == 'event' && $edit != null) {

            $event_id = $this->input->post('event_id');
//            $date = $this->input->post('event_date');
//            $date = str_replace(',', '', $date);
//            $event_date = date('Y-m-d H:m:s', strtotime($date));
//
//            $eventData = array(
//                'title' => $this->input->post('event_title'),
//                'description' => $this->input->post('edescription'),
//                'when' => $event_date,
//                'event_date' => $event_date,
//                'modifiedby' => $user_id,
//                'modifieddate' => date('Y-m-d h:i:s'),
//            );
//
//            $this->eventsmain->update($event_id, $eventData);

            $data['event_detail'] = $this->eventsgallery->get_by_event_id($event_id);
//            var_dump($data['event_detail']);
            if (isset($tags))
                $comment_data = $this->load->view('_event_image_tags', $data, TRUE);
            else
                $comment_data = $this->load->view('_edit_events_images', $data, TRUE);

            if ($comment_data) {
                echo json_encode(array('comment_data' => $comment_data, 'count' => count($data['event_detail'])));
                die;
            }

//            
//            echo json_encode(array('event_id' => $event_id, 'event_details' => $data['event_detail']));
//            die;
        }
    }

    public function handleUploadEvents($event_id, $fileParts, $tempFile, $fileName) {

        $fileTypes = array('jpeg', 'png', 'jpg'); // File extensions

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $this->session->set_flashdata('msg', 'File type not supported.');
            echo json_encode(array('msg' => 'File type not supported.'));
            die;
            return false;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/events'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads/events/' . $event_id;

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $fileName = date('dmyHis') . '-events-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        //var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    public function addComments() {

//        var_dump($_POST);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');



        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dataComment = array(
                'user_id' => $user_id,
                'event_gallery_id' => $this->input->post('image_id'),
                'comment' => $this->input->post('comments'),
                'c_ip' => $this->input->ip_address(),
                'createddate' => date('Y-m-d h:i:s'),
            );

            $insertId = $this->eventscomments->insert($dataComment);
        }
        $event_id = $this->input->post('event_id');
        $event_gallery_id = $this->input->post('image_id');
//        $event_id = (int) $_POST['event_id'];
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
        $data['event_detail'] = $this->eventsgallery->get_by_id($event_id);
        $data['event_comments'] = $this->eventscomments->get_by_id($event_gallery_id);

        /* if request is ajax */
        $comment_data = $this->load->view('_events_comment_div', $data, TRUE);
//        echo $comment_data;
        if ($comment_data) {
            echo json_encode(array('comment_data' => $comment_data, 'count' => count($data['event_comments'])));
            die;
        }
    }

    public function like_image() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $gallery_id = $this->input->post('image_id');
            $islike = $this->input->post('isLike');

            if ($islike == 1) {
                $currentImageData = $this->eventsgallery->get_by_id($gallery_id);
                $liek_count = ((int) $currentImageData['like_count'] + 1);
                $likeData = array('like_count' => $liek_count);
                $this->eventsgallery->update($gallery_id, $likeData);

                $likeUserEntry = array(
                    'user_id' => $user_id,
                    'gallery_id' => $gallery_id,
                    'createddate' => date('Y-m-d h:i:s'),
                );
                $gallery_like_id = $this->eventsgallerylikes->insert($likeUserEntry);

//            var_dump($currentImageData);
            } else {
                /* update event like count */
                $currentImageData = $this->eventsgallery->get_by_id($gallery_id);
                $liek_count = ((int) $currentImageData['like_count'] - 1);
                $likeData = array('like_count' => $liek_count);
                $this->eventsgallery->update($gallery_id, $likeData);

                $gallery_like_id = $this->input->post('isalreadylikeid');

                $this->eventsgallerylikes->delete($gallery_like_id);
            }
            $currentImageData = $this->eventsgallery->get_by_id($gallery_id);
            if ($currentImageData) {
                echo json_encode(array('like_counts' => $currentImageData['like_count'], 'gallery_like_id' => $gallery_like_id));
                die;
            }
        }
    }

    public function delete_event() {
        $event_id = $this->input->post('event_id');
        $blog_id = $this->input->post('blog_id');

        $this->eventsmain->delete($event_id);
        $this->blogdetail->delete($blog_id);
        $this->timelinecomment->delete_by_blog_id($blog_id);

        $this->eventsgallery->delete($event_id);
        $this->eventsgallerylikes->delete_by_gallery($gallery_like_id);
        $this->eventscomments->delete_by_gallery($gallery_like_id);
        return true;
    }

    public function delete_gallery_image() {
        $gallery_id = $this->input->post('gallery_id');
        $this->eventsgallery->delete($gallery_id);
        $this->eventsgallerylikes->delete_by_gallery($gallery_id);
        $this->eventscomments->delete_by_gallery($gallery_id);
        return true;
    }

    public function deleteGallerComment() {
        $comment_id = $this->input->post('comment_id');
        $this->eventscomments->delete($comment_id);
        return true;
    }

    public function addTags($param = null) {
//        var_dump($_POST);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $param == 'add') {
            $tagsData = $this->input->post('input_');
//            var_dump($tagsData);

            foreach ($tagsData as $id => $tag) {
                $dataTags = array(
                    'tag' => $tag,
                );
                $this->eventsgallery->update($id, $dataTags);
            }
        }

        return true;
    }

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);

        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);

        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);

        /* Dashboard */


        return $data;
    }

}
