<?php // var_dump($aItems);die;     ?>
<?php $i=1;     ?>
<div class="row">
    <div class="col-sm-12 main-bg margin-top-4">
        <!-- 4 Column Portfolio -->
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-xs-12">
                        <h3 class="text-center">Event Gallery</h3>
                        <?php if ($user_summary['emprole'] == 4) { ?>
                            <div class="pull-right">
                                <button class="btn btn-default btn-sm" data-toggle="modal" href="#addgallery-1"><i class="fa fa-plus-circle"></i> Add Event</button>
                            </div>
                        <?php } ?>

                        <div class="filter-container isotopeFilters">
                            <ul class="list-inline filter">
                                <li class="active"><a href="#" data-filter="*">All </a><span>/</span></li>
                                <li><a href="#" data-filter=".year-2013">2013</a><span>/</span></li>
                                <li><a href="#" data-filter=".year-2014">2014</a><span>/</span></li>
                                <li><a href="#" data-filter=".year-2015">2015</a><span>/</span></li>
                                <li><a href="#" data-filter=".year-2016">2016</a><span>/</span></li>
                                <li><a href="#" data-filter=".year-2017">2017</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="portfolio-section port-col">
            <div class="container">
                <div class="row">
                    <div class="event-slim">
                    <div class="isotopeContainer">
                        <?php foreach ($aItems as $eventData) { ?>
                            <div id="event_<?php echo $eventData->id ?>">
                                <div class="col-sm-3 isotopeSelector year-<?php echo $eventData->when ?>">
                                    <article class="">

                                        <?php if ($user_summary['emprole'] == 4) { ?>
                                            <span class="pull-right" >
                                                <a title="Delete Event" data-toggle="modal" onclick="deleteEvent('<?php echo $eventData->id ?>','<?php echo $eventData->blog_id ?>')">  
                                                    <i class="fa fa-trash text-ccc margin-right-5"></i>
                                                </a>
                                                <a title="Edit Event" data-toggle="modal" href="#edit_event_<?php echo $eventData->id ?>">  
                                                    <i class="fa fa-pencil text-ccc"></i>
                                                </a>
                                            </span>
                                        <?php } ?>
                                        <figure>
                                            <?php if(isset($eventData->filename) && $eventData->filename!='') { ?>
                                            <img src="<?php echo base_url() ?>assets/uploads/<?php echo $eventData->filename ?>" alt="">
                                            <?php }else{ ?>
                                            <img src="<?php echo base_url() ?>assets/uploads/events/events-ic.jpg" alt="">
                                            <?php } ?>
                                            <div class="overlay-background">
                                                <div class="inner"></div>
                                            </div>
                                            <div class="overlay">
                                                <div class="inner-overlay">
                                                    <div class="inner-overlay-content with-icons" >
                                                        <!-- <a title="First Image" class="fancybox-pop" rel="portfolio-1" href="plugins/fb-gallery/images/portfolio/28.jpg"><i class="fa fa-search"></i></a> -->
                                                        <a title="View Event" href="<?php echo base_url() ?>events/gallery/<?php echo $eventData->id ?>"><i class="fa fa-link"></i></a>

                                                    </div>
                                                </div>
                                            </div>
                                        </figure>
                                        <div class="article-title"><a href="#">@ <?php echo $eventData->title ?></a>

                                        </div>
                                    </article>
                                </div>
                                <?php if($i==4){?>
                        <div class="clearfix"></div>
                        <?php $i=1;}?>
                            </div>
                        
                        <?php $i++;} ?>
                    </div>
                        </div>
                </div>
            </div>
        </section>
        <!-- /4 Column Portfolio -->

    </div> 

</div>
<?php $this->load->view('_add_events'); ?>
<?php $this->load->view('_edit_events'); ?>

<script>
    function deleteEvent(dId,bid) {

        if (confirm('Are you sure, you want to delete this?')) {

//        if()
            $("div").remove("#event_" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/delete_event',
                data: {'event_id': dId,'blog_id':bid},
                success: function (data) {
                    showSuccess('Event Deleted Successfully');
//                    var parsed = $.parseJSON(data);
//                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>
<script>
$(document).ready(function () {
    $('.event-slim').slimscroll({
            width: '100%',
            height: '350px',
            axis: 'both'
        });
        });
</script>