<?php

class CMyComments {

    // constructor
    function CMyComments() {
    }

    // return comments block
    function getComments($i) {
        // draw last 10 comments
        $sComments = '';
        $aComments = $GLOBALS['MySQL']->getAll("SELECT * FROM `s281_items_cmts` WHERE `c_item_id` = '{$i}' ORDER BY `c_when` DESC LIMIT 10");
        foreach ($aComments as $i => $aCmtsInfo) {
            $sWhen = date('F j, Y H:i', $aCmtsInfo['c_when']);
            $sComments .= <<<EOF
<div class="comment" id="{$aCmtsInfo['c_id']}">
    <p>Comment from {$aCmtsInfo['c_name']} <span>({$sWhen})</span>:</p>
    <p>{$aCmtsInfo['c_text']}</p>
</div>
EOF;
        }

        return <<<EOF
        
        <div class="comments" id="comments">
          <div class="row">
            <div class="col-sm-12 margin-bottom-5">
                <div class="pull-left">
                    <h4>Event Gallery</h4>
                </div>
                <div class="pull-right margin-top-10">
                    <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                    <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                </div>
            </div>

            <div class="clearfix"> </div>

            <div class="col-sm-12">
                <div class="comment-bg">
                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>
                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>
                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>

                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>
                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>
                  <div class="media">
                      <div class="media-left">
                        <img src="img_avatar1.png" class="media-object" style="width:30px">
                      </div>
                      <div class="media-body">
                        <h5 class="media-heading">Balram kamble 
                            <small><i class="fa fa-calendar"></i>&nbsp;21 Feb 2017</small>
                            <small><i class="fa fa-clock-o"></i>&nbsp;10:15 am</small>
                        </h5>
                        <small>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                        incididunt ut labore et dolore magna aliqua.</small>
                      </div>
                  </div>

                  <div id="comments_warning1" style="display:none">Don`t forget to fill both fields (Name and Comment)</div>
                  <div id="comments_warning2" style="display:none">You can't post more than one comment per 10 minutes (spam protection)</div>
                  <div id="comments_list">{$sComments}</div>
                </div>
            </div>

            <div class="clearfix"> </div>

            <div class="col-sm-12">
                <form role="form" onsubmit="return false;">   
                    <div class="form-group margin-bottom-0">
                        <textarea name="text" placeholder="Message" class="form-control" id="text"></textarea>

                        <button class="btn btn-info" onclick="submitComment({$i}); return false;">
                            <i class="fa fa-paper-plane"></i>
                        </button>

                    </div>                    
                </form>              
            </div>

          </div>
</div>

 <script type="text/javascript">
    $('.comment-bg').slimScroll({
    height: '370px'
});
 </script>

EOF;
    }

    function acceptComment() {
        $iItemId = (int)$_POST['id']; // prepare necessary information
        $sIp = $this->getVisitorIP();
        $sName = $GLOBALS['MySQL']->escape(strip_tags($_POST['name']));
        $sText = $GLOBALS['MySQL']->escape(strip_tags($_POST['text']));

        if ($sName && $sText) {
            // check - if there is any recent post from you or not
            $iOldId = $GLOBALS['MySQL']->getOne("SELECT `c_item_id` FROM `s281_items_cmts` WHERE `c_item_id` = '{$iItemId}' AND `c_ip` = '{$sIp}' AND `c_when` >= UNIX_TIMESTAMP() - 600 LIMIT 1");
            if (! $iOldId) {
                // if everything is fine - allow to add comment
                $GLOBALS['MySQL']->res("INSERT INTO `s281_items_cmts` SET `c_item_id` = '{$iItemId}', `c_ip` = '{$sIp}', `c_when` = UNIX_TIMESTAMP(), `c_name` = '{$sName}', `c_text` = '{$sText}'");
                $GLOBALS['MySQL']->res("UPDATE `s281_photos` SET `comments_count` = `comments_count` + 1 WHERE `id` = '{$iItemId}'");

                // and print out last 10 comments
                $sOut = '';
                $aComments = $GLOBALS['MySQL']->getAll("SELECT * FROM `s281_items_cmts` WHERE `c_item_id` = '{$iItemId}' ORDER BY `c_when` DESC LIMIT 10");
                foreach ($aComments as $i => $aCmtsInfo) {
                    $sWhen = date('F j, Y H:i', $aCmtsInfo['c_when']);
                    $sOut .= <<<EOF
<div class="comment" id="{$aCmtsInfo['c_id']}">
    <p>Comment from {$aCmtsInfo['c_name']} <span>({$sWhen})</span>:</p>
    <p>{$aCmtsInfo['c_text']}</p>
</div>
EOF;
                }
                return $sOut;
            }
        }
        return 1;
    }

    // get visitor IP
    function getVisitorIP() {
        $ip = "0.0.0.0";
        if( ( isset( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) && ( !empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif( ( isset( $_SERVER['HTTP_CLIENT_IP'])) && (!empty($_SERVER['HTTP_CLIENT_IP'] ) ) ) {
            $ip = explode(".",$_SERVER['HTTP_CLIENT_IP']);
            $ip = $ip[3].".".$ip[2].".".$ip[1].".".$ip[0];
        } elseif((!isset( $_SERVER['HTTP_X_FORWARDED_FOR'])) || (empty($_SERVER['HTTP_X_FORWARDED_FOR']))) {
            if ((!isset( $_SERVER['HTTP_CLIENT_IP'])) && (empty($_SERVER['HTTP_CLIENT_IP']))) {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
        }
        return $ip;
    }
}

$GLOBALS['MyComments'] = new CMyComments();

?>