<div class="row">
    <?php foreach ($event_detail as $comments) { ?>
    <div id="<?php echo $comments->id ?>">
        <div class="col-sm-2">
            <div class="pull-right"><i class="fa fa-remove text-danger" onclick="deleteImage(<?php echo $comments->id ?>)"></i></div>
            <img src="<?php echo base_url() ?>assets/uploads/<?php echo $comments->imagepath ?>" id="<?php echo $comments->id ?>" class="img-responsive" />
        </div>
    </div>
<?php } ?>
</div>

<script>
    function deleteImage(dId) {

        if (confirm('Are you sure, you want to delete this?')) {

//        if()
            $("div").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/delete_gallery_image',
                data: {'gallery_id': dId},
                success: function (data) {
                    showSuccess('Event Image Deleted Successfully');
//                    var parsed = $.parseJSON(data);
//                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>