<!-- modal start -->
<div class="modal fade" id="addgallery-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Event Gallery</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim"> 
                    <div id="hideform" style="display: block;">
                        <?php echo form_open_multipart('', array('id' => 'form_add_event_id')); ?>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="input-field">
                                    <?php echo form_label(lang('event_title'), 'event_title', array('for' => 'event_title')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'event_title',
                                        'id' => 'event_title',
                                        'placeholder' => 'Event Title',
                                        'data-error' => '.errorEvent1'
                                    ));
                                    ?>
                                    <div class="errorEvent1"></div>
                                    <?php echo form_error('event_title'); ?>

                                </div> 
                            </div> 

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <label for="event_date">Event Date</label>
                                    <input id="event_date" name="event_date" class="event_date"  placeholder="Event Date" type="text" data-error=".errorEvent2">
                                    <div class="errorEvent2"></div>
                                </div>                                        
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12">
                                <div class="input-field">
                                    <?php echo form_label(lang('edescription'), 'edescription', array('for' => 'edescription')); ?>
                                    <?php
                                    echo form_textarea(array(
                                        'name' => 'edescription',
                                        'id' => 'edescription',
                                        'class' => 'materialize-textarea',
                                        'placeholder' => 'Event Description',
                                        'data-error' => '.errorEvent3'
                                    ));
                                    ?>
                                    <div class="errorEvent3"></div>
                                    <?php echo form_error('edescription'); ?>

                                </div> 
                            </div>

                            <div class="clearfix"></div>
                            <div class="col-sm-12 text-right padding-top-10">
                                <button type="button" class="btn btn-warning2 btn-sm" id="uploadimg_id">Save & Upload Images </button>    
                            </div>
                            <input type="hidden" name="event_id" id="event_id"  value=""/>
                        </div>
                        <?php echo form_close(); ?>
                    </div>

                    <div id="showDropzone" style="display: none;">
                        <div class="col-sm-12">
                            Drag & Drop Images here to upload
                            <form action="<?php echo base_url() ?>events/uploadEventsImg" class="dropzone" id="dropzoneForm">
                                <div class="fallback">
                                    <input name="file" type="file" multiple />
                                </div>
                                <input type="hidden" name="event_id" id="event_id"  value=""/>
                                <input type="hidden" id="event_blog_id" name="event_blog_id" value="">
                                <input type="hidden" name="e_title" id="e_title"  value=""/>
                                <input type="hidden" name="e_date" id="e_date" value=""/>
                                <input type="hidden" name="e_description" id="e_description" value=""/>
                            </form> 
                        </div>
                        <div class="col-sm-12 text-right padding-top-10">
                            <button type="button" class="btn btn-info btn-sm" id="submit_event">Upload & Add Tags</button> 
                        </div>
                    </div>

                    <div id="showTags" style="display: none;">
                        <div class="col-sm-12">
                            <h5>Add tags to images</h5>
                            <form action="<?php echo base_url() ?>events/addTags"  id="tagsForm">
                                <div class="col-sm-12">
                                    <div class="images"></div>
                                </div>
                                <input type="hidden" name="event_id" id="event_id"  value=""/>
                                <input type="hidden" name="e_title" id="e_title"  value=""/>
                                <input type="hidden" name="e_date" id="e_date" value=""/>
                                <input type="hidden" name="e_description" id="e_description" value=""/>
                            </form> 
                        </div>
                        <div class="col-sm-12 text-right padding-top-10">
                            <button type="button" class="btn btn-info btn-sm" id="submit_tags">Finish</button> 
                        </div>
                    </div>


                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->
<script>
    $(document).ready(function () {
        $(".close").on('click', function () {
            $("div .error").html('');
            $('input').removeClass('error');
            $("div").removeClass("error");


        });
    });
</script>
<script>
    $(document).ready(function () {

        $('.event_date').pickadate({
            selectYears: true,
            selectMonths: true,
        });


        $("#uploadimg_id").click(function () {


            if ($("#form_add_event_id").valid()) {
                var formEventData = $('#form_add_event_id').serialize();
                showSuccess('Event Details addedd successfully');
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url(); ?>events/uploadEventsImg/add',
                    data: formEventData,
                    success: function (data) {

                        var parsed = $.parseJSON(data);
                        $("input[name='event_id']").val(parsed.event_id);
                        $('#event_blog_id').val(parsed.event_blog_id);

                    }
                });

                $("#showDropzone").show();
                $("#hideform").hide();
                $("#e_title").val($("#event_title").val());
                $("#e_date").val($("#event_date").val());
                $("#e_description").val($("#edescription").val());
                 


            }
            else
                return false;
        });

        $("#submit_tags").click(function () {

            var formEventData = $('#tagsForm').serialize();
            showSuccess('Event Details addedd successfully');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/addTags/add',
                data: formEventData,
                success: function (data) {

//                        var parsed = $.parseJSON(data);
//                        $("input[name='event_id']").val(parsed.event_id);

                }
            });

//            $("#showDropzone").show();
            $("#hideform").hide();
            $("#e_title").val($("#event_title").val());
            $("#e_date").val($("#event_date").val());
            $("#e_description").val($("#edescription").val());
            location.reload();

        });






    });
</script>
<script>
    $(document).ready(function () {

        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>events/uploadEventsImg', // override for form's 'action' attribute
            type: 'post', // 'get' or 'post', override for form's 'method' attribute 
            clearForm: true,
        };

        $('#submit_event').click(function () {
            var formEventData = $('#form_add_event_id').serialize();
            $('#form_add_event_id')[0].reset();
            $('#dropzoneForm')[0].reset();
            $("#showDropzone").hide();
//            $("#hideform").show();
            $("#showTags").show();

            

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/uploadEventsImg/event/tags',
                data: formEventData,
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    //                    $("input[name='event_id']").val(parsed.event_id);
                    $(".images").html(parsed.comment_data);
                    showSuccess('Event Details Updated Successfully');

                }
            });


//            $("#addgallery-1 .close").click();
            showSuccess('Event Created Successfully');
//            location.reload();


        });
        // pre-submit callback 
        function showRequest(formData, jqForm, options) {
            return true;
        }
        // post-submit callback 
        function showResponse(responseText, statusText, xhr, $form) {

            $("div").removeClass('error');
            $('.modal').modal('hide');
            showSuccess('Event Created Successfully');
            $("#showDropzone").hide();
           
//            location.reload();
            return true;
        }
    });

</script>