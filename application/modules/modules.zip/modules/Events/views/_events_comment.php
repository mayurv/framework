<?php //   var_dump($event_comments);        ?>
<div class="comments" id="comments">
    <div class="row">
        <div class="col-sm-12 margin-bottom-5">
            <div class="pull-left">
                <h4 class="text-bold all-margin"><?php echo $event_detail['title'] ?></h4>

                <div class="event-desc-main">
                    <div class="event-desc"><p><?php echo $event_detail['tag'] ?></p></div>
                    <div class="event-like-ico">
                        <i class="fa fa-comment"> <span id="event_count"><?php echo count($event_comments); ?></span> </i>
                        <span class="margin-left-10">
                            <!--<input value="0" id="islike">-->
                            <?php if (isset($isalready_like['id'])) { ?>

                                <i class="testun fa fa-thumbs-up  text-info" onclick="UnlikeImage(<?php echo $event_detail['id'] ?>, <?php echo $isalready_like['id'] ?>)"> 
                                    <span id="id_like_count_<?php echo $isalready_like['id']; ?>"><?php echo $like_count; ?></span>
                                </i> 
                            <?php } else { ?>

                                <i class="test fa fa-thumbs-o-up   text-light-gray" onclick="likeImage(<?php echo $event_detail['id'] ?>)"> 
                                    <span id="id_like_count_<?php echo $isalready_like['id']; ?>"><?php echo $like_count; ?></span>
                                </i> 
                            <?php } ?>
                        </span> 

                    </div>
                </div>

            </div>
            <!--            <div class="pull-right margin-top-5">
                            <span class="text-light-gray"><?php echo date('d F, Y', strtotime($event_detail['event_date'])) ?></span>
                            
                        </div>-->
        </div>

        <div class="clearfix"> </div>

        <div class="col-sm-12">
            <div class="comment-bg">
                <?php // var_dump($event_comments);die;?>
                <?php foreach ($event_comments as $comments) { ?>
                    <div id="comment_<?php echo $comments['comment_id'] ?>">
                        <div class="media margin-top-0">
                            <div class="media-left">

                                <?php if (isset($comments['profileimg']) && $comments['profileimg'] != '') { ?>
                                    <img style="width:30px" class="img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $comments['profileimg']; ?>">  
                                <?php } else { ?>
                                    <img style="width:30px" class="img-responsive" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                <?php } ?>
                            </div>

                            <div class="media-body">
                                <p class=" ">
                                    <span class="text-bold"> <?php echo $comments['userfullname'] ?> </span>
                                    <span class="pull-right">
                                        <?php if ($user_summary['emprole'] == 4) { ?>
                                            <i class="fa fa-trash text-danger" onclick="deleteComment(<?php echo $comments['comment_id'] ?>)" title="Delete Comment"></i>
                                        <?php } ?>
                                        <span class="text-light-gray"><i class="text-light-gray"></i>&nbsp;<?php echo date('d F,y', strtotime($comments['comment_date'])) ?></span>
                                        <span class="text-light-gray"><i class="fa fa-clock-o text-light-gray"></i>&nbsp;<?php echo date('h:i A', strtotime($comments['comment_date'])) ?></span>
                                    </span>
                                </p>
                                <p><?php echo $comments['department_name'] ?>, <?php echo $comments['position_name'] ?></p>
                                
                                

                                <p><?php echo $comments['comment'] ?></p>
                            </div>

                        </div>
                        <input type="hidden" value="<?php echo $comments['id'] ?>" id='gallery_id' name='gallery_id'>
                        <div class="margin-bottom-10"></div>
                    </div>
                <?php } ?> 

                <div id="comments_list"></div>
            </div>
        </div>

        <div class="clearfix"> </div>

        <div class="col-sm-12">
            <form role="form" onsubmit="return false;">   
                <div class="form-group margin-bottom-0">
                    <textarea name="text" placeholder="Message" class="form-control" id="text"></textarea>

                    <button class="btn btn-info" onclick="submitComment(<?php echo $event_detail['id'] ?>);
                            return false;">
                        <i class="fa fa-paper-plane"></i>
                    </button>

                </div> 
                <input type="hidden" value="<?php echo $user_summary['user_id'] ?>" id='user_id' name='user_id'>
                <input type="hidden" value="<?php echo $event_detail['id'] ?>" id='event_id' name='event_id'>

            </form>              
        </div>

    </div>
</div>

<script type="text/javascript">
    $('.comment-bg').slimScroll({
        // height: '370px'
        height: '275px'
    });
    $('.event-desc').slimScroll({
        height: '80px'
    });
</script>
<script type="text/javascript">
    // submit comment
    function submitComment(id) {

        var comments = $('#text').val();
        var user_id = $('#user_id').val();


        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>events/addComments',
            data: {'user_id': user_id, 'comments': comments, 'image_id': id},
            success: function (data) {
                var parsed = $.parseJSON(data);

                $('#event_count').html('');
                $('#event_count').html(parsed.count);
                $('#text').val('');
//                $('#comments_list').html('');
                $('#comments_list').append(parsed.comment_data);
            }
        });

    }
    ;
</script>

<script>
    function UnlikeImage(imgId, isalreadylikeid) {
//       var islike = $('#islike').val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>events/like_image',
            data: {'image_id': imgId, 'isLike': 0, 'isalreadylikeid': isalreadylikeid},
            success: function (data) {
                var parsed = $.parseJSON(data);

                $('.testun').removeClass('fa-thumbs-up text-info');
                $('.testun').addClass('fa-thumbs-o-up');
                $('.test').removeClass('fa-thumbs-up text-info');
                $('.test').addClass('fa-thumbs-o-up');


                $(".testun").attr("onclick", "likeImage(" + imgId + ")");
                $(".test").attr("onclick", "likeImage(" + imgId + ")");
                $('#id_like_count_<?php echo $isalready_like['id']; ?>').html('');
                $('#id_like_count_<?php echo $isalready_like['id']; ?>').html(parsed.like_counts);
            }
        });

    }
    function likeImage(imgId) {
//       var islike = $('#islike').val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>events/like_image',
            data: {'image_id': imgId, 'isLike': 1},
            success: function (data) {
                var parsed = $.parseJSON(data);

                $('.test').removeClass('fa-thumbs-o-up text-light-gray');
                $('.test').addClass('fa-thumbs-up text-info');
                $('.testun').removeClass('fa-thumbs-o-up text-light-gray');
                $('.testun').addClass('fa-thumbs-up text-info');

                var param = imgId + ',' + parsed.gallery_like_id;
                $(".testun").attr("onclick", "UnlikeImage(" + param + ")");
                $(".test").attr("onclick", "UnlikeImage(" + param + ")");
                $('#id_like_count_<?php echo $isalready_like['id']; ?>').html('');
                $('#id_like_count_<?php echo $isalready_like['id']; ?>').html(parsed.like_counts);

            }
        });

    }
</script>
<!--delete comment-->
<script>

    function deleteComment(comment_id) {
//        var comment = $('#comment-textarea').val();
        if (confirm('Are you sure, you want to delete this permanently?')) {
            $("div").remove('#comment_' + comment_id);

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/deleteGallerComment',
                data: {'comment_id': comment_id},
                success: function (data) {
                    showSuccess('Comment Deleted');
                    var cnt = $('#event_count').html();
                    var update_cnt = cnt - 1;
                    $('#event_count').html('');
                    $('#event_count').html(update_cnt);

                }
            });
        }
    }
</script>
<!--delete comment-->