<!-- modal start -->
<?php // var_dump($aItems);die;?>
<script type="text/javascript" src="<?php echo base_url('plugins/dropzone/dropzone.min.js'); ?>"></script>
<?php if (isset($aItems)) { ?>
    <?php foreach ($aItems as $eventData) { ?>
        <div class="modal fade" id="edit_event_<?php echo $eventData->id ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"> Event Gallery</h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-modal-slim"> 
                            <div id="edit_hideform_<?php echo $eventData->id ?>" style="display: block;">
                                <?php echo form_open_multipart('', array('id' => 'form_edit_event_id_' . $eventData->id)); ?>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('event_title'), 'event_title', array('for' => 'event_title')); ?>
                                            <?php
                                            echo form_input(array(
                                                'name' => 'event_title',
                                                'id' => 'event_title',
                                                'placeholder' => 'Event Title',
                                                'value' => set_value('event_title', $eventData->title),
                                                'data-error' => '.errorEvent1'
                                            ));
                                            ?>
                                            <div class="errorEvent1"></div>
                                            <?php echo form_error('event_title'); ?>

                                        </div> 
                                    </div> 

                                    <div class="clearfix"></div>

                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('event_date'), 'event_date', array('for' => 'event_date')); ?>
                                            <?php
                                            echo form_input(array(
                                                'name' => 'event_date',
                                                'id' => 'event_date',
                                                'class' => 'event_date',
                                                'placeholder' => 'Event Date',
                                                'value' => set_value('event_title', date('d F, Y', strtotime($eventData->event_date))),
                                                'data-error' => '.errorEvent2'
                                            ));
                                            ?>
                                            <div class="errorEvent2"></div>
                                            <?php echo form_error('event_date'); ?>

                                        </div> 
                                    </div> 


                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('edescription'), 'edescription', array('for' => 'edescription')); ?>
                                            <?php
                                            echo form_textarea(array(
                                                'name' => 'edescription',
                                                'id' => 'edescription',
                                                'class' => 'materialize-textarea',
                                                'placeholder' => 'Event Description',
                                                'value' => set_value('description', $eventData->description),
                                                'data-error' => '.errorEvent3'
                                            ));
                                            ?>
                                            <div class="errorEvent3"></div>
                                            <?php echo form_error('edescription'); ?>

                                        </div> 
                                    </div>

                                    <div class="clearfix"></div>
                                    <!--id="edit_uploadimg_id"-->
                                    <div class="col-sm-12 text-right padding-top-10">
                                        <!--onclick="return validate_event_form(<?php echo $eventData->id ?>)"-->
                                        <button type="button" class="btn btn-warning2 btn-sm" id="id_edit_event_<?php echo $eventData->id ?>" >Update & Upload Images </button>    
                                    </div>
                                    <input type="hidden" name="event_id" id="event_id"  value="<?php echo $eventData->id ?>"/>
                                </div>
                                <?php echo form_close(); ?>
                            </div>

                            <div id="edit_showDropzone_<?php echo $eventData->id ?>" style="display: none;">
                                <div class="col-sm-12">
                                    <div class="images"></div>
                                </div>
                                <div class="col-sm-12">
                                    Drag & Drop Images here to upload
                                    <form action="<?php echo base_url() ?>events/uploadEventsImg" class="dropzone" id="dropzoneForm_<?php echo $eventData->id ?>">
                                        <div class="fallback">
                                            <input name="file" type="file" multiple accept="image/*"/>
                                        </div>
                                        <input type="hidden" name="event_id" id="event_id"  value="<?php echo $eventData->id ?>"/>
                                        <input type="hidden" name="e_title" id="e_title"  value=""/>
                                        <input type="hidden" name="e_date" id="e_date" value=""/>
                                        <input type="hidden" name="e_description" id="e_description" value=""/>
                                    </form> 
                                </div>
                                <div class="col-sm-12 text-right padding-top-10">
                                    <button type="button" class="btn btn-info btn-sm" id="submit_event_<?php echo $eventData->id ?>">Update & Edit Tags</button> 

                                </div>
                            </div>

                            <div id="showTags_<?php echo $eventData->id ?>" style="display: none;">
                                <div class="col-sm-12">
                                    <h5>Add tags to images</h5>
                                    <form action="<?php echo base_url() ?>events/addTags"  id="tagsFormEdit_<?php echo $eventData->id ?>">
                                        <div class="col-sm-12">
                                            <div class="images_<?php echo $eventData->id ?>"></div>
                                        </div>
                                        <input type="hidden" name="event_id" id="event_id"  value="<?php echo $eventData->id ?>"/>
                                        <input type="hidden" name="e_title" id="e_title"  value=""/>
                                        <input type="hidden" name="e_date" id="e_date" value=""/>
                                        <input type="hidden" name="e_description" id="e_description" value=""/>
                                    </form> 
                                </div>
                                <div class="col-sm-12 text-right padding-top-10">
                                    <button type="button" class="btn btn-info btn-sm" id="submit_tags_<?php echo $eventData->id ?>">Finish</button> 
                                </div>
                            </div>


                        </div>
                    </div>                                                    
                </div>
            </div>
        </div>
        <script>

            $('#submit_event_<?php echo $eventData->id ?>').click(function () {
                $("#edit_showDropzone_<?php echo $eventData->id ?>").hide();
                var formEventData = $('#tagsFormEdit_<?php echo $eventData->id ?>').serialize();
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url(); ?>events/uploadEventsImg/event/tags/edit',
                    data: formEventData,
                    success: function (data) {
                        var parsed = $.parseJSON(data);
                        //                    $("input[name='event_id']").val(parsed.event_id);
                        $(".images_<?php echo $eventData->id ?>").html(parsed.comment_data);
                        showSuccess('Event Details Updated Successfully');

                    }
                });

                $("#showTags_<?php echo $eventData->id ?>").show();
        //                $("#edit_event_<?php echo $eventData->id ?> .close").click();
                showSuccess('Event Updated Successfully');
        //                location.reload();
            });

            $("#id_edit_event_<?php echo $eventData->id ?>").on('click', function () {
                
                if ($('#form_edit_event_id_<?php echo $eventData->id ?>').valid()) {
                    var id = <?php echo $eventData->id ?>;
                    var formEventData = $('#form_edit_event_id_' + id).serialize();

                    $.ajax({
                        type: "POST",
                        url: '<?php echo base_url(); ?>events/uploadEventsImg/event',
                        data: formEventData,
                        success: function (data) {
                            var parsed = $.parseJSON(data);
        //                    $("input[name='event_id']").val(parsed.event_id);
                            $(".images").html(parsed.comment_data);
                            showSuccess('Event Details Updated Successfully');

                        }
                    });

                    $("#edit_showDropzone_" + id).show();
                    $("#edit_hideform_" + id).hide();
                    $("#e_title").val($("#event_title").val());
                    $("#e_date").val($("#event_date").val());
                    $("#e_description").val($("#edescription").val());
                }
            });

            $("#submit_tags_<?php echo $eventData->id ?>").click(function () {
                $('#loader-bg').show();
                $('.loader-animation').show();

                var formEventData = $('#tagsFormEdit_<?php echo $eventData->id ?>').serialize();
                showSuccess('Event Details addedd successfully');
                $.ajax({
                    type: "POST",
                    url: '<?php echo base_url(); ?>events/addTags/add',
                    data: formEventData,
                    success: function (data) {
                        $('#loader-bg').hide();
                        $('.loader-animation').hide();

        //                        var parsed = $.parseJSON(data);
        //                        $("input[name='event_id']").val(parsed.event_id);

                    }
                });

                $("#showDropzone").show();
                $("#hideform").hide();
                $("#e_title").val($("#event_title").val());
                $("#e_date").val($("#event_date").val());
                $("#e_description").val($("#edescription").val());
                 location.reload();
            });


        </script>
    <?php } ?>
<?php } ?>
<!-- modal end -->

<script>
    $(document).ready(function () {
        $(".close").on('click', function () {
            $("div .error").html('');
            $('input').removeClass('error');
            $("div").removeClass("error");

        });
    });
</script>
<script>
    $(document).ready(function () {
<?php if (isset($aItems)) { ?>
    <?php foreach ($aItems as $eventData) { ?>
                $("#form_edit_event_id_<?php echo $eventData->id ?>").validate({
                    rules: {
                        event_title: {
                            required: true,
                            minlength: 3
                        },
                        edescription: {
                            required: true,
                            minlength: 10
                        },
                        event_date: {
                            required: true,
                        },
                    },
                    //For custom messages
                    messages: {
                        uname: {
                            required: "Enter a username",
                            minlength: "Enter at least 5 characters"
                        },
                        curl: "Enter your website",
                    },
                    errorElement: 'div',
                    errorPlacement: function (error, element) {
                        var placement = $(element).data('error');
                        if (placement) {
                            $(placement).append(error)
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });
    <?php } ?>
<?php } ?>
    });
</script>

<!--<script>
    $(document).ready(function () {
        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>events/uploadEventsImg', // override for form's 'action' attribute
            type: 'post', // 'get' or 'post', override for form's 'method' attribute 
            clearForm: true,
        };

        $('#dropzoneForm_34').click(function () {
                $("#dropzoneForm_34").ajaxSubmit(options);
            
        });
        
        // pre-submit callback 
        function showRequest(formData, jqForm, options) {
            return true;
        }
        // post-submit callback 
        function showResponse(responseText, statusText, xhr, $form) {
            alert(responseText);
            alert(statusText);
            showSuccess('sahsajkhjksah');
            alert('sahjksahdkj');
            return true;
        }
    });
</script>-->

<script>
    $(document).ready(function () {
        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            type: 'post', // 'get' or 'post', override for form's 'method' attribute 
            clearForm: true,
        };


        // pre-submit callback 
        function showRequest(formData, jqForm, options) {
            return true;
        }
        // post-submit callback 
        function showResponse(responseText, statusText, xhr, $form) {
            $("div").removeClass('error');
            $('.modal').modal('hide');

            return true;
        }
    });
</script>