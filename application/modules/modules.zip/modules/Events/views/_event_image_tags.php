<div class="row">
    <table class="table table-responsive">
        <tbody>

            <?php foreach ($event_detail as $comments) { ?>
                <tr id="<?php echo $comments->id ?>">
                    <td width="30%">
                        <div class="pull-right"><i class="fa fa-remove text-danger" onclick="deleteImage(<?php echo $comments->id ?>)"></i></div>
                        <img src="<?php echo base_url() ?>assets/uploads/<?php echo $comments->imagepath ?>" id="<?php echo $comments->id ?>" class="img-responsive" />
                    </td>
                    <td>
                        <input id="input_<?php echo $comments->id ?>" name="input_[<?php echo $comments->id ?>]" max="255" placeholder="add #tag for image" value="<?php echo $comments->tag ?>">
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

</div>

<script>
    function deleteImage(dId) {

        if (confirm('Are you sure, you want to delete this?')) {

//        if()
            $("tr").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>events/delete_gallery_image',
                data: {'gallery_id': dId},
                success: function (data) {
                    showSuccess('Event Image Deleted Successfully');
//                    var parsed = $.parseJSON(data);
//                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>