<?php
$i = 1;
$cnt = count($event_comments)
?>
<?php foreach ($event_comments as $comments) { ?>
    <?php if ($i == $cnt) { ?>
        <div id="comment_<?php echo $comments['comment_id'] ?>">
            <div class="media margin-top-0">
                <div class="media-left">
                    <?php if (isset($comments['profileimg']) && $comments['profileimg'] != '') { ?>
                        <img style="width:30px" class="img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $comments['profileimg']; ?>">  
                    <?php } else { ?>
                        <img style="width:30px" class="img-responsive" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                    <?php } ?>
                </div>

                <div class="media-body">
                    <h5 class="media-heading text-bold"><?php echo $comments['userfullname'] ?> 
                        <span class="pull-right">
                            <?php if ($user_summary['emprole'] == 4) { ?>
                                <i class="fa fa-trash text-danger" onclick="deleteComment(<?php echo $comments['comment_id'] ?>)" title="Delete Comment"></i>
                            <?php } ?>
                            <small class="text-light-gray"><i class="text-light-gray"></i>&nbsp;<?php echo date('d F,y', strtotime($comments['comment_date'])) ?></small>
                            <small class="text-light-gray"><i class="fa fa-clock-o text-light-gray"></i>&nbsp;<?php echo date('h:i A', strtotime($comments['comment_date'])) ?></small>
                        </span>
                    </h5>


                    <p><?php echo $comments['comment'] ?></p>
                </div>

            </div>

            <input type="hidden" value="<?php echo $comments['id'] ?>" id='gallery_id' name='gallery_id'>
        </div>
    <?php } ?>
    <?php
    $i++;
}
?> 