<?php
//require_once('classes/CMySQL.php'); // include service classes to work with database and comments
//require_once('classes/CMyComments.php');
// prepare a list with photos
$sPhotos = '';
// get photos info
?>
<!DOCTYPE html>
<div id="loader-bg" style="display: none">
    <div class="loader-txt margin-bottom-10"><h3>We Make IT simple</h3></div>
    <div class="loader-animation" style="display: block">&#9632;&#9632;&#9632;&#9632;&#9632;</div>
</div>
<html lang="en"><head>
        <meta charset="utf-8" />
        <title>Event Gallery</title>


    </head>
    <body class="">
        <!-- Container with last photos -->
        <?php // var_dump($aItems);die;  ?>
        <section class="col-lg-12 ">
            <!-- appraisal block here -->
            <div class="row">
                <div class="col-sm-12 main-bg margin-top-4">
                    <div class="container">

                        
                        <h1 class="text-center">
                             <small><span class="pull-left">
                                     <a href="<?php echo base_url() ?>events" title="Go Back"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                            </span>
                        </small>
                            <?php echo $aItems[0]->title ?>
                       
                        </h1>
                        
                        <p>
                            <?php // echo $aItems[0]->description ?>
                        </p>
                        <div class="event-slim">
                        <?php $cnt = 1; ?>
                        <?php // var_dump($aItems)?>
                        <?php foreach ($aItems as $i => $aItemInfo) { ?>

                            
                            <div class="col-sm-3">
                                <!--<p class="text-center"><?php echo '#' . $cnt . '   ' . $aItemInfo->title ?></p>-->             
                                <div class="photo">                                
                                    <img src="<?php echo base_url() ?>assets/uploads/<?php echo $aItemInfo->imagepath ?>" id="<?php echo $aItemInfo->id ?>" class="img-responsive" />
                                    <input type="hidden" id="event_id" name="event_id" value="<?php echo $aItemInfo->event_id ?>">
                                    <input type="hidden" id="event_blog_id" name="event_blog_id" value="">

                                    <div class="photo-caption">

                                        <span class="margin-right-5">
                                            <i class="fa fa-comments-o fa-lg text-white" title="Total Comments">  </i>     
                                            <?php echo $aItemInfo->comment_count ?>
                                        </span>                                        
                                        <span class="text-white"title="Total Likes">
                                            <i class="fa fa fa-thumbs-o-up fa-lg text-white"></i> 
                                            <?php echo $aItemInfo->like_count ?></span>
                                    </div>

                                </div>
                            </div>
                            
                            
                        
                            <?php
                            $cnt++;
                        }
                        ?>
                            </div>

                    </div>

                    <!-- Hidden preview block -->
                    <div id="photo_preview" style="display:none">
                        <div class="photo_wrp">
                            <i class="close fa fa-times"></i>
                            <div class="pleft"></div>
                            <div class="pright"></div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </body>
</html>

<script>
// display photo preview ajaxy
//    $('.container .photo img').click(function (event) {
//        if (event.preventDefault) event.preventDefault();
//
//        getPhotoPreviewAjx($(this).attr('id'));
//    });
    function getPhotoPreviewAjx(id) {
        
        var event_id = <?php echo $aItemInfo->event_id ?>;
        $('#photo_preview').show();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>events/photoAjax',
            data: {'action': 'get_info', 'id': id, 'event_id': event_id},
            success: function (data) {
                var parsed = $.parseJSON(data);

                $('#photo_preview .pleft').html(parsed.data1);
                $('#photo_preview .pright').html(parsed.data2);
                $('#photo_preview').show();
                $('#event_blog_id').val(parsed.event_blog_id);
                

            }
        });




//    $.post('<?php echo base_url() ?>events/photoAjax', {action: 'get_info', id: id},
//        function(data){
//            $('#photo_preview .pleft').html(data.data1);
//            $('#photo_preview .pright').html(data.data2);
//            $('#photo_preview').show();
//        }, "json"
//    );
    }
    ;
</script>

<style>

    .photo {
        display: block;
        margin: 0 auto;
        overflow: hidden;
        position: relative;
        margin: 1% 0% 5% 0%;
        cursor: pointer;
    }
    .photo img {
        width: 100%;
        height: 152px;
        transition: all 0.5s ease-in-out 0s;
        -moz-transition: all 0.5s ease-in-out 0s;
        -webkit-transition: all 0.5s ease-in-out 0s;
        -o-transition: all 0.5s ease-in-out 0s;
    }
    .photo .photo-caption {
        /*background: rgba(0,0,0,0.6);*/
        background: linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.6) 100%);
        bottom: 0;
        color: #fff;
        display: table;
        left: 0;
        opacity: 0;
        padding: 10px 10px;
        position: absolute;
        transition: all 0.2s ease-in-out 0s;
        -moz-transition: all 0.2s ease-in-out 0s;
        -webkit-transition: all 0.2s ease-in-out 0s;
        -o-transition: all 0.2s ease-in-out 0s;
        width: 100%;
        text-align: right;
    }
    .photo:hover .photo-caption {
        opacity: 1;
    }
    .photo:hover img {
        transform: scale(1.5) rotateZ(-3deg);
        -moz-transform: scale(1.5) rotateZ(-3deg);
        -webkit-transform: scale(1.5) rotateZ(-3deg);
        -o-transform: scale(1.5) rotateZ(-3deg);
    }

    .fa-lg {font-size: 1.33333333em !important;}




</style>
<script>
$(document).ready(function () {
    $('.event-slim').slimscroll({
            width: '100%',
            height: '450px',
            axis: 'both'
        });
        });
</script>