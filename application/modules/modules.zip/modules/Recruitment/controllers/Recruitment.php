<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Recruitment extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('Ajax_pagination');
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language', 'form'));
        $this->load->model(array('user_model', 'recruitmentskills', 'recruitmentskills', 'recruitmentfeedback', 'users', 'candidatedetails', 'priority', 'businessEntity', 'employment_status', 'group_model', 'menu', 'jobTitle', 'department', 'rescheduleinterviewround'));
        $this->load->model(array('employeesummary', 'rejectoffer', 'holdoffer', 'rejectcandidate', 'skiprounds', 'interviewrounddetails', 'numbers', 'interviewRoundDetails', 'interviewtype', 'skills', 'state', 'city', 'country', 'employees', 'common', 'personaldetails', 'requisition'));
        $this->load->library('grocery_CRUD');
        $this->load->language('recruitment');
        $this->load->language('hr_lang');
        $this->load->language(array('general_lang', 'profile_lang'));
        $this->perPage = 10;
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');

        if ($this->ion_auth->is_admin()) {
            //$data['account'] = $this->user_model->get_by_id($this->session->userdata('user_id'));
            // var_dump($data['account'] );
        }
        if (!$this->ion_auth->in_group('hr')) {
            redirect('dashboard/', 'refresh');
        }

        $this->load->library('form_validation');
        $this->load->helper('form');
    }

    // redirect if needed, otherwise display the user list
    public function index() {


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
//        if ($this->ion_auth->in_group('hr')) {
//            redirect('hr/', 'refresh');
//        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();


        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }



        $this->data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $this->data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->data['openings'] = $this->requisition->get_all_openings();

        // var_dump($this->data['openings']);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($this->data) ? $this->data : NULL));
        $this->template->write_view('content', 'recruitment', (isset($this->data) ? $this->data : NULL), TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function summary() {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['summary'] = $this->requisition->get_summary();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'all_opening_summary', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function _callback_reqid($value = null, $primary_key = null) {


        $this->load->model(array('employees'));
        $empid = $this->Requisition->get_requisition_id();
        //echo '<pre>',  print_r($empid);die;
        if (isset($empid)) {
            $st = '<input type="text" name="employeeId" id="field-employeeId" value="MWX-' . $empid . '" />';
//                $st = $empid;
        } else {
            $st = 'REQ-001';
        }
        return $st;
    }

    public function addOpening() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $this->data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->data['jobtitle'] = $this->employees->get_jobtitle();
        $this->data['department'] = $this->employees->get_department_name();
        $this->data['emp_status'] = $this->employees->get_employement_status();
        $this->data['priority'] = $this->employees->get_priority();



        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($this->data) ? $this->data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($this->data) ? $this->data : NULL));
        $this->template->write_view('content', 'addOpening', (isset($this->data) ? $this->data : NULL), TRUE);
        //        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function closeOpening() {
        $req_id = $this->input->post('req_id');

        $close_date = date('Y-m-d H:m:s');

        $update_status = array(
            'actual_close_date' => $close_date,
            'opening_status' => 3
        );

        $status = $this->requisition->update_opening_closeDate($req_id, $update_status);

        if (isset($status)) {
            $this->session->set_flashdata('msg', 'Opening Close successfully');
            redirect('recruitment/');
        }
    }

    /**
     * User Add
     *
     * @return void
     */
    public function editCandidate() {
//         var_dump($_FILES);die;
        $this->addCandidate('edit');
    }

    public function disp() {
        var_dump($_POST);
        die;
    }

    public function addCandidate($action = 'add') {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        //  echo $id;die;
//        //$data['req_id']=$id;
//        //   var_dump($_POST);
//
//        $data['openings'] = null;
//
//        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
//            //  echo $id;
//            $data['openings'] = $this->candidatedetails->as_array()->get_by('id', $id);
//        }

        if ($this->session->userdata('user_id'))
//            $user_id = 1; //$this->session->userdata('user_id');
//        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//        $data['interviewer1_list'] = (array('' => 'Select Interviewer 1', '1' => 'Select pp 1') );
//        $data['interviewer2_list'] = (array('' => 'Select Interviewer 2', '1' => 'Select uu 1') );
//        $data['hr_list'] = (array('' => 'Select HR', '' => 'Select pppppp 1') );
        // $data['candidate'] = $this->requisition->get_candidate_status();
        //  $data['requisition_code'] = $this->requisition->get_requisition_code_byId($id);
            $data['business_entity_list'] = $this->businessEntity->get_businessEntity();
//        $data['country'] = $this->country->get_country_name();
//        $data['state'] = $this->state->get_state_name();
//        $data['city'] = $this->city->get_city_name();
//        $data['yearsexp'] = array('' => 'Select Years') + $this->numbers->get_years();
//        $data['monthsexp'] = array('' => 'Select Months') + $this->numbers->get_months();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {



            $req_id = $this->input->post('requisition_id');
            $can_id = $this->input->post('id');

            $passFormatData = array(
                'req_code' => $this->input->post('req_code'),
                'candidate_firstname' => $this->input->post('candidate_firstname'),
                'createddate' => date('Y-m-d H:i:s')
            );

            $user_slug = $this->user_unique_slug($passFormatData);
            $req = $this->input->post('req_code');


            $this->form_validation->set_rules('business_entity_id', 'business_entity_id', 'trim|required');
            $this->form_validation->set_rules('contact_number', 'contact_number', 'trim|required');
//            $this->form_validation->set_rules('req_no_positions', 'req_no_positions', 'trim|required');
//            $this->form_validation->set_rules('position_id', 'position_id', 'trim|required');
//            $this->form_validation->set_rules('department_id', 'department_id', 'trim|required');
//            $this->form_validation->set_rules('skills', 'skills', 'trim|required');
//        $this->form_validation->set_rules('aprrover', 'aprrover', 'trim|required');

            if ($this->form_validation->run() == true) {
                $addCandidate = array(
                    'requisition_id' => $this->input->post('requisition_id'),
                    'requisition_code' => $this->input->post('req_code'),
                    'business_entity_id' => $this->input->post('business_entity_id'),
                    'candidate_firstname' => $this->input->post('candidate_firstname'),
                    'candidate_lastname' => $this->input->post('candidate_lastname'),
                    'candidate_name' => ucfirst($this->input->post('candidate_firstname') . ' ' . $this->input->post('candidate_lastname')),
                    'emailid' => $this->input->post('emailid'),
                    'contact_number' => $this->input->post('contact_number'),
                    'user_cv' => $this->input->post('cv_doc'),
                    'qualification' => $this->input->post('qualification'),
                    'years_exp' => $this->input->post('years_exp'),
                    'months_exp' => $this->input->post('month_exp'),
                    //  'skillset' => $this->input->post('skillset'),
                    'salt' => $user_slug,
                    //  'Summary' => $this->input->post('Summary'),
                    'notice_period' => $this->input->post('notice_period'),
                    'current_ctc' => $this->input->post('current_ctc'),
                    'expected_ctc' => $this->input->post('expected_ctc'),
                    'cand_location' => $this->input->post('cand_location'),
                    'position' => $this->input->post('position'),
//                    'country' => $this->input->post('countryname'),
//                    'state' => $this->input->post('statename'),
//                    'city' => $this->input->post('cityname'),
                    'pincode' => $this->input->post('Pincode'),
                    'createddate' => date('Y-m-d H:i:s')
                );

                if (!empty($_FILES['cv_doc']['name'])) {
                    $uploded_file_path = $this->handleUpload($addCandidate['salt'], $req);
                    if ($uploded_file_path != '')
                        $addCandidate['user_cv'] = $uploded_file_path;
                }

                if ($action == 'add') {
                    $insertAssoId = $this->candidatedetails->insert($addCandidate);
                    $can_id = $this->db->insert_id();

                    if ($can_id % 8 == 0)
                        $color_code = 8;
                    else
                        $color_code = $can_id % 8;
                    $this->candidatedetails->update_colorcode($insertAssoId, $color_code);

                    $skillset = $this->input->post('skillset');
                    if (isset($skillset)) {
                        foreach ($skillset as $key => $val) {
                            $dataSkillsetDetail[$key]['candidate_id'] = $can_id;
                            $dataSkillsetDetail[$key]['skillset_id'] = $val;
                            $dataSkillsetDetail[$key]['createddate'] = date('Y-m-d H:m:s');
                            $dataSkillsetDetail[$key]['createdby'] = $user_id;
                        }
                    }
                    if (isset($dataSkillsetDetail)) {
                        foreach ($dataSkillsetDetail as $datatskill)
                            $this->recruitmentskills->insert($datatskill);
                    }

                    $this->session->set_flashdata('msg', 'User added successfully.');
                    $redirect_url = 'recruitment/screening/' . $req_id;
                    redirect($redirect_url);
                } else {

                    $insertAssoId = $this->candidatedetails->update($can_id, $addCandidate);

                    $skillset = $this->input->post('skillset');
//                    var_dump($skillset);die;
                    if (isset($skillset)) {
                        foreach ($skillset as $key => $val) {
                            $dataSkillsetDetail[$key]['candidate_id'] = $can_id;
                            $dataSkillsetDetail[$key]['skillset_id'] = $val;
                            $dataSkillsetDetail[$key]['createddate'] = date('Y-m-d H:m:s');
                            $dataSkillsetDetail[$key]['createdby'] = $user_id;
                        }
                    }
                    //var_dump($dataSkillsetDetail);die;
                    $this->recruitmentskills->delete_skills_byId($can_id);
                    if (isset($dataSkillsetDetail)) {
                        foreach ($dataSkillsetDetail as $datatskill)
                            $this->recruitmentskills->update_skillset($can_id, $datatskill);
                    }
                    //echo $this->db->last_query();                    die;
                    $this->session->set_flashdata('msg', 'User Updated successfully.');
                    $redirect_url = 'recruitment/screening/' . $req_id;
                    redirect($redirect_url);
                }

//                $this->load->model('interviewRoundDetails');
//                $data_interview1 = array(
//                    'req_id' => $this->input->post('reqcode_id'),
//                    'candidate_id' => $can_id,
//                    'interviewer_id' => $this->input->post('interviewer1_id'),
//                    'interview_round_number' => 1
//                );
//                $insertAssoId1 = $this->interviewRoundDetails->insert($data_interview1);
//
//
//                $data_interview2 = array(
//                    'req_id' => $this->input->post('reqcode_id'),
//                    'candidate_id' => $can_id,
//                    'interviewer_id' => $this->input->post('interviewer2_id'),
//                    'interview_round_number' => 2
//                );
//                $insertAssoId2 = $this->interviewRoundDetails->insert($data_interview2);
//
//
//                $data_hr = array(
//                    'req_id' => $this->input->post('reqcode_id'),
//                    'candidate_id' => $can_id,
//                    'interviewer_id' => $this->input->post('hr_id'),
//                    'interview_round_number' => 3
//                );
//                $insertAssoId3 = $this->interviewRoundDetails->insert($data_hr);
//
//
//
//
//                $this->session->set_flashdata('msg', 'User added successfully.');
                // redirect('recruitment/screening/'.$data['req_id']);
            } else {

                $this->session->set_flashdata('errors', validation_errors());
            }
        }

//        if (isset($user_id)) {
//            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
////            var_dump($data['current_login_user_details']);die;
//            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
//            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
//        }
    }

    public function save_interviewRound() {
//        return false;
        $candidate_id = $this->input->post('candidate_id');
        $round_id = $this->input->post('round_id');
        $req_id = $this->input->post('req_id');
        $check_round = $this->input->post('check_round');
//        var_dump($_POST);die;

        $candidate_id = substr($candidate_id, strrpos($candidate_id, '-') + 1);


        if ($check_round == 0 && $round_id == 3)
            $round_id = 5;
        else
            $round_id = substr($round_id, strrpos($round_id, '-') + 1);
        //echo $candidate_id.'---'.$round_id;die;

        $dataRoundDetails = array(
            'req_id' => $req_id,
            'candidate_id' => $candidate_id,
            'interview_round_number' => $round_id,
        );

        $this->interviewRoundDetails->insert($dataRoundDetails);
        $this->candidatedetails->update_position($candidate_id, $round_id);
    }

    public function reschedule_interview() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        var_dump($_POST);die;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $interview_round_number = $this->input->post('interview_round_number');
            $candidate_id = $this->input->post('candidate_id');
            $req_id = $this->input->post('req_id');


            $reschedule['round_status'] = 'reschedule';
            $reschedule['reschedule_id'] = '1';
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $reschedule);


            $round_status = 'reschedule';

            $cur_round_id = $this->interviewRoundDetails->get_record($candidate_id, $round_status);


            $date = $this->input->post('interview_date');
            $date = str_replace(',', '', $date);
            $interview_date = date('Y-m-d H:m:s', strtotime($date));
            $reschedule_data = array(
                'reschedule_id' => $cur_round_id,
                'interviewer_id' => $this->input->post('interviewer_id'),
                'interview_mode' => $this->input->post('interview_mode'),
                'interview_date' => $interview_date,
                'interview_time' => $this->input->post('interview_time'),
                'schedule_comment' => $this->input->post('schedule_comment'),
                'reschedule_comment' => $this->input->post('reschedule_comment'),
                'schedule_id' => $this->input->post('interview_round_number'),
                'interview_round_number' => $this->input->post('interview_round_number'),
                'req_id' => $this->input->post('req_id'),
                'position' => $this->input->post('position'),
                'candidate_id' => $this->input->post('candidate_id'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $insertedId = $this->rescheduleinterviewround->insert($reschedule_data);
//            $reschedule_data['reschedule_id'] = $insertedId;
//            unset($reschedule_data['position']);



            $id = $this->input->post('req_id');
            $redirect_url = 'recruitment/screening/' . $id;
            redirect($redirect_url);
        }
    }

    public function schedule_interview() {

        //  var_dump($_POST);die;
        $t = $this->input->post('interview_time');
//        var_dump($t);
        $login_time_as_string = date("H:i:s", strtotime($t));
//        var_dump($login_time_as_string);
//        echo $login_time_as_string;die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $interview_round_number = $this->input->post('interview_round_number');
            $candidate_id = $this->input->post('candidate_id');

            $date = $this->input->post('interview_date');
            $date = str_replace(',', '', $date);
            $interview_date = date('Y-m-d H:m:s', strtotime($date));
            $schedule_data = array(
                'interviewer_id' => $this->input->post('interviewer_id'),
                'interview_mode' => $this->input->post('interview_mode'),
                'interview_date' => $interview_date,
                'interview_time' => $login_time_as_string,
                'schedule_comment' => $this->input->post('schedule_comment'),
                'schedule_id' => $this->input->post('interview_round_number'),
                'interview_round_number' => $this->input->post('interview_round_number'),
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $this->input->post('candidate_id'),
                'round_status' => 'schedule',
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->interviewrounddetails->update_schedule($candidate_id, $interview_round_number, $schedule_data);
            // var_dump($schedule_data);
            // echo $this->db->last_query();die;
            $id = $this->input->post('req_id');
            $redirect_url = 'recruitment/screening/' . $id;
            redirect($redirect_url);
        }
    }

    function ajaxPaginationCandidateList($screening_id) {

        //   echo "pagination".$screening_id;die;
        //echo $this->uri->segment(4);
        $page = $this->input->post('page');
        // $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        //$offset = (int)$this->uri->segment(4) > 0 ? ($this->uri->segment(4) - 1) * $config['per_page'] : 0;
        if (!$page && $page == '') {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
        if (!empty($keywords)) {
            $conditions['search']['keywords'] = $keywords;
        }
        if (!empty($sortBy)) {
            $conditions['search']['sortBy'] = $sortBy;
        }

        //total rows count
        $totalRec = count($this->candidatedetails->get_candidate_list($screening_id));

        //pagination configuration
        $config['first_link'] = 'First';
        $config['target'] = '#postList';
        $config['uri_segment'] = 4;
        $config['base_url'] = base_url() . 'recruitment/ajaxPaginationCandidateList/' . $screening_id;
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['use_page_numbers'] = TRUE;
        $this->ajax_pagination->initialize($config);
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
//        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;

        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;
        $data['check_client_interview'] = $this->candidatedetails->check_client_interview($screening_id);
        //get the posts data
        $data['candidates'] = $this->candidatedetails->get_candidate_list($screening_id, $conditions);
        $data['skills_list'] = (array('' => 'Select Skills')) + $this->skills->dropdown('skill_title');
        //echo $this->db->last_query();
        // var_dump($data['employee']);
        //load the view
        $this->load->view('recruitment/_ajaxScreeningList', $data, false);
    }

    public function screening_list($screening_id) {

        // echo $screening_id;die;

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $totalRec = count($this->candidatedetails->get_candidate_list($screening_id));
//echo $this->db->last_query();
        //pagination configuration
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'recruitment/ajaxPaginationCandidateList/' . $screening_id;
        $config['total_rows'] = $totalRec;
        $config['uri_segment'] = 4;
        $config['per_page'] = $this->perPage;
        $config['link_func'] = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        // var_dump($config['base_url']);die;

        $data['candidates'] = $this->candidatedetails->get_candidate_list($screening_id, array('limit' => $this->perPage));
        $data['check_client_interview'] = $this->candidatedetails->check_client_interview($screening_id);
        $data['candidates_count'] = $this->candidatedetails->get_screening_count($screening_id);
        $data['screening_details'] = $this->requisition->get_by_id($screening_id);

        $data['skills_list'] = (array('' => 'Select Skills')) + $this->skills->dropdown('skill_title');
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        $data['summary'] = $this->requisition->get_summary();
        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'screening_list', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function disp1() {
        $this->load->view('temp');
    }

    public function screening($id) {


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        // $data['round1'] = $this->candidatedetails->get_candidate_round1_details($id);


        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        //$data['candidates'] = null;
//        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // $data['openings'] = $this->requisition->as_array()->get_by('id', $id);
        //add candidate
        $data['screening_name'] = $this->requisition->get_screening_name($id);

        $data['requisition_code'] = $this->requisition->get_requisition_code_byId($id);
        $data['requisition_id'] = $id;
        $data['candidate_status'] = $this->requisition->get_candidate_status();
        $data['hr_list'] = (array('' => 'Select HR')) + $this->employeesummary->get_all_manager_byDept(5);
        $data['business_entity_list'] = $this->businessEntity->get_businessEntity();
        $data['skills_list'] = $this->skills->dropdown('skill_title');
        $data['yearsexp'] = array('' => 'Select Years') + $this->numbers->get_years();
        $data['monthsexp'] = array('' => 'Select Months') + $this->numbers->get_months();
        $data['interview_types'] = (array('' => 'Select Interview Type')) + $this->interviewtype->dropdown('name');


        //candidate edit
        $data['candidates_edit'] = $this->candidatedetails->get_candidatedetailsByid($id);
//          var_dump($data['candidates_edit']);die;
        //$data['candidate_details'] = $this->candidatedetails->get_candidate_details($id);
        //main list 0
        $data['check_client_interview'] = $this->candidatedetails->check_client_interview($id);
        //  var_dump( $data['check_client_interview'][0]->client_interview_status);

        $data['candidates'] = $this->candidatedetails->get_candidate_details($id);
        // var_dump( $data['candidates']);
        // screening 1-7 procedure 
        $data['candidates1'] = $this->candidatedetails->get_candidate_details1($id);
        $data['candidates2'] = $this->candidatedetails->get_candidate_details2($id);
        $data['candidates3'] = $this->candidatedetails->get_candidate_details3($id);
        $data['candidates4'] = $this->candidatedetails->get_candidate_details4($id);
        $data['candidates5'] = $this->candidatedetails->get_candidate_details5($id);
        $data['candidates6'] = $this->candidatedetails->get_candidate_details6($id);
        $data['candidates7'] = $this->candidatedetails->get_candidate_details7($id);

        //schedule interview
        $data['interview_mode_list'] = (array('' => 'Select Interview Type')) + $this->interviewtype->dropdown('name');
        $dept_id = $this->requisition->get_department($id);
        $data['interviewer_list'] = $this->employeesummary->get_all_manager_byDept($dept_id);


//        $dept_id = $this->requisition->get_department($id);
//        $rep_manager = $this->employeesummary->get_all_rep_mang_by_dept_id($dept_id);
//
//        foreach ($rep_manager as $category)
//            $options[$category['id']] = $category['userfullname'];
//        $data['interview_mode_list'] = (array('' => 'Select Interview Type')) + $this->interviewtype->dropdown('name');
//        $data['interviewer_list'] = $options;
        //$data['interview_mode_list'] = ;
//        $data['interviewer1_list'] = (array('' => 'Select Interviewer 1', '1' => 'Select pp 1') );
//        $data['interviewer2_list'] = (array('' => 'Select Interviewer 2', '1' => 'Select uu 1') );
//        $data['hr_list'] = (array('' => 'Select HR', '' => 'Select pppppp 1') );
//        $data['country'] = $this->country->get_country_name();
//        $data['state'] = $this->state->get_state_name();
//        $data['city'] = $this->city->get_city_name();


        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'screening', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function view_interview_details() {

        if ($this->session->userdata('user_id'))
            $user_id = 1; //$this->session->userdata('user_id');
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//           $data['candidate']=  $this->common->get_candidate_status();
        //  $data['requisition'] = $this->requisition->get_requisition_code();
//           $data['country']=  $this->common->get_country_name();
//           $data['state']=  $this->common->get_state_name();
//           $data['city']=  $this->common->get_city_name();
        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'view_interview_details', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function handleUpload($salt, $req) {
        if (!empty($_FILES)) {

//             Validate the file type
            $fileTypes = array('doc', 'docx', 'pdf'); // File extensions
            $fileParts = pathinfo($_FILES['cv_doc']['name']);

            if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
                $this->session->set_flashdata('msg', 'File type not supported.');
                return false;
            }

            $ext = pathinfo($_FILES['cv_doc']['name'], PATHINFO_EXTENSION);
            $targetURL = '/assets/uploads/recruitment/' . $req; // Relative to the root
            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'recruitment' . DIRECTORY_SEPARATOR . $req;

            if (!file_exists($targetPath)) {
                mkdir($targetPath, 0777, true);
            }
            $tempFile = $_FILES['cv_doc']['tmp_name'];

            $cvname = $salt;
            $upload_path = 'recruitment/' . $req . '/' . $cvname . '.' . $ext;

            $targetPath .= DIRECTORY_SEPARATOR . $cvname . '.' . $ext;

            $upload_status = move_uploaded_file($tempFile, $targetPath);

            if (isset($upload_status))
                return $upload_path;
        }
    }

    public function addVendor() {

        if ($this->session->userdata('user_id'))
            $user_id = 1; //$this->session->userdata('user_id');
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//           $data['candidate']=  $this->common->get_candidate_status();
//             $data['requisition']=  $this->common->get_requisition_code();
//           $data['country']=  $this->common->get_country_name();
//           $data['state']=  $this->common->get_state_name();
//           $data['city']=  $this->common->get_city_name();
        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'view_recruitment_vendor', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function user_unique_slug($uniqueSlugData) {
        return strtolower($uniqueSlugData['req_code'] . '-' . $uniqueSlugData['candidate_firstname']);
    }

//    public function skip_round($candidate_id) {
//        if (!$this->ion_auth->logged_in()) {
//            redirect('auth', 'refresh');
//        }
//
//        if ($this->session->userdata('user_id'))
//            $user_id = $this->session->userdata('user_id');
//
//        if (isset($_POST)) {
//
//            $req_id = $this->input->post('req_id');
//            $updatePosition = $this->input->post('position_status') + 1;
//
//            $this->candidatedetails->update_position($candidate_id, $updatePosition);
//            $interview_round_number = $this->input->post('interview_round_number');
//            $skipData = array(
//               
//                'skip_id' => $this->input->post('interview_round_number'),               
//                
//                
//            );
//            //$this->interviewRoundDetails->insert($skipData);
//            $this->interviewRoundDetails->update_round($candidate_id, $interview_round_number, $skipData);
//
//            
//            $skipRoundData = array(
//                'req_id' => $this->input->post('req_id'),
//                'candidate_id' => $candidate_id,  
//                'skip_id' => $this->input->post('interview_round_number'),
//                'skip_comment' => $this->input->post('skip_comment'),
//                'interview_round_number' => ($this->input->post('interview_round_number')) ,
//                'createdby' => $user_id,
//                'createddate' => date('Y-m-d H:m:s'),
//            );
//
//            $this->skiprounds->insert($skipRoundData);
//            
//            
//            
//            
//            $skipInsertData = array(
//                'req_id' => $this->input->post('req_id'),
//                'candidate_id' => $candidate_id,         
//                'interview_round_number' => ($this->input->post('interview_round_number')) + 1,
//                'modifiedby' => $user_id,
//                'modifieddate' => date('Y-m-d H:m:s'),
//            );
//
//            $this->interviewRoundDetails->insert($skipInsertData);
//
//            $this->session->set_flashdata('msg', 'Skip Reason saved successfully.');
//            $redirect_url = 'recruitment/screening/' . $req_id;
//            redirect($redirect_url);
//        }
//    }

    public function skip_round($candidate_id) {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {
            $req_id = $this->input->post('req_id');
            $current_position = $this->input->post('position_status');
            $client_ckeck = $this->input->post('check_client_status');
            $interview_round_number = $this->input->post('interview_round_number');
//            var_dump($client_ckeck);die;
            if ($current_position == 3 && $client_ckeck == 0) {
                $updatePosition = $this->input->post('position_status') + 2;
                $interview_round_number_skip = $this->input->post('interview_round_number') + 2;
            } else {
                $updatePosition = $this->input->post('position_status') + 1;
                $interview_round_number_skip = $this->input->post('interview_round_number') + 1;
            }



//             die;
            $this->candidatedetails->update_position($candidate_id, $updatePosition);

            $skipData = array(
                'round_status' => 'skip',
            );
            //$this->interviewRoundDetails->insert($skipData);
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $skipData);

            // echo $this->db->last_query();die;

            $round_status = 'skip';

            $cur_round_id = $this->interviewRoundDetails->get_record($candidate_id, $round_status);


            $skipRoundData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
//                'candidate_round_id' => $cur_round_id,
                'skip_id' => $cur_round_id,
                'skip_comment' => $this->input->post('skip_comment'),
                'interview_round_number' => ($this->input->post('interview_round_number')),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->skiprounds->insert($skipRoundData);

            $skipInsertData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
                'interview_round_number' => $interview_round_number_skip,
//                'createdby' => $user_id,
//                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->interviewRoundDetails->insert($skipInsertData);



            $this->session->set_flashdata('msg', 'Skip Reason saved successfully.');
            $redirect_url = 'recruitment/screening/' . $req_id;
            redirect($redirect_url);
        }
    }

    public function reject_round($candidate_id) {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        var_dump($_POST);die;
        if (isset($_POST)) {

            $req_id = $this->input->post('req_id');
            $interview_round_number = $this->input->post('interview_round_number');
            $rejectCandData = array('isactive' => '3');

            $this->candidatedetails->update($candidate_id, $rejectCandData);

            $rejectData = array(
                'round_status' => 'rejected',
                    //'isactive' => '3', //rejected
            );

            //$this->interviewRoundDetails->update_reject_candidate($candidate_id, $interview_round_number, $rejectData);
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $rejectData);


            //$cur_round_id = $this->interviewRoundDetails->last_record();
            $round_status = 'rejected';

            $cur_round_id = $this->interviewRoundDetails->get_record($candidate_id, $round_status);


            $rejectCandidateData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
                'reject_id' => $cur_round_id,
                'reject_comment' => $this->input->post('reject_comment'),
                'interview_round_number' => $this->input->post('interview_round_number'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->rejectcandidate->insert($rejectCandidateData);

            $this->session->set_flashdata('msg', 'Candidate Rejected from Interview Screening Process');
            $redirect_url = 'recruitment/screening/' . $req_id;
            redirect($redirect_url);
        }
    }

    public function download_offer($id) {
        $data['candidate'] = $this->candidatedetails->get_candidateOfferDetails($id);
        // var_dump($data['candidate']);
        $this->load->view('download_offer', $data);
    }

    public function delete_candidate($candidate_id, $req_id) {
        $deleteCandData = array('isactive' => '6');  //delete candidate          
        $this->candidatedetails->update($candidate_id, $deleteCandData);
        $redirect = 'recruitment/screening/' . $req_id;
        redirect($redirect);
    }

    public function reject_offer($candidate_id) {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        var_dump($_POST);die;
        if (isset($_POST)) {
            $req_id = $this->input->post('req_id');
            $interview_round_number = $this->input->post('interview_round_number');
            $rejectCandData = array('isactive' => '4'); //reject offer

            $this->candidatedetails->update($candidate_id, $rejectCandData);
            $rejectofferdata = array(
                'round_status' => 'reject offer',
            );

            //$this->interviewRoundDetails->update_reject_candidate($candidate_id, $interview_round_number, $rejectoffer);
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $rejectofferdata);

            $round_status = 'reject offer';

            $cur_round_id = $this->interviewRoundDetails->get_record($candidate_id, $round_status);

            $rejectOfferData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
                'reject_offer_id' => $cur_round_id,
                'reject_offer_comment' => $this->input->post('reject_offer_comment'),
                'interview_round_number' => $this->input->post('interview_round_number'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->rejectoffer->insert($rejectOfferData);

            $this->session->set_flashdata('msg', 'Offer Rejected');
            $redirect_url = 'recruitment/screening/' . $req_id;
            redirect($redirect_url);
        }
    }

    public function hold_offer($candidate_id) {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {
            $req_id = $this->input->post('req_id');
            $updatePosition = $this->input->post('position_status') + 1;
            // $this->candidatedetails->update_position($candidate_id, $updatePosition);
            $interview_round_number = $this->input->post('interview_round_number');

            $holdData = array(
                'round_status' => 'hold_offer',
            );
            //$this->interviewRoundDetails->insert($skipData);
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $holdData);

            $round_status = 'hold_offer';

            $cur_round_id = $this->interviewRoundDetails->get_record($candidate_id, $round_status);


            $holdOfferData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
//                'candidate_round_id' => $cur_round_id,
                'hold_offer_id' => $cur_round_id,
                'hold_offer_comment' => $this->input->post('hold_offer_comment'),
                'interview_round_number' => ($this->input->post('interview_round_number')),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $this->holdoffer->insert($holdOfferData);

//            $skipInsertData = array(
//                'req_id' => $this->input->post('req_id'),
//                'candidate_id' => $candidate_id,
//                'interview_round_number' => ($this->input->post('interview_round_number')) + 1,
////                'createdby' => $user_id,
////                'createddate' => date('Y-m-d H:m:s'),
//            );
//
//            $this->interviewRoundDetails->insert($skipInsertData);



            $this->session->set_flashdata('msg', 'Hold offer Reason saved successfully.');
            $redirect_url = 'recruitment/screening/' . $req_id;
            redirect($redirect_url);
        }
    }

    public function send_offer($param) {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {
            $req_id = $this->input->post('req_id');
            $candidate_id = $this->input->post('candidate_id');
            $interview_round_number = $this->input->post('interview_round_number');

            $roundData = array(
                'interview_round_number' => $this->input->post('interview_round_number'),
                'round_status' => 'Offer Sent',
                'interview_round_completed' => $this->input->post('interview_round_number'),
                'round_date' => date('Y-m-d H:m:s'),
            );

            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $roundData);
        }

        $this->session->set_flashdata('msg', 'Offer Send.');
        $redirect_url = 'recruitment/screening/' . $req_id;
        redirect($redirect_url);
    }

    public function accept_offer() {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {
            $req_id = $this->input->post('req_id');
            $candidate_id = $this->input->post('candidate_id');
            $updatePosition = $this->input->post('position') + 1;



            $interview_round_number = $this->input->post('interview_round_number');

            $roundData = array(
                'interview_round_number' => $this->input->post('interview_round_number'),
                'round_status' => 'Accept Offer',
                'interview_round_completed' => $this->input->post('interview_round_number'),
                'round_date' => date('Y-m-d H:m:s'),
            );
            //$this->interviewRoundDetails->insert($skipData);
            $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $roundData);


            $this->candidatedetails->update_position($candidate_id, $updatePosition);


            $InsertData = array(
                'req_id' => $this->input->post('req_id'),
                'candidate_id' => $candidate_id,
                'round_status' => 'join',
                'interview_round_number' => ($this->input->post('interview_round_number')) + 1,
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            $result = $this->interviewRoundDetails->insert($InsertData);

            if ($result)
                return '1';

//            $this->session->set_flashdata('msg', 'Offer Accepted.');
//            $redirect_url = 'recruitment/screening/' . $req_id;
//            redirect($redirect_url);
        }
    }

    public function register_portal() {


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $registerCandData = array('isactive' => '5', 'position' => '8'); ///register to portal
        $candidate_id = $this->input->post('candidate_id');

        $this->candidatedetails->update($candidate_id, $registerCandData);


        $req_id = $this->input->post('req_id');

        $interview_round_number = $this->input->post('interview_round_number');

        $roundData = array(
            'round_status' => 'Register',
            'interview_round_completed' => $this->input->post('interview_round_number'),
            'round_date' => date('Y-m-d H:m:s'),
        );
        //$this->interviewRoundDetails->insert($skipData);
        $this->interviewRoundDetails->update_round($req_id, $candidate_id, $interview_round_number, $roundData);



        $this->session->set_flashdata('msg', 'Candidate successfully register to the portal');
        $redirect_url = 'recruitment/screening/' . $req_id;
        redirect($redirect_url);
    }

    public function searchReqcruitement() {
        if (isset($_POST)) {
            $key = trim($_POST['search_key']);
           
            $this->data['openings'] = $this->requisition->get_all_openings($key);
            
            $recruitment_card_display = $this->load->view('recruitment_card_display', $this->data, TRUE);
            echo json_encode(array('search_list' => $recruitment_card_display));
        }
    }

}
