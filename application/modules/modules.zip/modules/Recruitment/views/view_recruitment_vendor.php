<div class="row">
    <div class="container">
        
       
        <!-- Recruitment Name ID-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'recruit_name',
                ));
                ?>
                
                <?php echo form_label(lang('recruit_name'), 'recruit_name'); ?>
                <?php echo form_error('recruit_name'); ?>
            </div>
        </div>  

       
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'contact_no',
                ));
              
                ?>
                <?php echo form_label(lang('contact_no'), 'contact_no'); ?>
                 <?php echo form_error('contact_no'); ?>
            </div>
        </div> 
        
         <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'location',
                ));
              
                ?>
                <?php echo form_label(lang('location'), 'location'); ?>
                 <?php echo form_error('location'); ?>
            </div>
        </div> 

        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'email',
                ));
              
                ?>
                <?php echo form_label(lang('email'), 'email'); ?>
                 <?php echo form_error('email'); ?>
            </div>
        </div> 
        
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'website',
                ));
              
                ?>
                <?php echo form_label(lang('website'), 'website'); ?>
                 <?php echo form_error('website'); ?>
            </div>
        </div> 
        
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'description',
                ));
              
                ?>
                <?php echo form_label(lang('description'), 'description'); ?>
                 <?php echo form_error('description'); ?>
            </div>
        </div> 
        
      <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'contract_from',
                    'class' => 'datepicker validate'
                ));
                ?>
                <?php echo form_label(lang('contract_from'), 'contract_from'); ?>
                <?php echo form_error('contract_from'); ?>
            </div> 
        </div> 
        
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'contract_till',
                    'class' => 'datepicker validate'
                ));
                ?>
                <?php echo form_label(lang('contract_till'), 'contract_till'); ?>
                  <?php echo form_error('contract_till'); ?>
            </div> 
        </div> 
        
        
         <!-- Interview Mode Drop Down-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'amount',
                ));
                ?>
                 <?php echo form_label(lang('amount'), 'amount'); ?>
                 <?php echo form_error('amount'); ?>
            </div> 
        </div>
         
     
        <div class="col-sm-6">
            <?php echo form_label(lang('upload_file'), 'upload_file'); ?>
            <div class="input-field">
            <?php
            echo form_upload(array(
                'name' => 'upload_file',
            ));
            ?>

            </div>
        </div>
   
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_dropdown(array('id' => '', 'name' => 'isactive'), array('Inactive', 'Active'));
                ?>	
                <?php echo form_label(lang('status'), 'status'); ?>


            </div>

        </div>

    </div>
</div>


