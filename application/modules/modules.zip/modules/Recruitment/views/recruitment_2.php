<table class="table data-table table-hover table-responsive">
                <thead>
                    <tr>
                      
                        <th class="col-sm-1">Name</th>
                        <th class="col-sm-1">Close Date</th>
                        <th class="col-sm-1">Required Position</th>
                        <th class="col-sm-1">Skills</th>
                        <th class="col-sm-1">Qualification</th>                      
                        <th class="col-sm-1">Experiance</th>
                        <th class="col-sm-1">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($openings as $result) { //var_dump($result); ?>
                        <tr>
                            
                            <td><p><?php echo $result['jobtitlename']; ?></p></td>
                            <td><p><?php echo $result['close_date']; ?></p></td>
                            <td><p><?php echo $result['req_no_positions'] ?></p></td>
                            <td><?php echo $result['req_skills'] ?></td>
                            <td><?php echo $result['req_qualification'] ?></td> 
                            <td><?php echo $result['req_exp_years_from'] ?>-<?php echo $result['req_exp_years_to'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>



