<style>
    .timeline-item .date i {
  position: absolute;
  top: 0;
  right: 0;
  padding: 5px;
  width: 30px;
  text-align: center;
  border-top: 1px solid #e7eaec;
  border-bottom: 1px solid #e7eaec;
  border-left: 1px solid #e7eaec;
  background: #f8f8f8;
}
.timeline-item .date {
  text-align: right;
  width: 110px;
  position: relative;
  padding-top: 30px;
}
.timeline-item .content {
  border-left: 1px solid #e7eaec;
  border-top: 1px solid #e7eaec;
  padding-top: 10px;
  min-height: 100px;
}
.timeline-item .content:hover {
  background: #f6f6f6;
}
    
</style>
<?php foreach ($candidates as $r => $result) { ?>  
    <!-- candidatetimeline modal -->
    <div class="modal fade " id="candidatetimeline_<?php echo $result['id'] ?>" role="dialog">
        <div class="modal-dialog modal-lg ">
            <div class="modal-content">
                <div class="modal-header all-padding-10">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                </div>
                <!-- modal body here --> 
                <div class="user-modal-slim">
                    <div class="modal-body"> 
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="ibox-content ">

                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-briefcase"></i>
                                                6:00 am
                                                <br>
                                                <small class="text-navy">2 hour ago</small>
                                            </div>
                                            <div class="col-xs-7 content no-top-border">
                                                <p class="m-b-xs"><strong>Meeting</strong></p>

                                                <p>Conference on the sales results for the previous year. Monica please examine sales trends in marketing and products. Below please find the current status of the
                                                    sale.</p>

                                                <p><span data-diameter="40" class="updating-chart" style="display: none;">7,4,3,4,6,8,6,6,3,1,3,4,8,7,5,1,6,9,3,10,8,1,9,7,0,7,8,2,9,9,6,6,2,8,3,9,1</span><svg class="peity" height="16" width="64"><polygon fill="#1ab394" points="0 15 0 5 1.7777777777777777 9.5 3.5555555555555554 11 5.333333333333333 9.5 7.111111111111111 6.5 8.88888888888889 3.5 10.666666666666666 6.5 12.444444444444443 6.5 14.222222222222221 11 16 14 17.77777777777778 11 19.555555555555554 9.5 21.333333333333332 3.5 23.11111111111111 5 24.888888888888886 8 26.666666666666664 14 28.444444444444443 6.5 30.22222222222222 2 32 11 33.77777777777778 0.5 35.55555555555556 3.5 37.33333333333333 14 39.11111111111111 2 40.888888888888886 5 42.666666666666664 15.5 44.44444444444444 5 46.22222222222222 3.5 48 12.5 49.77777777777777 2 51.55555555555555 2 53.33333333333333 6.5 55.11111111111111 6.5 56.888888888888886 12.5 58.666666666666664 3.5 60.44444444444444 11 62.22222222222222 2 64 14 64 15"></polygon><polyline fill="transparent" points="0 5 1.7777777777777777 9.5 3.5555555555555554 11 5.333333333333333 9.5 7.111111111111111 6.5 8.88888888888889 3.5 10.666666666666666 6.5 12.444444444444443 6.5 14.222222222222221 11 16 14 17.77777777777778 11 19.555555555555554 9.5 21.333333333333332 3.5 23.11111111111111 5 24.888888888888886 8 26.666666666666664 14 28.444444444444443 6.5 30.22222222222222 2 32 11 33.77777777777778 0.5 35.55555555555556 3.5 37.33333333333333 14 39.11111111111111 2 40.888888888888886 5 42.666666666666664 15.5 44.44444444444444 5 46.22222222222222 3.5 48 12.5 49.77777777777777 2 51.55555555555555 2 53.33333333333333 6.5 55.11111111111111 6.5 56.888888888888886 12.5 58.666666666666664 3.5 60.44444444444444 11 62.22222222222222 2 64 14" stroke="#169c81" stroke-width="1" stroke-linecap="square"></polyline></svg></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-file-text"></i>
                                                7:00 am
                                                <br>
                                                <small class="text-navy">3 hour ago</small>
                                            </div>
                                            <div class="col-xs-7 content">
                                                <p class="m-b-xs"><strong>Send documents to Mike</strong></p>
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-coffee"></i>
                                                8:00 am
                                                <br>
                                            </div>
                                            <div class="col-xs-7 content">
                                                <p class="m-b-xs"><strong>Coffee Break</strong></p>
                                                <p>
                                                    Go to shop and find some products.
                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-phone"></i>
                                                11:00 am
                                                <br>
                                                <small class="text-navy">21 hour ago</small>
                                            </div>
                                            <div class="col-xs-7 content">
                                                <p class="m-b-xs"><strong>Phone with Jeronimo</strong></p>
                                                <p>
                                                    Lorem Ipsum has been the industry's standard dummy text ever since.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-user-md"></i>
                                                09:00 pm
                                                <br>
                                                <small>21 hour ago</small>
                                            </div>
                                            <div class="col-xs-7 content">
                                                <p class="m-b-xs"><strong>Go to the doctor dr Smith</strong></p>
                                                <p>
                                                    Find some issue and go to doctor.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="row">
                                            <div class="col-xs-3 date">
                                                <i class="fa fa-comments"></i>
                                                12:50 pm
                                                <br>
                                                <small class="text-navy">48 hour ago</small>
                                            </div>
                                            <div class="col-xs-7 content">
                                                <p class="m-b-xs"><strong>Chat with Monica and Sandra</strong></p>
                                                <p>
                                                    Web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                        
                        
                        <!-- modal slim scroll bar candidate-timeline-bg -->

                        <div class="candidate-timeline-bg">
                            <!-- row -->
                            <div class="row">
                                <div class="col-md-12">
                                    <!-- The time line -->
<!--                                    <div class="col-sm-6"> Technical Rounds</div>
                                    <div class="col-sm-6"> Management Rounds</div>-->

                                    <div class="col-sm-6"> 
                                        <div class="ibox">
                                            <div class="ibox-title"> Technical Rounds</div>
                                            <div class="ibox-content">
                                        <ul class="timeline">
                                            <?php if (isset($result['firstround_details'])) { ?>
<!--                                                <li class="time-label">
                                                    <i class="init-bg"></i>
                                                </li> -->
                                                <?php
                                                foreach ($result['firstround_details'] as $roundDetails) {
                                                    //var_dump( $roundDetails); 
                                                    ?>
                                                    <?php //foreach ($candidate_firsttiemline as $r => $list) { ?>           

                                                    <!-- timeline item interview_round_number -->
                                                    <li>
                                                        <?php
                                                        if ($roundDetails['interview_round_number'] == 1) {
                                                            $roundName = "Round 1";
                                                        }

                                                        if ($roundDetails['interview_round_number'] == 2) {
                                                            $roundName = "Round 2";
                                                            // $color_code = "bg-maroon";
                                                        }

                                                        if ($roundDetails['interview_round_number'] == 3) {
                                                            $roundName = "Round 3";
                                                            //  $color_code = "bg-purple";
                                                        }

                                                        if ($roundDetails['interview_round_number'] == 4) {
                                                            $roundName = "Client";
                                                            //  $color_code = "bg-yellow";
                                                        }

                                                        //color code
                                                        $color_code = 'bg-gray-light';

                                                        if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 1))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 1))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                            $color_code = "bg-aqua";

                                                        if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 2))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 2))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                            $color_code = "bg-maroon";

                                                        if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 3))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 3))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                            $color_code = "bg-purple";

                                                        if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 4))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 4))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                            $color_code = "bg-yellow";
                                                        ?>
                                                        <i class="fa <?php echo $color_code ?>"><?php echo $roundName ?></i>
                <!--                                                  <span class="label bg-blue text-center">Interview Round</span>-->
                                                        <?php //if ((isset($roundDetails['schedule_comment']) && $roundDetails['schedule_comment'] != null) || isset($roundDetails['skip_comment']) && $roundDetails['skip_comment'] != null) { ?>
                                                        <div class="timeline-item">
                                                            <!--<small class="time text-light-gray"> <?php echo isset($roundDetails['interview_date']) ? date('d M , Y', strtotime($roundDetails['interview_date'])) : '' ?></small>-->

                                                                                                                                                                                                                                <!--                                                            <h3 class="timeline-header"><a href="#"></a> <?php //echo $roundName                   ?></h3>-->
                                                            <div class="timeline-body">
                                                                <?php if (isset($roundDetails['round_status']) && $roundDetails['round_status'] == 'skip') { ?>
                                                                    <p> 
                                                                        <span class="text-yellow"><i class="fa fa-ban margin-right-10"> </i>Skip </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['skipdate']) ? date('d F Y | H:m A', strtotime($roundDetails['skipdate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Skip Comments">
                                                                                    <?php echo $roundDetails['skip_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>
                                                                    <?php
                                                                }
                                                                //else {
                                                                ?>

                                                                <?php if (isset($roundDetails['schedule_id']) && $roundDetails['schedule_id'] != 0 ) { ?>
                                                                    <p> 
                                                                        <span class="text-light-gray"><i class="fa fa-calendar-o margin-right-10"> </i>Schedule </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['schedulecreateddate']) ? date('d F Y | H:m A', strtotime($roundDetails['schedulecreateddate'])) : '' ?>

                                                                            </small>
                                                                        </span>


                                                                    </p>
                                                                    <table class="timeline-tbl margin-left-10">

                                                                        <tr>
                                                                            <td><span class="text-light-gray "><i class="fa fa-calendar"></i></span></td>
                                                                            <td><?php echo isset($roundDetails['scheduledate']) ? date('d F Y', strtotime($roundDetails['scheduledate'])) : '' ?> </td>                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray "><i class="fa fa-clock-o"></i></span></td>
                                                                            <td><?php echo isset($roundDetails['scheduletime']) ? date('H:m A', strtotime($roundDetails['scheduletime'])) : '' ?></td>                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Schedule Comments">
                                                                                    <?php echo $roundDetails['schedule_comment'] ?>

                                                                                </span></td>                                                                            
                                                                        </tr>
                                                                    </table>

                                                                <?php } ?>
                                                                <!---- start reschedule------>
                                                                <?php
                                                                if (isset($roundDetails['reschedule_id']) && $roundDetails['reschedule_id'] == '1') {
                                                                    if (isset($roundDetails['reschedule_details']) && !empty($roundDetails['reschedule_details'])) {
                                                                        foreach ($roundDetails['reschedule_details'] as $res) {
                                                                           
                                                                            ?>
                                                                            <?php
                                                                            $count = count($roundDetails['reschedule_details']);
                                                                            $id = $count - 1;
                                                                            ?>

                                                                            <p>
                                                                            <p><span>Round got reschedule by <?php echo $count ?> times</span></p>
                                                                            <span class="text-light-gray"><i class="fa fa-calendar-o margin-right-10"> </i>Re-Schedule </span>
                                                                            <span class="pull-right">
                                                                                <small class="text-light-gray">
                        <?php echo isset($res['res_interview_date']) ? date('d F Y | H:m A', strtotime($res['res_interview_date'])) : '' ?>
                                                                                </small>
                                                                            </span>
                                                                            </p>
                                                                            <table class="timeline-tbl margin-left-10">
                                                                                <tr>
                                                                                    <td><span class="text-light-gray "><i class="fa fa-calendar"></i></span></td>
                                                                                    <td><?php echo isset($res['res_interview_date']) ? date('d F Y', strtotime($res['res_interview_date'])) : '' ?> </td>                                                                            
                                                                                </tr>
                                                                                <tr>
                                                                                    <td><span class="text-light-gray "><i class="fa fa-clock-o"></i></span></td>
                                                                                    <td><?php echo isset($res['res_interview_time']) ? date('H:m A', strtotime($res['res_interview_time'])) : '' ?></td>                                                                            
                                                                                </tr>
                                                                                <tr>
                                                                                    <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                                    <td><span class="" title="Schedule Comments">
                        <?php echo $res['schedule_comment'] ?>

                                                                                        </span></td>                                                                            
                                                                                </tr>
                                                                            </table>


                                                                        <?php
                                                                        }
                                                                    }
                                                                }
                                                                ?>
                                                                <!---- end reschedule------>
            <?php if (isset($roundDetails['interview_round_completed']) && $roundDetails['interview_round_completed'] != 0) { ?>
                                                                    <hr>
                                                                    <p>
                                                                        <span class="text-light-gray"><i class="fa fa-envelope fa-2x margin-right-10"> </i>Feedback </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['interviewerdate']) ? date('d F Y | H:m A', strtotime($roundDetails['interviewerdate'])) : '' ?></small></span>
                                                                    </p>

                                                                    <table class="timeline-tbl margin-left-10">
                                                                        <tr>
                                                                            <td><span class="text-light-gray " title="Interview By"><i class="fa fa-check"></i></span></td>
                                                                            <td><span class="text-light-gray"><?php echo $roundDetails['interviewer_name'] ?></span></td>                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray" title="Interview By"><i class="fa fa-clock-o"></i></span></td>
                                                                            <td><?php echo isset($roundDetails['interviewerdate']) ? date('H:m A', strtotime($roundDetails['interviewerdate'])) : '' ?></td>                                                                            
                                                                        </tr>
                                                                        <tr align="right">
                                                                            <td></td>
                                                                            <td><span class="text-center">
                                                                                    <?php
                                                                                    $x = 1;
                                                                                    $rating = (int) $roundDetails['interviewer_rating'];
                                                                                    ?>
                                                                                    <?php while ($x <= 10) { ?>

                                                                                        <?php if ($x <= $rating) { ?>  
                                                                                            <i class="fa fa-star text-star"></i>
                                                                                        <?php } else { ?>
                                                                                            <i class="fa fa-star text-light-gray"></i>
                                                                                        <?php } ?>
                    <?php
                    $x++;
                }
                ?>

                                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>

                                                                                </span>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><?php echo $roundDetails['interviewer_comments']; ?></td>                                                                            
                                                                        </tr>
                                                                    </table>



            <?php } ?> 


            <?php if (isset($roundDetails['round_status']) && $roundDetails['round_status'] == 'rejected') { ?>
                                                                    <p> 
                                                                        <span class="text-danger"><i class="fa fa-ban margin-right-10"> </i>Reject </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['rejcandate']) ? date('d F Y | H:m A', strtotime($roundDetails['rejcandate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Reject Comments">
                <?php echo $roundDetails['reject_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>

                                                        <?php } ?> 


                                                            </div>                
                                                        </div>
                                                    <?php // } else {    ?>

                                                        <!--<div class="margin-bottom-20"></div>-->
                                                    <?php //}   ?>
                                                    </li>
            <?php
        }
    }
    ?>
                                            <li>
                                                <i class=" circle-bg fa fa-clock-o bg-gray circle-bg"></i>
                                            </li>
                                        </ul>
                                    </div>
                                    </div>
                                    </div>

                                    <div class="col-sm-6"> 
                                        <div class="ibox">
                                            <div class="ibox-title"> Management Rounds</div>
                                            <div class="ibox-content">
                                        <ul class="timeline">
                                            <?php if (isset($result['secondround_details'])) { ?>
                                                <li class="time-label">
                                                    <i class="init-bg"></i>
                                                </li> 
                                                <?php
                                                foreach ($result['secondround_details'] as $roundDetails) {
                                                    //  var_dump($roundDetails);
                                                    ?>
                                                    <?php
                                                    if ($roundDetails['interview_round_number'] == 5)
                                                        $roundName = "HR Round";

                                                    if ($roundDetails['interview_round_number'] == 6)
                                                        $roundName = "OFFER";

                                                    if ($roundDetails['interview_round_number'] == 7)
                                                        $roundName = "Joining";

                                                    //color code
                                                    $color_code = 'bg-gray-light';
                                                    if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 5))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 5))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                        $color_code = "bg-aqua";

                                                    if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 6))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 6))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                        $color_code = "bg-maroon";

                                                    if ((((isset($roundDetails['interview_round_completed'])) && ($roundDetails['interview_round_completed'] == 7))) || (( (isset($roundDetails['schedule_id'])) && ($roundDetails['schedule_id'] == 7))) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'skip' )) || ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] == 'rejected' )))
                                                        $color_code = "bg-purple";
                                                    ?>
                                                    <!-- timeline item -->
                                                    <li>
                                                        <i class="fa <?php echo $color_code ?>"><?php echo $roundName ?></i>
            <?php // if (isset($roundDetails['schedule_comment']) && $roundDetails['schedule_comment'] != null) {    ?>


                                                        <div class="timeline-item">
                                                            <small class="time text-light-gray"> <?php echo isset($roundDetails['createddate']) ? date('d M, D ', strtotime($roundDetails['createddate'])) : '' ?></small>

                                                            <div class="timeline-body">
            <?php
            if ((isset($roundDetails['round_status'])) && ($roundDetails['round_status'] != '0' ) && ($roundDetails['round_status'] != 'rejected' ) && ($roundDetails['round_status'] != 'reject offer' ) && ($roundDetails['round_status'] != 'Send Offer' ) && ($roundDetails['round_status'] != 'Register' ) && ($roundDetails['round_status'] != 'Accept Offer' )) {
                if (isset($roundDetails['schedule_comment'])) {
                    ?>
                                                                        <p> 
                                                                            <span class="text-light-gray"><i class="fa fa-calendar-o margin-right-10"> </i>Schedule </span>
                                                                            <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['schedulecreateddate']) ? date('d F Y | H:m A', strtotime($roundDetails['schedulecreateddate'])) : '' ?>

                                                                                </small>
                                                                            </span>


                                                                        </p>
                                                                        <table class="timeline-tbl margin-left-10">

                                                                            <tr>
                                                                                <td><span class="text-light-gray "><i class="fa fa-calendar"></i></span></td>
                                                                                <td><?php echo isset($roundDetails['scheduledate']) ? date('d F Y', strtotime($roundDetails['scheduledate'])) : '' ?> </td>                                                                            
                                                                            </tr>
                                                                            <tr>
                                                                                <td><span class="text-light-gray "><i class="fa fa-clock-o"></i></span></td>
                                                                                <td><?php echo isset($roundDetails['scheduletime']) ? date('H:m A', strtotime($roundDetails['scheduletime'])) : '' ?></td>                                                                            
                                                                            </tr>
                                                                            <tr>
                                                                                <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                                <td><span class="" title="Schedule Comments">
                    <?php echo $roundDetails['schedule_comment'] ?>

                                                                                    </span></td>                                                                            
                                                                            </tr>
                                                                        </table>

                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
            <?php if (isset($roundDetails['skip_comment'])) { ?>
                                                                    <p> 
                                                                        <span class="text-yellow"><i class="fa fa-ban margin-right-10"> </i>Skip </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['skipdate']) ? date('d F Y | H:m A', strtotime($roundDetails['skipdate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Skip Comments">
                                                                    <?php echo $roundDetails['skip_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table> 
            <?php } ?>
            <?php if (isset($roundDetails['interviewer_comments'])) { ?>
                                                                    <hr>                                               
                                                                    <p>
                                                                        <span class="text-light-gray"><i class="fa fa-envelope fa-2x margin-right-10"> </i>Feedback </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['interviewerdate']) ? date('d F Y | H:m A', strtotime($roundDetails['interviewerdate'])) : '' ?></small></span>
                                                                    </p>

                                                                    <table class="timeline-tbl margin-left-10">
                                                                        <tr>
                                                                            <td><span class="text-light-gray " title="Interview By"><i class="fa fa-check"></i></span></td>
                                                                            <td><span class="text-light-gray"><?php echo $roundDetails['interviewer_name'] ?></span></td>                                                                            
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray" title="Interview By"><i class="fa fa-clock-o"></i></span></td>
                                                                            <td><?php echo isset($roundDetails['interviewerdate']) ? date('H:m A', strtotime($roundDetails['interviewerdate'])) : '' ?></td>                                                                            
                                                                        </tr>
                                                                        <tr align="right">
                                                                            <td></td>
                                                                            <td><span class="text-center">
                                                                                    <?php
                                                                                    $x = 1;
                                                                                    $rating = (int) $roundDetails['interviewer_rating'];
                                                                                    ?>
                                                                                    <?php while ($x <= 10) { ?>

                                                                                        <?php if ($x <= $rating) { ?>  
                                                                                            <i class="fa fa-star text-star"></i>
                                                                                        <?php } else { ?>
                                                                                            <i class="fa fa-star text-light-gray"></i>
                                                                                        <?php } ?>
                    <?php
                    $x++;
                }
                ?>

                                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>

                                                                                </span>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><?php echo $roundDetails['interviewer_comments']; ?></td>                                                                            
                                                                        </tr>
                                                                    </table>
            <?php } ?> 


            <?php if (isset($roundDetails['reject_comment'])) { ?>
                                                                    <p> 
                                                                        <span class="text-danger"><i class="fa fa-ban margin-right-10"> </i>Reject </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['rejcandate']) ? date('d F Y | H:m A', strtotime($roundDetails['rejcandate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Reject Comments">
                                                                    <?php echo $roundDetails['reject_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>
            <?php } ?> 

            <?php if (isset($roundDetails['reject_offer_comment'])) { ?>
                                                                    <p> 
                                                                        <span class="text-danger"><i class="fa fa-newspaper-o margin-right-10"> </i>Reject Offer </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['offerrejectdate']) ? date('d F Y | H:m A', strtotime($roundDetails['offerrejectdate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Reject Offer Comments">
                <?php echo $roundDetails['reject_offer_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>

            <?php } ?> 

            <?php if (isset($roundDetails['hold_offer_comment'])) { ?>
                                                                    <p> 
                                                                        <span class="text-yellow"><i class="fa fa-newspaper-o margin-right-10"> </i>Hold Offer </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['holddate']) ? date('d F Y | H:m A', strtotime($roundDetails['holddate'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                <!--                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Hold Offer Comments">
                                                                    <?php echo $roundDetails['hold_offer_comment'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>-->
            <?php } ?> 

            <?php if (isset($roundDetails['round_status']) && $roundDetails['round_status'] == 'Send Offer') { ?>
                                                                    <p> 
                                                                        <span class="text-success"><i class="fa fa-check-circle-o  margin-right-10"> </i>Offer Send </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['round_date']) ? date('d F Y | H:m A', strtotime($roundDetails['round_date'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                <!--                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Offer Send Comments">
                <?php echo $roundDetails['round_status'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>-->

                                                                <?php } ?>    




            <?php if (isset($roundDetails['round_status']) && $roundDetails['round_status'] == 'Accept Offer') { ?>
                                                                    <p> 
                                                                        <span class="text-success"><i class="fa fa-check-circle-o  margin-right-10"> </i>Offer Accept </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['round_date']) ? date('d F Y | H:m A', strtotime($roundDetails['round_date'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                <!--                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Offer Accept Comments">
                <?php echo $roundDetails['round_status'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>-->

            <?php } ?> 

            <?php if (isset($roundDetails['round_status']) && $roundDetails['round_status'] == 'Register') { ?>
                                                                    <p> 
                                                                        <span class="text-success"><i class="fa fa-check-circle  margin-right-10"> </i>Register </span>
                                                                        <span class="pull-right"><small class="text-light-gray"><?php echo isset($roundDetails['round_date']) ? date('d F Y | H:m A', strtotime($roundDetails['round_date'])) : '' ?>

                                                                            </small>
                                                                        </span>
                                                                    </p>
                <!--                                                                    <table>
                                                                        <tr>
                                                                            <td><span class="text-light-gray"><i class="fa fa-comment-o"></i></span></td>
                                                                            <td><span class="" title="Register Comments">
                                                                    <?php echo $roundDetails['round_status'] ?>
                                                                                </span>
                                                                            </td>                                                                            
                                                                        </tr>
                                                                    </table>-->
            <?php } ?> 




                                                            </div>                
                                                        </div>
                                                    <?php //} else {      ?>
                                                        <!--<div class="margin-bottom-20"></div>-->
                                                    <?php // }     ?>
                                                    </li>
                                                    <!-- END timeline item -->
            <?php
        }
    }
    ?>
                                            <li>
                                                <i class=" circle-bg fa fa-clock-o bg-gray circle-bg"></i>
                                            </li>

                                        </ul>
                                    </div>
                                    </div>
                                    </div>


                                </div>
                                <!-- /.col -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- modal slim scroll bar candidate-timeline-bg -->
                    </div>     
                </div>      
            </div>      
        </div>
    </div>
    <!--candidatetimeline modal -->
<?php } ?>  
