
<!-- modal start -->
<?php
//var_dump($candidates_edit);
foreach ($candidates_edit as $result) { ?>
    <div class="modal fade" id="editCandidate_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Edit Candidate</h4>
                </div>
                <div class="modal-body">
                    <div class="user-modal-slim"> 
                        <?php
                        // var_dump($result);die;
                        echo form_open_multipart('recruitment/editCandidate/', array('id' => 'form_editCandidate_id_' . $result['user_id'], 'class' => 'form_editCandidate_id_' . $result['user_id']));
                        ?>
                        <input type="hidden" name="requisition_id" value="<?php echo $result['requisition_id'] ?>">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('requisition'), 'requisition', array('for' => 'reqcode_id')); ?>
                                    <?php //if ($_SERVER['REQUEST_METHOD'] === 'GET') { ?>
                                    <?php
//                                        echo form_input(array(
//                                            'id' => 'reqcode_id',
//                                            'name' => 'reqcode_id',
//                                            'placeholder' => 'Requisition Code',
//                                            'class' => 'browser-default',
//                                            'type' => 'text',
//                                            'data-error' => '.addCandidate1',
//                                            'value' => set_value('requisition_id', $result['requisition_id']),
//                                        ));
                                    ?>
                                    <?php //} else { ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'req_code',
                                        'name' => 'req_code',
                                        'placeholder' => 'Requisition Code',
                                        'class' => 'browser-default',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate1',
                                        'value' => $requisition_code,
                                    ));
                                    ?>

                                    <?php //}   ?>
                                    <div class="addCandidate1"></div>                                    
                                    <?php echo form_error('requisition_id'); ?>   
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('candidate_firstname'), 'candidate_firstname', array('for' => 'candidate_firstname')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'candidate_firstname',
                                        'id' => 'candidate_firstname',
                                        'class' => 'browser-default',
                                        'placeholder' => 'First Name',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate2',
                                        'value' => set_value('candidate_firstname', $result['candidate_firstname']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate2"></div>
                                    <?php echo form_error('candidate_firstname'); ?>
                                </div>         
                            </div>                  
                            <div class="clearfix"> </div>
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('candidate_lastname'), 'candidate_lastname', array('for' => 'candidate_lastname')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'candidate_lastname',
                                        'id' => 'candidate_lastname',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Last Name',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate3',
                                        'value' => set_value('candidate_lastname', $result['candidate_lastname']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate3"></div>
                                    <?php echo form_error('candidate_lastname'); ?>
                                </div>         
                            </div> 
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('emailid'), 'emailid', array('for' => 'emailid')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'emailid',
                                        'id' => 'emailid',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Email',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate4',
                                        'value' => set_value('emailid', $result['emailid']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate4"></div>
                                    <?php echo form_error('emailid'); ?>
                                </div>         
                            </div> 
                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('contact_number'), 'contact_number', array('for' => 'contact_number')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'contact_number',
                                        'id' => 'contact_number',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Contact Number',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate5',
                                        'value' => set_value('contact_number', $result['contact_number']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate5"></div>
                                    <?php echo form_error('contact_number'); ?>
                                </div>         
                            </div> 
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('qualification'), 'qualification', array('for' => 'qualification')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'qualification',
                                        'id' => 'qualification',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Qualification',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate6',
                                        'value' => set_value('qualification', $result['qualification']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate6"></div>
                                    <?php echo form_error('qualification'); ?>
                                </div>         
                            </div> 
                            <div class="clearfix"></div>

                            <div class="col-sm-3">
                                <?php echo form_label(lang('yearsc_exp'), 'years_exp', array('for' => 'years_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'years_exp', 'name' => 'years_exp', 'style' => 'max-height: 500px;height:500px;','class' => 'browser-default', 'data-error' => '.addCandidate7'), $yearsexp, set_value('years_exp', $result['years_exp']));
                                ?>
                                <div class="input-field">
                                    <div class="addCandidate7"></div>
                                </div> 
                                <?php echo form_error('years_exp'); ?>
                            </div>

                            <div class="col-sm-3">
                                <?php echo form_label(lang('month_exp'), 'month_exp', array('for' => 'month_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'month_exp', 'name' => 'month_exp'), $monthsexp, set_value('months_exp', $result['months_exp']), array('class' => 'browser-default', 'data-error' => '.addCandidate8'));
                                ?>
                                <div class="input-field">
                                    <div class="addCandidate8"></div>
                                </div> 
                                <?php echo form_error('month_exp'); ?>
                            </div>


                            <?php // var_dump($result['skill_detail'])?>
                            <?php // var_dump($skills_list)?>
                            <div class="col-sm-6">
                                <?php echo form_label(lang('skillset'), 'skillset', array('for' => 'skillset')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'skillset' . $result['id'],
                                    'name' => 'skillset[]',
                                    'multiple' => 'multiple',
                                    'class' => 'browser-default',
                                    'data-error' => '.addCandidate9',
                                        ), $skills_list, set_value('skillset_id', $result['skill_detail']));
                                ?>
                                <div class="input-field">
                                    <div class="addCandidate9"></div>
                                    <?php echo form_error('skillSet'); ?> 
                                </div>     
                            </div> 
                            <div class="clearfix"></div>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('cand_location'), 'cand_location', array('for' => 'cand_location')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'cand_location',
                                        'id' => 'cand_location',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Location',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate10',
                                        'value' => set_value('cand_location', $result['cand_location']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate10"></div>
                                    <?php echo form_error('cand_location'); ?>
                                </div>         
                            </div>                                         


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('current_ctc'), 'current_ctc', array('for' => 'current_ctc')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'current_ctc',
                                        'id' => 'current_ctc',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Current CTC',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate11',
                                        'value' => set_value('current_ctc', $result['current_ctc']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate11"></div>
                                    <?php echo form_error('current_ctc'); ?>
                                </div>         
                            </div>     

                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('expected_ctc'), 'expected_ctc', array('for' => 'expected_ctc')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'expected_ctc',
                                        'id' => 'expected_ctc',
                                        'class' => 'browser-default',
                                        'placeholder' => 'Expected CTC',
                                        'type' => 'text',
                                        'data-error' => '.addCandidate12',
                                        'value' => set_value('expected_ctc', $result['expected_ctc']),
                                    ));
                                    ?>                       
                                    <div class="addCandidate12"></div>
                                    <?php echo form_error('expected_ctc'); ?>
                                </div>         
                            </div>     


                            <div class="col-sm-6">
                                <?php
                                $options = array();
                                foreach ($business_entity_list as $category)
                                    $options[$category['id']] = $category['title'];
                                ?>
                                <?php echo form_label(lang('source'), 'source', array('for' => 'business_entity_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'business_entity_id',
                                    'name' => 'business_entity_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addCandidate13',
                                    ), $options ,set_value('business_entity_id', $result['business_entity_id']));
                                ?>
                                <div class="input-field">
                                    <div class="addCandidate13"></div>
                                    <?php echo form_error('business_entity_id'); ?> 
                                </div>     
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="file-field input-field">
                                    <div class="btn btn-default btn-sm margin-top-5">
                                        Browse
                                        <?php
                                        echo form_input(array(
                                            'type' => 'file',
                                            'name' => 'cv_doc',
                                            'id' => 'cv_doc',
                                            'value' => set_value('user_cv', $result['user_cv']),
                                            'data-error' => '.addCandidate14'
                                        ));
                                        ?>
                                    </div>
                                    <div class="file-path-wrapper">
                                        <?php
                                        echo form_input(array(
                                            'name' => 'cv_doc',
                                            'id' => 'cv_doc',
                                            'class' => 'file-path',
                                            'value' => set_value('user_cv', $result['user_cv']),
                                            'placeholder' => '( pdf, doc, docx, jpg)',
                                            'data-error' => '.addCandidate14'
                                        ));
                                        ?>
                                    </div>
                                    <div class="addCandidate14"></div>
                                </div>
                            </div>
                            <input type="hidden" name="id" value="<?php echo $result['user_id'] ?>">
                            <input type="hidden" name="position" value="<?php echo $result['position'] ?>">




                            <div class="col-sm-12 padding-top-10 text-right">
                                 <button type="submit" class="btn btn-warning2 btn-sm" onclick="return validate_candidate_form(<?php echo $result['user_id'] ?>)">Submit</button>
                                <!--<button type="submit" onclick="return " class="btn btn-warning2 btn-sm">Submit</button>-->
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                        </div>
                        <?php echo form_close() ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo base_url('plugins/multiselect_dropdown/jquery.multiselect.js'); ?>"></script>
    <!-- modal end -->
    <script type="text/javascript">
                                    $('#skillset<?php echo $result['id'] ?>').multiselect({
                                        columns: 1,
                                        placeholder: 'Select option'
                                    });

    </script>
<?php } ?>

