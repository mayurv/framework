<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>



<div class="row"> 
    <div class="col-sm-12">
        <div class="w-panel-bg">

            <!--  panel start here -->
            <div class="panel panel-default">
                <div class="panel-heading all-padding-10">
                    <div class="p-title">Add Opening</div>
                </div>

                <div class="panel-body all-padding-0">
                    <div class="office-info-1">
                        <?php
                        //var_dump($openings);
                        echo form_open('recruitment/add');?>
                         <?php echo (isset($flashdata) ? set_flashdata($flashdata) : '') ?>
                <?php echo $this->session->flashdata('msg'); ?>
                        
                        <div class="row">
                            
                            
                             <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'req_code',
                                        'id' => 'req_code',                                     
                                        'value' => $req_code,
                                    ));
                                    ?>
                                    <?php echo form_label(lang('job_code'), 'job_code'); ?>
                                    
                                    <?php echo form_error('req_code'); ?>      
                                </div> 
                            </div>
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'onboard_date',
                                        'id' => 'onboard_date',
                                        'data-format' => 'yyyy-mm-dd',
                                        'class' => 'datepicker',
                                        'value' => set_value('onboard_date', $openings['onboard_date']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('close_date'), 'close_date'); ?>
                                    <?php echo form_error('onboard_date'); ?>      
                                </div> 
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    $options = array();
                                    foreach ($job_code1 as $category)
                                        $options[$category['id']] = $category['jobtitlename'];
                                    echo form_dropdown(array('id' => 'jobtitle_id', 'name' => 'jobtitle_id'), $options,set_value('jobtitle', $openings['jobtitle']));
                                    ?>
                                    <?php echo form_label(lang('job_title'), 'job_title'); ?>
                                    <?php echo form_error('job_code'); ?>                    

                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown(array('id' => 'position_id', 'name' => 'position_id'), $position_list, set_value('position_id', $openings['position_id']));
                                    ?>
                                    <?php echo form_label(lang('position_id'), 'position_id'); ?>
                                    <?php echo form_error('position_id'); ?>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown('department_id', $department, set_value('department_id', $openings['department_id']), 'id="department_id"');
                                    ?>
                                    <?php echo form_label(lang('department_id'), 'department_id'); ?>
                                    <?php echo form_error('department_id'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown('reporting_manager', $reporting_manager_list, set_value('reporting_id', $openings['reporting_id']), 'id="reporting_manager"');
                                    ?>
                                    <?php echo form_label(lang('reportind_manager'), 'reportind_manager'); ?>
                                    <?php echo form_error('reporting_manager'); ?>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'req_no_positions',
                                        'value' => set_value('ReqPosition'),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('req_no_positions'), 'req_no_positions'); ?>
                                    <?php echo form_error('req_no_positions'); ?>
                                </div> 
                            </div>

<!--                            <div class="col-sm-6">
                                <div class="input-field">                                   
                                    <?php
                                    echo form_input(array(
                                        'name' => 'SelectedMemebers',
                                        'value' => set_value('SelectedMemebers'),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('selected_members'), 'selected_members'); ?>
                                    <?php echo form_error('SelectedMemebers'); ?>
                                </div> 
                            </div>-->

<!--                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'FilledPosition',
                                        'value' => set_value('FilledPosition'),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('filled_positions'), 'filled_positions'); ?>
                                    <?php echo form_error('FilledPosition'); ?>
                                </div> 
                            </div>-->

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'description',
                                        'value' => set_value('jobdescription', $openings['jobdescription']),
                                    ));
                                    ?> 
                                    <?php echo form_label(lang('jobdescription'), 'jobdescription'); ?>
                                    <?php echo form_error('description'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">                                    
                                    <?php
                                    echo form_input(array(
                                        'name' => 'Skills',
                                        'value' => set_value('req_skills',$openings['req_skills']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('req_skills'), 'req_skills'); ?>
                                    <?php echo form_error('Skills'); ?>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">  
                                    <?php
                                    echo form_input(array(
                                        'name' => 'Qualification',
                                        'value' => set_value('Qualification',$openings['req_qualification']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('req_qualification'), 'req_qualification', array('class' => 'form-label')); ?>
                                    <?php echo form_error('Qualification'); ?>
                                </div> 
                            </div>
                            <!--<div class="col-sm-6">-->
                            <?php // echo form_label(lang('req_exp_years'), 'req_exp_years'); ?>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'YesrsTo',
                                        'value' => set_value('YesrsTo',$openings['req_exp_years_to']),
                                    ));
                                    ?> 

                                    <?php echo form_label(lang('to'), 'to'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'YearsFrom',
                                        'value' => set_value('YearsFrom',$openings['req_exp_years_from']),
                                    ));
                                    ?> 

                                    <?php echo form_label(lang('from'), 'from'); ?>
                                </div> 
                            </div>
                        


                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $emp_status, set_value('emp_type', $openings['emp_type'])); ?>
                                <?php echo form_label(lang('emp_status_id'), 'emp_status_id'); ?>
                                <?php echo form_error('emp_status_id'); ?>
                            </div>                             
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">


                                <?php echo form_dropdown(array('id' => 'emp_priority_id', 'name' => 'emp_priority_id'), $priority, set_value('req_priority', $openings['req_priority'])); ?>

                                <?php echo form_label(lang('priority'), 'priority'); ?>
                                <?php echo form_error('emp_priority_id'); ?>
                            </div>
                        </div>
                        
                                                <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_dropdown(array('id' => 'approver', 'name' => 'approver'), $aprrover_list, set_value('approver1', $openings['approver1'])); ?>
                                <?php echo form_label(lang('approver'), 'approver'); ?>
                                <?php echo form_error('opening_status'); ?>
                            </div> 
                        </div>

<!--                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_dropdown(array('id' => 'opening_status', 'name' => 'opening_status'), $opening_status, set_value('opening_status', $openings['opening_status'])); ?>
                                <?php echo form_label(lang('opening_status'), 'opening_status'); ?>
                                <?php echo form_error('opening_status'); ?>
                            </div> 
                        </div>-->

                        <div class="col-sm-6">
                            <div class="input-field">
                                <input type="submit" name="add">
                            </div> 
                        </div>
</div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--  panel end here -->
    </div>
</div>
</div>
<script>
    $.ajax({
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });

    /*on load set dpartment & jobtitle names*/
    //        if ($("#jobtitle_id option:selected").text() != "") {
    //            $('#jobtitle_name').val($("#jobtitle_id option:selected").text());
    //        }
    if ($("#department_id option:selected").text() != "") {
        $('#department_name').val($("#department_id option:selected").text());
    }
    var department_id = $("select#department_id option:selected").val();
    $.ajax({
        type: "POST",
        url: '<?php echo base_url(); ?>recruitment/getPositionName',
        data: {'department_id': department_id},
        success: function (data) {
            //  $('select[name="reporting_manager"]').show();
            $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
            $('#reporting_manager').material_select();
        }
    });

    $('select[name="department_id"]').change(function () {
        var department_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>recruitment/getReportingManager',
            data: {'department_id': department_id},
            success: function (data) {
                $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                $('#reporting_manager').material_select();
                $('select[name="approver"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                $('#approver').material_select();
            }
        });

    });

    $('select[name="jobtitle_id"]').change(function () {
        var jobtitle_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>recruitment/getPositionName',
            data: {'jobtitle_id': jobtitle_id},
            success: function (data) {
                if (data) {
                    $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                    $('#position_id').material_select();
                }
            }
        });
    });



    $('select[name="job_code"]').change(function () {
        var job_code = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>recruitment/getJobTitle',
            data: {'job_code': job_code},
            success: function (data) {
                if (data) {
                    $('select[name="jobtitle_id"]').html(data.content).trigger('liszt:updated').val(jobtitle_id);
                    $('#jobtitle_id').material_select();
                }
            }
        });
    });

</script>


