<!-- modal start -->
            <div class="modal fade" id="addopening-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Add Opening</h4>
                        </div>
                        <div class="modal-body">
                            <div class="user-modal-slim"> 
                                <form class="formValidate" id="formValidate" method="post" action="">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <label for="rocode">Requisition Code*</label>
                                                <input id="rocode" name="rocode"  placeholder="Requisition Code" type="text" data-error=".errorTxt79">
                                                <div class="errorTxt79"></div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <label for="opencdate">Close Date</label>
                                                <input id="opencdate" name="opencdate" class="datepicker"  placeholder="Close Date" type="text" data-error=".errorTxt80">
                                                <div class="errorTxt80"></div>
                                            </div>                                        
                                        </div>

                                        <div class="clearfix"> </div>
                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <label for="ojtitle">Job Title*</label>
                                                <input id="ojtitle" type="text" placeholder="Job Title" name="ojtitle" data-error=".errorTxt81">
                                                <div class="errorTxt81"></div>
                                            </div>                                        
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <label for="ojposition">Position*</label>
                                                <input id="ojposition" type="text" placeholder="Position" name="ojposition" data-error=".errorTxt82">
                                                <div class="errorTxt82"></div>
                                            </div>                                        
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-6">
                                            <label for="odepart">Department*</label>
                                                <select class="browser-default"  id="odepart" name="odepart" data-error=".errorTxt83">
                                                    <option value="" disabled selected>Department</option>
                                                    <option value="1">PHP</option>
                                                    <option value="1">Design</option>
                                                    <option value="2">HR</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt83"></div>
                                                </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <label for="oreptmanager">Reporting Manager*</label>
                                                <select class="browser-default"  id="oreptmanager" name="oreptmanager" data-error=".errorTxt84">
                                                    <option value="" disabled selected>Reporting Manager</option>
                                                    <option value="1">Vishval</option>
                                                    <option value="1">Gandhar</option>
                                                    <option value="2">Mayur</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt84"></div>
                                                </div>
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-6">
                                            <label for="orequposition">Required Position*</label>
                                                <select class="browser-default"  id="orequposition" name="orequposition" data-error=".errorTxt85">
                                                    <option value="" disabled selected>Required Position</option>
                                                    <option value="1">2</option>
                                                    <option value="1">3</option>
                                                    <option value="2">5</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt85"></div>
                                                </div>
                                        </div>       

                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <label for="odescript">Description*</label>
                                                <input id="odescript" name="odescript"  placeholder="Description " type="text" data-error=".errorTxt86">
                                                <div class="errorTxt86"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-6">
                                            <label for="oreqskill">Required Skill*</label>
                                            <select class="browser-default" multiple id="oreqskill" name="oreqskill" data-error=".errorTxt87">                                            
                                                <option value="1">HTML</option>
                                                <option value="2">.Net</option>
                                                <option value="3">Java</option>
                                                <option value="4">Angular JS</option>
                                            </select>
                                            <div class="input-field">
                                                <div class="errorTxt87"></div>
                                            </div>
                                        </div>

                                        <div class="col-sm-6">
                                            <label for="orqualification">Qualification*</label>
                                                <select class="browser-default"  id="orqualification" name="orqualification" data-error=".errorTxt88">
                                                    <option value="" disabled selected>Qualification</option>
                                                    <option value="1">BCA</option>
                                                    <option value="1">MCA</option>
                                                    <option value="2">BE</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt88"></div>
                                                </div>
                                        </div>                                       
                                        <div class="clearfix"></div>

                                        <div class="col-sm-3">                                          
                                            <label for="oyexperience">Experience*</label>
                                                <select class="browser-default"  id="oyexperience" name="oyexperience" data-error=".errorTxt89">
                                                    <option value="" disabled selected>Year</option>
                                                    <option value="1">1 Year</option>
                                                    <option value="1">2 Year</option>
                                                    <option value="2">BE</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt89"></div>
                                                </div>
                                        </div>  
                                            
                                        <div class="col-sm-3">                                          
                                            <label for="omexperience">&nbsp;</label>
                                                <select class="browser-default"  id="omexperience" name="omexperience" data-error=".errorTxt90">
                                                    <option value="" disabled selected>Month</option>
                                                    <option value="1">1 Month</option>
                                                    <option value="1">2 Month</option>
                                                    <option value="2">5 Month</option> 
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt90"></div>
                                                </div>
                                        </div>

                                        <div class="col-sm-6">                                          
                                            <label for="oemployment">Employment Status*</label>
                                                <select class="browser-default"  id="oemployment" name="oemployment" data-error=".errorTxt91">
                                                    <option value="" disabled selected>Employment Status</option>
                                                    <option value="1">Full Time</option>
                                                    <option value="1">Part Time</option>
                                                </select>       
                                                <div class="input-field">
                                                    <div class="errorTxt91"></div>
                                                </div>
                                        </div>

                                        <div class="clearfix"></div>

                                        <div class="col-sm-6">
                                            <label for="opriority">Priority*</label>
                                            <select class="browser-default"  id="opriority" name="opriority" data-error=".errorTxt92">
                                                <option value="" disabled selected>Priority</option>
                                                <option value="1">High</option>
                                                <option value="1">Medium</option>
                                                <option value="2">Low</option> 
                                            </select>       
                                            <div class="input-field">
                                                <div class="errorTxt92"></div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="oapprover">Approver*</label>
                                            <select class="browser-default"  id="oapprover" name="oapprover" data-error=".errorTxt93">
                                                <option value="" disabled selected>Approver</option>
                                                <option value="1">Manager</option>
                                                <option value="1">Team Leader</option>
                                                <option value="2">VP</option> 
                                            </select>       
                                            <div class="input-field">
                                                <div class="errorTxt93"></div>
                                            </div>
                                        </div>                                     
                                       
                                        <div class="clearfix"></div>

                                        <div class="col-sm-12 padding-top-10">
                                            <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                            <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                        </div>
                                    </div>
                                </form>
                           </div>
                        </div>                                                    
                    </div>
                </div>
            </div>
            <!-- modal end -->