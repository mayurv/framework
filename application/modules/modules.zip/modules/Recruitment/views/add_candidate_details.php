<div class="row"> 
    <div class="col-sm-12">
        <div class="w-panel-bg">

            <!--  panel start here -->
            <div class="panel panel-default">
                <div class="panel-heading all-padding-10">
                    <div class="p-title">Add Opening</div>
                </div>

                <div class="panel-body all-padding-0">
                    <div class="office-info-1">
                        <?php
                        //var_dump($openings);
                        echo form_open('recruitment/addCandidate/',array('id'=>'form_addCandidate_id','class'=>'form_addCandidate_id'));
                        ?>
                        <?php echo (isset($flashdata) ? set_flashdata($flashdata) : '') ?>
                        <?php echo $this->session->flashdata('msg'); ?>
                        <input type="hidden" name="requisition_id" value="<?php echo $openings['reuisition_id'] ?>">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                                        echo form_input(array(
                                            'name' => 'reqcode_code',
                                            'class' => 'validate',
                                            'value' => set_value('requisition_id', $openings['requisition_id']),
                                        ));
                                    } else {
                                        ?>
                                        <?php
                                        echo form_input(array(
                                            'name' => 'reqcode_id',
                                            'class' => 'validate',
                                            'value' => $req_id
                                        ));
                                    }
                                    ?>
                                    <?php echo form_label(lang('requisition'), 'requisition'); ?>
                                    <?php echo form_error('requisition'); ?>

                                </div>
                            </div> 

                            <div class="col-sm-6">
                                <div class="input-field">


                                    <?php
                                    $options = array();
                                    foreach ($business_entity_list as $category)
                                        $options[$category['id']] = $category['title'];
                                    echo form_dropdown(array('id' => 'business_entity_id', 'name' => 'business_entity_id'), $options, set_value('business_entity_id', $openings['business_entity_id']));
                                    ?>



                                    <?php echo form_label(lang('source'), 'source'); ?>
                                    <?php echo form_error('source'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'candidate_firstname',
                                        'class' => 'validate',
                                        'value' => set_value('candidate_firstname', $openings['candidate_firstname']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('candidate_firstname'), 'candidate_firstname', array('data-error' => 'please enter valid email')); ?>
                                    <?php echo form_error('candidate_firstname'); ?>
                                </div> 
                            </div> 

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'candidate_lastname',
                                        'class' => 'validate',
                                        'value' => set_value('candidate_lastname', $openings['candidate_lastname']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('candidate_lastname'), 'candidate_lastname'); ?>
                                    <?php echo form_error('candidate_lastname'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'emailid',
                                        'class' => 'validate',
                                        'value' => set_value('emailid', $openings['emailid']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('emailid'), 'emailid'); ?>
                                    <?php echo form_error('emailid'); ?>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'contact_number',
                                        'class' => 'validate',
                                        'value' => set_value('contact_number', $openings['contact_number']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('contact_number'), 'contact_number'); ?>
                                    <?php echo form_error('contact_number'); ?>
                                </div>
                            </div>



                            <!--                            <div class="col-sm-6">
                                                            <div class="input-field">
                            <?php
                            echo form_input(array(
                                'type' => 'text',
                                'name' => 'CandidateResume',
                                'class' => 'validate'
                            ));
                            ?>
                            <?php echo form_label(lang('cand_resume'), 'cand_resume'); ?>
                            <?php echo form_error('cand_resume'); ?>
                            
                                                            </div>
                                                        </div>-->


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'qualification',
                                        'class' => 'validate',
                                        'value' => set_value('qualification', $openings['qualification']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('qualification'), 'qualification'); ?>
                                    <?php echo form_error('qualification'); ?>
                                </div>
                            </div>    


                            <div class="col-md-12">
                                <?php echo form_label(lang('year_experience'), 'year_experience'); ?>
                                <?php echo form_error('year_experience'); ?>
                            </div>

                            <div class="col-md-6">

                                <div class="col-md-3">
                                    <div class="input-field ">

                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'yrsexp',
                                            'placeholder' => 'years',
                                            'class' => 'validate',
                                            'value' => set_value('years_exp', $openings['years_exp']),
                                        ));
                                        ?>

                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="input-field">

                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'mnthsexp',
                                            'placeholder' => 'months',
                                            'class' => 'validate',
                                            'value' => set_value('month_exp', $openings['months_exp']),
                                        ));
                                        ?>

                                    </div>
                                </div>

                            </div> 


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'skillset',
                                        'class' => 'validate',
                                        'value' => set_value('skillset', $openings['skillset']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('skillset'), 'skillset'); ?>
                                    <?php echo form_error('skillset'); ?>
                                </div>
                            </div>

                            <!--
                                                        <div class="col-sm-6">
                                                            <div class="input-field">
                            <?php
                            echo form_input(array(
                                'type' => 'text',
                                'name' => 'EducationSummary',
                                'class' => 'validate'
                            ));
                            ?>
                            <?php //echo form_label(lang('education_summary'), 'education_summary'); ?>
                            <?php //echo form_error('education_summary'); ?>
                                                            </div>
                                                        </div>-->

                            <!--                            <div class="col-sm-6">
                                                            <div class="input-field">
                            <?php
                            echo form_input(array(
                                'type' => 'text',
                                'name' => 'Summary',
                                'class' => 'validate'
                            ));
                            ?>
                            <?php echo form_label(lang('summary'), 'summary'); ?>
                            <?php echo form_error('summary'); ?>
                                                            </div>
                                                        </div>-->


                            <!--                            <div class="col-sm-6">
                                                            <div class="input-field">
                            <?php
//              
                            $option = array('Select Candidate Status');
                            foreach ($candidate as $res)
                                $option[$res['id']] = $res['cand_status'];
//                var_dump($option);die;
                            echo form_dropdown(array('id' => '', 'name' => 'candstatus'), $option);
                            ?>
                            <?php echo form_label(lang('cand_status'), 'cand_status'); ?>
                            <?php echo form_error('cand_status'); ?>
                                                            </div>
                                                        </div>     -->


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'CurrentCctc',
                                        'class' => 'validate',
                                        'value' => set_value('current_ctc', $openings['current_ctc']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('current_ctc'), 'current_ctc'); ?>
                                    <?php echo form_error('current_ctc'); ?>
                                </div>
                            </div>   


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'ExpectedCtc',
                                        'class' => 'validate',
                                        'value' => set_value('expected_ctc', $openings['expected_ctc']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('expected_ctc'), 'expected_ctc'); ?>
                                    <?php echo form_error('expected_ctc'); ?>
                                </div>
                            </div>   


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'cand_location',
                                        'class' => 'validate',
                                        'value' => set_value('cand_location', $openings['cand_location']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('cand_location'), 'cand_location'); ?>
                                    <?php echo form_error('cand_location'); ?>
                                </div>
                            </div>    


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    $option = array();
                                    foreach ($country as $res)
                                        $option[$res['id']] = $res['countryname'];

                                    echo form_dropdown(array('id' => 'countryname', 'name' => 'countryname'), $option, set_value('country', $openings['country']));
                                    ?>
                                    <?php echo form_label(lang('country'), 'country'); ?>
                                    <?php echo form_error('country'); ?>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    $option = array();
                                    foreach ($state as $res)
                                        $option[$res['id']] = $res['statename'];

                                    echo form_dropdown(array('id' => 'statename', 'name' => 'statename'), $option, set_value('state', $openings['state']));
                                    ?>
                                    <?php echo form_label(lang('state'), 'state'); ?>
                                    <?php echo form_error('state'); ?>
                                </div>
                            </div>  

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    $option = array();
                                    foreach ($city as $res)
                                        $option[$res['id']] = $res['cityname'];

                                    echo form_dropdown(array('id' => 'cityname', 'name' => 'cityname'), $option, set_value('city', $openings['city']));
                                    ?>
                                    <?php echo form_label(lang('city'), 'city'); ?>
                                    <?php echo form_error('city'); ?>
                                </div>
                            </div>    



                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'Pincode',
                                        'class' => 'validate',
                                        'value' => set_value('pincode', $openings['pincode']),
                                    ));
                                    ?>
                                    <?php echo form_label(lang('pincode'), 'pincode'); ?>
                                    <?php echo form_error('pincode'); ?>
                                </div>
                            </div>    
                            
                              <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown('interviewer1_id', $interviewer1_list, set_value('interviewer1', $openings['interviewer1']), 'id="interviewer1_id"');
                                    ?>
                                    <?php echo form_label(lang('interviewer1'), 'interviewer1'); ?>
                                    <?php echo form_error('interviewer1'); ?>
                                </div>
                            </div>
                            
                              <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown('interviewer2_id', $interviewer2_list, set_value('interviewer2', $openings['interviewer2']), 'id="interviewer2_id"');
                                    ?>
                                    <?php echo form_label(lang('interviewer2'), 'interviewer2'); ?>
                                    <?php echo form_error('interviewer2'); ?>
                                </div>
                            </div>
                            
                              <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown('hr_id', $hr_list, set_value('hr', $openings['hr']), 'id="hr_id"');
                                    ?>
                                    <?php echo form_label(lang('hr'), 'hr'); ?>
                                    <?php echo form_error('hr_manager'); ?>
                                </div>
                            </div>



                            <!--                            <div class="col-sm-6">
                                                            <div class="input-field">
                            <?php
                            echo form_dropdown(array('id' => '', 'name' => 'isactive'), array('Inactive', 'Active'));
                            ?>	
                            <?php echo form_label(lang('status'), 'status'); ?>
                            
                            
                                                            </div>
                            
                                                        </div>-->

                            <div class="col-sm-6">
                                <div class="input-field">

                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                </div></div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--  panel end here -->
    </div>
</div>
</div>

<script>
    $(document).ready(function () {


        $("#reqcode_id").change(function () {



            var reqcode_id = $("select#reqcode_id option:selected").val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>test/get_candidate_list/',
                data: {'reqcode_id': reqcode_id},
                success: function (data) {
//                    if (data) {
//                        $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
//                        $('#position_id').material_select();
//                    }
                }
            });


        });
    });
</script>
