<!--<a href="<?php echo base_url() ?>/recruitment/disp1">click</a>-->
<?php // var_dump($check_client_interview);die;              ?>
<!-- top button bar here --> 
<div class="main-bg all-padding-15">
    <div class="row margin-bottom-10">
        <div class="col-sm-8">
            <h4><?php echo $screening_name ?></h4>
        </div>

        <div class="col-sm-4 padding-top-10 text-right">
            <button class="btn btn-danger btn-sm" data-toggle="modal" href="#addcandidate-1">
                <i class="fa fa-plus-circle"></i> Add Candidate</button>
        </div>
    </div>                          
    <!-- top button bar here -->

    <div class="wrapper1 ">
        <div class="wrapper-content">

            <div class="col-1-8" id="sortable1">
                <small class="text-light-gray">Candidate List <span class="badge badge-purple"><?php echo count($candidates); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">  
                        <ul id="sortable" class="sortable-list btn- connectList agile-list">
                            <?php foreach ($candidates as $r => $result) { ?>  
                                <li class="note element-<?php echo $result['title'] ?>" id="item-<?php echo $result['id'] ?>">  
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    <a title="Click for Quick View"  data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group btn-border">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>

                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a title="Edit Candidate" data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a title="Delete Candidate" data-toggle="modal" href="<?php echo base_url() . 'recruitment/delete_candidate/' . $result['id'] . '/' . $result['requisition_id'] ?>">Delete</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                </li>

                            <?php } ?>

                        </ul>

                    </div>
                </div>
            </div>

            <div class="col-1-8" id="sortable2">
                <small class="text-light-gray">Interviewer One <span class="badge badge-purple"><?php echo count($candidates1); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-1" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates1)) {
                                foreach ($candidates1 as $r => $result) {
                               // var_dump($result);
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">          
                                        <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                        <a title="Click for Quick View" data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">                                                
                                                    <!--<li><a data-toggle="modal" href="#req<?php // echo $result['requisition_id']             ?>modal_<?php echo $result['id'] ?>">Skip Round</a></li>-->
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>
                                                    <!--<li><a data-toggle="modal" href="#recruitment-feedback1_<?php echo $result['id'] ?>">Feedback</a></li>-->
                                                    <?php if (isset($result['schedule_details']) && ($result['schedule_details']['schedule_id'] != $result['position'] ) && $result['round_status'] != 'FeedbackReject') { ?>
                                                        <li><a data-toggle="modal" href="#recruitment-schedule1_<?php echo $result['id'] ?>">Schedule</a></li>
                                                    <?php } ?>

                                                    <?php
                                                    $flag = '';
                                                    if (isset($result['schedule_details']['reschedule_details'][0])) {
                                                        ?>                                                    
                                                        <?php // var_dump($result['schedule_details']['reschedule_details'][0]);die;?>
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['reschedule_details'][0]['res_interview_date'] . ' ' . $result['schedule_details']['reschedule_details'][0]['res_interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'R';
                                                        ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule1_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                        <?php }
                                                        ?>
                                                    <?php } if (($result['schedule_details']['round_status'] == 'schedule')) { ?>  
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['interview_date'] . ' ' . $result['schedule_details']['interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'S';
                                                        ?>
                                                        <?php //} ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule1_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">
                                            <?php if ($result['round_skipstatus'] == 1) { ?>
                                                <span class="skip_status">
                                                    <a class="text-ccc" data-toggle="modal" href="#req<?php echo $result['requisition_id'] ?>modal_<?php echo $result['id'] ?>"><blink id="" title="Skip this round">Skip </blink> | </a> 
                                                </span>  
                                            <?php } ?>
                                            <?php if (isset($result['round_status']) || isset($result['round_skipDetails'])) { ?>
                                                <?php if (($result['firstround_status'] != null && $result['firstround_status'] != '0') || ($result['round_status'] != null && $result['round_status'] != '0') || ($result['reschedule_status'] != null && $result['reschedule_status'] != '0' ) || ($result['round_skipDetails'] != null && $result['round_skipDetails'] != '0' )) { ?>
                                                    <a data-toggle="modal" href="#recruitment-feedback1_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           

                                                <?php } else {
                                                    ?>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-1-8" id="sortable3">
                <small class="text-light-gray">Interviewer Two <span class="badge badge-purple"><?php echo count($candidates2); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-2" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates2)) {
                                foreach ($candidates2 as $r => $result) {
                                    //var_dump() ;
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                        <a title="Click for Quick View" data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>
                                                    <!--<li><a data-toggle="modal" href="#recruitment-feedback2_<?php echo $result['id'] ?>">Feedback</a></li>-->
                                                    <?php if (isset($result['schedule_details']) && ($result['schedule_details']['schedule_id'] != $result['position'] ) && $result['round_status'] != 'FeedbackReject') { ?>
                                                        <li><a data-toggle="modal" href="#recruitment-schedule2_<?php echo $result['id'] ?>">Schedule</a></li>
                                                    <?php } ?>

                                                    <?php
                                                    $flag = '';
                                                    if (isset($result['schedule_details']['reschedule_details'][0])) {
                                                        ?>                                                    
                                                        <?php // var_dump($result['schedule_details']['reschedule_details'][0]);die;?>
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['reschedule_details'][0]['res_interview_date'] . ' ' . $result['schedule_details']['reschedule_details'][0]['res_interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'R';
                                                        ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule2_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                        <?php }
                                                        ?>
                                                        <?php
                                                    } if (isset($result['schedule_details']['round_status']))
                                                        if (($result['schedule_details']['round_status'] == 'schedule')) {
                                                            ?>  
                                                            <?php
                                                            $currentDate = new DateTime();
                                                            $currentDate = $currentDate->format('Y-m-d');
                                                            $scheduleDate = $result['schedule_details']['interview_date'] . ' ' . $result['schedule_details']['interview_time'];

                                                            $scheduleDate = new DateTime($scheduleDate);
                                                            $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                            $scheduleDate = $scheduleDate->format('Y-m-d');
                                                            $flag = 'S';
                                                            ?>
                                                            <?php //} ?>
                                                            <?php if ($scheduleDate < $currentDate) { ?>
                                                                <li><a data-toggle="modal" href="#recruitment-reschedule2_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                            <?php } else { ?>
                                                                <?php
                                                                if ($flag == 'R') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                    <?php
                                                                } if ($flag == 'S') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                                <?php } ?>
                                                                <?php
                                                            }
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">
                                            <?php if ($result['round_skipstatus'] == 2) { ?>
                                                <span class="skip_status">
                                                    <a class="text-ccc" data-toggle="modal" href="#req<?php echo $result['requisition_id'] ?>modal_<?php echo $result['id'] ?>"><blink id="" title="Skip this round">Skip </blink> | </a> 
                                                </span>  
                                            <?php } ?>
                                            <?php if (isset($result['round_status']) || isset($result['round_skipDetails'])) { ?>
                                                <?php if (($result['round_status'] != null && $result['round_status'] != '0') || ($result['round_skipDetails'] != null && $result['round_skipDetails'] != '0' )) { ?>

                                                    <a data-toggle="modal" href="#recruitment-feedback2_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           
                                                <?php } else {
                                                    ?>

                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>

                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-1-8" id="sortable4">
                <small class="text-light-gray">Interviewer Three <span class="badge badge-purple"><?php echo count($candidates3); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-3" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates3)) {
                                foreach ($candidates3 as $r => $result) {
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <?php // if( isset($result['interview_round_details'])) var_dump($result['interview_round_details']);       ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id_<?php echo $result['id'] ?>" name="modal_id_<?php echo $result['id'] ?>" value="<?php echo $result['id'] ?>">
                                <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                        <a title="Click for Quick View" data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">                                                
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>
                                                    <!--<li><a data-toggle="modal" href="#recruitment-feedback3_<?php echo $result['id'] ?>">Feedback</a></li>-->

                                                    <?php if (isset($result['schedule_details']) && ($result['schedule_details']['schedule_id'] != $result['position'] ) && $result['round_status'] != 'FeedbackReject') { ?>
                                                        <li><a data-toggle="modal" href="#recruitment-schedule3_<?php echo $result['id'] ?>">Schedule</a></li>
                                                    <?php } ?>

                                                    <?php
                                                    $flag = '';
                                                    if (isset($result['schedule_details']['reschedule_details'][0])) {
                                                        ?>                                                    
                                                        <?php // var_dump($result['schedule_details']['reschedule_details'][0]);die;?>
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['reschedule_details'][0]['res_interview_date'] . ' ' . $result['schedule_details']['reschedule_details'][0]['res_interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'R';
                                                        ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule3_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                        <?php }
                                                        ?>
                                                    <?php } if (($result['schedule_details']['round_status'] == 'schedule')) { ?>  
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['interview_date'] . ' ' . $result['schedule_details']['interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'S';
                                                        ?>
                                                        <?php //} ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule3_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">
                                            <?php if ($result['round_skipstatus'] == 3) { ?>
                                                <span class="skip_status">
                                                    <a class="text-ccc" data-toggle="modal" href="#req<?php echo $result['requisition_id'] ?>modal_<?php echo $result['id'] ?>"><blink id="" title="Skip this round">Skip </blink> | </a> 
                                                </span>  
                                            <?php } ?>
                                            <?php if (isset($result['round_status']) || isset($result['round_skipDetails'])) { ?>
                                                <?php if (($result['round_status'] != null && $result['round_status'] != '0') || ($result['round_skipDetails'] != null && $result['round_skipDetails'] != '0' )) { ?>

                                                    <a data-toggle="modal" href="#recruitment-feedback3_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           
                                                <?php } else {
                                                    ?>

                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div> 
            <?php if ($check_client_interview[0]['client_interview_status'] == 1) { ?>
                <div class="col-1-8" id="sortable5">
                    <small class="text-light-gray">Client <span class="badge badge-purple"><?php echo count($candidates4); ?></span></small>
                    <div class="ibox">
                        <div class="ibox-content">
                            <ul id="list-4" class="sortable-list connectList agile-list">
                                <?php
                                if (isset($candidates4)) {
                                    foreach ($candidates4 as $r => $result) {
                                        ?>  
                                        <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                        <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                        <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                   <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                        <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                            <a  title="Click for Quick View" data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                            &nbsp; <?php echo $result['candidate_name']; ?>                  
                                            <div class="pull-right">
                                                <div class="btn-group btn-border">
                                                    <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                        <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                    </a>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li><a data-toggle="modal" href="#req<?php echo $result['requisition_id'] ?>modal_<?php echo $result['id'] ?>">Skip Round</a></li>
                                                        <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>
                                                        <!--<li><a data-toggle="modal" href="#recruitment-feedback4_<?php echo $result['id'] ?>">Feedback</a></li>-->
                                                        <?php if (isset($result['schedule_details']) && ($result['schedule_details']['schedule_id'] != $result['position'] ) && $result['round_status'] != 'FeedbackReject') { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-schedule4_<?php echo $result['id'] ?>">Schedule</a></li>
                                                        <?php } ?>

                                                        <?php
                                                        $flag = '';
                                                        if (isset($result['schedule_details']['reschedule_details'][0])) {
                                                            ?>                                                    
                                                            <?php // var_dump($result['schedule_details']['reschedule_details'][0]);die;?>
                                                            <?php
                                                            $currentDate = new DateTime();
                                                            $currentDate = $currentDate->format('Y-m-d');
                                                            $scheduleDate = $result['schedule_details']['reschedule_details'][0]['res_interview_date'] . ' ' . $result['schedule_details']['reschedule_details'][0]['res_interview_time'];

                                                            $scheduleDate = new DateTime($scheduleDate);
                                                            $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                            $scheduleDate = $scheduleDate->format('Y-m-d');
                                                            $flag = 'R';
                                                            ?>
                                                            <?php if ($scheduleDate < $currentDate) { ?>
                                                                <li><a data-toggle="modal" href="#recruitment-reschedule4_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                            <?php } else { ?>
                                                                <?php
                                                                if ($flag == 'R') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                    <?php
                                                                } if ($flag == 'S') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                                <?php } ?>
                                                            <?php }
                                                            ?>
                                                        <?php } if (($result['schedule_details']['round_status'] == 'schedule')) { ?>  
                                                            <?php
                                                            $currentDate = new DateTime();
                                                            $currentDate = $currentDate->format('Y-m-d');
                                                            $scheduleDate = $result['schedule_details']['interview_date'] . ' ' . $result['schedule_details']['interview_time'];

                                                            $scheduleDate = new DateTime($scheduleDate);
                                                            $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                            $scheduleDate = $scheduleDate->format('Y-m-d');
                                                            $flag = 'S';
                                                            ?>
                                                            <?php //} ?>
                                                            <?php if ($scheduleDate < $currentDate) { ?>
                                                                <li><a data-toggle="modal" href="#recruitment-reschedule4_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                            <?php } else { ?>
                                                                <?php
                                                                if ($flag == 'R') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                    <?php
                                                                } if ($flag == 'S') {
                                                                    $flag = '';
                                                                    ?>
                                                                    <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                                <?php } ?>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                </div>
                                            </div> 
                                            <div class="margin-top-20 pull-right margin-right-20">
                                                <?php if ($result['round_skipstatus'] == 4) { ?>
                                                    <span class="skip_status">
                                                        <a class="text-ccc" data-toggle="modal" href="#req<?php echo $result['requisition_id'] ?>modal_<?php echo $result['id'] ?>"><blink id="" title="Skip this round">Skip </blink> | </a> 
                                                    </span>  
                                                <?php } ?>
                                                <?php if (isset($result['round_status']) || isset($result['round_skipDetails'])) { ?>
                                                    <?php if (($result['round_status'] != null && $result['round_status'] != '0') || ($result['round_skipDetails'] != null && $result['round_skipDetails'] != '0' )) { ?>

                                                        <a data-toggle="modal" href="#recruitment-feedback4_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           
                                                    <?php } else {
                                                        ?>

                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </li>

                                        <?php
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php } ?>

            <div class="col-1-8" id="sortable6">
                <small class="text-light-gray">HR <span class="badge badge-purple"><?php echo count($candidates5); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-5" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates5)) {
                                foreach ($candidates5 as $r => $result) { //var_dump($result);
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                        <a title="Click for Quick View"  data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>
                                                    <!--<li><a data-toggle="modal" href="#recruitment-feedback5_<?php echo $result['id'] ?>">Feedback</a></li>-->
                                                    <?php if (isset($result['schedule_details']) && ($result['schedule_details']['schedule_id'] != $result['position'] ) && $result['round_status'] != 'FeedbackReject') { ?>
                                                        <li><a data-toggle="modal" href="#recruitment-schedule5_<?php echo $result['id'] ?>">Schedule</a></li>
                                                    <?php } ?>

                                                    <?php
                                                    $flag = '';
                                                    if (isset($result['schedule_details']['reschedule_details'][0])) {
                                                        ?>                                                    
                                                        <?php // var_dump($result['schedule_details']['reschedule_details'][0]);die;?>
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['reschedule_details'][0]['res_interview_date'] . ' ' . $result['schedule_details']['reschedule_details'][0]['res_interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'R';
                                                        ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule5_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                        <?php }
                                                        ?>
                                                    <?php } if (($result['schedule_details']['round_status'] == 'schedule')) { ?>  
                                                        <?php
                                                        $currentDate = new DateTime();
                                                        $currentDate = $currentDate->format('Y-m-d');
                                                        $scheduleDate = $result['schedule_details']['interview_date'] . ' ' . $result['schedule_details']['interview_time'];

                                                        $scheduleDate = new DateTime($scheduleDate);
                                                        $scheduleDate = $scheduleDate->modify("+12 hours");
//                                                    $diff = $currentDate->diff($scheduleDate);
                                                        $scheduleDate = $scheduleDate->format('Y-m-d');
                                                        $flag = 'S';
                                                        ?>
                                                        <?php //} ?>
                                                        <?php if ($scheduleDate < $currentDate) { ?>
                                                            <li><a data-toggle="modal" href="#recruitment-reschedule5_<?php echo $result['id'] ?>"><span class="text-orange">ReSchedule</span></a></li>

                                                        <?php } else { ?>
                                                            <?php
                                                            if ($flag == 'R') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already ReScheduled</a></li>
                                                                <?php
                                                            } if ($flag == 'S') {
                                                                $flag = '';
                                                                ?>
                                                                <li><a data-toggle="modal" class="text-light-gray">Already Scheduled</a></li>
                                                            <?php } ?>
                                                            <?php
                                                        }
                                                    }
                                                    ?>                                   
                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">

                                            <?php if (isset($result['round_status'])) { ?>
                                                <?php if (($result['round_status'] != null && $result['round_status'] != '0') || ($result['round_skipDetails'] != null && $result['round_skipDetails'] != '0' )) { ?>


                                                    <a data-toggle="modal" href="#recruitment-feedback5_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback">  </i></a>                                           
                                                <?php } else {
                                                    ?>

                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                    </li>
                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div> 

            <div class="col-1-8" id="sortable7">
                <small class="text-light-gray">Offer <span class="badge badge-purple"><?php echo count($candidates6); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-6" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates6)) {
                                foreach ($candidates6 as $r => $result) {
                                    //  var_dump($result);
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    
                                 <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                        <a title="Click for Quick View"  data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>

                                                </a>
                                                <ul class="dropdown-menu pull-right">
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>

                                                    <?php if ($result['interview_round_details'][0]['round_status'] == 'Offer Sent') { ?>    
                                                        <li>
                                                            <a class="text-orange" onclick="" href="<?php echo base_url() . 'recruitment/download_offer/' . $result['id'] ?>">Alredy Send</a>
                                                        </li>
                                                        <li>
                                                            <a onclick="return acceptOffer(<?php echo $result['id'] ?>)">Accept Offer </a>
                                                            <form id="for_accept_offer_<?php echo $result['id'] ?>" method="post" action="<?php echo base_url() . 'recruitment/accept_offer/' . $result['id'] ?>">
                                                                <input type="hidden" value="<?php echo $result['id'] ?>" name="candidate_id">
                                                                <input type="hidden" value="<?php echo $result['requisition_id'] ?>" name="req_id">
                                                                <input type="hidden" value="<?php echo $result['schedule_details']['interview_round_number'] ?>" name="interview_round_number">
                                                                <input type="hidden" value="<?php echo $result['position'] ?>" name="position">
                                                            </form>
                                                        </li>

                                                        <?php //if($result['interview_round_details'][0]['round_status']=='Send Offer' ) {   ?>        
                                                        <li><a data-toggle="modal" href="#reject_offer_<?php echo $result['id'] ?>">Reject Offer</a></li>

                                                        <?php
                                                        if (isset($result['interview_hold_details']) && !empty($result['interview_hold_details'])) {
                                                            // var_dump($result['interview_hold_details']);
                                                            ?>
                                                            <li><a data-toggle="modal" class="text-orange" href="">Alredy on Hold </a></li>    

                                                        <?php } else { ?>
                                                            <li><a data-toggle="modal" href="#hold_offer<?php echo $result['id'] ?>">Hold Offer</a></li>    
                                                        <?php } ?>    
                                                    <?php } else { ?>

                                                                                    <!--<li><a data-toggle="modal" href="#recruitment-feedback6_<?php echo $result['id'] ?>">Feedback</a></li>-->

                                                        <li>
                                                            <a onclick="return sendOffer(<?php echo $result['id'] ?>)" href="">Send Offer</a>
                                                            <form id="for_send_offer_<?php echo $result['id'] ?>" method="post" action="<?php echo base_url() . 'recruitment/accept_offer/' . $result['id'] ?>">
                                                                <input type="hidden" value="<?php echo $result['id'] ?>" name="candidate_id">
                                                                <input type="hidden" value="<?php echo $result['requisition_id'] ?>" name="req_id">
                                                                <input type="hidden" value="<?php echo $result['schedule_details']['interview_round_number'] ?>" name="interview_round_number">
                                                                <input type="hidden" value="<?php echo $result['position'] ?>" name="position">
                                                            </form>
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">

                                            <a data-toggle="modal" href="#recruitment-feedback6_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           

                                        </div>
                                    </li>

                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-1-8" id="sortable8">
                <small class="text-light-gray">Joining <span class="badge badge-purple"><?php echo count($candidates7); ?></span></small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-7" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates7)) {
                                foreach ($candidates7 as $r => $result) {
                                    ?>  
                                    <?php $result['schedule_details'] = $result['schedule_details'][0] ?>
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" id="modal_id" name="modal_id" value="<?php echo $result['id'] ?>">
                                    
                                <?php if ($result['round_completion'] == 'false') { 
                                         $result['title'] = "btn-warning"; }
                                    else if ($result['round_completion'] == 'true') {                                    
                                         $result['title'] = "btn-success";  } ?>
                                    <li class="note <?php echo $result['round_status'] ?> element-<?php echo $result['title'] ?> <?php echo $result['round_word_status'] ?>" id="item-<?php echo $result['id'] ?>">                                  
                                        <a title="Click for Quick View" data-toggle="modal" href="#candidate_details0_<?php echo $result['id'] ?>" title="" class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></a>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group btn-border">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">
                                                    <li><a data-toggle="modal" href="#recruitment-reject<?php echo $result['requisition_id'] ?>_<?php echo $result['id'] ?>">Reject</a></li>

                                                                                                        <!--<li><a data-toggle="modal" href="#recruitment-feedback7_<?php echo $result['id'] ?>">Feedback</a></li>-->

                                                    <li>
                                                        <a onclick="return register_portal(<?php echo $result['id'] ?>)">Register </a>
                                                        <form id="register_portal_<?php echo $result['id'] ?>" method="post" action="<?php echo base_url() . 'recruitment/register_portal/' . $result['id'] ?>">
                                                            <input type="hidden" value="<?php echo $result['id'] ?>" name="candidate_id">
                                                            <input type="hidden" value="<?php echo $result['requisition_id'] ?>" name="req_id">
                                                            <input type="hidden" value="<?php echo $result['schedule_details']['interview_round_number'] ?>" name="interview_round_number">
                                                            <input type="hidden" value="<?php echo $result['position'] ?>" name="position">
                                                        </form>
                                                    </li>



                                                </ul>
                                            </div>
                                        </div> 
                                        <div class="margin-top-20 pull-right margin-right-20">

                                            <?php if (isset($result['round_status'])) { ?>
                                                <?php if ($result['round_status'] != null && $result['round_status'] != '0') { ?>


                                                    <a data-toggle="modal" href="#recruitment-feedback7_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> </i></a>                                           


                                                <?php } else {
                                                    ?>

                                                    <?php
                                                }
                                            }
                                            ?>
                                        </div>

                                    </li>

                                    <?php
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</div>
<?php $this->load->view('_addCandidate'); ?>
<?php //$this->load->view('_viewCandidate');      ?>
<?php $this->load->view('_editCandidate'); ?>
<?php $this->load->view('modal/_skip_modal'); ?>
<?php $this->load->view('modal/_hold_offer'); ?>
<?php $this->load->view('modal/_accept_offer'); ?>
<?php $this->load->view('modal/_reject_offer'); ?>
<?php $this->load->view('modal/_reject_modal'); ?>
<?php $this->load->view('modal/_candidate_details'); ?>
<?php $this->load->view('_feedback'); ?>
<?php $this->load->view('_schedule_interview'); ?>
<?php $this->load->view('modal/_reschedule_interview'); ?>
<script type="text/javascript" src="<?php echo base_url() ?>plugins/drag-drop/js/jquery-ui-1.10.4.min.js"></script>
<script type="text/javascript">
                                                            /* Date picker validation Fucntions */
                                                            $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
                                                                    showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
                                                            });
</script>

<script>



    function sendOffer(candidate_id)
    {
        var formData = $('#for_send_offer_' + candidate_id).serialize();
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/send_offer',
            type: 'POST',
            data: formData,
            success: function (data) {
                if (data == '1')
                    showErrorMessage("Offer Send.");
                window.location.reload();
            }
        });
    }

    function acceptOffer(candidate_id)
    {
        var formData = $('#for_accept_offer_' + candidate_id).serialize();
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/accept_offer',
            type: 'POST',
            data: formData,
            success: function (data) {
                if (data == '1')
                    showErrorMessage("Offer Accepted.");
                window.location.reload();
            }
        });
    }

    function register_portal(candidate_id)
    {
        var formData = $('#register_portal_' + candidate_id).serialize();
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/register_portal',
            type: 'POST',
            data: formData,
            success: function (data) {
                showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
                window.location.reload();
            }
        });
    }


    function save_interviewRound(item_id, drag_id, req_id)
    {
        var check_round = '<?php echo $check_client_interview[0]['client_interview_status']; ?>';
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/save_interviewRound',
            type: 'POST',
            data: {'round_id': item_id, 'candidate_id': drag_id, 'req_id': req_id, 'check_round': check_round},
            success: function (data) {
                window.location.reload();
                //  alert(data);
                //  console.log(data);

            }
        });
    }
    var check = 1;
    function save_sortable(serial)
    {
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/disp',
            type: 'POST',
            data: serial,
            success: function (data) {
                alert(data);
                console.log(data);
            }
        });
    }

    $(document).ready(function () {
        //inititally : candidate all list
        $("#sortable").sortable({
            connectWith: "#list-1",
            drop: function (event, ui) {
                alert('test');
            },
            receive: function (e, ui) {
                alert('test');
            }
        }).disableSelection();

        /*for dragable skip*/

        /*candidate - list for restriction*/
        $("#list-1").sortable({
            connectWith: "#list-2",
            beforeStop: function (event, ui) {
            },
            stop: function (e, ui) {
                var check_status = $('#all_completed').val();
                var round_status = '<?php $result['round_status'] ?>';
                var round_comp = $(ui.item).attr("class");
                var round_com = round_comp.split(" ");
                var round_complete = round_com[1];
                var round_status = round_com[3];
                if (round_complete == 1 && round_status != "FeedbackReject") {
                    var item_id = 'list-2';
                    var drag_id = $(ui.item).attr("id");
                    var req_id = $("#req_id").val();
//                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
//                return false;
                    save_interviewRound(item_id, drag_id, req_id);

                }
                else if (round_status === "FeedbackReject") {
                    showErrorMessage("Wrong move : Please Reject Candidate for current round");
                    $("#list-1").sortable('cancel');
                }
                else {
                    showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                    $("#list-1").sortable('cancel');

                }
            },
            receive: function (e, ui) {
                showSuccess("Candidate at First Round");
                var item_id = $(this).attr("id");
                var drag_id = $(ui.item).attr("id");
                var req_id = $("#req_id").val();
//                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
                save_interviewRound(item_id, drag_id, req_id);

            }
        }).disableSelection();

        $("#list-2").sortable({
            connectWith: "#list-3",
            beforeStop: function (event, ui) {
            },
            stop: function (e, ui) {
                var check_status = $('#all_completed').val();

                var round_comp = $(ui.item).attr("class");
                var round_com = round_comp.split(" ");
                var round_complete = round_com[1];
                var round_status = round_com[3];
//               alert(round_status);
                if (round_complete == 2 && round_status != "FeedbackReject") {
//                    alert('ss');
                    var item_id = 'list-3';
                    var drag_id = $(ui.item).attr("id");
                    var req_id = $("#req_id").val();
//                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
//                return false;
                    save_interviewRound(item_id, drag_id, req_id);

                }
                else if (round_status === "FeedbackReject") {
                    showErrorMessage("Wrong move : Please Reject Candidate for current round");
                    $("#list-2").sortable('cancel');
                }
                else {
                    showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                    $("#list-2").sortable('cancel');
                }
            },
        }).disableSelection();


<?php if ($check_client_interview[0]['client_interview_status'] == 1) { ?>

            $("#list-3").sortable({
                connectWith: "#list-4",
                beforeStop: function (event, ui) {
                },
                stop: function (e, ui) {
                    var check_status = $('#all_completed').val();
                    var round_comp = $(ui.item).attr("class");
                    var round_com = round_comp.split(" ");
                    var round_complete = round_com[1];
                    var round_status = round_com[3];
                    if (round_complete == 3 && round_status != "FeedbackReject") {
                        var item_id = 'list-4';
                        var drag_id = $(ui.item).attr("id");
                        var req_id = $("#req_id").val();
                        //                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
                        //                return false;
                        save_interviewRound(item_id, drag_id, req_id);

                    }
                    else if (round_status === "FeedbackReject") {
                        showErrorMessage("Wrong move : Please Reject Candidate for current round");
                        $("#list-3").sortable('cancel');
                    }
                    else {
                        showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                        $("#list-3").sortable('cancel');
                    }
                },
            }).disableSelection();

<?php } else { ?>
            $("#list-3").sortable({
                connectWith: "#list-5",
                beforeStop: function (event, ui) {
                },
                stop: function (e, ui) {
                    var check_status = $('#all_completed').val();
                    var round_comp = $(ui.item).attr("class");
                    var round_com = round_comp.split(" ");
                    var round_complete = round_com[1];
                    var round_status = round_com[3];
                    if (round_complete == 3 && round_status != "FeedbackReject") {
                        var item_id = 'list-5';
                        var drag_id = $(ui.item).attr("id");
                        var req_id = $("#req_id").val();
                        //                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
                        //                return false;
                        save_interviewRound(item_id, drag_id, req_id);

                    }
                    else if (round_status === "FeedbackReject") {
                        showErrorMessage("Wrong move : Please Reject Candidate for current round");
                        $("#list-3").sortable('cancel');
                    }
                    else {
                        showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                        $("#list-3").sortable('cancel');
                    }
                },
            }).disableSelection();
<?php } ?>
<?php if ($check_client_interview[0]['client_interview_status'] == 1) { ?>
            $("#list-4").sortable({
                connectWith: "#list-5",
                beforeStop: function (event, ui) {
                },
                stop: function (e, ui) {
                    var check_status = $('#all_completed').val();
                    var round_comp = $(ui.item).attr("class");
                    var round_com = round_comp.split(" ");
                    var round_complete = round_com[1];
                    var round_status = round_com[3];
                    if (round_complete == 4 && round_status != "FeedbackReject") {
                        var item_id = 'list-5';
                        var drag_id = $(ui.item).attr("id");
                        var req_id = $("#req_id").val();
                        //                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
                        //                return false;
                        save_interviewRound(item_id, drag_id, req_id);

                    }
                    else if (round_status === "FeedbackReject") {
                        showErrorMessage("Wrong move : Please Reject Candidate for current round");
                        $("#list-4").sortable('cancel');
                    }
                    else {
                        showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                        $("#list-4").sortable('cancel');
                    }
                },
            }).disableSelection();
<?php } ?>

        $("#list-5").sortable({
            connectWith: "#list-6",
            beforeStop: function (event, ui) {
            },
            stop: function (e, ui) {
                var check_status = $('#all_completed').val();
                var round_comp = $(ui.item).attr("class");
                var round_com = round_comp.split(" ");
                var round_complete = round_com[1];
                var round_status = round_com[3];
                if (round_complete == 5 && round_status != "FeedbackReject") {
                    var item_id = 'list-6';
                    var drag_id = $(ui.item).attr("id");
                    var req_id = $("#req_id").val();
//                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
//                return false;
                    save_interviewRound(item_id, drag_id, req_id);

                }
                else if (round_status === "FeedbackReject") {
                    showErrorMessage("Wrong move : Please Reject Candidate for current round");
                    $("#list-5").sortable('cancel');
                }
                else {
                    showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                    $("#list-5").sortable('cancel');
                }
            },
            receive: function (e, ui) {
//                var item_id = $(this).attr("id");
//                var drag_id = $(ui.item).attr("id");
//                var req_id = $("#req_id").val();
//                //alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
//                save_interviewRound(item_id, drag_id, req_id);
            }
        }).disableSelection();

        $("#list-6").sortable({
            connectWith: "#list-7",
            beforeStop: function (event, ui) {
            },
            stop: function (e, ui) {
                var check_status = $('#all_completed').val();
                var round_comp = $(ui.item).attr("class");
                var round_com = round_comp.split(" ");
                var round_complete = round_com[1];
                var round_status = round_com[3];
                if (round_complete == 6 && round_status != "FeedbackReject") {
                    var item_id = 'list-7';
                    var drag_id = $(ui.item).attr("id");
                    var req_id = $("#req_id").val();
//                alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
//                return false;
                    save_interviewRound(item_id, drag_id, req_id);

                }
                else if (round_status === "FeedbackReject") {
                    showErrorMessage("Wrong move : Please Reject Candidate for current round");
                    $("#list-6").sortable('cancel');
                }
                else {
                    showErrorMessage("Wrong move : Please Skip or Reject Candidate for current round");
                    $("#list-6").sortable('cancel');
                }
            },
        }).disableSelection();

        $('.wrapper1').slimscroll({
            width: '100%',
            height: '465px',
            axis: 'both'
        });
        //  $('.sortable').sortable({ cancel: '.note' });


    });
//    $(".sortable-list").droppable({
//    disabled: false,
//    out: function ( event, ui ) {
//        $(this).droppable("option", "disabled", false);
//    },
//    drop: function( event, ui ) {
//         $(this).droppable("option", "disabled", true);
//    }
//});

    //to disable sort class="unsortable"

</script> 
<script>
//    var blink_speed = 500;
//    var t = setInterval(function () {
//        var ele = document.getElementById('blinker');
//        ele.style.visibility = (ele.style.visibility == 'hidden' ? '' : 'hidden');
//    }, blink_speed);
</script>









