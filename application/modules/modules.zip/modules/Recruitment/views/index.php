<h1><?php echo lang('index_heading'); ?></h1>
<p><?php echo lang('index_subheading'); ?></p>
<a href="auth/logout">logout</a>
<div id="infoMessage"><?php echo $message; ?></div>

<table cellpadding=0 cellspacing=10>
    <tr>
        <th><?php echo lang('index_fname_th'); ?></th>
        <th><?php echo lang('index_lname_th'); ?></th>
        <th><?php echo lang('index_email_th'); ?></th>
        <th><?php echo lang('index_groups_th'); ?></th>
        <th><?php echo lang('index_status_th'); ?></th>
        <th><?php echo lang('index_action_th'); ?></th>
    </tr>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user->firstname, ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($user->lastname, ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlspecialchars($user->email, ENT_QUOTES, 'UTF-8'); ?></td>
            <td>
                <?php foreach ($user->groups as $group): ?>
                    <?php echo anchor("auth/edit_group/" . $group->id, htmlspecialchars($group->name, ENT_QUOTES, 'UTF-8')); ?><br />
                <?php endforeach ?>
            </td>
            <td><?php echo ($user->active) ? anchor("auth/deactivate/" . $user->id, lang('index_active_link')) : anchor("auth/activate/" . $user->id, lang('index_inactive_link')); ?></td>
            <td><?php echo anchor("auth/edit_user/" . $user->id, 'Edit'); ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<p><?php echo anchor('auth/create_user', lang('index_create_user_link')) ?> |
 <?php echo anchor('masters/create_group', lang('index_create_group_link')) ?> |
 <?php echo anchor('masters/create_role', lang('index_create_role_link')) ?> |
  <?php echo anchor('masters/create_menu', lang('index_create_menu_link')) ?>
 
</p>


<!--@auther: prajwal n-->

<p><?php echo anchor('masters/empl_status', lang('create_status')) ?> |
<?php echo anchor('masters/create_department', lang('create_dept')) ?> |
<?php echo anchor('masters/create_jobtitle', lang('create_jobtitle')) ?> |
<?php echo anchor('masters/create_prefix', lang('create_prefix')) ?> </p>
<p>
<?php echo anchor('masters/create_position', lang('create_position')) ?> |
<?php echo anchor('masters/create_competency', lang('create_competency')) ?> |
<?php echo anchor('masters/create_education', lang('create_education')) ?> |
    
</p>
<p>
<?php echo anchor('masters/create_nationality', lang('create_nationality')) ?> |
<?php echo anchor('masters/create_ethniccode', lang('create_ethniccode')) ?> |
<?php echo anchor('masters/create_language', lang('create_language')) ?> |
<?php echo anchor('masters/create_weekdays', lang('create_weekdays')) ?> |
<?php echo anchor('masters/create_holidaygroups', lang('create_holidaygroups')) ?> |
<?php echo anchor('masters/create_holidaydates', lang('create_holidaydates')) ?> |
</p>

<!--Prajwal N: 18-10-2016-->
<p>
<?php echo anchor('masters/create_gender', lang('create_gender')) ?> |
<?php echo anchor('masters/create_martialstatus', lang('create_martialstatus')) ?> |
</p>
<p>
    <?php echo anchor('masters/create_country', lang('create_country')) ?> |
    <?php echo anchor('masters/create_state', lang('create_state')) ?> |
    <?php echo anchor('masters/create_city', lang('create_city')) ?> |
</p>
