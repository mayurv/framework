<?php
//var_dump($candidate);

header("Content-type: application/vnd.ms-word");
$new_filename = $candidate[0]['candidate_name'].' '.$candidate[0]['deptname'];
$new_filename = str_replace(' ', '_', $new_filename);
header('Content-Disposition: attachment; filename="'.$new_filename.'.doc"');


echo "<html>";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">";
echo "<body>";


echo "<div class='pull-left'>";
echo "<p>".date('d F, Y')."<p>";
echo "<p>".$candidate[0]['candidate_name']."<p>"; 
echo "<p>".$candidate[0]['cand_location']."<p>"; 
echo "<p>".'RE: LETTER OF OFFER OF EMPLOYMENT  :  '.$candidate[0]['positioname'].' ('.$candidate[0]['deptname'].')'."<p>"; 

echo "<p>". 'Dear Mr. /Ms. '.ucwords($candidate[0]['candidate_lastname']). ','.'</p>';

echo "<p>".'Following our recent discussions, we are delighted to offer you the position of Position Title with Our Organization. Our Organization is describe key highlights about your organization. If you join Our Organization, you will become part of a fast-paced and dedicated team that works together to provide our clients with the highest possible level of service and advice.'.'</p>';

echo "<p>".'As a member of Our Organization team, we would ask for your commitment to deliver outstanding quality and results that exceed client expectations. In addition, we expect your personal accountability in all the products, actions, advice and results that you provide as a representative of Our Organization. In return, we are committed to providing you with every opportunity to learn, grow and stretch to the highest level of your ability and potential.'.'</p>';

echo "<p>".'We are confident you will find this new opportunity both challenging and rewarding. The following points outline the terms and conditions we are proposing.'.'</p>';

echo "<p> Title : ".$candidate[0]['positioname'].' ('.$candidate[0]['deptname'].')'."<p>"; 

echo "<p> <span>Start date:</span> <span style='color:red'>Start date</span>"."</span></p>";

echo "<p> <span>Salary:</span> <span style='color:red'>Amount per year</span>"."</span></p>";

echo "<p> <span>Probation: </span> <span style='color:red'>As per probationary policy</span>"."</span></p>";
	
echo "<p> <span>Hours of work: </span> <span style='color:red'>Hours of work per week this position requires</span>"."</span></p>";

echo "<p> We look forward to the opportunity to work with you in an atmosphere that is successful and mutually challenging and rewarding.</p>"; 

echo "<br>";
echo "<p> Sincerely,</p>";

echo "<p>".$candidate[0]['userfullname']."<p>"; 
echo "<p>HR </p>";
echo "<p> Mindwors Software service Ltd</p>";

echo "<br>";
echo "<br>";
echo "<br>";

echo "<p> With the signature below, I accept this offer for employment.</p>";

echo "<p> <span style='width:200px'> ___________________________ </span> <span style='width:200px;margin-left: 70px;}'> ______________________ </span> </p>";
echo "<p> <span style='width:200px;margin-left:50px;}'> ".$candidate[0]['candidate_name']." </span> <span style='width:200px;margin-left: 230px;}'> Date </span> </p>";
							

echo "</div>";
echo "</body>";
echo "</html>";

//var_dump($candidate);die;

?>