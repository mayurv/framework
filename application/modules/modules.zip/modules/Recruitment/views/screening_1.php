<!-- top button bar here -->                                
<div class="add-candidate-bg"> 
    <div class="pull-right">
        <button class="btn btn-default btn-sm" data-toggle="modal" href="#addopening-1"><i class="fa fa-plus-circle"></i> Add Opening</button>
        <button class="btn btn-danger btn-sm" data-toggle="modal" href="#addcandidate-1"><i class="fa fa-plus-circle"></i> Add Candidate</button>
    </div>
</div>                          
<!-- top button bar here -->

<?php
$color = array(
    '0' => 'btn-primary2',
    '1' => 'btn-danger',
    '2' => 'btn-primary',
    '3' => 'btn-info',
    '4' => 'btn-success',
    '5' => 'btn-warning',
    '6' => 'btn-blue',
    '7' => 'btn-warning2',
    '8' => 'btn-primary',
);

//$n=25;
$n = count($candidates);
$col_cnt = count($color);
if ($n > $col_cnt && $n < (2 * $col_cnt)) {
    $color = array_merge($color, $color);
}

if ($n > (2 * $col_cnt) && $n < (3 * $col_cnt)) {
    $color1 = array_merge($color, $color);
    $color = array_merge($color1, $color);
}

if ($n > (3 * $col_cnt) && $n < (4 * $col_cnt)) {
    $color1 = array_merge($color, $color);
    $color2 = array_merge($color1, $color);
    $color = array_merge($color2, $color);
}
?>


<div class="wrapper1 animated fadeInRight">
    <div class="wrapper-content">

        <div class="col-1-8">
            <small>Candidate List</small>
            <div class="ibox">
                <div class="ibox-content">  
                    <ul id="itemul" class="sortable-list btn- connectList agile-list">
                        <?php foreach ($candidates as $r => $result) { ?>  
                            <li class="note" id="item-<?php echo $color[$r] ?>">                                  
                                <button class="btn <?php echo $color[$r] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                &nbsp; <?php echo $result['candidate_name']; ?>                  
                                <div class="pull-right">
                                    <div class="btn-group">
                                        <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                            <i class="fa fa-ellipsis-v all-padding-5"></i>
                                        </a>
                                        <ul class="dropdown-menu pull-right">
                                            <li><a data-toggle="modal" href="#viewCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                            <li><a href="#">Delete</a></li>
                                            <li><a data-toggle="modal" href="#recruitment-feedback-1">Feedback</a></li>
                                            <li><a data-toggle="modal" href="#recruitment-schedule-1">Schedule</a></li>
                                        </ul>
                                    </div>
                                </div> 
                            </li>

                        <?php } ?>

                    </ul>

                </div>
            </div>
        </div>

        <div class="col-1-8">
            <small>Interviewer One</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list1" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8">
            <small>Interviewer Two</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list2" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8">
            <small>Interviewer Three</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list3" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div> 

        <div class="col-1-8">
            <small>Client</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list4" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8">
            <small>HR</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list5" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div> 

        <div class="col-1-8">
            <small>Offer</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list6" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8">
            <small>Joining</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list7" class="sortable-list connectList agile-list">

                    </ul>
                </div>
            </div>
        </div>
    </div> 
</div>
<?php $this->load->view('_addOpening'); ?>
<?php $this->load->view('_addCandidate'); ?>
<?php $this->load->view('_viewCandidate'); ?>
<?php $this->load->view('_feedback'); ?>
<?php $this->load->view('_schedule_interview'); ?>
<script type="text/javascript" src="<?php echo base_url() ?>plugins/drag-drop/js/jquery-ui-1.10.4.min.js"></script>
<script>
    function save_sortable(serial)
    {
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/disp',
            type: 'POST',
            data: serial,
            success: function (data) {
                alert(data);
                console.log(data);

            }
        });
    }

    $(document).ready(function () {

        $(".sortable-list").sortable({
         //   axis: 'x',
//            update: function (event, ui) {
//                var order = $(this).sortable('serialize');
//                console.log(order);
//            },
//            update: function (event, ui) {
//                var serial = $(this).sortable('serialize');
//                save_sortable(serial);
//            },
         //   items: "li:not(.unsortable)",
            // cancel: '.note', //disable moving
           connectWith: ".connectList",
//            update: function (event, ui) {
//                //alert(ui.li.attr("id"));
//                //alert(ui.item.closest('ul').attr('id')); //drop area id
//                //alert($(this).attr('id'));//working both
//
//            },
            beforeStop: function (event, ui) {
                //  alert($(this).attr('id'));
//        var myClassItem = $('.myClass', ui.item);
//        myClassItem.bind('click', function(){ /*my function*/ });
            },
            receive: function (e, ui) {
                var item_id = $(this).attr("id");
                var drag_id = $(ui.item).attr("id");
                alert('alert:' + item_id + ' of ' + drag_id);
            }
        }).disableSelection();
        $('.wrapper1').slimscroll({
            width: '100%',
            height: '410px',
            axis: 'both'
        });
        //  $('.sortable').sortable({ cancel: '.note' });


    });
//    $(".sortable-list").droppable({
//    disabled: false,
//    out: function ( event, ui ) {
//        $(this).droppable("option", "disabled", false);
//    },
//    drop: function( event, ui ) {
//         $(this).droppable("option", "disabled", true);
//    }
//});

    //to disable sort class="unsortable"

</script> 








