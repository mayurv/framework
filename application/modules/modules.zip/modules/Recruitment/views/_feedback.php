<?php //var_dump($candidates1);die;                                            ?>
<?php if (isset($candidates1)) { ?>
    <?php foreach ($candidates1 as $r => $result) { ?>


        <?php $i = 1; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback1_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">


                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('Completed', 'skip', 'reschedule', 'schedule', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                        <!--start skip-->
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 1) { ?>                                               
                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--skip end--> 


                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip') { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  
                                                                    <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span>
                                                                    </span>
                                                                </span> </p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>

                                                        <?php } ?>
                                                        <!--End schedule-->

                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>

                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>

                                                                    <?php if (($roundDetailsres['res_interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  
                                                                                <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('H:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span> </p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>
                                                                        <!--end interview feddback-->

                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                            <?php } ?>
                                                        <?php } ?>

                                                        <!--end reschedule round-->

                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number']) { ?>                                    

                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span> 
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>       


                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>
                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 1</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>


                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->


                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>  
                                            <?php
                                            $i--;
                                        }
                                        ?>


                                    <?php } ?>  






                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>    
        <?php
    }
}
?>


<?php if (isset($candidates2)) { ?>
    <?php foreach ($candidates2 as $r => $result) {
        ?>
        <?php $i = 2; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback2_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    //  var_dump($result);
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  

                                            <?php $round_status = array('Completed', 'skip', 'reschedule', 'schedule', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                        <!--start skip-->
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 2) { ?>                                               

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>


                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--skip end--> 

                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip') { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->


                                                            <p><span class="">Schedule To  
                                                                    <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right">

                                                                        <span class="text-muted"><?php echo date('H:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span>

                                                                    </span>
                                                                </span> 
                                                            </p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } ?>
                                                        <!--End schedule-->

                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['res_interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>


                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                            <?php } ?>
                                                        <?php } ?>

                                                        <!--end reschedule round-->


                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number']) { ?>                                    

                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<!--<p>Feedback</p>-->

                                                            </span>
                                                            <?php //echo 'ddd'.$roundDetails['interviewer_createddate'] ; die;?>

                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                             <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>       


                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>
                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 2</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>  
                                            <?php
                                            $i--;
                                        }
                                        ?>
                                    <?php } ?>  
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>    
    <?php } ?>
<?php } ?>



<?php if (isset($candidates3)) { ?>
    <?php foreach ($candidates3 as $r => $result) { ?>
        <?php $i = 3; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback3_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('Completed', 'skip', 'reschedule', 'schedule', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                        <!--start skip-->
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 3) { ?>                                               

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--skip end--> 

                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip') { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span></span>
                                                                </span><p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } ?>
                                                        <!--End schedule-->


                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['res_interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                                ?>
                                                            <?php } ?>
                                                        <?php } ?>

                                                        <!--end reschedule round-->


                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number']) { ?>                                    
                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span>
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?> 
                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>											

                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 3</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>     
                                            <?php
                                            $i--;
                                        }
                                        ?>
                                    <?php } ?>  
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div> 
    <?php } ?>
<?php } ?>


<?php if (isset($candidates4)) { ?>
    <?php foreach ($candidates4 as $r => $result) { ?>
        <?php $i = 4; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback4_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('Completed', 'skip', 'reschedule', 'schedule', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                        <!--start skip-->
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 4) { ?>                                               

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--skip end--> 


                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip') { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span>
                                                                    </span>
                                                                </span></p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } ?>
                                                        <!--End schedule-->


                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['res_interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        <?php } ?>
                                                        <!--end reschedule round-->

                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number']) { ?>                                    
                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span>
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?> 
                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>																	

                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 4</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>     
                                            <?php
                                            $i--;
                                        }
                                        ?>
                                    <?php } ?>  
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div> 

    <?php } ?>
<?php } ?>


<?php if (isset($candidates5)) { ?>
    <?php foreach ($candidates5 as $r => $result) { ?>
        <?php $i = 5; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback5_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('Completed', 'skip', 'reschedule', 'schedule', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($check_client_interview[0]['client_interview_status'] == 0) { ?>
                                                        <?php
                                                        if ($i == 4)
                                                            $i = 3;
                                                        ?>
                                                    <?php } ?>
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>

                                                        <!--start skip-->
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 5) { ?>                                               

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--skip end--> 


                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip') { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  
                                                                    <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span></span>
                                                                </span></p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>


                                                        <?php } ?>
                                                        <!--End schedule-->
                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['res_interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        <?php } ?>
                                                        <!--end reschedule round-->

                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number']) { ?>                                    
                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span>
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?> 
                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>															

                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 5</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div> 
                                            <?php
                                            $i--;
                                        }
                                        ?>
                                    <?php } ?>  
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div> 

    <?php } ?>
<?php } ?>


<?php if (isset($candidates6)) { ?>
    <?php foreach ($candidates6 as $r => $result) { ?>

        <?php $i = 6; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback6_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('Completed', 'skip', 'Offer Sent', 'Accept Offer', 'hold_offer', 'reject offer', 'reschedule', 'schedule', 'rejected', 'Register', 'FeedbackReject'); ?>
                                            <div class="feed-element">
                                                <a href="" class="pull-left margin-right-10">
                                                    <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                </a>        
                                                <div class="media-body ">
                                                    <?php if ($check_client_interview[0]['client_interview_status'] == 0) { ?>
                                                        <?php
                                                        if ($i == 4)
                                                            $i = 3;
                                                        ?>
                                                    <?php } ?>
                                                    <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 5) { ?>                                               

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--all 6 rounds conditions-->
                                                        <?php if ($roundDetails['round_status'] == 'Offer Sent' || $roundDetails['round_status'] == 'Accept Offer') { ?> 
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                            </span>
                                                         <span class="">  <span class="text-bold"> <?php echo $roundDetails['round_date'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['round_date'])) ?></span>
                                                            </span>

                                                            <div class="well">
                                                                <p class="text-info timeline-status"><?php echo $roundDetails['round_status'] ?></p>
                                                                <div class="pull-right">
                                                                    <!--                                                                    <a class="btn btn-xs btn-yellow">Offer Hold </a>-->
                                                                </div>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                        <!--end all 6 rounds conditions-->

                                                        <!--Hold Offer-->
                                                        <?php
                                                        if (isset($result['interview_hold_details'])) {
                                                            foreach ($result['interview_hold_details'] as $roundDetailshold) {
                                                                ?>
                                                                <?php if (($roundDetailshold['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>
                                                                    <span class="font-size-18 text-light-gray">
                                                                        Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                        <!--<p>Offer Status</p>-->
                                                                    </span>
                                                                    <div class="well">
                                                                        <p><?php echo $roundDetailshold['hold_offer_comment'] ?></p>
                                                                        <div class="pull-right">
                                                                            <a class="btn btn-xs btn-yellow">Offer Hold </a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="clearfix"></div>


                                                                    <?php
                                                                }
                                                            }
                                                        }
                                                        ?> 
                                                        <!--End Hold Offer-->

                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip' && $i != 6) { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span></span>
                                                                </span></p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } ?>
                                                        <!--End schedule-->

                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        <?php } ?>
                                                        <!--end reschedule round-->

                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number'] && $i != 6) { ?>                                    
                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span>
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?> 
                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>																	

                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 6</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->

                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <?php
                                            $i--;
                                        }
                                        ?>

                                    <?php } ?>  

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>
    <?php } ?>
<?php } ?>


<?php if (isset($candidates7)) { ?>
    <?php foreach ($candidates7 as $r => $result) { ?>
        <?php // var_dump($candidates7);     ?>
        <?php $i = 7; ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback7_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">                        
                        <div class="modal-body">                          


                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {

                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                            <?php $round_status = array('join', 'Completed', 'skip', 'Offer Sent', 'Accept Offer', 'hold_offer', 'reject offer', 'reschedule', 'schedule', 'FeedbackReject'); ?>

                                            <div class="feed-element">
                                                <?php if ($check_client_interview[0]['client_interview_status'] == 0) { ?>
                                                    <?php
                                                    if ($i == 4)
                                                        $i = 3;
                                                    ?>
                                                <?php } ?>

                                                <?php if ($roundDetails['interview_round_number'] == $i && in_array($roundDetails['round_status'], $round_status)) { ?>
                                                    <a href="" class="pull-left margin-right-10">
                                                        <button class="btn btn-md"><?php echo 'R' . $i . ''; ?></button>
                                                    </a>        
                                                    <div class="media-body ">

                                                        <?php
                                                        if (isset($result['interview_skip_details'])) {
                                                            foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                                ?>
                                                                <?php if (($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <?php if ($roundDetailskp['interview_round_number'] <= 7) { ?> 
                                                                        <?php // var_dump($result)   ?>

                                                                        <span class="font-size-18 text-light-gray">
                                                                            Interview Round <?php echo $roundDetailskp['interview_round_number'] ?> 
                                                                        </span>
                                                                        <div class="clearfix"></div>
                                                                        <span class="text-light-gray">
                                                                            <small class="pull-right text-muted"><?php // echo date('f D',  strtotime($roundDetailskp['round_date']))                         ?></small>
                                                                        </span>

                                                                        <div class="well">
                                                                            <p><?php echo $roundDetailskp['skip_comment'] ?></p>
                                                                            <div class="pull-right">
                                                                                <a class="btn btn-xs btn-warning">Skipped </a>
                                                                            </div>
                                                                        </div>

                                                                        <div class="clearfix"></div>
                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ?>  
                                                        <!--all 6 rounds conditions-->
                                                        <?php if ($roundDetails['round_status'] == 'Offer Sent' || $roundDetails['round_status'] == 'Accept Offer') { ?> 
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Offer Status</p>-->
                                                            </span>
                                                        <span class="">  <span class="text-bold"> </span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['round_date'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <p class="text-info timeline-status"><?php echo $roundDetails['round_status'] ?></p>
                                                                <div class="pull-right">
                                                                    <!--                                                                    <a class="btn btn-xs btn-yellow">Offer Hold </a>-->
                                                                </div>
                                                            </div>


                                                            <div class="clearfix"></div>

                                                        <?php } ?>
                                                        <!--end all 6 rounds conditions-->

                                                        <!--Hold Offer-->
                                                        <?php
                                                        if (isset($result['interview_hold_details'])) {
                                                            foreach ($result['interview_hold_details'] as $roundDetailshold) {
                                                                ?>
                                                                <?php if (($roundDetailshold['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                    <span class="font-size-18 text-light-gray">
                                                                        Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                        <!--<p>Offer Status</p>-->
                                                                    </span>
                                                                    <div class="well">
                                                                        <p><?php echo $roundDetailshold['hold_offer_comment'] ?></p>
                                                                        <div class="pull-right">
                                                                            <a class="btn btn-xs btn-yellow">Offer Hold </a>
                                                                        </div>
                                                                    </div>

                                                                    <div class="clearfix"></div>


                                                                    <?php
                                                                }
                                                            }
                                                        }
                                                        ?> 
                                                        <!--End Hold Offer-->


                                                        <!--Start schedule-->
                                                        <?php if ($roundDetails['interview_round_number'] == $roundDetails['interview_round_number'] && $roundDetails['round_status'] != 'skip' && $i != 6 && $i != 7) { ?>                                    
                                                            <span class="pull-right">
                                                                <p><?php echo $roundDetails['interview_mode'] ?></p>
                                                            </span>
                                                            <span class="font-size-18 text-light-gray">
                                                                Interview Round <?php echo $roundDetails['interview_round_number'] ?> 
                                                                <!--<p>Schedule</p>-->
                                                            </span> 
                                                            <!--round number info-->
                                                            <p><span class="">Schedule To  
                                                                    <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                    <span class="pull-right"><span class="text-muted"><?php echo date('h:i A', strtotime($roundDetails['interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetails['interview_date'])) ?></span></span>
                                                                </span>
                                                            </p>
                                                            <div class="well">
                                                                <?php echo $roundDetails['schedule_comment'] ?>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        <?php } ?>
                                                        <!--End schedule-->

                                                        <!--start reschedule round-->
                                                        <?php foreach ($result['schedule_details'] as $res) { ?>
                                                            <?php if ($res['reschedule_id'] == 1) { ?>                                            
                                                                <?php foreach ($res['reschedule_details'] as $roundDetailsres) { ?>
                                                                    <?php if (($roundDetailsres['interview_round_number'] == $roundDetails['interview_round_number'])) { ?>

                                                                        <span class="pull-right">
                                                                            <p><?php echo $roundDetailsres['res_interview_mode'] ?></p>

                                                                        </span>
                                                                        <span class="font-size-18 text-light-gray">
                                                                            <p>Rescheduled</p>

                                                                        </span> 
                                                                        <!--round number info-->

                                                                        <div class="clearfix"></div>

                                                                        <div class="margin-bottom-10"></div>
                                                                        <div class="clearfix"></div>

                                                                        <!--start interview feddback-->
                                                                        <p><span class="">Schedule To  
                                                                                <span class="text-bold"> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                                                <span class="pull-right"><?php echo date('h:i A', strtotime($roundDetailsres['res_interview_time'])) ?> - <?php echo date('d F', strtotime($roundDetailsres['res_interview_date'])) ?></span>
                                                                            </span></p>
                                                                        <div class="well">
                                                                            <?php echo $roundDetailsres['reschedule_comment'] ?>
                                                                        </div>

                                                                        <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                        <?php } ?>
                                                        <!--end reschedule round-->

                                                        <!--Start Interviwer feedback-->
                                                        <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number'] && $i != 6) { ?>                                    
                                                            <!--start interview feddback-->
                                                            <span class="font-size-18 text-light-gray">
                                                                <!--<p>Feedback</p>-->

                                                            </span>
                                                            <span class="">Interview By  <span class="text-bold"> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                                <span class="pull-right text-muted"><?php echo date('h:i A - d F', strtotime($roundDetails['interviewer_createddate'])) ?></span>
                                                            </span>
                                                            <div class="well">
                                                                <?php
                                                                $resultstr = array();
                                                                foreach ($roundDetails['skill_rating'] as $k => $skilldata) {
                                                                    ?>
                                                                    <?php if ($skilldata != '') { ?>
                                                                        <?php $resultstr[$k]['name'] = $skills_list[$skilldata['id']]; ?>
                                                                        <?php $resultstr[$k]['value'] = $skilldata['rating']; ?>                                  
                                                                    <?php } ?>
                                                                <?php }
                                                                ?>
                                                                <table class="table table-responsive table-bordered">
                                                                    <thead>
                                                                    <th>Skill Set</th>
                                                                    <th>Rating Given</th>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach ($resultstr as $k => $inputData) {
                                                                            ?>
                                                                            <tr>
                                                                                <td ><span class="btn btn-xs btn-primary"><?php echo $inputData['name'] ?></span></td>
                                                                                <td ><span class="btn btn-xs btn-default text-bold"><?php echo $inputData['value'] ?></span></td>

                                                                            </tr>
                                                                        <?php } ?>                                                                   
                                                                    </tbody>
                                                                </table>                                                                 

                                                                <p>
                                                                    <?php
                                                                    $x = 1;
                                                                    $rating = (float) $roundDetails['interviewer_rating'];
                                                                    ?>
                                                                    <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                                        <i class="fa fa-star text-star font-size-18"></i>
                                                                    <?php } ?>
                                                                    <?php if (strpos($rating, '.')) { ?>

                                                                        <i class="fa fa-star-half-full text-star  font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?>
                                                                    <?php while ($x <= 10) { ?>
                                                                        <i class="fa fa-star-o text-star font-size-18"></i>
                                                                        <?php
                                                                        $x++;
                                                                    }
                                                                    ?> 
                                                                    <small class="text-light-gray">(<?php echo $roundDetails['interviewer_rating'] ?>/10)</small>
                                                                </p>
                                                                <?php echo $roundDetails['interviewer_comments'] ?>																	

                                                                <div class="pull-right">
                                                                    <?php if ($roundDetails['round_status'] == 'FeedbackReject') { ?>
                                                                        <a class="btn btn-xs btn-danger">Rejected in Round 7</a>
                                                                    <?php } else { ?>
                                                                        <a class="btn btn-xs btn-success">Completed </a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <!--end interview feddback-->
                                                        <?php } ?>
                                                        <!--End Interviwer feedback-->


                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>                   

                                            <?php
                                            $i--;
                                        }
                                        ?>


                                    <?php } ?>  






                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>


    <?php } ?>
<?php } ?>





<!--feedback modal start -->
<div class="modal fade" id="recruitment-feedback-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Feedback</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <form class="formValidate" id="formValidate" method="post" action="">
                        <div class="row">
                            <div class="col-sm-4"> 
                                <p class="font-size-15 text-bold">Baliram Kamble</p>
                                <p>5 Year 6 Months</p>
                            </div>
                            <div class="col-sm-4">
                                <label for="feedround">Round*</label>
                                <select class="browser-default"  id="feedround" name="feedround" data-error=".errorTxt101">
                                    <option value="" disabled selected>Round</option>
                                    <option value="1">Telephonic</option>
                                    <option value="1">Face 2 Face</option>
                                </select>       
                                <div class="input-field">
                                    <div class="errorTxt101"></div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <p class="text-bold">Interview Date: 24/01/2017</p>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2 margin-top-10 margin-bottom-10">       
                                <p class="text-bold">Sr. No.</p>
                            </div>

                            <div class="col-sm-5 margin-top-10 margin-bottom-10">       
                                <p class="text-bold">Technology</p>
                            </div>
                            <div class="col-sm-5 margin-top-10 margin-bottom-10">      
                                <p class="text-bold">Rating</p>           
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">1</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt1">Opps*</label>
                                    <input id="feedt1" name="feedt1"  placeholder="Opps " type="text" data-error=".errorTxt102">
                                    <div class="errorTxt102"></div>
                                </div>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt2">PHP*</label>
                                    <input id="feedt2" name="feedt2"  placeholder="PHP " type="text" data-error=".errorTxt103">
                                    <div class="errorTxt103"></div>
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">2</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt3">CI*</label>
                                    <input id="feedt3" name="feedt3"  placeholder="CI " type="text" data-error=".errorTxt104">
                                    <div class="errorTxt104"></div>
                                </div>
                            </div>      

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt4">Database*</label>
                                    <input id="feedt4" name="feedt4"  placeholder="Database " type="text" data-error=".errorTxt104">
                                    <div class="errorTxt104"></div>
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">3</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt5">Jquery*</label>
                                    <input id="feedt5" name="feedt5"  placeholder="Jquery " type="text" data-error=".errorTxt105">
                                    <div class="errorTxt105"></div>
                                </div>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt6">Javascript*</label>
                                    <input id="feedt6" name="feedt6"  placeholder="Javascript " type="text" data-error=".errorTxt106">
                                    <div class="errorTxt106"></div>
                                </div>
                            </div>                                       
                            <div class="clearfix"></div>

                            <div class="col-sm-6">                                          
                                <div class="input-field">
                                    <label for="feedarating">Average Rating*</label>
                                    <input id="feedarating" name="feedarating"  placeholder="Average Rating" type="text" data-error=".errorTxt107">
                                    <div class="errorTxt107"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label for="feedstatus">Status*</label>
                                <select class="browser-default"  id="feedstatus" name="feedstatus" data-error=".errorTxt108">
                                    <option value="" disabled selected>Status</option>
                                    <option value="1">Select</option>
                                    <option value="1">Reject</option>              
                                </select>       
                                <div class="input-field">
                                    <div class="errorTxt108"></div>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <label for="feedremark" class="active">Remark*</label>
                                    <textarea id="feedremark" placeholder="Remark" data-error=".errorTxt109" class="materialize-textarea"></textarea>
                                    <div class="errorTxt109"></div>
                                </div>
                            </div>                                        
                            <div class="clearfix"></div>
                            <div class="col-sm-12 text-right padding-top-10">
                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!--feedback modal end -->   