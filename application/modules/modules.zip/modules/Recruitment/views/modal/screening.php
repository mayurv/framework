<!-- top button bar here -->                                
<div class="add-candidate-bg"> 
    <div class="pull-right">

        <button class="btn btn-danger btn-sm" data-toggle="modal" href="#addcandidate-1"><i class="fa fa-plus-circle"></i> Add Candidate</button>
    </div>
</div>                          
<!-- top button bar here -->

<?php
//$color = array(
//    '0' => 'btn-primary2',
//    '1' => 'btn-danger',
//    '2' => 'btn-primary',
//    '3' => 'btn-info',
//    '4' => 'btn-success',
//    '5' => 'btn-warning',
//    '6' => 'btn-blue',
//    '7' => 'btn-warning2',
//    '8' => 'btn-primary',
//);
//
////$n=25;
//$n = count($candidates);
//$col_cnt = count($color);
//if ($n > $col_cnt && $n < (2 * $col_cnt)) {
//    $color = array_merge($color, $color);
//}
//
//if ($n > (2 * $col_cnt) && $n < (3 * $col_cnt)) {
//    $color1 = array_merge($color, $color);
//    $color = array_merge($color1, $color);
//}
//
//if ($n > (3 * $col_cnt) && $n < (4 * $col_cnt)) {
//    $color1 = array_merge($color, $color);
//    $color2 = array_merge($color1, $color);
//    $color = array_merge($color2, $color);
//}
?>


<div class="wrapper1">
    <div class="wrapper-content">

        <div class="col-1-8" id="sortable1">
            <small>Candidate List</small>
            <div class="ibox">
                <div class="ibox-content">  
                    <ul id="sortable" class="sortable-list btn- connectList agile-list">
                        <?php foreach ($candidates as $r => $result) { ?>  
                            <li class="note" id="item-<?php echo $result['id'] ?>">  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                &nbsp; <?php echo $result['candidate_name']; ?>                  
                                <div class="pull-right">
                                    <div class="btn-group">
                                        <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                            <i class="fa fa-ellipsis-v all-padding-5"></i>

                                        </a>
                                        <ul class="dropdown-menu pull-right">
                                            <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                            <li><a href="#">Delete</a></li>
                                            <li><a data-toggle="modal" href="#recruitment-feedback-1">Feedback</a></li>
                                            <li><a data-toggle="modal" href="#recruitment-schedule-1">Schedule</a></li>
                                        </ul>
                                    </div>
                                </div> 
                            </li>

                        <?php } ?>

                    </ul>

                </div>
            </div>
        </div>

        <div class="col-1-8" id="sortable2">
            <small>Interviewer One</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-1" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates1)) {
                            foreach ($candidates1 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject1_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback1_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule1_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback1_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>
                                    </li>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8" id="sortable3">
            <small>Interviewer Two</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-2" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates2)) {
                            foreach ($candidates2 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject2_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback2_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule2_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback2_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>
                                    </li>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8" id="sortable4">
            <small>Interviewer Three</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-3" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates3)) {
                            foreach ($candidates3 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject3_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback3_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule3_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback3_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>
                                    </li>
                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div> 
        <?php if ($check_client_interview[0]['client_interview_status'] == 1) { ?>
            <div class="col-1-8" id="sortable5">
                <small>Client</small>
                <div class="ibox">
                    <div class="ibox-content">
                        <ul id="list-4" class="sortable-list connectList agile-list">
                            <?php
                            if (isset($candidates4)) {
                                foreach ($candidates4 as $r => $result) {
                                    ?>  
                                    <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                        <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                        &nbsp; <?php echo $result['candidate_name']; ?>                  
                                        <div class="pull-right">
                                            <div class="btn-group">
                                                <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v all-padding-5"></i>
                                                </a>
                                                <ul class="dropdown-menu pull-right">
                                                    <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                    <li><a data-toggle="modal" href="#recruitment-reject4_<?php echo $result['id'] ?>">Reject</a></li>
                                                    <li><a data-toggle="modal" href="#recruitment-feedback4_<?php echo $result['id'] ?>">Feedback</a></li>
                                                    <li><a data-toggle="modal" href="#recruitment-schedule4_<?php echo $result['id'] ?>">Schedule</a></li>
                                                </ul>
                                            </div>
                                        </div> 
                                        <?php if (isset($result['round_status'])) { ?>
                                            <?php if ($result['round_status'] != null) { ?>
                                                <div class="margin-top-20 pull-right">
                                                    <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                    <a data-toggle="modal" href="#recruitment-feedback4_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                    <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                        <i class="fa fa-download text-ccc " title="Download"></i>
                                                    </a>
                                                </div>
                                                <?php
                                            } else {
                                                
                                            }
                                            ?>
                                        </li>

                                        <?php
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php } ?>

        <div class="col-1-8" id="sortable6">
            <small>HR</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-5" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates5)) {
                            foreach ($candidates5 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject5_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback5_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule5_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback5_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>
                                    </li>

                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div> 

        <div class="col-1-8" id="sortable7">
            <small>Offer</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-6" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates6)) {
                            foreach ($candidates6 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>

                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject6_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback6_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule6_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback6_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>
                                    </li>

                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-1-8" id="sortable8">
            <small>Joining</small>
            <div class="ibox">
                <div class="ibox-content">
                    <ul id="list-7" class="sortable-list connectList agile-list">
                        <?php
                        if (isset($candidates7)) {
                            foreach ($candidates7 as $r => $result) {
                                ?>  
                                <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                <li class="note" id="item-<?php echo $result['id'] ?>">                                  
                                    <button class="btn <?php echo $result['title'] ?> btn-circle btn-sm"><?php echo ucfirst(substr($result['candidate_name'], 0, 1)); ?></button>
                                    &nbsp; <?php echo $result['candidate_name']; ?>                  
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <a href="#" class="dropdown-toggle toggle-shadow" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v all-padding-5"></i>
                                            </a>
                                            <ul class="dropdown-menu pull-right">
                                                <li><a data-toggle="modal" href="#editCandidate_<?php echo $result['id'] ?>">Edit Candidate</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-reject7_<?php echo $result['id'] ?>">Reject</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-feedback7_<?php echo $result['id'] ?>">Feedback</a></li>
                                                <li><a data-toggle="modal" href="#recruitment-schedule17_<?php echo $result['id'] ?>">Schedule</a></li>
                                            </ul>
                                        </div>
                                    </div> 
                                    <?php if (isset($result['round_status'])) { ?>
                                        <?php if ($result['round_status'] != null) { ?>
                                            <div class="margin-top-20 pull-right">
                                                <i class="fa fa-clock-o text-ccc" title="Schedule Interview"> | </i>
                                                <a data-toggle="modal" href="#recruitment-feedback7_<?php echo $result['id'] ?>"><i class="fa fa-list-ul  text-ccc" title="View Feedback"> | </i></a>

                                                <a href="<?php echo base_url() ?>assets/uploads/<?php echo $result['user_cv'] ?>" target="_blank">
                                                    <i class="fa fa-download text-ccc " title="Download"></i>
                                                </a>
                                            </div>
                                            <?php
                                        } else {
                                            
                                        }
                                        ?>

                                    </li>

                                    <?php
                                }
                            }
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div> 
</div>

<?php $this->load->view('_addCandidate'); ?>
<?php //$this->load->view('_viewCandidate');     ?>
<?php $this->load->view('_editCandidate'); ?>
<?php $this->load->view('_feedback'); ?>
<?php $this->load->view('_schedule_interview'); ?>
<script type="text/javascript" src="<?php echo base_url() ?>plugins/drag-drop/js/jquery-ui-1.10.4.min.js"></script>
<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>

<script>

<?php if (($this->session->flashdata())) { ?>
        showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>

    function save_interviewRound(item_id, drag_id, req_id)
    {
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/save_interviewRound',
            type: 'POST',
            data: {'round_id': item_id, 'candidate_id': drag_id, 'req_id': req_id},
            success: function (data) {
                //  alert(data);
                //  console.log(data);

            }
        });
    }

    function save_sortable(serial)
    {
        $.ajax({
            url: '<?php echo base_url(); ?>recruitment/disp',
            type: 'POST',
            data: serial,
            success: function (data) {
                alert(data);
                console.log(data);

            }
        });
    }

    $(document).ready(function () {
        $(".sortable-list").sortable({
//$("#sortable1, #sortable2 ,#sortable3, #sortable4,#sortable5, #sortable6,#sortable7, #sortable8").sortable({
//            axis: 'x',
//            update: function (event, ui) {
//                var order = $(this).sortable('serialize');
//                console.log(order);
//            },
//            update: function (event, ui) {
//                var serial = $(this).sortable('serialize');
//                save_sortable(serial);
//            },
//   items: "li:not(.unsortable)",
// cancel: '.note', //disable moving
// connectWith: '.sortable',
            connectWith: ".connectList",
//            update: function (event, ui) {
//                //alert(ui.li.attr("id"));
//                //alert(ui.item.closest('ul').attr('id')); //drop area id
//                //alert($(this).attr('id'));//working both
//
//            },
            beforeStop: function (event, ui) {
//  alert($(this).attr('id'));
//        var myClassItem = $('.myClass', ui.item);
//        myClassItem.bind('click', function(){ /*my function*/ });
            },
            receive: function (e, ui) {
                var item_id = $(this).attr("id");
                var drag_id = $(ui.item).attr("id");
                var req_id = $("#req_id").val();
//alert('alert:' + item_id + ' of ' + drag_id + 'reqid' + req_id);
                save_interviewRound(item_id, drag_id, req_id);
            }
        }).disableSelection();
        $('.wrapper1').slimscroll({
            width: '100%',
            height: '500px',
            axis: 'both'
        });
//  $('.sortable').sortable({ cancel: '.note' });


    });
//    $(".sortable-list").droppable({
//    disabled: false,
//    out: function ( event, ui ) {
//        $(this).droppable("option", "disabled", false);
//    },
//    drop: function( event, ui ) {
//         $(this).droppable("option", "disabled", true);
//    }
//});

//to disable sort class="unsortable"

</script> 