<?php foreach ($openings as $r => $result) { ?>

    <div class="modal fade" id="view_opening_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><?php echo $result['jobtitlename'] . ' <small>(' . $result['deptname'] . ')</small>'; ?></h4>
                </div>
                <div class="modal-body all-padding-0">
                    <div class="user-normal-slim"> 
                        <p class="text-center">                             
                            <label class="btn btn-primary btn-lg" title="Required Position" style="cursor:pointer"><?php echo $result['req_no_positions'] ?></label>                                                  
                        </p>

                        

                        <p class="text-center margin-top-10">
                            <small class="text-info font-size-15 " title="Close Date"><?php echo date('d F Y', strtotime($result['close_date'])); ?></small>
                            
                        </p>  
                        <p class="text-center margin-top-5">
                           <label class="btn btn-xs btn-info "><?php echo $result['req_type'] ?> </label>
                        </p>  


                        <div class="emp-office-bg"> 
                           
                        
<!--                            Requirement Type
                            <div class="emp-icon-left"> 
                                <i class="fa fa-search" title="Experiance"></i>
                            </div>
                            <div class="emp-content-right"> 
                                <div class="btn btn-xs btn-primary"><?php echo $result['req_type'] ?> </div>
                                
                            </div>
                            Requirement Type-->
                            
                            
                            <!--experiance-->
                            <div class="emp-icon-left"> 
                                <i class="fa fa-briefcase" title="Experiance"></i>
                            </div>
                            <div class="emp-content-right"> 
                                <?php echo $result['req_exp_years_from'] . '-' . $result['req_exp_years_to'] . ' years' ?>
                            </div>
                            <!--experiance here-->




                            <!--qualification-->
                            <div class="emp-icon-left"> 
                                <i class="fa fa-university" title="Qualification"></i>
                            </div>
                            <div class="emp-content-right"> 
                                <?php echo ($result['req_qualification']); ?>
                            </div>
                            <!--qualification here-->



                            <!--req_skills-->
                            <div class="emp-icon-left"> 
                                <i class="fa fa-gear" title="Skills"></i>
                            </div>
                            <div class="emp-content-right"> 
                                <?php echo ($result['req_skills']); ?>
                            </div>
                            <!--req_skills here-->


                            <!--jobdescription-->
                            <div class="emp-icon-left"> 
                                <i class="fa fa-comments" title="Description"></i>
                            </div>
                            <div class="emp-content-right"> 
                                <?php echo ($result['jobdescription']); ?>
                            </div>
                            <!--jobdescription here-->
                        </div>

                        <?php $currentDate = date('Y-m-d'); ?>

                        <p class="text-center">
                            <?php if ($result['ispublished'] == 0) { ?>
                                <label class="btn btn-default btn-md" title="status">Not Approved</label>
                            <?php } else if ($result['opening_status'] == 3) { ?>
                                <label class="btn btn-success btn-md">Closed</label>

                            <?php } else { ?>
                                <?php $currentDate > $result['close_date'] ? $status = 'btn-danger' : $status = 'btn-warning'; ?>
                                <label class="btn <?php echo $status ?> btn-md">On Going</label>
                            <?php } ?>
                        </p>


                    </div>
                </div>                                                    
            </div>
        </div>
    </div>

<?php } ?>
  



