<!--reschedule interview modal start -->

<?php foreach ($candidates1 as $r => $result) { ?>
    <?php // var_dump($result['schedule_details']);die;?>

    <?php if (isset($result['schedule_details'])) { ?>


        <div class="modal fade" id="recruitment-reschedule1_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Re-Schedule Interview</h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-modal-slim"> 
                            <?php
                            // var_dump($candiate);die;
                            echo form_open('recruitment/reschedule_interview/', array('id' => 'reschdule_interview_id' . $result['id'], 'class' => 'reschdule_interview_id'));
                            ?> 
                            <div class="row">

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('interviewer_id'), 'interviewer_id', array('for' => 'interviewer_id')); ?>
                                    <?php
                                    echo form_dropdown(array(
                                        'id' => 'interviewer_id',
                                        'name' => 'interviewer_id',
                                        'class' => 'browser-default',
                                        'data-error' => '.schedule1',
                                            ), $interviewer_list);
                                    ?>
                                    <div class="input-field">
                                        <div class="schedule1"></div>
                                        <?php echo form_error('interviewer_id'); ?> 
                                    </div>                    
                                </div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                                    <?php
                                    echo form_dropdown(array(
                                        'id' => 'interview_mode',
                                        'name' => 'interview_mode',
                                        'class' => 'browser-default',
                                        'data-error' => '.schedule3',
                                            ), $interview_mode_list);
                                    ?>
                                    <div class="input-field">
                                        <div class="schedule3"></div>
                                        <?php echo form_error('interview_mode'); ?> 
                                    </div>                    
                                </div

                                <div class="clearfix">

                                    <div class="col-sm-6">
                                        <div class="input-field">
                                            <?php echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                                            <?php
                                            echo form_input(array(
                                                'id' => 'interview_date',
                                                'name' => 'interview_date',
                                                'placeholder' => 'Interview Date',
                                                'data-format' => 'yyyy-mm-dd',
                                                'class' => 're_interview_date_' . $result['id'],
                                                'data-error' => '.addOpening4',
                                            ));
                                            ?>   
                                            <div class="addOpening4"></div>                                
                                            <?php echo form_error('interview_date'); ?> 
                                        </div>                                        
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-field">
                                            <?php echo form_label(lang('interview_time')); ?>

                                            <?php
                                            echo form_input(array(
                                                'id' => 'interview_time',
                                                'name' => 'interview_time',
                                                'placeholder' => 'Interview Time',
                                                'data-template' => "dropdown",
                                                'data-show-seconds' => "true",
                                                'data-default-time' => "09:45 PM",
                                                //'class' => 'timepicker',
                                                'data-error' => '.addOpening5',
                                            ));
                                            ?>   

                                                                                                                                            <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                            <div class="addOpening5"></div>
                                        </div>
                                    </div>

                                    <div class="clearfix"></div>

                                    <!--                            <div class="col-sm-12">
                                                                    <div class="input-field">
                                                                        <label for="sccomment" class="active">Comment*</label>
                                                                        <textarea id="sccomment" placeholder="Comment" data-error=".errorTxt98" class="materialize-textarea"></textarea>
                                                                        <div class="errorTxt98"></div>
                                                                    </div>
                                                                </div>-->


                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('schedule_comment'), 'schedule_comment', array('for' => 'schedule_comment')); ?>                            <?php
                                            echo form_textarea(array(
                                                'name' => 'schedule_comment',
                                                'id' => 'schedule_comment',
                                                'class' => 'browser-default materialize-textarea',
                                                'placeholder' => 'Comment',
                                                'type' => 'text',
                                                'data-error' => '.addCandidate6',
                                            ));
                                            ?>                       
                                            <div class="addCandidate6"></div>
                                            <?php echo form_error('schedule_comment'); ?>
                                        </div>         
                                    </div> 
                                    <div class="clearfix"></div>

                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('reschedule_comment'), 'reschedule_comment', array('for' => 'reschedule_comment')); ?>                            <?php
                                            echo form_textarea(array(
                                                'name' => 'reschedule_comment',
                                                'id' => 'reschedule_comment',
                                                'class' => 'browser-default materialize-textarea',
                                                'placeholder' => 'Reschedule Comment',
                                                'type' => 'text',
                                                'data-error' => '.addCandidate6',
                                            ));
                                            ?>                       
                                            <div class="addCandidate6"></div>
                                            <?php echo form_error('reschedule_comment'); ?>
                                        </div>         
                                    </div>
                                    <div class="clearfix"></div>

                                    <input type="hidden" name="interview_round_number" value="1">
                                    <input type="hidden" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                    <input type="hidden" name="candidate_id" value="<?php echo $result['id'] ?>">
                                    <input type="hidden" name="position" value="<?php echo $result['position'] ?>">

                                    <div class="clearfix"></div>

                                    <div class="col-sm-12 text-right padding-top-10">
                                        <!--                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                        <button type="submit" onclick="return validate_reschedule_form(<?php echo $result['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>

                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>                                                    
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                /* Date picker validation Fucntions */
                $(document).ready(function () {
                    $(".re_interview_date_<?php echo $result['id'] ?>").click(function () {
                        $('.re_interview_date_<?php echo $result['id'] ?>').pickadate({
                            selectYears: true,
                            selectMonths: true,
                            min: new Date(),
                        });
                    });
                });
            </script>
        <?php } ?>
    <?php } ?>



    <?php foreach ($candidates2 as $r => $result) { ?>
        <?php if (isset($result['schedule_details'])) { ?>


            <div class="modal fade" id="recruitment-reschedule2_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Re-Schedule Interview</h4>
                        </div>
                        <div class="modal-body">
                            <div class="user-modal-slim"> 
                                <?php
                                // var_dump($candiate);die;
                                echo form_open('recruitment/reschedule_interview/', array('id' => 'reschdule_interview_id' . $result['id'], 'class' => 'reschdule_interview_id'));
                                ?> 
                                <div class="row">

                                    <div class="col-sm-6">
                                        <?php echo form_label(lang('interviewer_id'), 'interviewer_id', array('for' => 'interviewer_id')); ?>
                                        <?php
                                        echo form_dropdown(array(
                                            'id' => 'interviewer_id',
                                            'name' => 'interviewer_id',
                                            'class' => 'browser-default',
                                            'data-error' => '.schedule1',
                                                ), $interviewer_list);
                                        ?>
                                        <div class="input-field">
                                            <div class="schedule1"></div>
                                            <?php echo form_error('interviewer_id'); ?> 
                                        </div>                    
                                    </div>

                                    <div class="col-sm-6">
                                        <?php echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                                        <?php
                                        echo form_dropdown(array(
                                            'id' => 'interview_mode',
                                            'name' => 'interview_mode',
                                            'class' => 'browser-default',
                                            'data-error' => '.schedule3',
                                                ), $interview_mode_list);
                                        ?>
                                        <div class="input-field">
                                            <div class="schedule3"></div>
                                            <?php echo form_error('interview_mode'); ?> 
                                        </div>                    
                                    </div

                                    <div class="clearfix">

                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <?php echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                                                <?php
                                                echo form_input(array(
                                                    'id' => 'interview_date',
                                                    'name' => 'interview_date',
                                                    'placeholder' => 'Interview Date',
                                                    'data-format' => 'yyyy-mm-dd',
                                                    'class' => 're_interview_date_' . $result['id'],
                                                    'data-error' => '.addOpening4',
                                                ));
                                                ?>   
                                                <div class="addOpening4"></div>                                
                                                <?php echo form_error('interview_date'); ?> 
                                            </div>                                        
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="input-field">
                                                <?php echo form_label(lang('interview_time')); ?>

                                                <?php
                                                echo form_input(array(
                                                    'id' => 'interview_time',
                                                    'name' => 'interview_time',
                                                    'placeholder' => 'Interview Time',
                                                    'data-template' => "dropdown",
                                                    'data-show-seconds' => "true",
                                                    'data-default-time' => "09:45 PM",
                                                    'class' => 'timepicker',
                                                    'data-error' => '.addOpening5',
                                                ));
                                                ?>   

                                                                                                                                            <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                                <div class="addOpening5"></div>
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>

                                        <!--                            <div class="col-sm-12">
                                                                        <div class="input-field">
                                                                            <label for="sccomment" class="active">Comment*</label>
                                                                            <textarea id="sccomment" placeholder="Comment" data-error=".errorTxt98" class="materialize-textarea"></textarea>
                                                                            <div class="errorTxt98"></div>
                                                                        </div>
                                                                    </div>-->


                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <?php echo form_label(lang('schedule_comment'), 'schedule_comment', array('for' => 'schedule_comment')); ?>                            <?php
                                                echo form_textarea(array(
                                                    'name' => 'schedule_comment',
                                                    'id' => 'schedule_comment',
                                                    'class' => 'browser-default materialize-textarea',
                                                    'placeholder' => 'Comment',
                                                    'type' => 'text',
                                                    'data-error' => '.addCandidate6',
                                                ));
                                                ?>                       
                                                <div class="addCandidate6"></div>
                                                <?php echo form_error('schedule_comment'); ?>
                                            </div>         
                                        </div> 


                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <?php echo form_label(lang('reschedule_comment'), 'reschedule_comment', array('for' => 'reschedule_comment')); ?>                            <?php
                                                echo form_textarea(array(
                                                    'name' => 'reschedule_comment',
                                                    'id' => 'reschedule_comment',
                                                    'class' => 'browser-default materialize-textarea',
                                                    'placeholder' => 'Reschedule Comment',
                                                    'type' => 'text',
                                                    'data-error' => '.addCandidate6',
                                                ));
                                                ?>                       
                                                <div class="addCandidate6"></div>
                                                <?php echo form_error('reschedule_comment'); ?>
                                            </div>         
                                        </div>


                                        <input type="hidden" name="interview_round_number" value="2">
                                        <input type="hidden" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                        <input type="hidden" name="candidate_id" value="<?php echo $result['id'] ?>">
                                        <input type="hidden" name="position" value="<?php echo $result['position'] ?>">

                                        <div class="clearfix"></div>

                                        <div class="col-sm-12 text-right padding-top-10">
                                            <!--                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                            <button type="submit" onclick="return validate_reschedule_form(<?php echo $result['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>

                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>                                                    
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    /* Date picker validation Fucntions */
                    $(document).ready(function () {
                        $(".re_interview_date_<?php echo $result['id'] ?>").click(function () {
                            $('.re_interview_date_<?php echo $result['id'] ?>').pickadate({
                                selectYears: true,
                                selectMonths: true,
                                min: new Date(),
                            });
                        });
                    });
                </script>

            <?php } ?>

        <?php } ?>

        <?php foreach ($candidates3 as $r => $result) { ?>
            <?php if (isset($result['schedule_details'])) { ?>

                <div class="modal fade" id="recruitment-reschedule3_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Re-Schedule Interview</h4>
                            </div>
                            <div class="modal-body">
                                <div class="user-modal-slim"> 
                                    <?php
                                    // var_dump($candiate);die;
                                    echo form_open('recruitment/reschedule_interview/', array('id' => 'reschdule_interview_id' . $result['id'], 'class' => 'reschdule_interview_id'));
                                    ?> 
                                    <div class="row">

                                        <div class="col-sm-6">
                                            <?php echo form_label(lang('interviewer_id'), 'interviewer_id', array('for' => 'interviewer_id')); ?>
                                            <?php
                                            echo form_dropdown(array(
                                                'id' => 'interviewer_id',
                                                'name' => 'interviewer_id',
                                                'class' => 'browser-default',
                                                'data-error' => '.schedule1',
                                                    ), $interviewer_list);
                                            ?>
                                            <div class="input-field">
                                                <div class="schedule1"></div>
                                                <?php echo form_error('interviewer_id'); ?> 
                                            </div>                    
                                        </div>

                                        <div class="col-sm-6">
                                            <?php echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                                            <?php
                                            echo form_dropdown(array(
                                                'id' => 'interview_mode',
                                                'name' => 'interview_mode',
                                                'class' => 'browser-default',
                                                'data-error' => '.schedule3',
                                                    ), $interview_mode_list);
                                            ?>
                                            <div class="input-field">
                                                <div class="schedule3"></div>
                                                <?php echo form_error('interview_mode'); ?> 
                                            </div>                    
                                        </div

                                        <div class="clearfix">

                                            <div class="col-sm-6">
                                                <div class="input-field">
                                                    <?php echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                                                    <?php
                                                    echo form_input(array(
                                                        'id' => 'interview_date',
                                                        'name' => 'interview_date',
                                                        'placeholder' => 'Interview Date',
                                                        'data-format' => 'yyyy-mm-dd',
                                                        'class' => 're_interview_date_' . $result['id'],
                                                        'data-error' => '.addOpening4',
                                                    ));
                                                    ?>   
                                                    <div class="addOpening4"></div>                                
                                                    <?php echo form_error('interview_date'); ?> 
                                                </div>                                        
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="input-field">
                                                    <?php echo form_label(lang('interview_time')); ?>

                                                    <?php
                                                    echo form_input(array(
                                                        'id' => 'interview_time',
                                                        'name' => 'interview_time',
                                                        'placeholder' => 'Interview Time',
                                                        'data-template' => "dropdown",
                                                        'data-show-seconds' => "true",
                                                        'data-default-time' => "09:45 PM",
                                                        'class' => 'timepicker',
                                                        'data-error' => '.addOpening5',
                                                    ));
                                                    ?>   

                                                                                                                                                <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                                    <div class="addOpening5"></div>
                                                </div>
                                            </div>

                                            <div class="clearfix"></div>

                                            <!--                            <div class="col-sm-12">
                                                                            <div class="input-field">
                                                                                <label for="sccomment" class="active">Comment*</label>
                                                                                <textarea id="sccomment" placeholder="Comment" data-error=".errorTxt98" class="materialize-textarea"></textarea>
                                                                                <div class="errorTxt98"></div>
                                                                            </div>
                                                                        </div>-->


                                            <div class="col-sm-12">
                                                <div class="input-field">
                                                    <?php echo form_label(lang('schedule_comment'), 'schedule_comment', array('for' => 'schedule_comment')); ?>                            <?php
                                                    echo form_textarea(array(
                                                        'name' => 'schedule_comment',
                                                        'id' => 'schedule_comment',
                                                        'class' => 'browser-default materialize-textarea',
                                                        'placeholder' => 'Comment',
                                                        'type' => 'text',
                                                        'data-error' => '.addCandidate6',
                                                    ));
                                                    ?>                       
                                                    <div class="addCandidate6"></div>
                                                    <?php echo form_error('schedule_comment'); ?>
                                                </div>         
                                            </div> 


                                            <div class="col-sm-12">
                                                <div class="input-field">
                                                    <?php echo form_label(lang('reschedule_comment'), 'reschedule_comment', array('for' => 'reschedule_comment')); ?>                            <?php
                                                    echo form_textarea(array(
                                                        'name' => 'reschedule_comment',
                                                        'id' => 'reschedule_comment',
                                                        'class' => 'browser-default materialize-textarea',
                                                        'placeholder' => 'Reschedule Comment',
                                                        'type' => 'text',
                                                        'data-error' => '.addCandidate6',
                                                    ));
                                                    ?>                       
                                                    <div class="addCandidate6"></div>
                                                    <?php echo form_error('reschedule_comment'); ?>
                                                </div>         
                                            </div>


                                            <input type="hidden" name="interview_round_number" value="3">
                                            <input type="hidden" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                            <input type="hidden" name="candidate_id" value="<?php echo $result['id'] ?>">
                                            <input type="hidden" name="position" value="<?php echo $result['position'] ?>">

                                            <div class="clearfix"></div>

                                            <div class="col-sm-12 text-right padding-top-10">
                                                <!--                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                                <button type="submit" onclick="return validate_reschedule_form(<?php echo $result['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>

                                            </div>
                                        </div>
                                        <?php echo form_close(); ?>
                                    </div>
                                </div>                                                    
                            </div>
                        </div>
                    </div>
                    <script type="text/javascript">
                        /* Date picker validation Fucntions */
                        $(document).ready(function () {
                            $(".re_interview_date_<?php echo $result['id'] ?>").click(function () {
                                $('.re_interview_date_<?php echo $result['id'] ?>').pickadate({
                                    selectYears: true,
                                    selectMonths: true,
                                    min: new Date(),
                                });
                            });
                        });
                    </script>
                <?php } ?>
            <?php } ?>



            <?php foreach ($candidates4 as $r => $result) { ?>
                <?php if (isset($result['schedule_details'])) { ?>

                    <div class="modal fade" id="recruitment-reschedule4_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title">Re-Schedule Interview</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="user-modal-slim"> 
                                        <?php
                                        // var_dump($candiate);die;
                                        echo form_open('recruitment/reschedule_interview/', array('id' => 'reschdule_interview_id' . $result['id'], 'class' => 'reschdule_interview_id'));
                                        ?> 
                                        <div class="row">

                                            <div class="col-sm-6">
                                                <?php echo form_label(lang('interviewer_id'), 'interviewer_id', array('for' => 'interviewer_id')); ?>
                                                <?php
                                                echo form_dropdown(array(
                                                    'id' => 'interviewer_id',
                                                    'name' => 'interviewer_id',
                                                    'class' => 'browser-default',
                                                    'data-error' => '.schedule1',
                                                        ), $interviewer_list);
                                                ?>
                                                <div class="input-field">
                                                    <div class="schedule1"></div>
                                                    <?php echo form_error('interviewer_id'); ?> 
                                                </div>                    
                                            </div>

                                            <div class="col-sm-6">
                                                <?php echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                                                <?php
                                                echo form_dropdown(array(
                                                    'id' => 'interview_mode',
                                                    'name' => 'interview_mode',
                                                    'class' => 'browser-default',
                                                    'data-error' => '.schedule3',
                                                        ), $interview_mode_list);
                                                ?>
                                                <div class="input-field">
                                                    <div class="schedule3"></div>
                                                    <?php echo form_error('interview_mode'); ?> 
                                                </div>                    
                                            </div

                                            <div class="clearfix">

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                                                        <?php
                                                        echo form_input(array(
                                                            'id' => 'interview_date',
                                                            'name' => 'interview_date',
                                                            'placeholder' => 'Interview Date',
                                                            'data-format' => 'yyyy-mm-dd',
                                                            'class' => 're_interview_date_' . $result['id'],
                                                            'data-error' => '.addOpening4',
                                                        ));
                                                        ?>   
                                                        <div class="addOpening4"></div>                                
                                                        <?php echo form_error('interview_date'); ?> 
                                                    </div>                                        
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php echo form_label(lang('interview_time')); ?>

                                                        <?php
                                                        echo form_input(array(
                                                            'id' => 'interview_time',
                                                            'name' => 'interview_time',
                                                            'placeholder' => 'Interview Time',
                                                            'data-template' => "dropdown",
                                                            'data-show-seconds' => "true",
                                                            'data-default-time' => "09:45 PM",
                                                            'class' => 'timepicker',
                                                            'data-error' => '.addOpening5',
                                                        ));
                                                        ?>   

                                                                                                                                                <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                                        <div class="addOpening5"></div>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>

                                                <!--                            <div class="col-sm-12">
                                                                                <div class="input-field">
                                                                                    <label for="sccomment" class="active">Comment*</label>
                                                                                    <textarea id="sccomment" placeholder="Comment" data-error=".errorTxt98" class="materialize-textarea"></textarea>
                                                                                    <div class="errorTxt98"></div>
                                                                                </div>
                                                                            </div>-->


                                                <div class="col-sm-12">
                                                    <div class="input-field">
                                                        <?php echo form_label(lang('schedule_comment'), 'schedule_comment', array('for' => 'schedule_comment')); ?>                            <?php
                                                        echo form_textarea(array(
                                                            'name' => 'schedule_comment',
                                                            'id' => 'schedule_comment',
                                                            'class' => 'browser-default materialize-textarea',
                                                            'placeholder' => 'Comment',
                                                            'type' => 'text',
                                                            'data-error' => '.addCandidate6',
                                                        ));
                                                        ?>                       
                                                        <div class="addCandidate6"></div>
                                                        <?php echo form_error('schedule_comment'); ?>
                                                    </div>         
                                                </div> 


                                                <div class="col-sm-12">
                                                    <div class="input-field">
                                                        <?php echo form_label(lang('reschedule_comment'), 'reschedule_comment', array('for' => 'reschedule_comment')); ?>                            <?php
                                                        echo form_textarea(array(
                                                            'name' => 'reschedule_comment',
                                                            'id' => 'reschedule_comment',
                                                            'class' => 'browser-default materialize-textarea',
                                                            'placeholder' => 'Reschedule Comment',
                                                            'type' => 'text',
                                                            'data-error' => '.addCandidate6',
                                                        ));
                                                        ?>                       
                                                        <div class="addCandidate6"></div>
                                                        <?php echo form_error('reschedule_comment'); ?>
                                                    </div>         
                                                </div>


                                                <input type="hidden" name="interview_round_number" value="4">
                                                <input type="hidden" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                                <input type="hidden" name="candidate_id" value="<?php echo $result['id'] ?>">
                                                <input type="hidden" name="position" value="<?php echo $result['position'] ?>">

                                                <div class="clearfix"></div>

                                                <div class="col-sm-12 text-right padding-top-10">
                                                    <!--                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                                    <button type="submit" onclick="return validate_reschedule_form(<?php echo $result['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>

                                                </div>
                                            </div>
                                            <?php echo form_close(); ?>
                                        </div>
                                    </div>                                                    
                                </div>
                            </div>
                        </div>
                        <script type="text/javascript">
                            /* Date picker validation Fucntions */
                            $(document).ready(function () {
                                $(".re_interview_date_<?php echo $result['id'] ?>").click(function () {
                                    $('.re_interview_date_<?php echo $result['id'] ?>').pickadate({
                                        selectYears: true,
                                        selectMonths: true,
                                        min: new Date(),
                                    });
                                });
                            });
                        </script>
                    <?php } ?>
                <?php } ?>




                <?php foreach ($candidates5 as $r => $result) { ?>
                    <?php if (isset($result['schedule_details'])) { ?>

                        <div class="modal fade" id="recruitment-reschedule5_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close schedule_close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 class="modal-title">Re-Schedule Interview</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="user-modal-slim"> 
                                            <?php
                                            // var_dump($candiate);die;
                                            echo form_open('recruitment/reschedule_interview/', array('id' => 'reschdule_interview_id' . $result['id'], 'class' => 'reschdule_interview_id'));
                                            ?> 
                                            <div class="row">

                                                <div class="col-sm-6">
                                                    <?php echo form_label(lang('interviewer_id'), 'interviewer_id', array('for' => 'interviewer_id')); ?>
                                                    <?php
                                                    echo form_dropdown(array(
                                                        'id' => 'interviewer_id',
                                                        'name' => 'interviewer_id',
                                                        'class' => 'browser-default',
                                                        'data-error' => '.schedule1',
                                                            ), $interviewer_list);
                                                    ?>
                                                    <div class="input-field">
                                                        <div class="schedule1"></div>
                                                        <?php echo form_error('interviewer_id'); ?> 
                                                    </div>                    
                                                </div>

                                                <div class="col-sm-6">
                                                    <?php echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                                                    <?php
                                                    echo form_dropdown(array(
                                                        'id' => 'interview_mode',
                                                        'name' => 'interview_mode',
                                                        'class' => 'browser-default',
                                                        'data-error' => '.schedule3',
                                                            ), $interview_mode_list);
                                                    ?>
                                                    <div class="input-field">
                                                        <div class="schedule3"></div>
                                                        <?php echo form_error('interview_mode'); ?> 
                                                    </div>                    
                                                </div

                                                <div class="clearfix">

                                                    <div class="col-sm-6">
                                                        <div class="input-field">
                                                            <?php echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                                                            <?php
                                                            echo form_input(array(
                                                                'id' => 'interview_date',
                                                                'name' => 'interview_date',
                                                                'placeholder' => 'Interview Date',
                                                                'data-format' => 'yyyy-mm-dd',
                                                                'class' => 're_interview_date_' . $result['id'],
                                                                'data-error' => '.addOpening4',
                                                            ));
                                                            ?>   
                                                            <div class="addOpening4"></div>                                
                                                            <?php echo form_error('interview_date'); ?> 
                                                        </div>                                        
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="input-field">
                                                            <?php echo form_label(lang('interview_time')); ?>

                                                            <?php
                                                            echo form_input(array(
                                                                'id' => 'interview_time',
                                                                'name' => 'interview_time',
                                                                'placeholder' => 'Interview Time',
                                                                'data-template' => "dropdown",
                                                                'data-show-seconds' => "true",
                                                                'data-default-time' => "09:45 PM",
                                                                'class' => 'timepicker',
                                                                'data-error' => '.addOpening5',
                                                            ));
                                                            ?>   

                                                                                                                                                <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                                            <div class="addOpening5"></div>
                                                        </div>
                                                    </div>

                                                    <div class="clearfix"></div>

                                                    <!--                            <div class="col-sm-12">
                                                                                    <div class="input-field">
                                                                                        <label for="sccomment" class="active">Comment*</label>
                                                                                        <textarea id="sccomment" placeholder="Comment" data-error=".errorTxt98" class="materialize-textarea"></textarea>
                                                                                        <div class="errorTxt98"></div>
                                                                                    </div>
                                                                                </div>-->


                                                    <div class="col-sm-12">
                                                        <div class="input-field">
                                                            <?php echo form_label(lang('schedule_comment'), 'schedule_comment', array('for' => 'schedule_comment')); ?>                            <?php
                                                            echo form_textarea(array(
                                                                'name' => 'schedule_comment',
                                                                'id' => 'schedule_comment',
                                                                'class' => 'browser-default materialize-textarea',
                                                                'placeholder' => 'Comment',
                                                                'type' => 'text',
                                                                'data-error' => '.addCandidate6',
                                                            ));
                                                            ?>                       
                                                            <div class="addCandidate6"></div>
                                                            <?php echo form_error('schedule_comment'); ?>
                                                        </div>         
                                                    </div> 


                                                    <div class="col-sm-12">
                                                        <div class="input-field">
                                                            <?php echo form_label(lang('reschedule_comment'), 'reschedule_comment', array('for' => 'reschedule_comment')); ?>                            <?php
                                                            echo form_textarea(array(
                                                                'name' => 'reschedule_comment',
                                                                'id' => 'reschedule_comment',
                                                                'class' => 'browser-default materialize-textarea',
                                                                'placeholder' => 'Reschedule Comment',
                                                                'type' => 'text',
                                                                'data-error' => '.addCandidate6',
                                                            ));
                                                            ?>                       
                                                            <div class="addCandidate6"></div>
                                                            <?php echo form_error('reschedule_comment'); ?>
                                                        </div>         
                                                    </div>


                                                    <input type="hidden" name="interview_round_number" value="5">
                                                    <input type="hidden" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                                                    <input type="hidden" name="candidate_id" value="<?php echo $result['id'] ?>">
                                                    <input type="hidden" name="position" value="<?php echo $result['position'] ?>">

                                                    <div class="clearfix"></div>

                                                    <div class="col-sm-12 text-right padding-top-10">
                                                        <!--                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                                        <button type="submit" onclick="return validate_reschedule_form(<?php echo $result['id'] ?>)"  class="btn btn-warning2 btn-sm">Submit</button>

                                                    </div>
                                                </div>
                                                <?php echo form_close(); ?>
                                            </div>
                                        </div>                                                    
                                    </div>
                                </div>
                            </div>
                            <script type="text/javascript">
                                /* Date picker validation Fucntions */
                                $(document).ready(function () {
                                    $(".re_interview_date_<?php echo $result['id'] ?>").click(function () {
                                        $('.re_interview_date_<?php echo $result['id'] ?>').pickadate({
                                            selectYears: true,
                                            selectMonths: true,
                                            min: new Date(),
                                        });
                                    });
                                });
                            </script>
                        <?php } ?>
                    <?php } ?>










                    </script>
                    <script type="text/javascript">

                        $(document).ready(function () {


                            $(".schedule_close").click(function () {

                                $(this).removeClass('error');
                                $('.error').html('');
                            });
                        });
                    </script>