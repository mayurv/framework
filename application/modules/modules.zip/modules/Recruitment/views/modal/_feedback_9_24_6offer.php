<?php //var_dump($candidates1);die;           ?>
<?php
if (isset($candidates1)) {
    foreach ($candidates1 as $r => $result) {
//var_dump($result);
        ?>
        <div class="modal fade" id="recruitment-feedback1_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?><span class="text-light-gray"> Interview Details</span></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <?php
                                    //var_dump($result['schedule_details']['reschedule_details']);
                                    if (isset($result['interview_round_details']) && !empty($result['interview_round_details']))
                                        foreach ($result['interview_round_details'] as $roundDetails) {
//                                        var_dump($roundDetails);
                                            ?>
                                            <?php if (($roundDetails['round_status'] == 'schedule') || ($roundDetails['round_status'] == 'reschedule')) { ?> 
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Round:</span> 
                                                    <span><?php echo $roundDetails['interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetails['interview_date'] ?></span>
                                                    <span> <?php echo $roundDetails['interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                </div>
                                            <?php } ?>




                                            <?php if ($roundDetails['interview_round_completed'] == '1') { ?>                                    
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Round:</span> 
                                                    <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                                                        <?php echo $roundDetails['interviewer_comments'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">




                                            <?php } else { ?>

                                                <!--<div class="col-sm-12 margin-bottom-10">Interview round 1 feedback empty</div>-->
                                            <?php } ?> 



                                        <?php } ?>  
                                    <?php
                                    if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                        foreach ($result['schedule_details']['reschedule_details'] as $roundDetails) {
//                                            var_dump($roundDetails);
                                            ?>
                                            <hr style="width: 80%; height: 5px">
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                <span><?php echo $roundDetails['res_interview_round_number'] ?></span>
                                            </div>

                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="clr-999">Interview Schdule on :</span>
                                                <span> <?php echo $roundDetails['res_interview_date'] ?></span>
                                                <span> <?php echo $roundDetails['res_interview_time'] ?></span>
                                            </div>

                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['res_interviewer_name'] ?></span>
                                            </div>

                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="clr-999">Type:</span> <span><?php echo $roundDetails['res_interview_mode'] ?></span>
                                            </div>

                                            <div class="col-sm-12 margin-bottom-10">
                                                <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetails['reschedule_comment'] ?></span>
                                            </div>

                                        <?php } ?>
                                    <?php } ?>


                                    <?php
//                                    } else {
//                                        echo 'not yet33';
//                                    }
                                    ?>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>      
        <?php
    }
}
?>


<?php
if (isset($candidates2)) {
    foreach ($candidates2 as $r => $result) {
        ?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback2_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="row">

                                        <?php
                                        //var_dump($result['schedule_details']['reschedule_details']);
                                        if (isset($result['interview_round_details']) && !empty($result['interview_round_details']))
                                            foreach ($result['interview_round_details'] as $roundDetails) {
                                                ?>
                                                <?php
                                                if (($roundDetails['interview_round_number'] <= '2')) {
                                                    if (($roundDetails['round_status'] == 'schedule') || ($roundDetails['round_status'] == 'reschedule')) {
                                                        ?> 
                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Round:</span> 
                                                            <span><?php echo $roundDetails['interview_round_number'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Schdule on :</span>
                                                            <span> <?php echo $roundDetails['interview_date'] ?></span>
                                                            <span> <?php echo $roundDetails['interview_time'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                        </div>
                                                    <?php } ?>
                                                <?php } ?>
                                                <hr style="width: 80%; height: 5px">



                                                <?php if (($roundDetails['interview_round_completed'] <= '2') && ($roundDetails['interview_round_completed'] != '0')) { ?>                                    
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Round:</span> 
                                                        <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                    </div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                        <label class="control-label clr-999">Comment</label>
                                                        <p>
                                                            <?php echo $roundDetails['interviewer_comments'] ?>
                                                        </p>
                                                    </div>
                                                    <hr style="width: 80%; height: 5px">




                                                <?php } else { ?>

                                                    <!--<div class="col-sm-12 margin-bottom-10">Interview round 1 feedback empty</div>-->
                                                <?php } ?> 



                                            <?php } ?>  
                                        <?php
                                        if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                            foreach ($result['schedule_details']['reschedule_details'] as $roundDetails) {
                                                //var_dump($roundDetails);
                                                ?>
                                                <hr style="width: 80%; height: 5px">
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                    <span><?php echo $roundDetails['res_interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetails['res_interview_date'] ?></span>
                                                    <span> <?php echo $roundDetails['res_interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['res_interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['res_interview_mode'] ?></span>
                                                </div>

                                                <div class="col-sm-12 margin-bottom-10">
                                                    <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetails['reschedule_comment'] ?></span>
                                                </div>

                                            <?php } ?>
                                        <?php } ?>


                                        <?php
//                                    } else {
//                                        echo 'not yet33';
//                                    }
                                        ?>
                                    </div>

                                    <?php
                                    if (isset($result['interview_skip_details'])) {
                                        foreach ($result['interview_skip_details'] as $roundDetails) {
                                            ?>
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="text-orange">Skip Round:</span> 
                                                <span class="text-orange"><?php echo $roundDetails['interview_round_number'] ?></span>
                                            </div>
                                            <?php if ($roundDetails['interview_round_number'] <= 1) { ?>                                               
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                                                        <?php echo $roundDetails['skip_comment'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">

                                                <?php
                                            }
                                        }
                                    }
                                    ?>  

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>
        <?php
    }
}
?>


<?php
if (isset($candidates3)) {
    foreach ($candidates3 as $r => $result) {
//        var_dump($result);die;
        ?>  
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback3_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="row">

                                        <?php
                                        //var_dump($result['schedule_details']['reschedule_details']);
                                        if (isset($result['interview_round_details']) && !empty($result['interview_round_details']))
                                            foreach ($result['interview_round_details'] as $roundDetails) {
//                                                var_dump($roundDetails);
                                                ?>
                                                <?php
                                                if (($roundDetails['interview_round_number'] <= '3')) {
                                                    if (($roundDetails['round_status'] == 'schedule') || ($roundDetails['round_status'] == 'reschedule')) {
                                                        ?> 
                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Round:</span> 
                                                            <span><?php echo $roundDetails['interview_round_number'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Schdule on :</span>
                                                            <span> <?php echo $roundDetails['interview_date'] ?></span>
                                                            <span> <?php echo $roundDetails['interview_time'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                        </div>
                                                    <?php }
                                                }
                                                ?>




                <?php if (($roundDetails['interview_round_completed'] <= '3') && ($roundDetails['interview_round_completed'] != '0')) { ?>                                    
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Round:</span> 
                                                        <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                    </div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                        <label class="control-label clr-999">Comment</label>
                                                        <p>
                    <?php echo $roundDetails['interviewer_comments'] ?>
                                                        </p>
                                                    </div>
                                                    <hr style="width: 80%; height: 5px">




                <?php } else { ?>

                                                    <!--<div class="col-sm-12 margin-bottom-10">Interview round 1 feedback empty</div>-->
                <?php } ?> 



                                            <?php } ?>  
                                        <?php
                                        if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                            foreach ($result['schedule_details']['reschedule_details'] as $roundDetails) {
                                                //var_dump($roundDetails);
                                                ?>
                                                <hr style="width: 80%; height: 5px">
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                    <span><?php echo $roundDetails['res_interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetails['res_interview_date'] ?></span>
                                                    <span> <?php echo $roundDetails['res_interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['res_interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['res_interview_mode'] ?></span>
                                                </div>

                                                <div class="col-sm-12 margin-bottom-10">
                                                    <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetails['reschedule_comment'] ?></span>
                                                </div>

                                            <?php } ?>
        <?php } ?>


                                        <?php
//                                    } else {
//                                        echo 'not yet33';
//                                    }
                                        ?>
                                    </div>

                                    <?php
                                    if (isset($result['interview_skip_details'])) {
                                        foreach ($result['interview_skip_details'] as $roundDetails) {
                                            ?>
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="text-orange">Skip Round:</span> 
                                                <span class="text-orange"><?php echo $roundDetails['interview_round_number'] ?></span>
                                            </div>
                <?php if ($roundDetails['interview_round_number'] <= 2) { ?>                                               
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                    <?php echo $roundDetails['skip_comment'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">

                                                <?php
                                            }
                                        }
                                    }
                                    ?>  

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>
        <?php
    }
}
?>


<?php
if (isset($candidates4)) {
    foreach ($candidates4 as $r => $result) {
        ?> 
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback4_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="row">

                                        <?php
                                        //var_dump($result['schedule_details']['reschedule_details']);
                                        if (isset($result['interview_round_details']) && !empty($result['interview_round_details']))
                                            foreach ($result['interview_round_details'] as $roundDetails) {
                                                ?>
                                                <?php
                                                if (($roundDetails['interview_round_number'] <= '4')) {
                                                    if (($roundDetails['round_status'] == 'schedule') || ($roundDetails['round_status'] == 'reschedule')) {
                                                        ?> 
                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Round:</span> 
                                                            <span><?php echo $roundDetails['interview_round_number'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Schdule on :</span>
                                                            <span> <?php echo $roundDetails['interview_date'] ?></span>
                                                            <span> <?php echo $roundDetails['interview_time'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                        </div>
                                                    <?php }
                                                }
                                                ?>




                <?php if (($roundDetails['interview_round_completed'] <= '4') && ($roundDetails['interview_round_completed'] != '0')) { ?>                                    
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Round:</span> 
                                                        <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                    </div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                        <label class="control-label clr-999">Comment</label>
                                                        <p>
                    <?php echo $roundDetails['interviewer_comments'] ?>
                                                        </p>
                                                    </div>
                                                    <hr style="width: 80%; height: 5px">




                                                <?php } else { ?>

                                                    <!--<div class="col-sm-12 margin-bottom-10">Interview round 1 feedback empty</div>-->
                <?php } ?> 



                                            <?php } ?>  
                                        <?php
                                        if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                            foreach ($result['schedule_details']['reschedule_details'] as $roundDetails) {
                                                //var_dump($roundDetails);
                                                ?>
                                                <hr style="width: 80%; height: 5px">
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                    <span><?php echo $roundDetails['res_interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetails['res_interview_date'] ?></span>
                                                    <span> <?php echo $roundDetails['res_interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['res_interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['res_interview_mode'] ?></span>
                                                </div>

                                                <div class="col-sm-12 margin-bottom-10">
                                                    <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetails['reschedule_comment'] ?></span>
                                                </div>

            <?php } ?>
                                        <?php } ?>


                                        <?php
//                                    } else {
//                                        echo 'not yet33';
//                                    }
                                        ?>
                                    </div>

                                    <?php
                                    if (isset($result['interview_skip_details'])) {
                                        foreach ($result['interview_skip_details'] as $roundDetails) {
                                            ?>
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="text-orange">Skip Round:</span> 
                                                <span class="text-orange"><?php echo $roundDetails['interview_round_number'] ?></span>
                                            </div>
                <?php if ($roundDetails['interview_round_number'] <= 3) { ?>                                               
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                    <?php echo $roundDetails['skip_comment'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">

                                                <?php
                                            }
                                        }
                                    }
                                    ?>  

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>

        <?php
    }
}
?>


<?php
if (isset($candidates5)) {
    foreach ($candidates5 as $r => $result) {
        ?>  
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback5_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">

                                    <div class="row">

                                        <?php
                                        //var_dump($result['schedule_details']['reschedule_details']);
                                        if (isset($result['interview_round_details']) && !empty($result['interview_round_details']))
                                            foreach ($result['interview_round_details'] as $roundDetails) {
                                                ?>
                                                <?php
                                                if (($roundDetails['interview_round_number'] <= '5')) {
                                                    if (($roundDetails['round_status'] == 'schedule') || ($roundDetails['round_status'] == 'reschedule')) {
                                                        ?> 
                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Round:</span> 
                                                            <span><?php echo $roundDetails['interview_round_number'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Interview Schdule on :</span>
                                                            <span> <?php echo $roundDetails['interview_date'] ?></span>
                                                            <span> <?php echo $roundDetails['interview_time'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                        </div>

                                                        <div class="col-sm-6 margin-bottom-10">
                                                            <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                        </div>
                    <?php }
                }
                ?>




                <?php if (($roundDetails['interview_round_completed'] <= '5') && ($roundDetails['interview_round_completed'] != '0')) { ?>                                    
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Round:</span> 
                                                        <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                    </div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>

                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                    </div>
                                                    <div class="col-sm-6 margin-bottom-10">
                                                        <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                    <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                        <label class="control-label clr-999">Comment</label>
                                                        <p>
                    <?php echo $roundDetails['interviewer_comments'] ?>
                                                        </p>
                                                    </div>
                                                    <hr style="width: 80%; height: 5px">




                                                <?php } else { ?>

                                                    <!--<div class="col-sm-12 margin-bottom-10">Interview round 1 feedback empty</div>-->
                                                <?php } ?> 



                                            <?php } ?>  
                                        <?php
                                        if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                            foreach ($result['schedule_details']['reschedule_details'] as $roundDetails) {
                                                //var_dump($roundDetails);
                                                ?>
                                                <hr style="width: 80%; height: 5px">
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                    <span><?php echo $roundDetails['res_interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetails['res_interview_date'] ?></span>
                                                    <span> <?php echo $roundDetails['res_interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetails['res_interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['res_interview_mode'] ?></span>
                                                </div>

                                                <div class="col-sm-12 margin-bottom-10">
                                                    <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetails['reschedule_comment'] ?></span>
                                                </div>

                                            <?php } ?>
                                        <?php } ?>


                                        <?php
//                                    } else {
//                                        echo 'not yet33';
//                                    }
                                        ?>
                                    </div>

                                    <?php
                                    if (isset($result['interview_skip_details'])) {
                                        foreach ($result['interview_skip_details'] as $roundDetails) {
                                            ?>
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="text-orange">Skip Round:</span> 
                                                <span class="text-orange"><?php echo $roundDetails['interview_round_number'] ?></span>
                                            </div>
                <?php if ($roundDetails['interview_round_number'] <= 4) { ?>                                               
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                    <?php echo $roundDetails['skip_comment'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">

                                                <?php
                                            }
                                        }
                                    }
                                    ?>  

                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>

        <?php
    }
}
?>


<?php if (isset($candidates6)) { ?>
   <?php foreach ($candidates6 as $r => $result) { ?>

        <?php $i = 6;?>
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback6_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
//                                        if ($result['interview_round_details']['interview_round_number']==6 && ($result['interview_round_details']['round_status']) == 'Completed' ) {
                                        
                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>  
                                    <?php $round_status = array('Completed','skip','Send Offer','Accept Offer','hold_offer','reject offer','reschedule','schedule','rejected','Register');?>
                                    <?php echo '<br>************Round number-  '.$i.'<br>';?>
                                            <?php if($roundDetails['interview_round_number']==$i && in_array($roundDetails['round_status'],$round_status)) {?>
                                    <?php
                                                    if (isset($result['interview_skip_details'])  ) {
                                                        foreach ($result['interview_skip_details'] as $roundDetailskp) {
                                                            ?>
                                    <?php if(($roundDetailskp['interview_round_number'] == $roundDetails['interview_round_number'])){?>
                                                            <div class="col-sm-6 margin-bottom-10">
                                                                <span class="text-orange">Skip Round:</span> 
                                                                <span class="text-orange"><?php echo $roundDetailskp['interview_round_number'] ?></span>
                                                            </div>
                                <?php if ($roundDetailskp['interview_round_number'] <= 5) { ?>                                               
                                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                                    <label class="control-label clr-999">Comment</label>
                                                                    <p>
                                    <?php echo $roundDetailskp['skip_comment'] ?>
                                                                    </p>
                                                                </div>
                                                                <hr style="width: 80%; height: 5px">

                                                                <?php
                                                        }}
                                                        }
                                                    }
                                                    ?>  
                                                                <!--all 6 rounds conditions-->
                                            <?php if ($roundDetails['round_status'] == 'Send Offer' || $roundDetails['round_status'] == 'hold_offer' || $roundDetails['round_status'] == 'Accept Offer') { ?> 
                                                                <?php echo $roundDetails['round_status'];} ?>
                                                                <!--end all 6 rounds conditions-->
                                                                
                                                                
                                                                <!--Start Interviwer feedback-->
                                                                 <?php if ($roundDetails['interview_round_completed'] == $roundDetails['interview_round_number'] && $i!=6) { ?>                                    
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Round:</span> 
                                                    <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                                                <?php echo $roundDetails['interviewer_comments'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">
                                                <?php } ?>
                                                <!--End Interviwer feedback-->
                                                                 
                                                
                                                
                                                <!--Hold Offer-->
                                                <?php  if (isset($result['interview_hold_details'])) {
                                                        foreach ($result['interview_hold_details'] as $roundDetailshold) {  ?>
                                                <?php if(($roundDetailshold['interview_round_number'] == $roundDetails['interview_round_number'])){?>
                                                            <div class="col-sm-6 margin-bottom-10">
                                                                <span >Round <?php echo $roundDetailshold['interview_round_number'] ?>:</span> 
                                                                <span >Hold</span>
                                                            </div>

                                                            <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                                <label class="control-label clr-999">Comment</label>
                                                                <p>
                                                                    <?php echo $roundDetailshold['hold_offer_comment'] ?>
                                                                </p>
                                                            </div>
                                                            <hr style="width: 80%; height: 5px">

                                                            <?php
                                                }
                                                        }
                                                    }
                                                    ?> 
                                                    <!--End Hold Offer-->
                                                    
                                                    
                                                    <!--start reschedule round-->
                                                                  <?php
                                        if (isset($result['schedule_details']['reschedule_details']) && !empty($result['schedule_details']['reschedule_details'])) {
                                            foreach ($result['schedule_details']['reschedule_details'] as $roundDetailsres) { ?>
                                               <?php if(($roundDetailsres['interview_round_number'] == $roundDetails['interview_round_number'])){?>
                                                
                                                <hr style="width: 80%; height: 5px">
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999 text-orange">Reschedule Interview Round:</span> 
                                                    <span><?php echo $roundDetailsres['res_interview_round_number'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Schdule on :</span>
                                                    <span> <?php echo $roundDetailsres['res_interview_date'] ?></span>
                                                    <span> <?php echo $roundDetailsres['res_interview_time'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Schedule To:</span><span> <?php echo $roundDetailsres['res_interviewer_name'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetailsres['res_interview_mode'] ?></span>
                                                </div>

                                                <div class="col-sm-12 margin-bottom-10">
                                                    <span class="clr-999">Reschedule Comment:</span> <span><?php echo $roundDetailsres['reschedule_comment'] ?></span>
                                                </div>

                                            <?php }
                                            } ?>
                                        <?php } ?>
                                                    <!--end reschedule round-->
                                                    
                                                            
                                                
                                                
                                            <?php }?>
                                            <?php $i--;} ?>
                                                
                                                  
            <?php } ?>  
                                  
       




                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>
 <?php } ?>
        <?php } ?>


<?php
if (isset($candidates7)) {
    foreach ($candidates7 as $r => $result) {
        ?> 
        <!-- feedbackview modal -->
        <div class="modal fade" id="recruitment-feedback7_<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-500">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header all-padding-10">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title font-16"><?php echo $result['candidate_name'] ?></h4>
                    </div>
                    <!-- modal body here --> 
                    <div class="user-modal-slim">
                        <div class="modal-body">
                            <div class="candidate-timeline-bg">
                                <div class="row">
                                    <?php
                                    if (isset($result['interview_round_details'])) {
                                        foreach ($result['interview_round_details'] as $roundDetails) {
                                            ?>
                <?php if ($roundDetails['interviewer_rating'] != '') { ?>                                    
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Round:</span> 
                                                    <span><?php echo $roundDetails['interview_round_completed'] ?></span>
                                                </div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Interview Taken on:</span><span> <?php echo $roundDetails['interview_date'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Type:</span> <span><?php echo $roundDetails['interview_mode'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Taken by:</span><span> <?php echo $roundDetails['interviewer_name'] ?></span>
                                                </div>
                                                <div class="col-sm-6 margin-bottom-10">
                                                    <span class="clr-999">Rating:</span> <span><?php echo $roundDetails['interviewer_rating'] ?></span>
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                                                <?php echo $roundDetails['interviewer_comments'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">
                                            <?php } else { ?>
                                                <!--<div class="col-sm-6 margin-bottom-10">Interview round 2 feedback empty</div>-->
                                            <?php } ?>                                                
                                        <?php } ?>                                                
                                    <?php } ?>
                                    <?php
                                    if (isset($result['interview_skip_details'])) {
                                        foreach ($result['interview_skip_details'] as $roundDetails) {
                                            ?>
                                            <div class="col-sm-6 margin-bottom-10">
                                                <span class="text-orange">Skip Round:</span> 
                                                <span class="text-orange"><?php echo $roundDetails['interview_round_number'] ?></span>
                                            </div>
                <?php if ($roundDetails['interview_round_number'] <= 6) { ?>                                               
                                                <div class="col-sm-12 margin-bottom-10 padding-bottom-10 border-bottom1">

                                                    <label class="control-label clr-999">Comment</label>
                                                    <p>
                    <?php echo $roundDetails['skip_comment'] ?>
                                                    </p>
                                                </div>
                                                <hr style="width: 80%; height: 5px">

                                                <?php
                                            }
                                        }
                                    }
                                    ?>        
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>

        <?php
    }
}
?>





<!--feedback modal start -->
<div class="modal fade" id="recruitment-feedback-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Feedback</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <form class="formValidate" id="formValidate" method="post" action="">
                        <div class="row">
                            <div class="col-sm-4"> 
                                <p class="font-size-15 text-bold">Baliram Kamble</p>
                                <p>5 Year 6 Months</p>
                            </div>
                            <div class="col-sm-4">
                                <label for="feedround">Round*</label>
                                <select class="browser-default"  id="feedround" name="feedround" data-error=".errorTxt101">
                                    <option value="" disabled selected>Round</option>
                                    <option value="1">Telephonic</option>
                                    <option value="1">Face 2 Face</option>
                                </select>       
                                <div class="input-field">
                                    <div class="errorTxt101"></div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <p class="text-bold">Interview Date: 24/01/2017</p>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2 margin-top-10 margin-bottom-10">       
                                <p class="text-bold">Sr. No.</p>
                            </div>

                            <div class="col-sm-5 margin-top-10 margin-bottom-10">       
                                <p class="text-bold">Technology</p>
                            </div>
                            <div class="col-sm-5 margin-top-10 margin-bottom-10">      
                                <p class="text-bold">Rating</p>           
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">1</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt1">Opps*</label>
                                    <input id="feedt1" name="feedt1"  placeholder="Opps " type="text" data-error=".errorTxt102">
                                    <div class="errorTxt102"></div>
                                </div>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt2">PHP*</label>
                                    <input id="feedt2" name="feedt2"  placeholder="PHP " type="text" data-error=".errorTxt103">
                                    <div class="errorTxt103"></div>
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">2</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt3">CI*</label>
                                    <input id="feedt3" name="feedt3"  placeholder="CI " type="text" data-error=".errorTxt104">
                                    <div class="errorTxt104"></div>
                                </div>
                            </div>      

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt4">Database*</label>
                                    <input id="feedt4" name="feedt4"  placeholder="Database " type="text" data-error=".errorTxt104">
                                    <div class="errorTxt104"></div>
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-sm-2">       
                                <p class="margin-top-25">3</p>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt5">Jquery*</label>
                                    <input id="feedt5" name="feedt5"  placeholder="Jquery " type="text" data-error=".errorTxt105">
                                    <div class="errorTxt105"></div>
                                </div>
                            </div>

                            <div class="col-sm-5">                                          
                                <div class="input-field">
                                    <label for="feedt6">Javascript*</label>
                                    <input id="feedt6" name="feedt6"  placeholder="Javascript " type="text" data-error=".errorTxt106">
                                    <div class="errorTxt106"></div>
                                </div>
                            </div>                                       
                            <div class="clearfix"></div>

                            <div class="col-sm-6">                                          
                                <div class="input-field">
                                    <label for="feedarating">Average Rating*</label>
                                    <input id="feedarating" name="feedarating"  placeholder="Average Rating" type="text" data-error=".errorTxt107">
                                    <div class="errorTxt107"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <label for="feedstatus">Status*</label>
                                <select class="browser-default"  id="feedstatus" name="feedstatus" data-error=".errorTxt108">
                                    <option value="" disabled selected>Status</option>
                                    <option value="1">Select</option>
                                    <option value="1">Reject</option>              
                                </select>       
                                <div class="input-field">
                                    <div class="errorTxt108"></div>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <label for="feedremark" class="active">Remark*</label>
                                    <textarea id="feedremark" placeholder="Remark" data-error=".errorTxt109" class="materialize-textarea"></textarea>
                                    <div class="errorTxt109"></div>
                                </div>
                            </div>                                        
                            <div class="clearfix"></div>
                            <div class="col-sm-12 text-right padding-top-10">
                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!--feedback modal end -->   