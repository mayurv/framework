<?php foreach ($candidates6 as $r => $result) { ?>  
    <!-- Reject modal start -->
    <div class="modal fade" id="reject_offer_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Reject Round: Interview one</h4>
                </div>
                <div class="modal-body">

                    <div class="user-normal-slim">

                        <div class="">               
                            <?php echo form_open('recruitment/reject_offer/' . $result['id'], array('id' => 'form_reject_offer_id', 'class' => 'form_reject_offer_id')); ?>
                            <!-- 1st row start here -->
                            <div class="row">

                                <div class="col-sm-6">
                                    <label>Candidate Name:</label>
                                </div>
                                <div class="col-sm-6">                                    
                                    <?php echo $result['candidate_name'] ?>

                                </div>

                                <div class="clearfix"></div>
                                <div class="margin-bottom-20"></div>
                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <label for="reject_comment" class="active">Reject Offer Reason</label>
                                        <textarea id="reject_comment" name="reject_offer_comment" placeholder="Reject offer reason in detail" data-error=".errorReject1" class="materialize-textarea" required="true"></textarea>
                                        <div class="errorReject1"></div>
                                    </div>
                                </div>                                

                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button class="btn btn-warning2 btn-sm ">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <input type="hidden" id="req_id" name="req_id" value="<?php echo $result['requisition_id'] ?>">
                            <input type="hidden" id="position_status" name="position_status" value="<?php echo $result['position'] ?>">
                            <input type="hidden"  name="interview_round_number" value="6">
                            <!-- 1st row end here -->
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Reject modal end -->
<?php } ?>