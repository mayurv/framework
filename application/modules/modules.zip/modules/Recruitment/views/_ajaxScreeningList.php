 <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th>Candidate Name</th>
                            <th>Contact Details</th>
                            <th>Round</th>
                            <th>Qualification</th>
                            <th>Skill Set</th>
                            <th>Location</th>
                            <th>Source</th>
                            <th>Experiance</th>
                            <th>CTC</th>
                            <th>Created Date</th>

                        </tr>
                    </thead>
                    <div class="pull-right"> 

                    </div>
                    <tbody class="">
                        <?php foreach ($candidates as $r => $result) { ?>  
                            <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">
                                <td class=""><a title="Click here to view detail Screening Procedure" data-toggle="modal" href="#candidatetimeline_<?php echo $result['id'] ?>"><?php echo $result['candidate_name']; ?></a></td>
                                <td><p class=""><?php echo $result['contact_number']; ?></p>
                                    <p class="text-light-head"><?php echo $result['emailid']; ?></p></td>
                                <td class="">
                                    <?php //echo $result['interview_round_number']; ?>
                                    
                                    <?php  echo  $result['max_interview_round_number'] == '1' ? 'Interview 1' : ($result['max_interview_round_number'] == '2' ? 'Interview 2' :  ($result['max_interview_round_number'] == '3' ? 'Interview 3' :  ($result['max_interview_round_number'] == '4' ? 'Client Interview ': ($result['max_interview_round_number'] == '5' ? 'HR Roaund' : ($result['max_interview_round_number'] == '6' ? 'Offer'  : ($result['max_interview_round_number'] == '7' ? 'Joining' : 'Initiated'))))))?>
                                    
                                    
                                    
                                    <p class="text-light-head"><?php if(isset($result['max_round_status'])) echo  $result['max_round_status'] == 'hold_offer' ? '<span class="text-warning">Offer Hold</span>' : ($result['max_round_status'] == 'rejected' ? '<span class="text-danger">Rejected</span>' :  ($result['max_round_status'] == 'reject offer' ? '<span class="text-danger">Reject Offer</span>' :  ($result['max_round_status'] == 'Register' ? '<span class="text-success">Register</span>': ($result['max_round_status'] == 'Accept Offer' ? '<span class="text-success">Accept Offer</span>' : ''))))?></p>
                                </td>
                                <td class=""><?php echo $result['qualification']; ?></td>
                            <td width="20%" class="">
                                    <?php 
                                    $resultstr = array();
                                    foreach ($result['skill_detail'] as $skilldata) {   ?>
                                        <?php if ($skilldata != '') { ?>
                                    <?php  $resultstr[] = $skills_list[$skilldata];?>                                  
                                           <?php } ?>
                                    <?php }?>
                                     <span class="tag skill-lbl"><?php echo implode(",",$resultstr); ?> </span>
                                </td>
                                <td class=""><?php echo $result['cand_location']; ?></td>
                                <td class=""><?php echo $result['business_type']; ?></td>
                                <td class="texttd-light-head">
                                    <p class=""></p><?php echo $result['years_exp']; ?> yrs
                                    <?php echo $result['months_exp']; ?> months
                                </td>
                                <td class="">
                                    <p class="">Current :<?php echo $result['current_ctc']; ?></p>
                                    <p class="">Expected :<?php echo $result['expected_ctc']; ?></p>
                                </td>
                                <td>
                                    <p><?php echo date("j F, Y", strtotime($result['createddate'])); ?></p>

                                </td>



                            </tr>  
                        <?php } ?>
                    </tbody>
                </table>
        <?php echo $this->ajax_pagination->create_links(); ?>
    
<?php $this->load->view('_candidatetimeline'); ?>