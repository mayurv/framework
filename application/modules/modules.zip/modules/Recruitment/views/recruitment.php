<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php $currentDate = date('Y-m-d'); ?>
</div>
<div class="main-bg all-padding-15">
    <div class="row">
        <div class="col-md-6">
            <h4>Recruitment</h4>
        </div>
        <div class="col-sm-6">
            <div class="pull-right">
                <table>
                    <tr>
                        <td>
                            <button class="btn btn-xs btn-default"><i class="fa fa-filter" onclick="return filterReqType('')" title="All"></i></button>
                        </td>
                        <td>
                            &nbsp;<button class="btn btn-xs btn-default" onclick="return filterReqType('1')" title="Drive"><i class="fa fa-users"></i></button>
                        </td>                        
                        <td>
                            &nbsp;<button class="btn btn-xs btn-default" onclick="return filterReqType('2')" title="Walk-in"><i class="fa fa-handshake-o"></i></button>
                        </td>
                        <td>
                            &nbsp;<button class="btn btn-xs btn-default" onclick="return filterReqType('3')" title="Project Req"><i class="fa fa-laptop"></i></button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="req-slim">
                <div class="card_display">
                    <?php foreach ($openings as $result) { //var_dump($result);
                        ?>
                        <div class="col-lg-2 col-md-3 col-sm-4"> 
                            <?php
                            if ($result['complition_status'] == 'false') {
                                $box_shadow = 'box-shadow-warning';
                            } else if ($result['complition_status'] == 'true') {
                                $box_shadow = 'box-shadow-success';
                            } else {
                                $box_shadow = 'box-shadow';
                            }
                            ?>
                            <div class="job-rq-opening-bg <?php echo $box_shadow; ?>">
                                <?php if ($result['client_interview_status'] == 1) { ?>
                                    <div class="lbl-position"><label class="label ">C</label></div>
                                <?php } else { ?>
                                <?php } ?>

                                <div class="close-right margin-top-5">                                

                                </div>

                                <div class="media">
                                    <h5 class="text-bold  text-center margin-bottom-0">
                                        <a href="<?php echo base_url() ?>recruitment/screening_list/<?php echo $result['id']; ?>" title="Opening For" class="text-primary"><?php echo $result['jobtitlename'] . ' <small>(' . $result['deptname'] . ')</small>'; ?></a>
                                    </h5>
                                    <p class="text-center">
                                        <small class="text-light-head" title="To Date"><?php echo date('d F Y', strtotime($result['close_date'])); ?></small>
                                    </p>
                                    <p class="text-center">
                                        <small class="text-light-head" title="To Date"><?php echo $result['req_exp_years_from'] . '-' . $result['req_exp_years_to'] . ' years' ?></small>
                                    </p>
                                    <p class="text-center">                             
                                        <span title="Filled Position" style="cursor:pointer"><?php echo $result['selected'] ?></span>
                                        /<span title="Required Position" style="cursor:pointer"><?php echo $result['req_no_positions'] ?></span>                                                  
                                    </p>


                                    <div class="text-center">

                                        <?php if ($result['ispublished'] == 0) { ?>
                                            <label class="label label-default" title="status">Not Approved</label>
                                        <?php } else if ($result['opening_status'] == 3) { ?>
                                            <label class="label label-success">Closed</label>

                                        <?php } else { ?>
                                            <?php $currentDate > $result['close_date'] ? $status = 'label-danger' : $status = 'label-aqua'; ?>
                                            <label class="label <?php echo $status ?>">On Going</label>
                                        <?php } ?>
                                        <div class="label label-secondary"><?php echo $result['req_type'] ?> </div>

                                    </div>
                                    <?php
                                    $val = (100 / $result['req_no_positions']) * $result['selected'];
                                    ?>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="<?php echo $result['selected'] ?>" aria-valuemin="0" aria-valuemax="<?php echo $result['req_no_positions'] ?>" style="width: <?php echo $val ?>%; height: 100%; background-color: rgba(31, 181, 172, 1);"></div>

                                    </div>  
                                    <table class="table" >
                                        <tr >
                                            <td>
                                                <?php if ($result['opening_status'] == 3) { ?>
                                                    <a href="#" title="All Positions Fullfilled">
                                                        <span class="text-light-head"><i class="fa fa-desktop "></i></span>
                                                    </a>
                                                <?php } else { ?>
                                                    <?php if ($currentDate > $result['close_date']) { ?>
                                                        <a href="<?php echo base_url() ?>recruitment/screening/<?php echo $result['id']; ?>" title="Close Date Exceed" >
                                                            <span class="text-light-head"><i class="fa fa-desktop text-info"></i></span>
                    <!--                                                    <i class="fa fa-angle-double-right "></i>-->
                                                        </a>
                                                    <?php } else { ?>
                                                        <a href="<?php echo base_url() ?>recruitment/screening/<?php echo $result['id']; ?>" title="Click Here">
                                                            <span class="text-light-head"><i class="fa fa-desktop text-info"></i></span>
                    <!--                                                    <i class="fa fa-angle-double-right "></i>-->
                                                        </a>
                                                    <?php } ?>
                                                <?php } ?>
                                            </td>
                                            <td >
                                                <?php
                                                $currentDate = new DateTime();
                                                $currentDate = $currentDate->format('Y-m-d');
                                                ?>  
                                                <?php if ($result['opening_status'] != 3) { ?>
                                                    <div class="" style="display: inline">
                                                        <label class="" id="editopening" href="#editClosingDate-<?php echo $result['id']; ?>" data-toggle="modal"><i class="fa fa-minus-square text-danger "></i></label>
                                                    </div>
                                                <?php } else { ?>
                                                    <i class="fa fa-minus-square text-light-gray" title="Opening Closed"></i>
                                                <?php } ?>
                                            </td>
                                            <td >
                                                <div >                                
                                                    <a data-toggle="modal" href="#view_opening_<?php echo $result['id'] ?>"><i class="fa fa-external-link text-ccc" title="view"></i></a>
                                                </div></td>
                                        </tr>
                                    </table>

                                </div>
                            </div>
                        </div> 
                    <?php } ?> 
                </div>
            </div>

        </div>
    </div>
</div>
<div id="loader-bg" style="display: none">
    <div class="loader-txt margin-bottom-10"><h3 class="text-white">We Make IT simple</h3></div>
    <div class="loader-animation" style="display: block">&#9632;&#9632;&#9632;&#9632;&#9632;</div>
</div>
<?php $this->load->view('modal/_view_opening'); ?>
<?php $this->load->view('modal/_editClosingDate'); ?>
<script>
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>

        $('.req-slim').slimscroll({
            width: '100%',
            height: '465px',
            axis: 'both'
        });
    });
</script>
<script>
    var req_url = '<?php echo base_url(); ?>recruitment/searchReqcruitement';
    function filterReqType(filter) {
        search_reqtype(filter, req_url);
    }
    function search_reqtype(search_key, url) {
        $('#loader-bg').show();
        $('.loader-animation').show();
        $.ajax({
            type: "POST",
            url: url,
            data: {'search_key': search_key},
            success: function (data) {
                $('#loader-bg').hide();
                $('.loader-animation').hide();
//                $('.loader').hide();
//                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                $('.card_display').html('');
                if (parsed.search_list == null) {
                    $('.card_display').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.card_display').html(parsed.search_list);
                }
            }
        });
    }
</script>

