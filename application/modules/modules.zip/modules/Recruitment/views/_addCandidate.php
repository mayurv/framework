<!-- modal start -->
<div class="modal fade" id="addcandidate-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Candidate</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim"> 
                    <?php
                    // var_dump($candidate_details);die;
                    echo form_open_multipart('recruitment/addCandidate/', array('id' => 'form_addCandidate_id', 'class' => 'form_addCandidate_id'));
                    ?>
                    <input type="hidden" name="requisition_id" value="<?php echo $requisition_id ?>">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('requisition'), 'requisition', array('for' => 'req_code')); ?>

                                <?php
                                echo form_input(array(
                                    'id' => 'req_code',
                                    'name' => 'req_code',
                                    'placeholder' => 'Requisition Code',
                                    'class' => 'browser-default',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate1',
                                    'value' => $requisition_code,
                                ));
                                ?>                               
                                <div class="addCandidate1"></div>                                    
                                <?php echo form_error('requisition_id'); ?>   
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('candidate_firstname'), 'candidate_firstname', array('for' => 'candidate_firstname')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'candidate_firstname',
                                    'id' => 'candidate_firstname',
                                    'class' => 'browser-default',
                                    'placeholder' => 'First Name',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate2',
                                ));
                                ?>                       
                                <div class="addCandidate2"></div>
                                <?php echo form_error('candidate_firstname'); ?>
                            </div>         
                        </div>                  
                        <div class="clearfix"> </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('candidate_lastname'), 'candidate_lastname', array('for' => 'candidate_lastname')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'candidate_lastname',
                                    'id' => 'candidate_lastname',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Last Name',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate3',
                                ));
                                ?>                       
                                <div class="addCandidate3"></div>
                                <?php echo form_error('candidate_lastname'); ?>
                            </div>         
                        </div> 
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('emailid'), 'emailid', array('for' => 'emailid')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'emailid',
                                    'id' => 'emailid',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Email',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate4',
                                ));
                                ?>                       
                                <div class="addCandidate4"></div>
                                <?php echo form_error('emailid'); ?>
                            </div>         
                        </div> 
                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('contact_number'), 'contact_number', array('for' => 'contact_number')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'contact_number',
                                    'id' => 'contact_number',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Contact Number',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate5',
                                ));
                                ?>                       
                                <div class="addCandidate5"></div>
                                <?php echo form_error('contact_number'); ?>
                            </div>         
                        </div> 
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('qualification'), 'qualification', array('for' => 'qualification')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'qualification',
                                    'id' => 'qualification',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Qualification',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate6',
                                ));
                                ?>                       
                                <div class="addCandidate6"></div>
                                <?php echo form_error('qualification'); ?>
                            </div>         
                        </div> 
                        <div class="clearfix"></div>

                        <div class="col-sm-3">
                            <?php echo form_label(lang('yearsc_exp'), 'years_exp', array('for' => 'years_exp')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'years_exp',
                                'name' => 'years_exp',
                                'style' => 'max-height: 500px;height:500px;',
                                'class' => 'browser-default',
                                'data-error' => '.addCandidate7'), $yearsexp);
                            ?>
                            <div class="input-field">
                                <div class="addCandidate7"></div>
                            </div> 
                            <?php echo form_error('years_exp'); ?>
                        </div>

                        <div class="col-sm-3">
                            <?php echo form_label(lang('months_exp'), 'months_exp', array('for' => 'months_exp')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'months_exp',
                                'name' => 'month_exp',
                                'class' => 'browser-default',
                                'placeholder' => 'Qualification',
                                'data-error' => '.addCandidate8'), $monthsexp);
                            ?>
                            <div class="input-field">
                                <div class="addCandidate8"></div>
                            </div> 
                            <?php echo form_error('month_exp'); ?>
                        </div>



                        <div class="col-sm-6">
                            <?php echo form_label(lang('skillset'), 'skillset', array('for' => 'skillset')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'skillset',
                                'name' => 'skillset[]',
                                'multiple' => 'multiple',
                                'class' => 'browser-default',
                                'data-error' => '.addCandidate9',
                                    ), $skills_list);
                            ?>
                            <div class="input-field">
                                <div class="addCandidate9"></div>
                                <?php echo form_error('skillset'); ?> 
                            </div>     
                        </div>

                        <div class="clearfix"></div>


                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('cand_location'), 'cand_location', array('for' => 'cand_location')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'cand_location',
                                    'id' => 'cand_location',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Candidate Current Location',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate10',
                                ));
                                ?>                       
                                <div class="addCandidate10"></div>
                                <?php echo form_error('cand_location'); ?>
                            </div>         
                        </div>     

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('notice_period'), 'notice_period', array('for' => 'notice_period')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'notice_period',
                                    'id' => 'notice_period',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Notice Period in Days',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate101',
                                ));
                                ?>                       
                                <div class="addCandidate101"></div>
                                <?php echo form_error('notice_period'); ?>
                            </div>         
                        </div>   

                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('current_ctc'), 'current_ctc', array('for' => 'current_ctc')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'current_ctc',
                                    'id' => 'current_ctc',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Current CTC',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate11',
                                ));
                                ?>                       
                                <div class="addCandidate11"></div>
                                <?php echo form_error('current_ctc'); ?>
                            </div>         
                        </div>     



                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('expected_ctc'), 'expected_ctc', array('for' => 'expected_ctc')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'expected_ctc',
                                    'id' => 'expected_ctc',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Expected CTC',
                                    'type' => 'text',
                                    'data-error' => '.addCandidate12',
                                ));
                                ?>                       
                                <div class="addCandidate12"></div>
                                <?php echo form_error('expected_ctc'); ?>
                            </div>         
                        </div>     

                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <?php
                            $options = array('' => 'Select Source');
                            foreach ($business_entity_list as $category)
                                $options[$category['id']] = $category['title'];
                            ?>
                            <?php echo form_label(lang('source'), 'source', array('for' => 'business_entity_id')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'business_entity_id',
                                'name' => 'business_entity_id',
                                'class' => 'browser-default',
                                'data-error' => '.addCandidate13',
                                    ), $options);
                            ?>
                            <div class="input-field">
                                <div class="addCandidate13"></div>
                                <?php echo form_error('business_entity_id'); ?> 
                            </div>     
                        </div>



                        <div class="col-sm-6">
                            <div class="file-field input-field">
                                <div class="btn btn-default btn-sm margin-top-5">
                                    Browse
                                    <?php
                                    echo form_input(array(
                                        'type' => 'file',
                                        'name' => 'cv_doc',
                                        'id' => 'cv_doc',
                                        'data-error' => '.addCandidate14'
                                    ));
                                    ?>
                                </div>
                                <div class="file-path-wrapper">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'cv_doc',
                                        'id' => 'cv_doc',
                                        'class' => 'file-path',
                                        'placeholder' => '( pdf, doc, docx)',
                                    ));
                                    ?>
                                </div>
                                <div class="addCandidate14"></div>
                            </div>
                        </div>
                        <input type="hidden" name="position" value="0">

<!--                        <input type="hidden" name="interview_round_number" value="1">
<div class="col-sm-3">
                        <?php // echo form_label(lang('interviewer1'), 'interviewer1', array('for' => 'interviewer1')); ?>
                        <?php
//                            echo form_dropdown(array(
//                                'id' => 'interviewer1',
//                                'name' => 'interviewer1',
//                                'class' => 'browser-default',
//                                'data-error' => '.addCandidate14',
//                                     ), $interviewer1_list);
                        ?>
    <div class="input-field">
        <div class="addCandidate14"></div>
                        <?php // echo form_error('interviewer1'); ?> 
    </div>     
</div>
<div class="col-sm-3">
    <div class="input-field">
                        <?php // echo form_label(lang('interview_date'), 'interview_date', array('for' => 'interview_date')); ?>
                        <?php
//                                echo form_input(array(
//                                    'id' => 'interview_date',
//                                    'name' => 'interview_date',
//                                    'placeholder' => 'Interview Date',
//                                    'data-format' => 'yyyy-mm-dd',
//                                    'class' => 'close_date',
//                                    'data-error' => '.addCandidate15',
//                                ));
                        ?>   
        <div class="addCandidate15"></div>                                
                        <?php // echo form_error('interview_date'); ?> 
    </div>                                        
</div>
<div class="col-sm-2">
    <div class="input-field">
        <label for="rtime">Time</label>               
        <input type="text" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt65">
        <div class="errorTxt65"></div>
    </div>
</div> 
<div class="col-sm-4">
                        <?php // echo form_label(lang('interview_mode'), 'interview_mode', array('for' => 'interview_mode')); ?>
                        <?php
//                            echo form_dropdown(array(
//                                'id' => 'interview_mode',
//                                'name' => 'interview_mode',
//                                'class' => 'browser-default',
//                                'data-error' => '.addCandidate17',
//                                ), $interview_types);
                        ?>
    <div class="input-field">
        <div class="addCandidate17"></div>
                        <?php // echo form_error('interview_mode'); ?> 
    </div>     
</div>-->

                        <div class="col-sm-12 padding-top-10">
                            <button type="submit" class="btn btn-warning2 btn-sm pull-right">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->

<!--<script type="text/javascript">
        $('#skillset').multiselect({
            columns: 1,
            placeholder: 'Select option'
        });

    </script>-->