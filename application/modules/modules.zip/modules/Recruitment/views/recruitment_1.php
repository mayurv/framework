<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<a href="<?php echo base_url() ?>recruitment/add">Add Job Opening </a> | 

<a href="<?php echo base_url() ?>recruitment/view_candidate_details">Add candidate_details </a> | 

<a href="<?php echo base_url() ?>recruitment/view_interview_details">Add interview_details </a> | 

<a href="<?php echo base_url() ?>recruitment/addVendor">Add vendor </a>
<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">
    <div class="content-body">
        <div class="row">


            <div class="col-md-12">
                <?php foreach ($openings as $result) {
                  //  var_dump();
                    ?>
                    <div class="col-md-4 m-t-xl">
               
                       
                            <a href="<?php echo base_url() ?>recruitment/edit/<?php echo $result['id']; ?>" class=" pull-right"><i class="fa fa-pencil-square-o"></i></a>
                            <ul class="list-unstyled">
                                <li><i class="fa fa-home"></i> <?php echo $result['jobtitlename']; ?></li>
                                <li><i class="fa fa-user"></i> <?php echo $result['onboard_date'];  ?></li>
                                      <?php
                        //var_dump($openings);
                        echo form_open('recruitment/addCandidate/');
                        
                        ?>
                                <input type='hidden' name='req_id' value='<?php echo $result['req_code']  ?>'>
                                <li><i class="fa fa-user"></i> <input type="submit">Add Candidate</li>
                                 <?php echo form_close(); ?>
                                <li><i class="fa fa-user"></i> <?php echo($result['opening_status'] == 0) ? 'On Going' : (($result['opening_status'] == 1) ? 'Hold' : 'Close');  ?></li>
                                <li><i class="fa fa-suitcase"></i><?php echo $result['filled_positions']  ?>/ <?php  echo $result['req_no_positions'] ?></li>
                                <li><a href="">View Candidates</a></li>
                                <li><a href="">Total : <?php echo $result['total_cnt']  ?></a></li>
                                 <li><a href="<?php echo base_url() ?>recruitment/screening/<?php echo $result['req_code']; ?>">View Screening</a></li>
                                <div class="progress map_progress">
                                    <?php 
                                    $val = (100/$result['req_no_positions'])*$result['filled_positions'];
                                    
                                    ?>
                                    <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="<?php echo $result['filled_positions']  ?>" aria-valuemin="0" aria-valuemax="<?php  echo $result['req_no_positions'] ?>" style="width: <?php echo $val  ?>%; height: 30%; background-color: rgba(31, 181, 172, 1);"></div>
                                </div>
                            </ul>
                        

                    </div>


                <?php } ?>


                <?php if (isset($output)) echo $output; ?>
            </div>
        </div>


    </div>
</div>

<?php ?>