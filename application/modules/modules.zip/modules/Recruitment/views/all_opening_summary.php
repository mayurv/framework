

<div class="main-1bg white-bg all-padding-15">
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <h4>Screening Summary</h4>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#home-3" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-bar-chart"></i> List
                    </a>
                </li>
                <li class="">
                    <a href="#profile-3" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i>  Chart
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="home-3">


                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="post-list" id="postList">
                                <table class="table table-responsive">
                                    <thead>
                                        <tr>
                                            <th>Position Name</th> 
                                            <th>Total No of Vacancy</th> 
                                            <th>Shortlisted</th> 
                                            <th>Schedule for Interview</th> 
                                            <th>Offer Made</th> 
                                            <th>Offer Hold</th>  
                                            <th>Offer Rejected</th>
                                            <th>Offer Accepted</th> 
                                            <th>Rejected</th> 
                                            <th>Joinees</th> 
                                            <th>Unfilled Vacancy</th>
                                        </tr>
                                    </thead>
                                    <div class="pull-right"> 

                                    </div>
                                    <tbody class="">
                                        <?php foreach ($summary as $r => $result) { ?>  
                                            <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">

                                                <td class=""><?php echo $result['jobtitlename'] . '(' . $result['deptname'] . ')'; ?></td>
                                                <td class=""><?php echo $result['req_no_positions']; ?></td>
                                                <td class=""><?php echo $result['shortlisted']; ?></td>
                                                <td class=""><?php echo $result['interviewing']; ?></td>
                                                <td class=""><?php echo $result['offer_made']; ?></td>
                                                <td class=""><?php echo $result['offer_hold']; ?></td>
                                                <td class=""><?php echo $result['offer_reject']; ?></td>
                                                <td class=""><?php echo $result['offer_accept']; ?></td>
                                                <td class=""><?php echo $result['rejected']; ?></td>
                                                <td class=""><?php echo $result['joinees']; ?></td>
                                                <td class=""><?php echo ($result['req_no_positions'] - $result['selected']); ?></td>



                                            </tr>  
                                        <?php } ?>
                                    </tbody>
                                </table>
                                <?php echo $this->ajax_pagination->create_links(); ?>
                            </div>



                        </div>
                    </div>

                </div>
                <div class="tab-pane fade" id="profile-3">
                    
                        <p class="pull-right">2017</p>
                        <canvas id="barChart" height="80"></canvas>
                 

                </div>

            </div>

        </div>
    </div>
</div>



<link href="<?php //echo base_url('assets/plugins/chart/chartist.min.css');         ?>" rel="stylesheet" type="text/css">      
<script src="<?php //echo base_url('assets/plugins/chart/chartist.min.js');         ?>" type="text/javascript"></script>

<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script src="<?php //echo base_url('assets/plugins/chart/chartjs-demo.js');         ?>" type="text/javascript"></script>
<script src="<?php //echo base_url('assets/plugins/chart/jquery-3.1.1.min.js');         ?>" type="text/javascript"></script>
<?php
$horizontal_array = array();
$joinees_array = array();
$horizontal_array1 = array();
$joinees_array1 = array();
foreach ($summary as $r => $result) {
    $horizontal_array[$r] = $result['jobtitlename'] . '(' . $result['deptname'] . ')';
    $joinees_array[$r] = $result['joinees'];
}
foreach ($summary as $r => $result) {
    $horizontal_array1[$r] = $result['jobtitlename'] . '(' . $result['deptname'] . ')';
    $joinees_array1[$r] = $result['joinees'];
}

//$horizontal_array =array_merge($horizontal_array,$horizontal_array1);
//$joinees_array = array_merge($joinees_array,$joinees_array1);
?>
<script>
    $(function () {


        var barData = {
            labels: <?php echo json_encode($horizontal_array); ?>,
            datasets: [
                {
                    label: "Openings",
                    backgroundColor: 'rgba(26,179,148,0.5)',
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: <?php echo json_encode($joinees_array); ?>
                }
            ]
        };

        var barOptions = {
            responsive: true,
            scales: {
                xAxes: [{
                        ticks: {
                            stepSize: 10,
                        },
                        stacked: true,
                        gridLines: {
                            lineWidth: 0,
                            color: "rgba(255,255,255,0)"
                        }
                    }],
                yAxes: [{
                        stacked: true,
                        ticks: {
                            min: 0,
                            stepSize: 1,
                        }

                    }]
            }
        };

        var ctx2 = document.getElementById("barChart").getContext("2d");
        new Chart(ctx2, {type: 'bar', data: barData, options: barOptions});

    });


</script>

<!--<script>
   $(document).ready(function () {


       // Simple line

       new Chartist.Line('#ct-chart1', {
           labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
           series: [
               [12, 9, 7, 8, 5],
               [2, 1, 3.5, 7, 3],
               [1, 3, 4, 5, 6]
           ]
       }, {
           fullWidth: true,
           chartPadding: {
               right: 40
           }
       });


       // Line scatter diagram

       var times = function (n) {
           return Array.apply(null, new Array(n));
       };

       var data = times(26).map(Math.random).reduce(function (data, rnd, index) {
           data.labels.push(index + 1);
           data.series.forEach(function (series) {
               series.push(Math.random() * 100)
           });

           return data;
       }, {
           labels: [],
           series: times(4).map(function () {
               return new Array()
           })
       });

       var options = {
           showLine: false,
           axisX: {
               labelInterpolationFnc: function (value, index) {
                   return index % 13 === 0 ? 'W' + value : null;
               }
           }
       };

       new Chartist.Line('#ct-chart2', data, options);


       // Stocked bar chart

       new Chartist.Bar('#ct-chart3', {
           labels: ['Q1', 'Q2', 'Q3', 'Q4'],
           series: [
               [800000, 1200000, 1400000, 1300000],
               [200000, 400000, 500000, 300000],
               [100000, 200000, 400000, 600000]
           ]
       }, {
           stackBars: true,
           axisY: {
               labelInterpolationFnc: function (value) {
                   return (value / 1000) + 'k';
               }
           }
       }).on('draw', function (data) {
           if (data.type === 'bar') {
               data.element.attr({
                   style: 'stroke-width: 30px'
               });
           }
       });


       // Stocked horizontal bar

       new Chartist.Bar('#ct-chart4', {
           labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
           series: [
               [5, 4, 3, 7, 5, 10, 3],
               [3, 2, 9, 5, 4, 6, 4]
           ]
       }, {
           seriesBarDistance: 10,
           reverseData: true,
           horizontalBars: true,
           axisY: {
               offset: 70
           }
       });


       // Simple pie chart

       var data = {
           series: [5, 3, 4]
       };

       var sum = function (a, b) {
           return a + b
       };

       new Chartist.Pie('#ct-chart5', data, {
           labelInterpolationFnc: function (value) {
               return Math.round(value / data.series.reduce(sum) * 100) + '%';
           }
       });

       // Gauge chart

       new Chartist.Pie('#ct-chart6', {
           series: [20, 10, 30, 40]
       }, {
           donut: true,
           donutWidth: 60,
           startAngle: 270,
           total: 200,
           showLabel: false
       });

   });
</script>-->
