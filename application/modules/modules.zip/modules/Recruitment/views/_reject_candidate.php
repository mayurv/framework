<?php foreach ($candidates1 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates2 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates3 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates4 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates5 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates6 as $r => $result) { ?>  

<?php } ?>


<?php foreach ($candidates7 as $r => $result) { ?>  

<?php } ?>