<div class="row">
    <div class="container">
        
         <!-- Requisition ID-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
              
                $option = array();
                foreach ($requisition as $res)
                    $option[$res['id']] = $res['req_code'];
//                var_dump($option);die;
                echo form_dropdown(array('id' => '', 'name' => 'reqcode'), $option);
                ?>
                <?php echo form_label(lang('requisition'), 'requisition'); ?>
                <?php echo form_error('requisition'); ?>
            </div>
        </div>  
        
        <!-- Candidate ID-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'candidate_name',
                ));
                ?>
                
                <?php echo form_label(lang('candidate_name'), 'candidate_name'); ?>
            </div>
        </div>  

        <!-- Interviwer ID-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'interviewer_id',
                ));
              
                ?>
                <?php echo form_label(lang('interviewer_id'), 'interviewer_id'); ?>
            </div>
        </div> 


      <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewDate',
                    'class' => 'datepicker'
                ));
                ?>
                <?php echo form_label(lang('interview_date'), 'interview_date'); ?>
            </div> 
        </div> 
        
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewTime',
                    'class' => 'timepicker'
                ));
                ?>
                <?php echo form_label(lang('interview_time'), 'interview_time'); ?>
            </div> 
        </div> 
        
        
         <!-- Interview Mode Drop Down-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_dropdown(array(
                    'type' => 'text',
                    'name' => 'InterviewMode',
                ));
                ?>
                <?php echo form_label(lang('interview_mode'), 'interview_mode'); ?>
            </div> 
        </div>
         
         <!-- Interview Round Number-->
        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewRoundNumber',
                ));
                ?>
                <?php echo form_label(lang('interview_round_number'), 'interview_round_number'); ?>
            </div>
        </div>
         
          <!-- Interview Round -->
         <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewRound',
                ));
                ?>
                <?php echo form_label(lang('interview_round'), 'interview_round'); ?>
            </div>
        </div>

        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewFeedback'
                ));
                ?>
                <?php echo form_label(lang('interview_feedback'), 'interview_feedback'); ?>
            </div>
        </div>

       

        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'InterviewComments',
                ));
                ?>
                <?php echo form_label(lang('interview_comments'), 'interview_comments'); ?>
            </div>
        </div>


        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'RoundStatus',
                ));
                ?>
                <?php echo form_label(lang('round_status'), 'round_status'); ?>
            </div>
        </div>    


       

        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'name' => 'int_location',
                ));
                ?>
                <?php echo form_label(lang('int_location'), 'int_location'); ?>
            </div>
        </div>



        <div class="col-sm-6">
            <div class="input-field">
                <?php
                echo form_dropdown(array('id' => '', 'name' => 'isactive'), array('Inactive', 'Active'));
                ?>	
                <?php echo form_label(lang('status'), 'status'); ?>


            </div>

        </div>

    </div>
</div>


