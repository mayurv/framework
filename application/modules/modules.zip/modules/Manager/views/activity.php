<div class="main-bg all-padding-15">
    <?php $this->load->view('_addOpening'); ?>
    <?php $this->load->view('_editOpening'); ?>
    <?php $this->load->view('_editClosingDate'); ?>
    <div class="row">
        <div class="col-sm-12">
             <div class="pull-left">
             <h4>Recruitment</h4>
             </div>
              
            <div class="pull-right">
                <button class="btn btn-default btn-sm" data-toggle="modal" href="#addopening-1"><i class="fa fa-plus-circle"></i> Add Opening</button>
                <i class="fa fa-question-circle text-ccc" title="Note: Once Opening /Position approved, you cannot modify"></i>
            </div>
        </div>
    </div>
    

    
    <div class="row">        
        <div class="col-md-12">
            <?php foreach ($openings as $result) {
                ?>
                <div class="col-lg-2 col-md-3 col-sm-4"> 
                    <div class="job-opening-bg">
                        <?php if ($result['client_interview_status'] == 1) { ?>
                            <div class="lbl-position"><label class="label ">C</label></div>
                        <?php } else { ?>
                        <?php } ?>
                            <div class="close-right margin-top-5">
                            <a data-toggle="modal" href="#view_opening_<?php echo $result['id'] ?>"><i class="fa fa-external-link text-ccc" title="view"></i></a>
                        </div>
                        <?php
                        $currentDate = new DateTime();
                        $currentDate = $currentDate->format('Y-m-d');
                        ?>
                        <?php if ($currentDate > $result['close_date']) { ?>
<!--                            <div class="close-right margin-top-5 margin-right-10">
                                <a id="editopening" href="#editClosingDate-<?php echo $result['id']; ?>" data-toggle="modal">
                                    <i class="fa fa-pencil text-ccc" title="Update Closing Date"></i>
                                </a>

                            </div>-->
                        <?php } else { ?>
<!--                            <div class="margin-top-5"></div>-->
                        <?php } ?>
                        <div class="media">
                            <h5 class="text-bold text-info text-center margin-bottom-0">
                                <?php if ($result['ispublished'] == 0) { ?>
                                    <a id="editopening" href="#editopening-<?php echo $result['id']; ?>" data-toggle="modal" title="Opening For"><?php echo $result['jobtitlename']; ?></a>
                                <?php } else { ?>
                                    <span id="editopening" data-toggle="modal" title="Opening For" class="text-bold"><?php echo $result['jobtitlename']; ?></span>
                                <?php } ?>

                            </h5>
                            <p class="text-center">
                                <small title="To Date" class="blink-bg<?php echo $result['id'] ?>"><?php echo date('d F Y', strtotime($result['close_date'])); ?></small>
                            </p>
                             <p class="text-center">
                                <small class="text-light-gray" title="To Date"><?php echo $result['req_exp_years_from'].'-'.$result['req_exp_years_to'].' years' ?></small>
                            </p>
                            <p class="text-center">                             
                                <span title="Filled Position" style="cursor:pointer"><?php echo $result['selected'] ?></span>
                                /<span title="Required Position" style="cursor:pointer"><?php echo $result['req_no_positions'] ?></span>                                                  
                            </p>

                            <p class="text-center text-info">
                                <a href="<?php echo base_url() ?>manager/screening_list/<?php echo $result['id']; ?>" class="text-ccc"><i class="fa fa-user"></i>  Candidates</a>
                            </p>
                     <p class="text-center">
                                <?php if ($result['ispublished'] == 0) { ?>
                                    <label class="label label-default" title="status">Not Approved</label>
                                <?php } else if ($result['opening_status'] ==3) { ?>
                                    <label class="label label-success">Closed</label>

                                <?php } else { ?>
                                    <?php $currentDate > $result['close_date'] ? $status = 'label-danger' : $status = 'label-aqua'; ?>
                                    <label class="label <?php echo $status ?>">On Going</label>
                                <?php } ?>
                            </p>
                            <?php
                            $val = (100 / $result['req_no_positions']) * $result['filled_positions'];
                            ?>
                            <div class="progress">
                                <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="<?php echo $result['filled_positions'] ?>" aria-valuemin="0" aria-valuemax="<?php echo $result['req_no_positions'] ?>" style="width: <?php echo $val ?>%; height: 30%; background-color: rgba(31, 181, 172, 1);"></div>

                            </div>                                                
                        </div>
                    </div>
                </div> 

                <script>
                    $(document).ready(function () {
                        // do fading 3 times
    <?php
    $currentDate = date('Y-m-d');
    ?>
    <?php if ($currentDate > $result['close_date']) { ?>
                            for (i = 0; i < 100; i++) {
                                $('.blink-bg<?php echo $result['id'] ?>').addClass('text-danger').fadeTo('slow', 0.5).fadeTo('slow', 1.0);
                            }
    <?php } ?>

                    });

                </script>

            <?php } ?>                
        </div>

    </div>
</div>
<?php $this->load->view('_view_opening'); ?>
<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>


