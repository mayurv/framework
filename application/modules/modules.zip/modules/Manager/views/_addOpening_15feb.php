<!-- modal start -->
<div class="modal fade" id="addopening-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Opening</h4>
            </div>
            <div class="modal-body ">
                <div class="user-modal-slim"> 
                    <?php echo form_open('manager/add_opening', array('id' => 'form_addOpening_id', 'class' => 'form_addOpening_id form-horizontal')); ?>
                   
                        <div class="form-group">
                            <div class="col-sm-12">                            
                                <?php
                                echo form_checkbox(array(
                                    'id' => 'client_interview',
                                    'name' => 'client_interview',
                                    'style' => 'left: 0 !important; opacity: 0 !important;',
                                    'checked' => '',
                                    'value' => '0',
                                ));
                                ?>
                                <?php echo form_label(lang('client_interview'), 'client_interview', array('for' => 'client_interview','class' => 'control-label', 'style' => 'font-size:12px !important')); ?>                                
                                <?php echo form_error('req_code'); ?>                          
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_code'), 'req_code', array('for' => 'req_code','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'req_code',
                                        'name' => 'req_code',
                                        'placeholder' => 'Requisition Code',
                                        'class' => 'form-control',
                                        'type' => 'text',
                                        'data-error' => '.addOpening1',
                                        'value' => $req_code
                                    ));
                                    ?>
                                    <div class="addOpening1"></div>                                    
                                    <?php echo form_error('req_code'); ?>   
                                </div>
                            </div>
                            <div class="col-sm-6">
                                
                                    <?php echo form_label(lang('close_date'), 'close_date', array('for' => 'close_date','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'close_date',
                                        'name' => 'close_date',
                                        'placeholder' => 'Close Date',
                                        'data-format' => 'yyyy-mm-dd',
                                        'class' => 'close_date form-control',
                                        'data-error' => '.addOpening2',
                                    ));
                                    ?>   
                                <div class="input-field">
                                    <div class="addOpening2"></div>                                
                                    <?php echo form_error('close_date'); ?> 
                                </div>                                        
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <?php echo form_label(lang('job_title'), 'job_title', array('for' => 'jobtitle','class' => 'control-label')); ?>                                
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'jobtitle',
                                    'name' => 'jobtitle',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening3',
                                        ), $job_code);
                                ?> 
                                <div class="input-field">
                                    <div class="addOpening3"></div>
                                    <?php echo form_error('jobtitle'); ?> 
                                </div>                                        
                            </div>
                            <div class="col-sm-6">
                                <?php echo form_label(lang('position_id'), 'position_id', array('for' => 'position_id','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'position_id',
                                    'name' => 'position_id',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening4',
                                        ), $position_list);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening4"></div>
                                    <?php echo form_error('position_id'); ?> 
                                </div>                                        
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <?php echo form_label(lang('department_id'), 'department_id', array('for' => 'department_id','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'department_id',
                                    'name' => 'department_id',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening5',
                                        ), $department);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening5"></div>
                                    <?php echo form_error('department_id'); ?> 
                                </div>                  
                            </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'reporting_manager',
                                    'name' => 'reporting_manager',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening50',
                                        ), $reporting_manager_list);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening50"></div>
                                    <?php echo form_error('reporting_manager'); ?> 
                                </div>                    
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_no_positions'), 'req_no_positions', array('for' => 'req_no_positions','class' => 'control-label')); ?>                            <?php
                                    echo form_input(array(
                                        'name' => 'req_no_positions',
                                        'id' => 'req_no_positions',
                                        'class' => 'form-control',
                                        'placeholder' => 'Required Position',
                                        'type' => 'text',
                                        'data-error' => '.addOpening6',
                                    ));
                                    ?>                       
                                    <div class="addOpening6"></div>
                                    <?php echo form_error('req_no_positions'); ?>
                                </div>         
                            </div>    

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('jobdescription'), 'jobdescription', array('for' => 'description','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'description',
                                        'id' => 'description',
                                        'placeholder' => 'Job Description',
                                        'type' => 'text',
                                        'class' => 'form-control',
                                        'data-error' => '.addOpening7',
                                    ));
                                    ?>
                                    <div class="addOpening7"></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_skills'), 'req_skills', array('for' => 'skills','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'skills',
                                        'name' => 'skills',
                                        'type' => 'text',
                                        'class' => 'form-control',
                                        'placeholder' => 'Required Skills',
                                        'data-error' => '.addOpening8',
                                    ));
                                    ?>                    
                                    <div class="addOpening8"></div>
                                    <?php echo form_error('skills'); ?> 
                                </div>     
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('req_qualification'), 'req_qualification', array('for' => 'qualification','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'qualification',
                                        'id' => 'qualification',
                                        'type' => 'text',
                                        'placeholder' => 'Required qualification',
                                        'class' => 'form-control',
                                        'data-error' => '.addOpening9',
                                    ));
                                    ?>
                                    <div class="addOpening9"></div>
                                    <?php echo form_error('req_qualification'); ?> 
                                </div>                    
                            </div>                                       
                        </div>

                        <div class="form-group">
                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('from'), 'from', array('for' => 'yearsFrom','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'yearsFrom',
                                        'id' => 'yearsFrom',
                                        'type' => 'text',
                                        'placeholder' => 'From',
                                        'class' => 'form-control',
                                        'data-error' => '.addOpening10',
                                    ));
                                    ?>
                                    <div class="addOpening10"></div>
                                    <?php echo form_error('req_exp_years_from'); ?> 
                                </div>                    
                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('to'), 'to', array('for' => 'yesrsTo','class' => 'control-label')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'yesrsTo',
                                        'id' => 'yesrsTo',
                                        'type' => 'text',
                                        'placeholder' => 'To',
                                        'class' => 'form-control',
                                        'data-error' => '.addOpening11',
                                    ));
                                    ?>
                                    <div class="addOpening11"></div>
                                    <?php echo form_error('req_exp_years_to'); ?> 
                                </div>                    
                            </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('for' => 'emp_status_id','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'emp_status_id',
                                    'name' => 'emp_status_id',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening12',
                                        ), $emp_status);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening12"></div>
                                    <?php echo form_error('emp_type'); ?> 
                                </div>     
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-sm-6">
                                <?php echo form_label(lang('emp_priority_id'), 'emp_priority_id', array('for' => 'emp_priority_id','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'emp_priority_id',
                                    'name' => 'emp_priority_id',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening13',
                                        ), $priority);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening13"></div>
                                    <?php echo form_error('req_priority'); ?> 
                                </div>     
                            </div>


                            <div class="col-sm-6">
                                <?php echo form_label(lang('approver'), 'approver', array('for' => 'approver','class' => 'control-label')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'approver',
                                    'name' => 'approver',
                                    'class' => 'form-control',
                                    'data-error' => '.addOpening14',
                                        ), $aprrover_list);
                                ?>
                                <div class="input-field">
                                    <div class="addOpening14"></div>
                                    <?php echo form_error('approver1'); ?> 
                                </div>     
                            </div>

                        </div>

                        <div class="form-group">
                            <div class="col-sm-12 padding-top-10 text-right">
                                <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                        </div>
                  
                    <?php echo form_close() ?>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->
<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
        $(".close_date").click(function () {
            $('.close_date').pickadate({
                selectYears: true,
                selectMonths: true,
            });
        });


        $("#client_interview").click(function () {

            var isChecked = $("#client_interview").val();
            if (isChecked == 0) {

                $("#client_interview").val('1');
            } else {

                $("#client_interview").val('0');
            }

        });
    });

    /* Deopdown Functions */
    $('select[name="jobtitle"]').change(function () {
        var jobtitle = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getPositionName',
            data: {'jobtitle_id': jobtitle},
            success: function (data) {
                if (data) {
                    $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                    $("#position_id").val($("#position_id option:first").val());
                }
            }
        });
    });

    $('select[name="department_id"]').change(function () {
        var department_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getReportingManager',
            data: {'department_id': department_id},
            success: function (data) {
                $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                $('#reporting_manager').material_select();
                $('select[name="approver"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                $('#approver').material_select();
                $("#reporting_manager").val($("#reporting_manager option:first").val());
                $("#approver").val($("#approver option:first").val());
            }
        });
    });

//    $('select[name="jobtitle_id"]').change(function () {
//        var jobtitle_id = $(this).val();
//        $.ajax({
//            type: "POST",
//            url: '<?php echo base_url(); ?>manager/getPositionName',
//            data: {'jobtitle_id': jobtitle_id},
//            success: function (data) {
//                if (data) {
//                    $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
//                    $('#position_id').material_select();
//                     $("#position_id").val($("#position_id option:first").val());
//                }
//            }
//        });
//    });


    $('select[name="job_code"]').change(function () {
        var job_code = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getJobTitle',
            data: {'job_code': job_code},
            success: function (data) {
                if (data) {
                    $('select[name="jobtitle_id"]').html(data.content).trigger('liszt:updated').val(jobtitle_id);
                    $('#jobtitle_id').material_select();
                }
            }
        });
    });
</script>   
