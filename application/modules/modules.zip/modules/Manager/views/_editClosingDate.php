<?php ?>
<!-- modal start -->
<?php
foreach ($openings as $result) {
//    var_dump($result);
//    die;
    ?>
    <div class="modal fade" id="editClosingDate-<?php echo $result['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Request for Closing Date</h4>
                </div>
                <div class="modal-body">
                    <div class="user-modal-slim"> 
                        <?php echo form_open('manager/editClosingDate', array('id' => 'form_editClosingDate_id' . $result['id'], 'class' => 'form_editClosingDate_id' . $result['id'])); ?>
                        <?php
                        if ($result['client_interview_status'] == '1') {
                            $ch = "checked";
                            $chval = 1;
                        } else {
                            $ch = "";
                            $chval = 0;
                        }
                        ?>

                        <div class="row">


                            <div class="col-sm-12">
                                <span class="text-info timeline-status"><?php echo $result['req_code'] ?></span> 
                                <span><?php echo $result['jobtitlename'] ?></span>
                            </div>

                            <div class="col-sm-12">
                                <span>Positions: <?php echo $result['filled_positions'] ?> / <?php echo $result['req_no_positions'] ?></span>
                                
                            </div>
                           

                            <div class="col-sm-12">
                                <div class="well margin-top-10">
                                     <span><?php echo $result['jobdescription'] ?></span> 
                                </div>
                            </div>

                            <div class="col-sm-12 ">
                                <div class="input-field">
                                    <?php echo form_label(lang('close_date'), 'close_date', array('for' => 'close_date')); ?>
                                    <?php
                                    echo form_input(array(
                                        'id' => 'close_date',
                                        'name' => 'close_date',
                                        'placeholder' => 'Close Date',
                                        'data-format' => 'yyyy-mm-dd',
                                        'class' => 'close_date',
                                        'data-error' => '.addOpening102',
                                        'value' => set_value('close_date', date('d F, Y', strtotime($result['close_date']))),
                                    ));
                                    ?>   
                                    <div class="addOpening102"></div>                                
                                    <?php echo form_error('close_date'); ?> 
                                </div>                                        
                            </div>

                            <div class="clearfix"> </div>
                            <div class="col-sm-12 padding-top-10 text-right">
                                <button type="submit" onclick="validate_editClosingdate_form(<?php echo $result['id']; ?>);" class="btn btn-warning2 btn-sm">Submit</button>
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                            <input type="hidden" name="req_id" value="<?php echo $result['id'] ?>">
                            <input type="hidden" name="previous_close_date" value="<?php echo $result['close_date'] ?>">
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>                                                    
            </div>
        </div>
    </div>


    <!-- modal end -->
    <script type="text/javascript">

        //    $(window).on('load', function () {
        //        
        //       
        //        var jobtitle_id = $("#id_jobtitle").val();
        //        alert(jobtitle_id);
        //        $.ajax({
        //            type: "POST",
        //            url: '<?php //echo base_url();         ?>manager/getPositionName',
        //            data: {'jobtitle_id': jobtitle_id},
        //            success: function (data) {
        ////                alert(data.content);
        //                if (data) {
        //                    $('select[name="position_id1"]').html(data.content).trigger('liszt:updated').val(position_id1);
        //                    $('#position_id1').material_select();
        ////                    alert(data.content);
        //                }
        //            }
        //        });
        //    });
        //            onwindow load{
        //            $dept id =
        //                    getPosition(dept)
        //            }

        /* Date picker validation Fucntions */
        $(document).ready(function () {
            $(".close_date").click(function () {
                $('.close_date').pickadate({
                    selectYears: true,
                    selectMonths: true,
                });
            });
            $("#client_interview<?php echo $result['id'] ?>").click(function () {

                var isChecked = $("#client_interview<?php echo $result['id'] ?>").val();
                if (isChecked == 0) {

                    $("#client_interview<?php echo $result['id'] ?>").val('1');
                } else {

                    $("#client_interview<?php echo $result['id'] ?>").val('0');
                }

            });
        });
        /* Deopdown Functions */
        $('select[id="jobtitle<?php echo $result['id'] ?>"]').change(function () {
            var jobtitle = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getPositionName',
                data: {'jobtitle_id': jobtitle},
                success: function (data) {
                    if (data) {
                        $('select[id="position_id<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(position_id);
                        $("#position_id<?php echo $result['id'] ?>").val($("#position_id<?php echo $result['id'] ?> option:first").val());
                    }
                }
            });
        });

        $('select[id="department_id<?php echo $result['id'] ?>"]').change(function () {
            var department_id = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getReportingManager',
                data: {'department_id': department_id},
                success: function (data) {
                    $('select[id="reporting_manager<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $('#reporting_manager<?php echo $result['id'] ?>').material_select();
                    $("#reporting_manager<?php echo $result['id'] ?>").val($("#reporting_manager<?php echo $result['id'] ?> option:first").val());
                    $('select[id="approver<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $('#approver<?php echo $result['id'] ?>').material_select();
                    $("#approver<?php echo $result['id'] ?>").val($("#approver<?php echo $result['id'] ?> option:first").val());
                }
            });
        });
        //    $('select[name="jobtitle_id"]').change(function () {
        //        var jobtitle_id = $(this).val();
        //        $.ajax({
        //            type: "POST",
        //            url: '<?php echo base_url(); ?>manager/getPositionName',
        //            data: {'jobtitle_id': jobtitle_id},
        //            success: function (data) {
        //                if (data) {
        //                    $('select[name="position_id1"]').html(data.content).trigger('liszt:updated').val(position_id1);
        ////                    $('#position_id1').material_select();
        //                    $("#position_id1").val($("#position_id1 option:first").val());
        //                }
        //            }
        //        });
        //    });
        $('select[id="job_code<?php echo $result['id'] ?>"]').change(function () {
            var job_code = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>manager/getJobTitle',
                data: {'job_code': job_code},
                success: function (data) {
                    if (data) {
                        $('select[id="jobtitle_id<?php echo $result['id'] ?>"]').html(data.content).trigger('liszt:updated').val(jobtitle_id);
                        $('#jobtitle_id<?php echo $result['id'] ?>').material_select();
                        $("#jobtitle_id<?php echo $result['id'] ?>").val($("#jobtitle_id<?php echo $result['id'] ?> option:first").val());
                    }
                }
            });
        });
    </script>   
<?php } ?>