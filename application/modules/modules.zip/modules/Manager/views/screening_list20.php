<?php 

// var_dump($screening_details);die;  ?>
<div class="main-bg all-padding-15 tab-data text-left">
    <div class="row"> 
        <div class="col-sm-6">
            <div id="idSort" class="left-float">
                <i class="sort-data fa fa-sort-alpha-asc margin-top-15"><input type="hidden" value="asc" id="sortBy"></i>
            </div>   

            <div class="post-search-panel">
                <input class="search-input" type="text" id="keywords" placeholder="Type keywords to filter Associate" onkeyup="searchFilter()"/>
                <div class="search-i-bg" id="id_search"> 
                    <i class="fa fa-search text-light-gray"></i>
                </div>             
            </div>

        </div>        
    </div>
    <?php // if ($result['client_interview_status'] == 1) { ?>
    <?php // } ?>
    <!--Screening summary-->
    <?php
    $roundinit = 0;
    $round1 = 0;
    $round2 = 0;
    $round3 = 0;
    $round4 = 0;
    $round5 = 0;
    $round6 = 0;
    $round7 = 0;
    $reject = 0;
    ?>
    <?php
    if (isset($candidates_count)) {
        foreach ($candidates_count as $result) {
            ?>    
            <?php
            if ($result['position'] == '0' && $result['isactive'] != '3') {
                $roundinit++;
            }
            if ($result['position'] == '1' && $result['isactive'] != '3') {
                $round1++;
            }
            if ($result['position'] == '2' && $result['isactive'] != '3') {
                $round2++;
            }
            if ($result['position'] == '3' && $result['isactive'] != '3') {
                $round3++;
            }
            if ($result['position'] == '4' && $result['isactive'] != '3') {
                $round4++;
            }
            if ($result['position'] == '5' && $result['isactive'] != '3') {
                $round5++;
            }
            if ($result['position'] == '6' && $result['isactive'] != '3') {
                $round6++;
            }
        if (  ($result['position'] == '7' && $result['isactive'] == '0')||($result['position'] == '8' && $result['isactive'] == '5') ) {
                $round7++;
            }
            if ($result['isactive'] == '3' || $result['isactive'] == '4') {
                $reject++;
            }
            
            ?>       
        <?php }
        ?>
        <div class="row"> 
            <div class="col-sm-12 tbl-padding-30">            
                <table class="table responsive  table-bordered">
                    <tr>
                        <th width="25%">
                            <?php // var_dump($screening_details);die; ?>
                    <p><a href="#">
                            <span class="font-size-15"><?php echo $screening_details['jobtitlename']; ?></span>
                            <small class="text-light-gray"> (<?php echo $screening_details['jobtitlecode']; ?>)</small></a>
                        <?php if (isset($result['isactive']))
                            if ($result['isactive'] == 1) {
                                ?>
                                <label class="label label-default" title="status">Not Approved</label>
                            <?php } else { ?>
                                <label class="label label-aqua">On Going</label
        <?php } ?>
                    </p>
                    <p><small class="text-light-gray" title="Close Date"><?php echo date('d F, Y', strtotime($screening_details['close_date'])); ?></small></p>
                    <p><small class="text-light-gray" title="Total Candidates">Total Candidates: <?php echo count($candidates_count); ?></small></p>
                    </th>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $roundinit; ?></p>
                        <p class="text-center"><small class="text-light-head">Initialized</small></p>
                    </td>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $round1; ?></p>
                        <p class="text-center"><small class="text-light-head">Round 1</small></p>
                    </td>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $round2; ?></p>
                        <p class="text-center"><small class="text-light-head">Round 2</small></p>
                    </td>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $round3; ?></p>
                        <p class="text-center"><small class="text-light-head">Round 3</small></p>
                    </td>  

    <?php if (isset($screening_details['client_interview_status']) && $screening_details['client_interview_status'] == 1) { ?>
                        <td width="8%" valign="middle">                            
                            <p class="text-center text-info"><?php echo $round4; ?></p>
                            <p class="text-center"><small class="text-light-head">Client</small></p>
                        </td>
    <?php } ?>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $round5; ?></p>
                        <p class="text-center"><small class="text-light-head">HR</small></p>
                    </td>
                    <td width="8%"  valign="middle">
                        <p class="text-center text-info"><?php echo $round6; ?></p>
                        <p class="text-center"><small class="text-light-head">Offer</small></p>
                    </td>
                    <td width="8%" valign="middle">
                        <p class="text-center text-info"><?php echo $round7; ?></p>
                        <p class="text-center"><small class="text-light-head">Joining</small></p>
                    </td>
                    <td width="8%" valign="middle" style="background: #f3e2e2; ">
                        <p class="text-center text-info"><?php echo $reject; ?></p>
                        <p class="text-center"><small class="text-light-head">Rejected</small></p>
                    </td>
                    </tr>
                </table>           
            </div>
        </div>

<?php } ?>
    <div class="row"> 
        <div class="col-sm-12 tbl-padding-30"> 
            <div class="post-list" id="postList">
                <table class="table table-responsive">
                    <thead>
                        <tr>
                            <th>Candidate Name</th>
                            <th>Contact Details</th>
                            <th>Round</th>
                            <th>Qualification</th>
                            <th>Skill Set</th>
                            <th>Location</th>
                            <th>Source</th>
                            <th>Experience</th>
                            <th>CTC</th>
                            <th>Created Date</th>

                        </tr>
                    </thead>
                    <div class="pull-right"> 

                    </div>
                    <tbody class="">
<?php foreach ($candidates as $r => $result) {
    
    ?>  
                            <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">
                                <td class=""><a title="Click here to view detail Screening Procedure" data-toggle="modal" href="#candidatetimeline_<?php echo $result['id'] ?>"><?php echo $result['candidate_name']; ?></a></td>
                                <td><p class=""><?php echo $result['contact_number']; ?></p>
                                    <p class="text-light-head"><?php echo $result['emailid']; ?></p></td>
                                <td class="">
                                    <?php //echo $result['interview_round_number'];  ?>

    <?php echo $result['max_interview_round_number'] == '1' ? 'Interview 1' : ($result['max_interview_round_number'] == '2' ? 'Interview 2' : ($result['max_interview_round_number'] == '3' ? 'Interview 3' : ($result['max_interview_round_number'] == '4' ? 'Client Interview ' : ($result['max_interview_round_number'] == '5' ? 'HR Roaund' : ($result['max_interview_round_number'] == '6' ? 'Offer' : ($result['max_interview_round_number'] == '7' ? 'Joining' : 'Initiated')))))) ?>


                                    <!--<p class="text-light-head"><?php //if((isset($result['reschedule_id'])==1) && ())?></p>-->
                                    <p class="text-light-head"><?php if (isset($result['max_round_status'])) echo $result['max_round_status'] == 'hold_offer' ? '<span class="text-warning">Offer Hold</span>' : ($result['max_round_status'] == 'rejected' ? '<span class="text-danger">Rejected</span>' : ($result['max_round_status'] == 'reject offer' ? '<span class="text-danger">Reject Offer</span>' : ($result['max_round_status'] == 'Register' ? '<span class="text-success">Selected</span>' : ($result['max_round_status'] == 'Accept Offer' ? '<span class="text-success">Accept Offer</span>' : ($result['max_round_status'] == 'reschedule' ? '<span class="text-warning">Reschedule </span>' : ($result['max_round_status'] == 'Offer Sent' ? '<span class="text-success">Offer Sent </span>': ($result['max_round_status'] == 'join' ? '<span class="text-success">Join </span>' : ''))))))) ?></p>
                                </td>
                                <td class=""><?php echo $result['qualification']; ?></td>
                                <td width="20%" class="">
                                    <?php 
                                    $resultstr = array();
                                    foreach ($result['skill_detail'] as $skilldata) {   ?>
                                        <?php if ($skilldata != '') { ?>
                                    <?php  $resultstr[] = $skills_list[$skilldata];?>                                  
                                           <?php } ?>
                                    <?php }?>
                                     <span class="tag skill-lbl"><?php echo implode(",",$resultstr); ?> </span>
                                </td>
                                <td class=""><?php echo $result['cand_location']; ?></td>
                                <td class=""><?php echo $result['business_type']; ?></td>
                                <td class="texttd-light-head">
                                    <p class=""></p><?php echo $result['years_exp']; ?> yrs
    <?php echo $result['months_exp']; ?> months
                                </td>
                                <td class="">
                                    <p class="">Current :<?php echo $result['current_ctc']; ?></p>
                                    <p class="">Expected :<?php echo $result['expected_ctc']; ?></p>
                                </td>
                                <td>
                                    <p><?php echo date("j F, Y", strtotime($result['createddate'])); ?></p>

                                </td>



                            </tr>  
<?php } ?>
                    </tbody>
                </table>
<?php echo $this->ajax_pagination->create_links(); ?>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('_candidatetimeline'); ?>

<script>
    function searchFilter(page_num) {
        page_num = page_num ? page_num : 0;
        
        var keywords = $('#keywords').val();
        var sortBy = $('#sortBy').val();
        var screening_id = '<?php echo $screening_details['id']; ?>';
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>recruitment/ajaxPaginationCandidateList/' + screening_id + '/' + page_num,
            data: 'page=' + page_num + '&keywords=' + keywords + '&sortBy=' + sortBy,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#postList').html(html);
                $('.loading').fadeOut("slow");
            }
        });
    }
</script>

<script>
    $(document).ready(function () {
        $(".sort-data").click(function () {
            $('.sort-data').toggleClass('fa-sort-alpha-desc text-info');
            if ($('#sortBy').val() == 'asc')
                $('#sortBy').val('desc');
            else
                $('#sortBy').val('asc');
            searchFilter();

//            $('.sort-data').addClass('fa-sort-alpha-desc');
        });
    });
</script>

