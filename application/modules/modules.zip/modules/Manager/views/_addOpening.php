<!-- modal start -->
<div class="modal fade" id="addopening-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Opening</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim"> 
                    <?php echo form_open('manager/add_opening', array('id' => 'form_addOpening_id', 'class' => 'form_addOpening_id')); ?>
                    <div class="row">
                        <div class="col-sm-12">                            
                            <?php
                            echo form_checkbox(array(
                                'id' => 'client_interview',
                                'name' => 'client_interview',
                                'style' => 'left: 0 !important; opacity: 0 !important;',
                                'checked' => '',
                                'value' => '0',
                            ));
                            ?>
                            <?php echo form_label(lang('client_interview'), 'client_interview', array('for' => 'client_interview', 'style' => 'font-size:12px !important')); ?>                                
                            <?php echo form_error('req_code'); ?>                          
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('req_code'), 'req_code', array('for' => 'req_code')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'req_code',
                                    'name' => 'req_code',
                                    'placeholder' => 'Requisition Code',
                                    'class' => 'browser-default',
                                    'type' => 'text',
                                    'data-error' => '.addOpening1',
                                    'value' => $req_code
                                ));
                                ?>
                                <input type="hidden" name="requisition_id" value="">
                                <div class="addOpening1"></div>                                    
                                <?php echo form_error('req_code'); ?>   
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('close_date'), 'close_date', array('for' => 'close_date')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'close_date',
                                    'name' => 'close_date',
                                    'placeholder' => 'Close Date',
                                    'data-format' => 'yyyy-mm-dd',
                                    'class' => 'close_date',
                                    'data-error' => '.addOpening2',
                                ));
                                ?>   
                                <div class="addOpening2"></div>                                
                                <?php echo form_error('close_date'); ?> 
                            </div>                                        
                        </div>


                        <div class="clearfix"> </div>

                        <?php if ($user_summary['emprole'] == 4) { ?>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('req_type'), 'req_type', array('for' => 'req_type', 'data-error' => 'please select Requisition Type')); ?>

                                <?php
                                echo form_dropdown(array('id' => 'req_type', 
                                    'name' => 'req_type', 
                                    'class' => 'browser-default ', 
                                    'data-error' => '.errorTxtOff99'), $req_type_list);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff99"></div>
                                </div>
                                <?php echo form_error('req_type'); ?>

                            </div> 

                            <div class="col-sm-6" id="project_id_div" >
                                <?php echo form_label(lang('project_id'), 'project_id', array('for' => 'project_id', 'data-error' => 'project_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'project_id',
                                    'name' => 'project_id',
                                    'class' => 'browser-default ',
                                    'data-error' => '.errorTxtOff10'), $project_list);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff10"></div>
                                </div>
                                <?php echo form_error('project_id'); ?>

                            </div>
                        
                        <div class="clearfix"> </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('department_id'), 'department_id', array('for' => 'email', 'data-error' => 'please select department')); ?>

                                <?php
                                echo form_dropdown(array('id' => 'department_id', 
                                    'name' => 'department_id', 
                                    'class' => 'browser-default ', 
                                    'data-error' => '.errorTxtOff9'), $department);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff9"></div>
                                </div>
                                <?php echo form_error('department_id'); ?>

                            </div> 

                            <div class="col-sm-6">
                                <?php echo form_label(lang('manager_id'), 'reporting_manager', array('for' => 'reporting_manager', 'data-error' => 'reporting_manager')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'reporting_manager', 'name' => 'reporting_manager','class' => 'browser-default ', 'data-error' => '.errorTxtOff10','disabled'=>'disabled'));
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff10"></div>
                                </div>
                                <?php echo form_error('reporting_manager'); ?>

                            </div>
                        <div class="clearfix"> </div>
                        
                        <?php } else { ?>                 

                            <div class="col-sm-6">
                                <?php echo form_label(lang('req_type'), 'req_type', array('for' => 'req_type', 'data-error' => 'please select Requisition Type')); ?>

                                <?php
                                echo form_dropdown(array('id' => 'req_type', 
                                    'name' => 'req_type', 
                                    'class' => 'browser-default ', 
                                    'data-error' => '.errorTxtOff99'), 
                                        $req_type_list[3]);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff99"></div>
                                </div>
                                <?php echo form_error('req_type'); ?>

                            </div> 

                            <div class="col-sm-6" id="project_id_div" >
                                <?php echo form_label(lang('project_id'), 'project_id', array('for' => 'project_id', 'data-error' => 'project_id')); ?>
                                <?php
                                echo form_dropdown(array(
                                    'id' => 'project_id',
                                    'name' => 'project_id',
                                    'class' => 'browser-default ',
                                    'data-error' => '.errorTxtOff10'), $myproject_list);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtOff10"></div>
                                </div>
                                <?php echo form_error('project_id'); ?>

                            </div>
                        
                        <div class="clearfix"> </div>

                            <div class="col-sm-6">
                                <?php
                                echo form_input(array(
                                    'type' => 'hidden',
                                    'id' => 'department_id',
                                    'name' => 'department_id',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening5',
                                    'value' => $user_summary['department_id'],
                                ));
                                ?>               
                            </div>

                            <div class="col-sm-6">
                                <?php
                                echo form_input(array(
                                    'type' => 'hidden',
                                    'id' => 'reporting_manager',
                                    'name' => 'reporting_manager',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening50',
                                    'value' => $user_summary['user_id'],
                                ));
                                ?>                   
                            </div>
                        <?php } ?>
                        <div class="clearfix"></div>


                        <div class="col-sm-6">
                            <?php echo form_label(lang('job_title'), 'job_title', array('for' => 'jobtitle')); ?>                                
                            <?php
                            echo form_dropdown(array(
                                'id' => 'jobtitle',
                                'name' => 'jobtitle',
                                'class' => 'browser-default',
                                'data-error' => '.addOpening3',
                                    ), $job_code);
                            ?> 
                            <div class="input-field">
                                <div class="addOpening3"></div>
                                <?php echo form_error('jobtitle'); ?> 
                            </div>                                        
                        </div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('position_id'), 'position_id', array('for' => 'position_id')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'position_id',
                                'name' => 'position_id',
                                'class' => 'browser-default',
                                'data-error' => '.addOpening4',
                                    ), $position_list);
                            ?>
                            <div class="input-field">
                                <div class="addOpening4"></div>
                                <?php echo form_error('position_id'); ?> 
                            </div>                                        
                        </div>
                        <div class="clearfix"></div>




                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('req_no_positions'), 'req_no_positions', array('for' => 'req_no_positions')); ?>                            <?php
                                echo form_input(array(
                                    'name' => 'req_no_positions',
                                    'id' => 'req_no_positions',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Required Position',
                                    'type' => 'text',
                                    'data-error' => '.addOpening6',
                                ));
                                ?>                       
                                <div class="addOpening6"></div>
                                <?php echo form_error('req_no_positions'); ?>
                            </div>         
                        </div>    

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('jobdescription'), 'jobdescription', array('for' => 'description')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'description',
                                    'id' => 'description',
                                    'placeholder' => 'Job Description',
                                    'type' => 'text',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening7',
                                ));
                                ?>
                                <div class="addOpening7"></div>
                            </div>
                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('req_skills'), 'req_skills', array('for' => 'skills')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'skills',
                                    'name' => 'skills',
                                    'type' => 'text',
                                    'class' => 'browser-default',
                                    'placeholder' => 'Required Skills',
                                    'data-error' => '.addOpening8',
                                ));
                                ?>                    
                                <div class="addOpening8"></div>
                                <?php echo form_error('skills'); ?> 
                            </div>     
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('req_qualification'), 'req_qualification', array('for' => 'qualification')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'qualification',
                                    'id' => 'qualification',
                                    'type' => 'text',
                                    'placeholder' => 'Required qualification',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening9',
                                ));
                                ?>
                                <div class="addOpening9"></div>
                                <?php echo form_error('req_qualification'); ?> 
                            </div>                    
                        </div>                                       
                        <div class="clearfix"></div>


                        <div class="col-sm-3">
                            <div class="input-field">
                                <?php echo form_label(lang('from'), 'from', array('for' => 'yearsFrom')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'yearsFrom',
                                    'id' => 'yearsFrom',
                                    'type' => 'text',
                                    'placeholder' => 'From',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening10',
                                ));
                                ?>
                                <div class="addOpening10"></div>
                                <?php echo form_error('req_exp_years_from'); ?> 
                            </div>                    
                        </div>

                        <div class="col-sm-3">
                            <div class="input-field">
                                <?php echo form_label(lang('to'), 'to', array('for' => 'yesrsTo')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'yesrsTo',
                                    'id' => 'yesrsTo',
                                    'type' => 'text',
                                    'placeholder' => 'To',
                                    'class' => 'browser-default',
                                    'data-error' => '.addOpening11',
                                ));
                                ?>
                                <div class="addOpening11"></div>
                                <?php echo form_error('req_exp_years_to'); ?> 
                            </div>                    
                        </div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('for' => 'emp_status_id')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'emp_status_id',
                                'name' => 'emp_status_id',
                                'class' => 'browser-default',
                                'data-error' => '.addOpening12',
                                    ), $emp_status);
                            ?>
                            <div class="input-field">
                                <div class="addOpening12"></div>
                                <?php echo form_error('emp_type'); ?> 
                            </div>     
                        </div>
                        <div class="clearfix"></div>


                        <div class="col-sm-6">
                            <?php echo form_label(lang('emp_priority_id'), 'emp_priority_id', array('for' => 'emp_priority_id')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'emp_priority_id',
                                'name' => 'emp_priority_id',
                                'class' => 'browser-default',
                                'data-error' => '.addOpening13',
                                    ), $priority);
                            ?>
                            <div class="input-field">
                                <div class="addOpening13"></div>
                                <?php echo form_error('req_priority'); ?> 
                            </div>     
                        </div>


                        <div class="col-sm-6">
                            <?php echo form_label(lang('approver'), 'approver', array('for' => 'approver')); ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'approver',
                                'name' => 'approver',
                                'class' => 'browser-default',
                                'data-error' => '.addOpening14',
                                    ), $aprrover_list);
                            ?>
                            <div class="input-field">
                                <div class="addOpening14"></div>
                                <?php echo form_error('approver1'); ?> 
                            </div>     
                        </div>

                        <div class="clearfix"></div>


                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->
<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
//           $("#req_type").change(function () {
////               alert($("#req_type option:selected").val());
//        if ($("#req_type option:selected").val() == '3') {
//            $('#project_id_div').show();        }
//        else {
//            $('#project_id_div').hide();
//        }       
//    });


        $(".close_date").click(function () {
            $('.close_date').pickadate({
                selectYears: true,
                selectMonths: true,
                min: new Date(),
            });
        });


        $("#client_interview").click(function () {

            var isChecked = $("#client_interview").val();
            if (isChecked == 0) {

                $("#client_interview").val('1');
            } else {

                $("#client_interview").val('0');
            }

        });
    });

    /* Deopdown Functions */
    $('select[name="jobtitle"]').change(function () {
        var jobtitle = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getPositionName',
            data: {'jobtitle_id': jobtitle},
            success: function (data) {
                if (data) {
                    $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                    $("#position_id").val($("#position_id option:first").val());
                }
            }
        });
    });


    $('select[name="job_code"]').change(function () {
        var job_code = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getJobTitle',
            data: {'job_code': job_code},
            success: function (data) {
                if (data) {
                    $('select[name="jobtitle_id"]').html(data.content).trigger('liszt:updated').val(jobtitle_id);
                    $('#jobtitle_id').material_select();
                }
            }
        });
    });

    //to get reporting manager 
    $("#department_id").change(function () {
        $('#reporting_manager').removeAttr('disabled');
        if ($("#department_id option:selected").text() != "") {
            $('#department_name').val($("#department_id option:selected").text());
        }

        $('#reporting_manager_name').val('');
        if ($("#reporting_manager option:selected").text() != "") {
            $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
        }
        var department_id = $("select#department_id option:selected").val();
        ajaxCallToGetAllManager(department_id);
    });



    function ajaxCallToGetAllManager(department_id)
    {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>manager/getReportingManager',
            data: {'department_id': department_id},
            success: function (data) {
                $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                $("#reporting_manager").val($("#reporting_manager option:first").val());
            }
        });
    }
</script>   
