<?php
foreach ($leaveEdit_list as $list) { ?>
    <div class="modal fade" id="edit-leave-Modal-<?php echo $list['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content ">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Edit Leave</h4>
                </div>
                <div class="modal-body">
                        <?php echo form_open('leave/edit_leaveType/' . $list['id'], array('id' => 'form_addLeave_id_modal', 'class' => 'form_addLeave_id_modal')); ?>
                        <div class="row">
                            <div class="col-sm-12">

                                <?php echo form_label(lang('leavename'), 'leavename', array('for' => 'leavename')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'leavename', 'name' => 'leavename', 'class' => 'browser-default', 'data-error' => '.errorLeaveE1'), $leavetype, set_value('leavetype', $list['leavetype']));
                                ?>
                                <div class="input-field">    
                                    <div class="errorLeaveE1"></div>
                                    <?php echo form_error('leavename'); ?>
                                </div>                                       
                            </div>
                            <div class="clearfix"></div>                                                                       
                            
                            <div class="col-sm-12">
                                <div class="input-field">
                                    
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'leavepreallocated',                                        
                                        'value' => set_value('leavepreallocated', $list['leavepreallocated']),  
                                        'placeholder' => 'leavepreallocated',
                                        'data-error' => '.errorLeaveE2'                                       
                                    ));
                                    ?>               
                                    <?php echo form_label(lang('leavepreallocated'), 'leavepreallocated', array('for' => 'leavepreallocated')); ?>
                                    <div class="errorLeaveE2"></div>
                                     <?php echo form_error('firstname'); ?>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-12 padding-top-10 text-right">
                                <input type="submit" class="btn btn-warning2 btn-sm" />
                             </div>
                        </div>
                    <input type="hidden" value="<?php echo $list['leaveYear']?>" name="leaveYear">
                        <?php echo form_close(); ?>                  
                </div>
            </div>
        </div>
    </div>
<?php } ?>
