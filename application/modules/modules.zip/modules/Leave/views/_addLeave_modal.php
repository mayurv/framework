<!-- modal start -->
<div class="modal fade" id="addleave-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Leave</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <?php echo form_open('leave/add_leave', array('id' => 'form_addLeave_id', 'class' => 'form_addLeave_id')); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo form_label(lang('leaveYear'), 'leaveYear', array('for' => 'leaveYear')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'leaveYear', 'name' => 'leaveYear', 'class' => 'browser-default', 'data-error' => '.errorLeave1'), $leaveYear_list);
                            ?>
                            <div class="input-field">
                                <div class="errorLeave1"></div>
                            </div> 
                            <?php echo form_error('leaveYear'); ?>
                        </div>

                        <div class="clearfix"> </div>

                        <input type="hidden" name="total_count" id="total_count" value="">
                        

                        <div class="col-sm-6">
                            <?php echo form_label(lang('leavename'), 'leavename',array('for' => 'leavename')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'leavename_id', 'name' => 'leavename', 'class' => 'browser-default', 'data-error' => '.errorLeave2'), $leavetype);
                            ?>                                                      
                            <div class="input-field">
                                <div class="errorLeave2"></div>                                
                                <?php echo form_error('leavename'); ?>
                            </div>                                       
                        </div>
                        
                        <div class="col-sm-5">
                            <div class="input-field">
                                <?php echo form_label(lang('leavepreallocated'), 'leavepreallocated', array('for' => 'leavepreallocated')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'leavepreallocated',
                                    'id' => 'leavepreallocated',
                                    'placeholder' => 'leavepreallocated',
                                    'data-error' => '.errorLeave3'
                                ));
                                ?>
                                <div class="errorLeave3"></div>
                            </div>
                        </div>
                        <div class="col-sm-1 margin-top-20">
                            <i class="fa fa-plus add-row font-size-11"></i>

                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-12">
                            <!-- bind data start here -->
                            <div class="holiday-dbind-bg">
                                <div class="row border-bottom margin-bottom-10 padding-bottom-10"> 
<!--                                    <div class="col-sm-2"><p class="text-bold">Select</p></div>-->
                                    <div class="col-sm-6"><p class="text-bold">Type</p></div>
                                    <div class="col-sm-4"><p class="text-bold">Alloted</p></div>  
                                    <div class="col-sm-2"><p class="text-bold"></p></div>
                                </div>
                            </div>
                            <!-- bind data end here -->
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-sm-12 text-right padding-top-10">

                            <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->

<script type="text/javascript">
    var i = 0;
    function formatDate(date) {
        var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }
    $('input[name="holiday_date"]').on('change', function () {
        var cur_date = $(this).val();

        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var d = new Date(formatDate(cur_date));
        var dayName = days[d.getDay()];

        $('#holiday_day').val(dayName);

    });

    $(document).ready(function () {
        $(".add-row").on('click', function () {
            i++;           
            if ($("#leavename_id option:selected").val() == '' || $("#leavepreallocated").val() == '') {
                alert('Leave fields can not be null!');
                return false;
            }
            var leave_id = $("#leavename_id option:selected").val();
            var name = $("#leavename_id option:selected").text();
            var allocated = $("#leavepreallocated").val();
            $("#total_count").val(i);
            var markup = "<div class='margin-bottom-5 deleteLeave_" + i + "'><div class='row'>\n\n\
                          <div class='col-sm-6'><p class='text-bold'><input type='hidden' name='leavename-" + i + "' value='" + leave_id + "'>" + name + "</p></div>\n\n\
                          <div class='col-sm-4'><p class='text-bold'><input type='hidden' name='alloted-" + i + "' value='" + allocated + "'>" + allocated + "</p></div>\n\
                          <div class='col-sm-2' ><i class='fa fa-trash text-ccc' onclick=\"deleteLeave('" + i + "');\"></i></div></div></div>";

            $(".holiday-dbind-bg").append(markup);
            $("#leavename_id option[value='']").attr('selected', 'selected');
            $("#leavepreallocated").val('');
        });
    });
</script>

<script>
    function deleteLeave(dId) {
        if (i > 0)
            i--;
        $("div").remove(".deleteLeave_" + dId);
    }
</script>
