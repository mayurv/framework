<?php // var_dump($associates);die;        ?>
<div class="white-bg all-padding-15 ">
    <div class="col-sm-12">
        <div class="leave-heading">
            <h4 class="text-bold">Leave Allocation  <?php // echo date('Y');     ?>
                <div class="pull-right">
                    <!--<button type="button" class="btn btn-sm btn-default"><i class="fa fa-plus-circle"></i> Assign Leave</button>-->
                </div>
            </h4>
            <span class="pull-right">
                <a href="<?php echo base_url();?>hr/cronjob" class="btn btn-sm btn-primary">Allocate Privilege Leaves</a>
            </span>
        </div>
    </div>


    <div class="col-md-12">
        <table id="dt-associate-of-months" class="table">
            <thead>
                <tr>       
                    <th width="20%">Associate Name</th>
                    <th>Department</th>
                    <th>Casual</th>                         
                    <th><span class="btn btn-warning btn-xs">Privilege *</span></th>                         
                    <th>Sick</th>                         
                    <th>Parental</th>                         
                    <th>Maternity</th>      
                    <th>Year</th>      
                    <th>Carry Forward</th>      
                    <th>Probation Status</th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php if (isset($associates)) { ?>
                    <?php foreach ($associates as $r => $assocdata) { ?>
                        <tr>                                
                            <td>
                                <i>
                                    <?php if (isset($assocdata['profileimg']) && $assocdata['profileimg'] != '') { ?>
                                        <img class="img-responsive img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $assocdata['profileimg']; ?>">  
                                    <?php } else { ?>
                                        <img class="img-responsive img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                    <?php } ?>
                                </i>                               
                                <p><?php echo $assocdata['userfullname'] ?></p>
                                <p><small class="text-info"><?php echo $assocdata['position_name'] ?></small></p>
                            </td>
                            <!--badge bg-priviledge badge bg-sick badge bg-parental bg-maternity-->
                            <td><p class="btn btn-xs btn-default"><?php echo $assocdata['department_name'] ?></p></td>
                            <td><p><span class="btn btn-circle btn-default btn-sm"><?php echo isset($assocdata['leave_balance'][2]) ? $assocdata['leave_balance'][2] : '0' ?></span></p></td>                           
                            <td><p><span class="btn btn-circle btn-default btn-sm"><?php echo isset($assocdata['leave_balance'][0]) ? $assocdata['leave_balance'][0] : '0' ?></span></p></td>                           
                            <td><p><span class="btn btn-circle btn-default btn-sm"><?php echo isset($assocdata['leave_balance'][1]) ? $assocdata['leave_balance'][1] : '0' ?></span></p></td>                           
                            <td><p><span class="btn btn-circle btn-default btn-sm"><?php echo isset($assocdata['leave_balance'][3]) ? $assocdata['leave_balance'][3] : '0' ?></span></p></td>                           


                            <td><p><span class="btn  btn-default btn-sm"><?php echo isset($assocdata['leave_balance'][4]) ? $assocdata['leave_balance'][4] : '<span class="">NA</span>' ?></span></p></td>                           

             <!--<td><p><?php // echo isset($assocdata['leave_balance'][4]) ? $assocdata['leave_balance'][4] : '<span class="text-warning">NA</span>'   ?></p></td>-->                           

                            <td><p><?php echo date('Y') ?></p></td>                           
                            <td><p class="btn btn-success btn-sm"><?php echo isset($assocdata['carry_forward']) ? $assocdata['carry_forward'] : '0' ?></p></td>      
                            <td>
                                <p><?php echo ($assocdata['probation_status'] == 1) ? "<span class='btn btn-success btn-xs'>Completed</span>" : "<span class='btn btn-warning btn-xs'>In-Probation</span>" ?></p>
                                <p title="Date of Joining"><small class="text-light-gray"><?php echo date('d F Y', strtotime($assocdata['date_of_joining'])) ?></small></p>
                            </td>                                                                            
                            <td>

                                <i class="fa fa-pencil text-ccc" data-toggle="modal" data-target="#allocate-lv-<?php echo $assocdata['id'] ?>" title="Delete"></i>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<div id="loader-bg" style="display: none">
    <!--<div class="loader" style="display: block"></div>-->
    <div class="loader-txt margin-bottom-10"><h3>We Make IT simple</h3></div>
    <div class="loader-animation" style="display: block">&#9632;&#9632;&#9632;&#9632;&#9632;</div>
</div>
<?php $this->load->view('_modal_allocate_lv') ?>

