<div class="main-bg all-padding-15">
    <!-- top button bar here -->  
    <h4 class="text-bold">Leave Types Allocation</h4>
    <div class="add-candidate-bg"> 
        <div class="pull-right">
            <button class="btn btn-default btn-sm" data-toggle="modal" href="#addleave-1"><i class="fa fa-plus-circle"></i> Add Leave</button>
        </div>
    </div>                          
    <!-- top button bar here -->

    <div class="row">
        <div class="col-sm-3">
            <ul class="nav nav-tabs" role="tablist">  
                <?php foreach ($leaveList_years as $list) { ?>
                    <?php $list['year_id'] == $cur_year ? $tabActive="active" : $tabActive=""  ?>
                    <li role="presentation" class="<?php echo $tabActive ?>" >
                        <a class="cl-year" id="year-id" href="#<?php echo $list['year_id'] ?>" aria-controls="Year <?php echo $list['year_id'] ?>" role="tab" data-toggle="tab"><?php echo $list['year_id'] ?></a>
                    </li>  
                <?php } ?>  
            </ul>
        </div>
        <div class="col-sm-9">
            <div class="leavelist_display" >
                <?php $this->load->view('leave/_leaveList_display') ?>
            </div> 
        </div>
    </div>
</div>   
<?php $this->load->view('leave/_addLeave_modal') ?>
<?php $this->load->view('leave/edit_leaveType'); ?> 

<script type="text/javascript">
    function AjaxCallLeaveListData(year_id) {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>leave/getLeaveListData',
            data: {'year_id': year_id},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.leavelistdata == null) {
                    $('.leavelist_display').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.leavelist_display').show();
                    $('.first_display').hide();
                    $('.leavelist_display').html(parsed.leavelistdata);
                }
            }
        });
    }
    $(document).ready(function () {
    
        $('.cl-year').on('click', function (event) {
            //alert($(this).attr('href').substring(1));
            var year_id = $(this).attr('href').substring(1);
            AjaxCallLeaveListData(year_id);
        });
        
        $('.cl-year').on('click', function (event) {
            //alert($(this).attr('href').substring(1));
            var year_id = $(this).attr('href').substring(1);
            AjaxCallLeaveListData(year_id);
        });
    });
</script>
<script>
    $(window).load(function () {
    <?php if (($this->session->flashdata())) { ?>
                showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
    <?php } ?>
    });
</script>