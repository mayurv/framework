<!--Modal View Leaves-->
<?php // var_dump($associates); die;?>
<?php if (isset($associates)) { ?>
    <?php foreach ($associates as $r => $assocdata) { ?>
        <div class="modal fade" id="allocate-lv-<?php echo $assocdata['id'] ?>" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">   
                    <div class="modal-header padding-bottom-0">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4>Leave Allocation - <?php echo $assocdata['userfullname'] ?> </h4>
                    </div>


                    <div class="modal-body user-modal-slim">
                        <?php echo form_open('leave/leaveallocate/' . $assocdata['id'], array('id' => 'form_allocate_leave_' . $assocdata['user_id'], 'class' => 'form-horizontal')); ?>
                        <div class="row">
                            
                            <div class="col-sm-12">
                                <div class="alert alert-info">
                                    Note : Once Candidate get register, his/her leaves are alloted by system after registration, to change it  you can click "+" or "-" to add/subtract leave
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-sm-12 note-<?php echo $assocdata['id'] ?>"></div>


                            <div class="col-sm-12">
                                <div class="row">
<!--                                    <div class="col-sm-2 text-center">
                                <?php if (isset($assocdata['profileimg']) && $assocdata['profileimg'] != '') { ?>
                                        <img class=" img-rounded img-responsive text-center" style="width: 50%" src="<?php echo base_url() . 'assets/uploads/' . $assocdata['profileimg']; ?>">  
                                <?php } else { ?>
                                    <img class=" img-rounded img-responsive text-center" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                <?php } ?>
                                <span class="text-info"><?php echo $assocdata['userfullname'] ?></span>
                                <?php echo $assocdata['position_name'] ?>
                            </div>-->
                                    <div class="col-sm-2 border-right">
                                        <div  class="" >
                                            <div class="all-padding-5 text-center text-primary">
                                                <span class=""> SICK LEAVE  <p class="text-center"><i class="fa fa-thermometer-empty fa-2x"> </i></p></span>                                                                              
                                            </div>
                                            <div class="text-center all-padding-5">

                                                <button class="btn btn-default btn-xs sub-sick" type="button" id="sub" ><i class="fa fa-minus"></i></button>
                                                <button  type="button" class="btn btn-default btn-xs" type="text" id="sick_bal_<?php echo $assocdata['id'] ?>" value="<?php echo isset($assocdata['leave_balance'][1]) ? $assocdata['leave_balance'][1] : '0' ?>" class="field text-center no-border" >
                                                    <?php echo isset($assocdata['leave_balance'][1]) ? $assocdata['leave_balance'][1] : '0' ?>
                                                </button>
                                                <button class="btn btn-default btn-xs add-sick" type="button" id="add" ><i class="fa fa-plus"></i></button>
                                                <input type="hidden" value="<?php echo isset($assocdata['leave_balance'][1]) ? $assocdata['leave_balance'][1] : '0' ?>" id="sick-deducted">
                                                <input type="hidden" value="<?php echo $assocdata['id'] ?>" id="adjust-leave<?php echo $assocdata['id'] ?>">
                                            </div>
                                        </div>
                                        <?php if ($assocdata['sick_leave_status'] == '1') { ?>
                                            <div class="switch text-center">
                                                <label > 
                                                    <input style="" type="checkbox" id="sick_status_<?php echo $assocdata['user_id'] ?>" name="sick_status_<?php echo $assocdata['user_id'] ?>" value="1" onclick="changeSickStatus('<?php echo $assocdata['user_id'] ?>')" checked="checked">
                                                    <span class="lever"></span>
                                                    <input type="hidden" id="sick_in_<?php echo $assocdata['user_id'] ?>" name="sick_status_<?php echo $assocdata['user_id'] ?>" value="1" >

                                                </label>
                                            </div>
                                        <?php } else { ?>
                                            <div class="switch text-center">
                                                <label > 
                                                    <input style="" type="checkbox" id="sick_status_<?php echo $assocdata['user_id'] ?>" name="sick_status_<?php echo $assocdata['user_id'] ?>" value="0" onclick="changeSickStatus('<?php echo $assocdata['user_id'] ?>')" >
                                                    <span class="lever"></span>
                                                    <input type="hidden" id="sick_in_<?php echo $assocdata['user_id'] ?>" name="sick_status_<?php echo $assocdata['user_id'] ?>" value="0" >

                                                </label>
                                            </div>
                                        <?php } ?>
                                    </div>

                                    <div class="col-sm-2 border-right">
                                        <div  class="">
                                            <div class="all-padding-5 text-center text-gray">
                                                <span class="">PRIVILEGE LEAVE <p class="text-center"><i class="fa fa-money fa-2x"></i></p></span>                                        
                                            </div>
                                            <div class="text-center all-padding-5">
                                                <input type="number" min="0" class=""  id="p_bal_<?php echo $assocdata['id'] ?>" value="<?php echo $assocdata['leave_balance'][0] ?>" class="field text-center no-border" >
                                                    <?php // echo isset($assocdata['leave_balance'][0]) ? $assocdata['leave_balance'][0] : '0' ?>
<!--                                                </input>-->
                                                <input type="hidden" value="<?php echo isset($assocdata['leave_balance'][0]) ? $assocdata['leave_balance'][0] : '0' ?>" id="pl-deducted">
                                                <input type="hidden" value="<?php echo $assocdata['id'] ?>" id="adjust-leave<?php echo $assocdata['id'] ?>">

                                            </div>
                                        </div>
                                        &nbsp;
                                    </div>


                                    <div class="col-sm-2 ">
                                        <div  class="" >
                                            <div class="all-padding-5 text-center text-info">
                                                <span class="">CASUAL LEAVE <p class="text-center"><i class="fa fa-calendar-o  fa-2x"></i></p></span>                                        
                                            </div>
                                            <div class="text-center all-padding-5">

                                                <button class="btn btn-default btn-xs c-sub" type="button" id="sub" ><i class="fa fa-minus"></i></button>
                                                <button type="button" class="btn btn-default btn-xs" type="text" id="c_bal_<?php echo $assocdata['id'] ?>" value="<?php echo isset($assocdata['leave_balance'][2]) ? $assocdata['leave_balance'][2] : '0' ?>" class="field text-center no-border" ><?php echo isset($assocdata['leave_balance'][2]) ? $assocdata['leave_balance'][2] : '0' ?></button>
                                                <button class="btn btn-default btn-xs c-add" type="button" id="add" ><i class="fa fa-plus"></i></button>
                                                <input type="hidden" value="<?php echo isset($assocdata['leave_balance'][2]) ? $assocdata['leave_balance'][2] : '0' ?>" id="cl-deducted">
                                                <input type="hidden" value="<?php echo $assocdata['id'] ?>" id="adjust-leave<?php echo $assocdata['id'] ?>">

                                            </div>
                                        </div>
                                        <?php if ($assocdata['cas_leave_status'] == '1') { ?>
                                            <div class="switch text-center">
                                                <label > 
                                                    <input style="" type="checkbox" id="cas_status_<?php echo $assocdata['user_id'] ?>" name="cas_status_<?php echo $assocdata['user_id'] ?>" value="1" onclick="changeCasStatus('<?php echo $assocdata['user_id'] ?>')" checked="checked">
                                                    <span class="lever"></span>
                                                    <input type="hidden" id="cas_in_<?php echo $assocdata['user_id'] ?>" name="cas_status_<?php echo $assocdata['user_id'] ?>" value="1" >

                                                </label>
                                            </div>
                                        <?php } else { ?>
                                            <div class="switch text-center">
                                                <label > 
                                                    <input style="" type="checkbox" id="cas_status_<?php echo $assocdata['user_id'] ?>" name="cas_status_<?php echo $assocdata['user_id'] ?>" value="0" onclick="changeCasStatus('<?php echo $assocdata['user_id'] ?>')">
                                                    <span class="lever"></span>
                                                    <input type="hidden" id="cas_in_<?php echo $assocdata['user_id'] ?>" name="cas_status_<?php echo $assocdata['user_id'] ?>" value="0" >

                                                </label>
                                            </div>
                                        <?php } ?>

                                    </div>

                                    <?php if (isset($assocdata['personal_detail'])) { ?>
                                        <?php if ($assocdata['personal_detail']['marital_status_id'] == '2' && $assocdata['personal_detail']['gender_id'] == '1') { ?>

                                            <div class="col-sm-2 border-left">
                                                <div  class="" >
                                                    <div class="all-padding-5 text-center text-success">
                                                        <span class="">PARENTAL LEAVE <p class="text-center"><i class="fa fa-child fa-2x"></i></p></span>                                        
                                                    </div>
                                                    <div class="text-center all-padding-5">

                                                        <button class="btn btn-default btn-xs par-sub" type="button" id="sub" ><i class="fa fa-minus"></i></button>
                                                        <button type="button" class="btn btn-default btn-xs" id="par_bal_<?php echo $assocdata['id'] ?>" value="<?php echo $assocdata['leave_balance'][3] ?>" class="field text-center no-border" ><?php echo $assocdata['leave_balance'][3] ?></button>
                                                        <button class="btn btn-default btn-xs par-add" type="button" id="add" ><i class="fa fa-plus"></i></button>
                                                        <input type="hidden" value="<?php echo $assocdata['leave_balance'][3] ?>" id="par-deducted">
                                                        <input type="hidden" value="<?php echo $assocdata['id'] ?>" id="adjust-leave<?php echo $assocdata['id'] ?>">

                                                    </div>
                                                </div>
                                                <?php if ($assocdata['par_leave_status'] == '1') { ?>

                                                    <div class="switch">
                                                        <label > 
                                                            <input style="" type="checkbox" id="par_status_<?php echo $assocdata['user_id'] ?>" name="par_status_<?php echo $assocdata['user_id'] ?>" value="1" onclick="changeParStatus('<?php echo $assocdata['user_id'] ?>')" checked="checked">
                                                            <span class="lever"></span>
                                                            <input type="hidden" id="par_in_<?php echo $assocdata['user_id'] ?>" name="par_status_<?php echo $assocdata['user_id'] ?>" value="1" >

                                                        </label>
                                                    </div>
                                                <?php } else { ?>
                                                    <div class="switch">
                                                        <label > 
                                                            <input style="" type="checkbox" id="par_status_<?php echo $assocdata['user_id'] ?>" name="par_status_<?php echo $assocdata['user_id'] ?>" value="0" onclick="changeParStatus('<?php echo $assocdata['user_id'] ?>')" >
                                                            <span class="lever"></span>
                                                            <input type="hidden" id="par_in_<?php echo $assocdata['user_id'] ?>" name="par_status_<?php echo $assocdata['user_id'] ?>" value="0" >

                                                        </label>
                                                    </div>
                                                <?php } ?>

                                            </div>  




                                        <?php } ?>
                                    <?php } ?>

                                    <?php if (isset($assocdata['personal_detail'])) { ?>
                                        <?php if ($assocdata['personal_detail']['marital_status_id'] == '2' && $assocdata['personal_detail']['gender_id'] == '2') { ?>


                                            <div class="col-sm-2 border-left">
                                                <div  class="" >
                                                    <div class="all-padding-5 text-center text-info">
                                                        <span class="">MATERNITY LEAVE <p class="text-center"><i class="fa fa-child fa-2x"></i></p></span>                                        
                                                    </div>
                                                    <div class="text-center col-sm-12">
                                                        <?php
                                                        $assocdataMatL = array('180' => '180', '90' => '90');
                                                        echo form_dropdown(array('id' => 'maternity_' . $assocdata['user_id'], 'name' => 'maternity_' . $assocdata['user_id']), $assocdataMatL, set_value('maternity_', $assocdata['leave_balance']['4']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff2'));
                                                        ?>


                                                    </div>  


                                                    <div class=" text-center">
                                                        <!--<label for="mat_status_<?php // echo $assocdata['user_id']                      ?>" class="lever"></label>-->
                                                        <?php if ($assocdata['maternity_leave_status'] == '1') { ?>


                                                            <div class="switch">
                                                                <label> 
                                                                    <input style="left:0px !important" type="checkbox" id="mat_status_<?php echo $assocdata['user_id'] ?>" name="mat_status_<?php echo $assocdata['user_id'] ?>" value="1" onclick="changeMatStatus('<?php echo $assocdata['user_id'] ?>')" checked="checked">
                                                                    <span class="lever margin-top-10"></span>
                                                                    <input type="hidden" id="mat_in_<?php echo $assocdata['user_id'] ?>" name="mat_status_<?php echo $assocdata['user_id'] ?>" value="1" >

                                                                </label>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="switch">
                                                                <label> 
                                                                    <input style="left:0px !important" type="checkbox" id="mat_status_<?php echo $assocdata['user_id'] ?>" name="mat_status_<?php echo $assocdata['user_id'] ?>" value="0" onclick="changeMatStatus('<?php echo $assocdata['user_id'] ?>')" >
                                                                    <span class="lever margin-top-10"></span>
                                                                    <input type="hidden" id="mat_in_<?php echo $assocdata['user_id'] ?>" name="mat_status_<?php echo $assocdata['user_id'] ?>" value="0" >

                                                                </label>
                                                            </div>

                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php } ?>
                                    <?php } ?>


                                </div>


                            </div>



                            <div class="clearfix"></div>

                        </div>
                        <div class="clearfix"></div>
                        <div class="margin-top-20"></div>

                        <div class="clearfix"></div>

                        <div class="row">
                            <div class="col-sm-12 ">
                                <div class=" text-right">

                                    <input hidden type="text" value="" name="cl_<?php echo $assocdata['user_id'] ?>" id="cl_<?php echo $assocdata['user_id'] ?>">
                                    <input hidden type="text" value="" name="pl_<?php echo $assocdata['user_id'] ?>" id="pl_<?php echo $assocdata['user_id'] ?>">
                                    <input hidden type="text" value="" name="sl_<?php echo $assocdata['user_id'] ?>" id="sl_<?php echo $assocdata['user_id'] ?>">
                                    <input hidden type="text" value="" name="par_<?php echo $assocdata['user_id'] ?>" id="par_<?php echo $assocdata['user_id'] ?>">
                                    <input hidden type="text" value="<?php echo $assocdata['user_id'] ?>" name="associate_id" id="<?php echo $assocdata['user_id'] ?>">
                                    <button type="button" class="btn btn-warning2 btn-sm" onclick="assignLeaves('<?php echo $assocdata['user_id'] ?>', '<?php echo $assocdata['id'] ?>')">Submit</button>
                                </div> 
                            </div>
                        </div>
                        <?php echo form_close(); ?>
                    </div>

                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>

<script type="text/javascript">


    //Sick Leave

    $('.add-sick').click(function () {
        //to get current leqave id
        var leave_id = $(this).next().next().val();

        $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

        var val = +$(this).prev().val() + 0.5;
        $(this).prev().val(val);
        $(this).prev().text(val);

    });
    $('.sub-sick').click(function () {
        //to get current leqave id

        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
    });


    //Casual Leave

    $('.c-add').click(function () {
        //to get current leqave id
        var leave_id = $(this).next().next().val();



        $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

        var val = +$(this).prev().val() + 0.5;
        $(this).prev().val(val);
        $(this).prev().text(val);

    });
    $('.c-sub').click(function () {
        //to get current leqave id

        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
    });

    //Priviledge Leave
    $('.add-p').click(function () {
        var leave_id = $(this).next().next().val();


        $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);
        var val = +$(this).prev().val() + 0.5;
        $(this).prev().val(val);
        $(this).prev().text(val);


    });
    $('.sub-p').click(function () {
        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());
        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);
            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
    });
    //Loss of Pay
    $('.add-loss').click(function () {
        var leave_id = $(this).next().next().val();

        var adbal = $("#adjust_bal" + leave_id).val();
        var losval = $(this).val();
        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (adjustBal < noofdays) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);
        }
        else {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            //$('.note').fadeOut(1000);
            return true;

        }

    });
    $('.sub-loss').click(function () {
        var leave_id = $(this).next().next().next().next().val();



        if ($(this).next().val() > 0) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);
            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
    });


</script>

<script>

    function assignLeaves(associateId, allotId) {


        $("#cl_" + associateId).val($("#c_bal_" + allotId).val());
        $("#pl_" + associateId).val($("#p_bal_" + allotId).val());
        $("#sl_" + associateId).val($("#sick_bal_" + allotId).val());
        $("#par_" + associateId).val($("#par_bal_" + allotId).val());
//        return false;
        $("#form_allocate_leave_" + associateId).submit();


    }

    function regularizeLeave(leaveId) {


        var noofdays = parseFloat($("#noofday_" + leaveId).val());
        var adjustBal = parseFloat($("#adjust_bal" + leaveId).text());

        if (adjustBal < noofdays) {
            $('.note-' + leaveId).fadeIn(100);
            var alertNotify = '<div class="alert alert alert-warning alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong>Warning:</strong> Please Regularize Leave</div>';
            $('.note-' + leaveId).html(alertNotify);
        }
        else {

//            $("#associate_id" + leaveId).val();
            $("#cl_" + leaveId).val(parseFloat($("#c_bal_" + leaveId).text()));
            $("#pl_" + leaveId).val(parseFloat($("#p_bal_" + leaveId).text()));
            $("#sl_" + leaveId).val(parseFloat($("#sick_bal_" + leaveId).text()));
            $("#paid_" + leaveId).val(parseFloat($("#loss_bal_" + leaveId).text()));

            $("#form_regularize_id_" + leaveId).submit();
        }
    }
</script>

<script>
    //Parental Leave
    $(document).ready(function () {
        $('.par-add').click(function () {
            //to get current leqave id
            var leave_id = $(this).next().next().val();

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);


        });
        $('.par-sub').click(function () {
            //to get current leqave id

            var leave_id = $(this).next().next().next().next().val();

            var noofdays = parseFloat($("#noofday_" + leave_id).val());
            var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

            if (noofdays == adjustBal) {
                $('.note-' + leave_id).fadeIn(100);
                var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
                $('.note-' + leave_id).html(alertNotify);
                //$('.note').fadeOut(1000);
                return true;
            }

            if ($(this).next().val() > 0) {

                $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

                var vals = +$(this).next().val() - 0.5;
                $(this).next().val(vals);
                $(this).next().text(vals);
            }
        });
    });
</script>
|<script>
    function changeSickStatus(mat_id) {
        if ($("#sick_status_" + mat_id).val() == 0) {
            $("#sick_status_" + mat_id).val('1');
            $("#sick_in_" + mat_id).val('1');
        } else {
            $("#sick_status_" + mat_id).val('0');
            $("#sick_in_" + mat_id).val('0');
        }
    }
    function changeParStatus(mat_id) {
        if ($("#par_status_" + mat_id).val() == 0) {
            $("#par_status_" + mat_id).val('1');
            $("#par_in_" + mat_id).val('1');
        } else {
            $("#par_status_" + mat_id).val('0');
            $("#par_in_" + mat_id).val('0');
        }
    }
    function changeCasStatus(mat_id) {
        if ($("#cas_status_" + mat_id).val() == '0') {
            $("#cas_status_" + mat_id).val('1');
            $("#cas_in_" + mat_id).val('1');
        } else {
            $("#cas_status_" + mat_id).val('0');
            $("#cas_in_" + mat_id).val('0');
        }
    }
    function changePriStatus(mat_id) {
//        if ($("#pri_status_" + mat_id).val() == 0) {
//            $("#mat_status_" + mat_id).val('1');
//            $("#mat_in_" + mat_id).val('1');
//        } else {
//            $("#mat_status_" + mat_id).val('0');
//            $("#mat_in_" + mat_id).val('0');
//        }
    }
    function changeMatStatus(mat_id) {
        if ($("#mat_status_" + mat_id).val() == 0) {
            $("#mat_status_" + mat_id).val('1');
            $("#mat_in_" + mat_id).val('1');
        } else {
            $("#mat_status_" + mat_id).val('0');
            $("#mat_in_" + mat_id).val('0');
        }
    }
</script>
