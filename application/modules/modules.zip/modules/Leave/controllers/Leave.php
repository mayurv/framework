<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Leave extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

//        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'leavetypes', 'frontend/leaverequest', 'employeesleave', 'leavetypesAllocation', 'holidaydates', 'years', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
//        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('leave_lang');

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/dashboard', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function add_leave() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data['list'] = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $leave_type_count = $this->input->post('total_count');
            if (isset($leave_type_count)) {
                for ($i = 1; $i <= $leave_type_count; $i++) {
                    $dataLeaveType[$i]['leavetype'] = $this->input->post('leavename-' . $i);
                    $dataLeaveType[$i]['leavepreallocated'] = $this->input->post('alloted-' . $i);
                    $dataLeaveType[$i]['leaveYear'] = $this->input->post('leaveYear');
                    $dataLeaveType[$i]['isactive'] = 1;
                    $dataLeaveType[$i]['createdby'] = $user_id;
                    $dataLeaveType[$i]['createddate'] = date('Y-m-d H:m:s');
                }
            }
            if (isset($dataLeaveType))
                foreach ($dataLeaveType as $dataResult) {
                    $this->leavetypesAllocation->insert($dataResult);
                }
            $this->session->set_flashdata('msg', 'Record addedd successfully');
        }

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $current_year = $this->leavetypesAllocation->getCurrentPublishYear();
        if (!empty($current_year)) {
            $current_year = $current_year[0]['year_id'];
            $data['cur_year'] = $current_year;
        } else {
            $current_year = date('Y');
            $data['cur_year'] = date('Y');
        }

        $data['leaveType_list'] = $this->leavetypesAllocation->getLeaveListByYear($current_year);
        $data['leaveEdit_list'] = $this->leavetypesAllocation->getEditLeaveListByYear($current_year);
        $data['publish_status'] = $this->leavetypesAllocation->get_publishStatus($current_year);
        $data['leavetype'] = (array('' => 'Select Type') + $this->leavetypes->dropdown('leavetype'));
        $data['leaveList_years'] = $this->leavetypesAllocation->get_AllYearsList();
        $data['publish_status'] = $data['publish_status'][0]['isactive'];
        $data['leaveYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'addLeaveType', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function getLeaveListData() {
        $year_id = $_POST['year_id'];
        $data['cur_year'] = $year_id;
        $data['leaveYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));
        $data['leavetype'] = (array('' => 'Select Type') + $this->leavetypes->dropdown('leavetype'));
        $data['leaveEdit_list'] = $this->leavetypesAllocation->getEditLeaveListByYear($year_id);
        $data['publish_status'] = $this->leavetypesAllocation->get_publishStatus($year_id);
        $data['publish_status'] = $data['publish_status'][0]['isactive'];
        $data['leaveType_list'] = $this->leavetypesAllocation->getLeaveListByYear($year_id);
        $leaveListData = $this->load->view('leave/_leaveList_display', $data, TRUE);
        echo json_encode(array('leavelistdata' => $leaveListData));
        die;
    }

    public function delete_leaveType() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $this->input->post('delete_id');
            $this->leavetypesAllocation->delete($id);
        }

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Leave Data */
        $current_year = $this->leavetypesAllocation->getCurrentPublishYear();
        if (!empty($current_year)) {
            $current_year = $current_year[0]['year_id'];
            $data['cur_year'] = $current_year;
        } else {
            $current_year = date('Y');
            $data['cur_year'] = date('Y');
        }

        $data['leaveType_list'] = $this->leavetypesAllocation->getLeaveListByYear($current_year);
        $data['leaveEdit_list'] = $this->leavetypesAllocation->getEditLeaveListByYear($current_year);
        $data['publish_status'] = $this->leavetypesAllocation->get_publishStatus($current_year);
        $data['leavetype'] = (array('' => 'Select Type') + $this->leavetypes->dropdown('leavetype'));
        $data['leaveList_years'] = $this->leavetypesAllocation->get_AllYearsList();
        $data['publish_status'] = $data['publish_status'][0]['isactive'];
        $data['leaveYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'addLeaveType', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function publish_leaveList($year) {

        $new_year = date('Y-m-d'); //'2018-01-01';
        $current_date = date('Y-01-01'); //'2018-01-01'; //

        $current_date = date('Y-m-d');
        $current_date = new DateTime($current_date);
        
        $this_year = date('Y-m-d', strtotime(date('Y-01-01')));
        $this_year = new DateTime($this_year);


        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $year = $this->years->get_yearId($year);
            $dataPublish = array(
                'isactive' => 0
            );
            $this->leavetypesAllocation->update_publishStatus($year, $dataPublish);
            $this->session->set_flashdata('msg', 'Leave List published successfully');


            /* Start Leave Allocation */
            $current_year = date("Y");
            $cur_year_id = $this->years->get_current_yearId($current_year);
            $leave_list = $this->leavetypesAllocation->get_leavetypesAllocationList($cur_year_id);

            $dataAssociate = $this->employeesummary->as_array()->get_all();
            $this->employeesleave->delete_leave_by_year($current_year);
//            $this->db->delete('main_employeeleaves','alloted_year=','2017');
//            echo $this->db->last_query();die;
            foreach ($dataAssociate as $summaryData) {
                if (count($leave_list) != 0) {
                    $cnt = count($leave_list);

                    for ($i = 0; $i < $cnt; $i++) {

                        $dataAllotedLeaveType[$i]['user_id'] = $summaryData['user_id'];
                        $dataAllotedLeaveType[$i]['alloted_year'] = $leave_list[$i]['year_id'];

                        if ($leave_list[$i]['leavetype'] == 1) {
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 0;
                        } else if ($leave_list[$i]['leavetype'] == 4 && $summaryData['prefix_id'] == 1) {
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 5;
                        } else if ($leave_list[$i]['leavetype'] == 5 && $summaryData['prefix_id'] == 2) {
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 180;
                        } else if ($leave_list[$i]['leavetype'] == 4 && $summaryData['prefix_id'] == 2) {
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 0;
                        } else if ($leave_list[$i]['leavetype'] == 5 && $summaryData['prefix_id'] == 1) {
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 0;
                        } else
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = $leave_list[$i]['leavepreallocated'];


                        $dataAllotedLeaveType[$i]['leavetype'] = $leave_list[$i]['leavetype'];
                        $dataAllotedLeaveType[$i]['createdby'] = $user_id;
                        $dataAllotedLeaveType[$i]['createddate'] = date('Y-m-d H:m:s');
                    }

                    if (isset($dataAllotedLeaveType)) {

                        foreach ($dataAllotedLeaveType as $dataResult) {

                            //seeck leave allocate first resigitration & active paid leaves

                            $date = date('Y-m-d', strtotime($summaryData['date_of_joining'] . "+ 6 months"));
                            $date = new DateTime($date);

                            if ($date > $this_year && $date < $current_date) {
                                $this_year = $current_date;
                                $monthCount = $current_date->diff($this_year);
                                $months = $monthCount->m;
                            } else {
                                $this_year = $this_year;
                                $months = date('m');
                            }


                            if ($date < $this_year) {
                                if ($dataResult['leavetype'] == '2' || $dataResult['leavetype'] == '6' || $dataResult['leavetype'] == '3')
                                    $dataResult['isactive'] = '1';
                                else
                                    $dataResult['isactive'] = '0';
                                $this->employeesleave->insert($dataResult);
                               
                                
                            }else {
                                if ($dataResult['leavetype'] == '2' || $dataResult['leavetype'] == '6')
                                    $dataResult['isactive'] = '1';
                                else
                                    $dataResult['isactive'] = '0';
                                $this->employeesleave->insert($dataResult);
                            }
                        }
                    }
                    $dataAllotedLeaveType = '';
                }
            }
            /* End Leave Allocation */
        }

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Leave Data */
        $current_year = $this->leavetypesAllocation->getCurrentPublishYear();
        if (!empty($current_year)) {
            $current_year = $current_year[0]['year_id'];
            $data['cur_year'] = $current_year;
        } else {
            $current_year = date('Y');
            $data['cur_year'] = date('Y');
        }

        $data['leaveType_list'] = $this->leavetypesAllocation->getLeaveListByYear($current_year);
        $data['leaveEdit_list'] = $this->leavetypesAllocation->getEditLeaveListByYear($current_year);
        $data['publish_status'] = $this->leavetypesAllocation->get_publishStatus($current_year);
        $data['leavetype'] = (array('' => 'Select Type') + $this->leavetypes->dropdown('leavetype'));
        $data['leaveList_years'] = $this->leavetypesAllocation->get_AllYearsList();
        $data['publish_status'] = $data['publish_status'][0]['isactive'];
        $data['leaveYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'addLeaveType', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function edit_leaveType($id) {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dataLeaveType = array(
                'leaveYear' => $this->input->post('leaveYear'),
                'leavetype' => $this->input->post('leavename'),
                'leavepreallocated' => $this->input->post('leavepreallocated'),
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );
            $this->leavetypesAllocation->update($id, $dataLeaveType);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Leave Data */
        $current_year = $this->leavetypesAllocation->getCurrentPublishYear();
        if (!empty($current_year)) {
            $current_year = $current_year[0]['year_id'];
            $data['cur_year'] = $current_year;
        } else {
            $current_year = date('Y');
            $data['cur_year'] = date('Y');
        }

        $data['leaveType_list'] = $this->leavetypesAllocation->getLeaveListByYear($current_year);
        $data['leaveEdit_list'] = $this->leavetypesAllocation->getEditLeaveListByYear($current_year);
        $data['publish_status'] = $this->leavetypesAllocation->get_publishStatus($current_year);

        $data['leavetype'] = (array('' => 'Select Type') + $this->leavetypes->dropdown('leavetype'));
        $data['leaveList_years'] = $this->leavetypesAllocation->get_AllYearsList();


        $data['publish_status'] = $data['publish_status'][0]['isactive'];

        $data['leaveYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'addLeaveType', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function allocation() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dataLeaveType = array(
                'leaveYear' => $this->input->post('leaveYear'),
                'leavetype' => $this->input->post('leavename'),
                'leavepreallocated' => $this->input->post('leavepreallocated'),
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );
            $this->leavetypesAllocation->update($id, $dataLeaveType);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }



        $data['associates'] = $this->employeesummary->as_array()->get_all();
//        $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        if (isset($data['associates'])) {
            foreach ($data['associates'] as $keyIndex => $lsrData) {

                $data['associates'][$keyIndex]['personal_detail'] = $this->personaldetails->as_array()->get_by_id($lsrData['user_id']);
                $data['associates'][$keyIndex]['leave_balance'] = $this->employeesleave->as_array()->get_by_id_all($lsrData['user_id']);

                $data['associates'][$keyIndex]['maternity_leave_status'] = '0';
                $data['associates'][$keyIndex]['maternity_leave_status'] = '0';
                $data['associates'][$keyIndex]['sick_leave_status'] = '0';
                $data['associates'][$keyIndex]['cas_leave_status'] = '0';
                $data['associates'][$keyIndex]['par_leave_status'] = '0';
//                $data['associates'][$keyIndex]['leave_tempded_balance'] = $this->leavededuction->get_by_id($lsrData['id']);
//                var_dump($data['associates'][$keyIndex]['leave_balance']);
                if (isset($data['associates'][$keyIndex]['leave_balance']))
                    foreach ($data['associates'][$keyIndex]['leave_balance'] as $key => $value) {




                        $data['associates'][$keyIndex]['leave_year'] = $value['alloted_year'];
                        $data['associates'][$keyIndex]['leave_balance'][$key] = $value['alloted_leaves'];

                        if ($key == 4)
                            $data['associates'][$keyIndex]['maternity_leave_status'] = $value['isactive'];

                        if ($key == 0) {
                            $data['associates'][$keyIndex]['carry_forward'] = $value['carry_forward'];
                            $data['associates'][$keyIndex]['pri_leave_status'] = $value['isactive'];
                        }
                        if ($key == 1)
                            $data['associates'][$keyIndex]['sick_leave_status'] = $value['isactive'];

                        if ($key == 2)
                            $data['associates'][$keyIndex]['cas_leave_status'] = $value['isactive'];

                        if ($key == 3)
                            $data['associates'][$keyIndex]['par_leave_status'] = $value['isactive'];



//                $data['associates'][$keyIndex]['leave_balance'][$key]=$value['used_leaves'];                
                    }
            }
        }
        //probation status
        $current_date = date('Y-m-d');
        $current_date = new DateTime($current_date);
        $this_year = date('Y-m-d', strtotime(date('Y-01-01')));
        $this_year = new DateTime($this_year);


        foreach ($data['associates'] as $key => $assData) {

            $date = date('Y-m-d', strtotime($assData['date_of_joining'] . "+ 6 months"));
            $date = new DateTime($date);


            if ($date > $this_year && $date > $current_date) {
                $data['associates'][$key]['probation_status'] = '0';
            } else {
                $data['associates'][$key]['probation_status'] = '1';
            }
            if($data['associates'][$key]['user_id']=='1'){
                unset($data['associates'][$key]);
            }
        }
//        var_dump($data['associates']);die;

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_allocateleaves', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function leaveallocate() {
//
//        var_dump($_POST);die;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $associate_id = $this->input->post('associate_id');
            $pl = $this->input->post('pl_' . $associate_id);
            $cl = $this->input->post('cl_' . $associate_id);
            $sl = $this->input->post('sl_' . $associate_id);


            //Privillege Leave         
                $dataPL = array(
                    'alloted_leaves' => $pl,
                    'isactive' => '1',
                    'modifiedby' => $this->session->userdata('user_id'),
                    'modifieddate' => date('Y-m-d H:i:s'),
                );           
            //Privillege Leave
            
            //Casual Leave
            if ($this->input->post('cas_status_' . $associate_id) == '1') {
                $dataCL = array(
                    'alloted_leaves' => $cl,
                    'isactive' => '1',
                    'modifiedby' => $this->session->userdata('user_id'),
                    'modifieddate' => date('Y-m-d H:i:s'),
                );
            }
            if ($this->input->post('cas_status_' . $associate_id) == '0') {
                $dataCL = array(
                    'alloted_leaves' => $cl,
                    'isactive' => '0',
                    'modifiedby' => $this->session->userdata('user_id'),
                    'modifieddate' => date('Y-m-d H:i:s'),
                );
            }
            //Casual Leave
            //Sick leave
            if ($this->input->post('sick_status_' . $associate_id) == '1') {
                $dataSL = array(
                    'alloted_leaves' => $sl,
                    'isactive' => '1',
                    'modifiedby' => $this->session->userdata('user_id'),
                    'modifieddate' => date('Y-m-d H:i:s'),
                );
            }
            if ($this->input->post('sick_status_' . $associate_id) == '0') {
                $dataSL = array(
                    'alloted_leaves' => $sl,
                    'isactive' => '0',
                    'modifiedby' => $this->session->userdata('user_id'),
                    'modifieddate' => date('Y-m-d H:i:s'),
                );
            }
            //End Sick leave
            //Parental leave
            if ($this->input->post('par_' . $associate_id) || $this->input->post('par_status_' . $associate_id) == 0) {
                if ($this->input->post('par_status_' . $associate_id) == '1') {

                    $par = $this->input->post('par_' . $associate_id);
                    $dataPAR = array(
                        'alloted_leaves' => $par,
                        'isactive' => '1',
                        'modifiedby' => $this->session->userdata('user_id'),
                        'modifieddate' => date('Y-m-d H:i:s'),
                    );
                    $this->employeesleave->update_leave_parental($associate_id, 4, $dataPAR);
                }

                if ($this->input->post('par_status_' . $associate_id) == '0') {

                    $par = $this->input->post('par_' . $associate_id);

                    $dataPAR = array(
                        'alloted_leaves' => $par,
                        'isactive' => '0',
                        'modifiedby' => $this->session->userdata('user_id'),
                        'modifieddate' => date('Y-m-d H:i:s'),
                    );
                    $this->employeesleave->update_leave_parental($associate_id, 4, $dataPAR);
                }
            }
            //Parental leave
            
            //Maternity leave
            if ($this->input->post('mat_status_' . $associate_id) || $this->input->post('mat_status_' . $associate_id) == 0) {

                if ($this->input->post('mat_status_' . $associate_id) == '1') {
                    $mat = $this->input->post('maternity_' . $associate_id);
                    $dataMAT = array(
                        'alloted_leaves' => $mat,
                        'isactive' => '1',
                        'modifiedby' => $this->session->userdata('user_id'),
                        'modifieddate' => date('Y-m-d H:i:s'),
                    );
                    $this->employeesleave->update_leave_maternity($associate_id, 5, $dataMAT);
                }
                if ($this->input->post('mat_status_' . $associate_id) == '0') {

                    $mat = $this->input->post('maternity_' . $associate_id);
                    $dataMAT = array(
                        'alloted_leaves' => $mat,
                        'isactive' => '0',
                        'modifiedby' => $this->session->userdata('user_id'),
                        'modifieddate' => date('Y-m-d H:i:s'),
                    );
                    $this->employeesleave->update_leave_maternity($associate_id, 5, $dataMAT);
                }
            }
            //End Maternity leave
            $this->employeesleave->update_leave_priviledged($associate_id, 1, $dataPL);
            $this->employeesleave->update_leave_seek($associate_id, 2, $dataSL);
            $this->employeesleave->update_leave_casual($associate_id, 3, $dataCL);
//            $this->employeesleave->update_leave_parental($associate_id, 4, $dataPAR);
//            $this->employeesleave->update_leave_maternity($associate_id, 5, $dataMAT);
//            $this->employeesleave->update_leave_paid($associate_id, 6, $dataPaid);
            redirect('/leave/allocation', 'refresh');
        }
    }

}
