<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class State extends MY_Model {

    public $_table = 'main_state';
    public $primary_key = 'id';
    public $belongs_to = array('main_country'); // => array('model' => 'country_model'));
    protected $soft_delete = true;
    protected $soft_delete_key = 'isactive';

    public function __construct() {
        parent::__construct();
    }

    protected function data_process($row) {
        $row[$this->callback_parameters[0]] = $this->_process($row[$this->callback_parameters[0]]);

        return $row;
    }

//    public $validate = array(
//        array('field' => 'name',
//            'label' => 'Name',
//            'rules' => 'required|unique'),
//        array('field' => 'country_id',
//            'label' => 'Country',
//            'rules' => 'required')
//    );

    /**
     * Get name by id
     *
     * @access public
     * @param string $id
     * @return string name
     */
    function get_name_by_id($id) {
        if ($id != null) {
            $obj = $this->db->select('statename')->get_where('state', array('id' => $id))->row();
            if (isset($obj)) {
                return $obj->name;
            }
        }
        return null;
    }

}
