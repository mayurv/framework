<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of hr
 *
 * @author admin
 */
class Employees extends MY_Model{
    //put your code here
    public $_table = 'main_employees';
    public $primary_key = 'id';
  
    public $belongs_to = array('main_users');
    //public $before_create = array('timestamps_bc');
    
    //to get reporting manager by department id
    public function get_repman_by_id($deptid) {
        return $this->db->get_where('main_employees_summary', array('firstname' => $deptid))->row();
    }
    
    //get all position by jobtitle id
    public function get_position_by_id($jobtitleid) {
        return $this->db->get_where('main_position', array('positioname' => $jobtitleid))->row();
    }

}
