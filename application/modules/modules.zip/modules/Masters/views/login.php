
<style>
    .backstretch 
    {
        z-index: 0 !important;
    }

    .loginpage, .loginpage form label, .loginpage form, .loginpage .message
    {
        z-index:999;
    }

</style>
<div class="login-wrapper">
    <div id="login" class="login loginpage col-lg-offset-4 col-lg-4 col-md-offset-3 col-md-6 col-sm-offset-3 col-sm-6 col-xs-offset-2 col-xs-8">
        <h1><a href="#" title="Login Page" tabindex="-1">Ultra Admin</a></h1>
        <div id="infoMessage"><?php echo $message; ?></div>
        <?php echo form_open("auth/login"); ?>
        <div class="form-group">
            <!--<label class="form-label" for="email-1">Username</label>-->
            <?php echo lang('login_identity_label', 'identity', 'class="form-label" '); ?>
            <!--<input type="email" class="form-control" id="email-1" placeholder="Enter username">-->
            <?php echo form_input($identity); ?>
        </div>

        <div class="form-group">
            <!--<label class="form-label" for="password-1">Password:</label>-->
            <!--<input type="password" class="form-control" id="password-1" placeholder="Enter password">-->
            <?php echo lang('login_password_label', 'password' ,'class="form-label" '); ?>
            <?php echo form_input($password); ?>
        </div>

        <div class="form-group">
            <label class="form-label">
                <!--<input type="checkbox" class="iCheck" checked> <span>Remember me</span>-->
                <?php echo form_checkbox('remember', '1', FALSE, 'id="remember" class="iCheck"'); ?><span>Remember me</span>
                  <!--<span>  <?php // echo lang('login_remember_label', 'remember'); ?></span>-->

            </label>
        </div>

        <div class="form-group">
            <!--<button type="submit" class="teal ui button btn-block">Sign In</button>-->
            <?php echo form_submit('submit', lang('login_submit_btn'), 'class="teal ui button btn-block"'); ?>

        </div>


        <?php echo form_close(); ?>

        <p id="nav">
            <a class="pull-left" href="#" title="Password Lost and Found">Forgot password?</a>
            <a class="pull-right" href="ui-register.html" title="Sign Up">Sign Up</a>
        </p>


    </div>
</div>

<script src="<?php echo base_url(); ?>assets/js/jquery.backstretch.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {

        /*
         Fullscreen background
         */
        $.backstretch([
            "../assets/img/backgrounds/2.jpg"
                    , "../assets/img/backgrounds/3.jpg"
                    , "../assets/img/backgrounds/1.jpg"
        ], {duration: 3000, fade: 750});

        /*
         Form validation
         */
        $('.login-form input[type="text"], .login-form input[type="password"], .login-form textarea').on('focus', function () {
            $(this).removeClass('input-error');
        });

        $('.login-form').on('submit', function (e) {

            $(this).find('input[type="text"], input[type="password"], textarea').each(function () {
                if ($(this).val() == "") {
                    e.preventDefault();
                    $(this).addClass('input-error');
                }
                else {
                    $(this).removeClass('input-error');
                }
            });

        });


    });
</script>

