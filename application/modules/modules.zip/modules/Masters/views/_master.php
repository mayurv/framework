<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php foreach ($output->css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
    <?php endforeach; ?>
    <?php foreach ($output->js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</head>
<?php // var_dump($title);?>
<div class="col-sm-12 margin-bottom-20">
    <div class="main-bg padding-lt-rt-top">        
        <div class="user-modal-slim">
            <?php echo $output->output; ?>
        </div>
        
    </div>
</div>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->

