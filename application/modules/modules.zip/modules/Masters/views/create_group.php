<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php foreach ($output->css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
    <?php endforeach; ?>
    <?php foreach ($output->js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</head>

<div class="row-fluid">
    <div class="container">
        <?php if (isset($title)): ?>
            <div class="crud-header well">
                <?php if (isset($title_icn)): ?>
                    <div class="icn-title <?php echo $title_icn ?>"></div>
                <?php endif; ?>
                <h3><?php echo $title ?></h3></div>
        <?php endif; ?>
        <?php echo $output->output; ?>
    </div>
</div>

