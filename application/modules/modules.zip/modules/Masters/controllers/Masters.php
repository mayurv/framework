<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Masters extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('user_model', 'group_model', 'menu'));
        $this->load->model(array('personaldetails', 'employeesummary', 'users'));
        $this->load->library('grocery_CRUD');
        $this->load->language('master');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
//        $this->template->set_master_template('template.php');

        if ($this->ion_auth->is_admin()) {
            //$data['account'] = $this->user_model->get_by_id($this->session->userdata('user_id'));
            // var_dump($data['account'] );
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    // redirect if needed, otherwise display the user list
    public function index() {

        if ($this->ion_auth->is_admin()) {
            //$data['account'] = $this->user_model->get_by_id($this->session->userdata('user_id'));
            // var_dump($data['account'] );
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        //echo "inside index";die;
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        } elseif (!$this->ion_auth->is_admin()) { // remove this elseif if you want to enable this for non-admins
            // redirect them to the home page because they must be an administrator to view this
            return show_error('You must be an administrator to view this page.');
        } else {
            // set the flash data error message if there is one
            $this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

            //list the users
            $this->data['users'] = $this->ion_auth->users()->result();
            foreach ($this->data['users'] as $k => $user) {
                $this->data['users'][$k]->groups = $this->ion_auth->get_users_groups($user->id)->result();
            }
            $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

            $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
            $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

            if ($this->session->userdata('user_id'))
                $user_id = $this->session->userdata('user_id');

            $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

            $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
            $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

            //current_login_user_details
            if (isset($user_id)) {
                $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
                $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
                $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
            }

            if (isset($user_id)) {
                $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
                $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
                $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
            }

            //$this->_render_page('auth/index', $this->data);
            $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
            $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
            $this->template->write_view('content', 'index', (isset($this->data) ? $this->data : NULL));
            //$this->template->write_view('content','gallery/artwork', );
            $this->template->write_view('footer', 'snippets/footer', '', TRUE);
            $this->template->render();
        }
    }

    // create a new group
    public function create_group() {
        $this->data['title'] = $this->lang->line('title_create_group');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('datatables');
        $crud->set_table('main_groups')
                ->display_as('group_name', lang('group_name'))
                ->display_as('isactive', lang('status'));
        $crud->set_subject('User Type');
        $crud->set_table_title(lang('Group Management'));
        $crud->columns('group_name', 'description', 'isactive', 'level');

        $crud->add_fields('created', 'group_name', 'description', 'isactive', 'createdby');
        $crud->edit_fields('modified', 'group_name', 'isactive', 'description', 'id', 'modifiedby');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('created', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modified', 'hidden', date('Y-m-d H:i:s'));

        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_after_insert(array($this, '_callback_after_insert_group_entry'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $crud->set_rules('group_name', lang('group_name'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('group_name');

        $crud->callback_before_insert(array($this, '_callback_change_to_lower_case_insert'));
        $crud->callback_before_update(array($this, '_callback_change_to_lower_case_update'));


        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('title_create_group');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    function _callback_change_to_lower_case_insert($post_array, $primary_key) {
        /* to set 0 value into database */
        if ($post_array['group_name'])
            $post_array['group_name'] = strtolower($post_array['group_name']);
        return $post_array;
    }

    function _callback_change_to_lower_case_update($post_array, $primary_key) {
        /* to set 0 value into database */
        if ($post_array['group_name'])
            $post_array['group_name'] = strtolower($post_array['group_name']);
        return $post_array;
    }

    function _callback_after_insert_group_entry($post_array, $primary_key) {
        /* to set 0 value into database */
        if ($post_array['parent'] == '')
            $post_array['parent'] = '0';
        return $post_array;
    }

    function showStatus($value) {
        if ($value == 0)
            $st = "Inactive";
        else
            $st = "Active";
        return $st;
    }

    public function create_role() {
        $this->data['title'] = $this->lang->line('create_role_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_roles')
                ->display_as('rolename', lang('rolename'))
                ->display_as('roletype', lang('roletype'))
                ->display_as('roledescription', lang('roledescription'))
                ->display_as('createddate', lang('createddate'))
                ->display_as('modifieddate', lang('modifieddate'))
                ->field_type('isactive', array('1' => 'Active', '0' => 'Inactive'));
        $crud->set_subject('Role Type');
        $crud->columns('rolename', 'roletype', 'roledescription', 'createddate', 'modifieddate', 'isactive');

        $crud->set_relation('group_id', 'groups', 'name');


        $crud->add_fields('group_id', 'rolename', 'roletype', 'roledescription', 'createddate', 'createdby', 'isactive');
        $crud->edit_fields('group_id', 'rolename', 'roletype', 'roledescription', 'modifieddate', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        //$crud->change_field_type('levelid',  'hidden');
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $crud->set_rules('group_id', 'Group ID', 'trim|required');   //p
        $crud->set_rules('rolename', lang('rolename'), 'trim|required|min_length[2]|max_length[30]');    //p
        $crud->unique_fields('rolename');
        $crud->set_rules('roletype', lang('roletype'), 'trim|required|min_length[2]|max_length[30]');    //p
        $crud->unique_fields('roletype');


        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('create_role_title');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    function menu() {

        $this->data['title'] = $this->lang->line('create_menu_title');
//        $this->data['title'] = $this->lang->line('create_menu_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();
        $crud->set_theme('flexigrid');

        $crud->set_table('main_menu')
                ->set_subject('Users')
                ->columns('menuName', 'group_id', 'isactive')
                ->display_as('menuName', lang('menuName'))
                ->display_as('group_id', lang('group_id'))
                ->display_as('isactive', lang('isactive'));

        $crud->set_subject('Menu Type');

        $crud->unique_fields('menuName');

//        $crud->set_read_fields('menuName','isactive');
//        $crud->callback_read_field('isactive',array($this, 'showStatus'));

        $crud->set_relation('group_id', 'groups', 'name');
        $crud->set_relation('parent', 'main_menu', 'menuName');

        $crud->add_fields('group_id', 'menuName', 'url', 'iconPath', 'parent', 'createddate', 'createdby', 'isactive');
        $crud->edit_fields('group_id', 'menuName', 'url', 'iconPath', 'parent', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $crud->set_rules('url', lang('url'), 'trim|max_length[55]');
        $crud->set_rules('iconPath', lang('iconPath'), 'min_length[2]|max_length[25]');




        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        $crud->callback_before_insert(array($this, '_callback_before_insert_parent_check'));
        $crud->callback_before_update(array($this, '_callback_before_update_parent_check'));

        //echo '<pre>',print_r($_POST);die;
//         $output = $crud->render();
//        $output->title = lang('title_menu');
//        //var_dump($output); die;
//        //$this->_example_output($output);
//        $this->template->write_view('header', 'snippets/header', NULL);
//        $this->template->write_view('sidebar', 'snippets/sidebar', NULL);
//        $this->template->write_view('content', '_master', (isset($output) ? $output : NULL));
//        $this->template->render();

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */
        
        if (isset($user_id)) {
                $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
                $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
                $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
            }

        $data['output'] = $crud->render();
        $data['title'] = lang('create_menu_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    function _callback_before_insert_parent_check($post_array) {

        if ($post_array['parent'] == '')
            $post_array['parent'] = '0';
        return $post_array;
    }

    function _callback_before_update_parent_check($post_array) {

        if ($post_array['parent'] == '')
            $post_array['parent'] = '0';
        return $post_array;
    }

    function addlevelid($value, $row) {
        // echo '<pre>',print_r($row);exit;
        $level_id = $this->group_model->get_level($row->id);
        //var_dump($myText);exit;
        //$id=$level_id->level;
        //return $id;
        $myText = (array) $level_id;
//           var_dump($myText);exit;
        return $myText[0];
    }

    function fieldStatusGroup($value, $primary_key) {
        $this->db->select('id');
        $this->db->from('work');
        $this->db->where('medium_id', $primary_key);
        $query = $this->db->get();
        $res = $query->result_array();
        $st = '';
        if (empty($res)) {
            $st .= '<input type="hidden" name="status" id="field-status" value="' . $value . '" /><input type="checkbox" id="field-statust" name="statust" ' . ($value == 0 ? ' checked="checked" ' : '') . ' value="' . $value . '" />';
            $st .= '<script>$(document).ready(function(){$("#field-statust").change(function(){$(\'input[name="status"]\').val(($(this).is(":checked") ? "0" : "1"));});});</script>';
        } else {
            $st .= '<input type="hidden" name="status" id="field-status" value="' . $value . '" /><input type="checkbox" id="field-statust" name="statust" ' . ($value == 0 ? ' checked="checked" ' : '') . ' value="' . $value . '" disabled="disabled"/>';
        }
        return $st;
    }

    // edit a group
    public function edit_group($id) {
        // bail if no group id given
        if (!$id || empty($id)) {
            redirect('auth', 'refresh');
        }

        $this->data['title'] = $this->lang->line('edit_group_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $group = $this->ion_auth->group($id)->row();

        // validate form input
        $this->form_validation->set_rules('name', $this->lang->line('edit_group_validation_name_label'), 'required|alpha_dash');

        if (isset($_POST) && !empty($_POST)) {
            if ($this->form_validation->run() === TRUE) {
                $group_update = $this->ion_auth->update_group($id, $_POST['name'], $_POST['group_description']);

                if ($group_update) {
                    $this->session->set_flashdata('message', $this->lang->line('edit_group_saved'));
                } else {
                    $this->session->set_flashdata('message', $this->ion_auth->errors());
                }
                redirect("auth", 'refresh');
            }
        }

        // set the flash data error message if there is one
        $this->data['message'] = (validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

        // pass the user to the view
        $this->data['group'] = $group;

        $readonly = $this->config->item('admin_group', 'ion_auth') === $group->name ? 'readonly' : '';

        $this->data['name'] = array(
            'name' => 'name',
            'id' => 'name',
            'type' => 'text',
            'value' => $this->form_validation->set_value('name', $group->name),
            $readonly => $readonly,
        );
        $this->data['group_description'] = array(
            'name' => 'group_description',
            'id' => 'group_description',
            'type' => 'text',
            'value' => $this->form_validation->set_value('group_description', $group->description),
        );

        $this->_render_page('auth/edit_group', $this->data);
    }

    public function _get_csrf_nonce() {
        $this->load->helper('string');
        $key = random_string('alnum', 8);
        $value = random_string('alnum', 20);
        $this->session->set_flashdata('csrfkey', $key);
        $this->session->set_flashdata('csrfvalue', $value);

        return array($key => $value);
    }

    public function _valid_csrf_nonce() {
        if ($this->input->post($this->session->flashdata('csrfkey')) !== FALSE &&
                $this->input->post($this->session->flashdata('csrfkey')) == $this->session->flashdata('csrfvalue')) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    public function _render_page($view, $data = null, $returnhtml = false) {//I think this makes more sense
        $this->viewdata = (empty($data)) ? $this->data : $data;

        $view_html = $this->load->view($view, $this->viewdata, $returnhtml);

        if ($returnhtml)
            return $view_html; //This will return html on 3rd argument being true
    }

    /* @Prajwal N */
    /* Moved to Hr */

    public function empl_status() {
        $this->data['title'] = $this->lang->line('create_empl_status_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_employment_status')
                ->display_as('isactive', lang('status'))
                ->display_as('emp_status', lang('emp_status'));
        $crud->set_subject('Employee Status');
        $crud->set_table_title(lang('employment Status'));
        //To display on view(form)
        $crud->columns('emp_status', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'emp_status', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'emp_status', 'isactive', 'description', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('emp_status', lang('Emp Status'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('emp_status');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');




        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('title_employment');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function department() {


        $this->data['title'] = $this->lang->line('create_deptartment_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_departments')
                ->display_as('isactive', lang('status'))
                ->display_as('deptname', lang('deptname'));
        $crud->set_subject('Department');
        $crud->set_table_title(lang('department'));
        //To display on view(form)
        $crud->columns('deptname', 'description', 'start_date', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'deptname', 'description', 'start_date', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'deptname', 'isactive', 'description', 'start_date', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('deptname', lang('deptname'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('deptname');

        $crud->set_rules('description', lang('description'), 'min_length[3]|max_length[225]');
        $crud->set_rules('start_date', 'Start Date', 'trim|required');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('department');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    /* Moved to Hr */

    public function create_jobtitle() {
        $this->data['title'] = $this->lang->line('create_jobtitle_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_jobtitle')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Job Title');
        $crud->set_table_title(lang('jobtitle'));

        $crud->columns('jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'isactive')
                ->display_as('jobtitlecode', lang('jobtitlecode'))
                ->display_as('jobtitlename', lang('jobtitlename'))
                ->display_as('jobdescription', lang('jobdescription'));

        $crud->add_fields('createddate', 'jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'comments', 'isactive', 'createdby');
        $crud->edit_fields('modifieddate', 'jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'comments', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('jobtitlecode', lang('jobtitlecode'), 'trim|required|min_length[2]|max_length[10]');
        $crud->unique_fields('jobtitlecode');

        $crud->set_rules('jobtitlename', lang('jobtitlename'), 'required|min_length[2]|max_length[30]');
        $crud->unique_fields('jobtitlename');

        $crud->set_rules('jobdescription', lang('jobdescription'), 'required|min_length[3]|max_length[500]');

        $crud->set_rules('minexprequired', 'minexprequired', 'integer', 'trim|integer|required|min_length[1]|max_length[5]');
        // $this->form_validation->set_rules('number', 'Number', 'callback_less_than_or_equal[9]');
        $crud->set_rules('comments', lang('comments'), 'required|min_length[3]|max_length[500]');
        // $crud->unique_fields('Comments');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */
        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['output'] = $crud->render();
        $data['title'] = lang('jobtitle');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function create_prefix() {
        $this->data['title'] = $this->lang->line('create_prefix_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_prefix')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Prefix');
        $crud->set_table_title(lang('prefix'));
        //To display on view(form)
        $crud->columns('prefix', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'prefix', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'prefix', 'description', 'isactive', 'id', 'modifiedby');


        //Set Rules
        $crud->set_rules('prefix', lang('prefix'), 'trim|required|min_length[2]|max_length[10]');
        $crud->unique_fields('prefix');

        $crud->set_rules('description', 'description', 'trim|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['output'] = $crud->render();
        $data['title'] = lang('prefix');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    /* Moved to Hr */

    public function create_position() {
        $this->data['title'] = $this->lang->line('create_position_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_position')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Position');
        $crud->set_table_title(lang('Position'));
        //To display on view(form)
        $crud->columns('positioname', 'jobtitle_id', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'positioname', 'jobtitle_id', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'positioname', 'jobtitle_id', 'description', 'isactive', 'id', 'modifiedby');


        $crud->set_relation('jobtitle_id', 'main_jobtitle', 'jobtitlename');

        //Set Rules
        $crud->set_rules('positioname', lang('positioname'), 'trim|required|min_length[2]|max_length[25]', 'alpha');
        $crud->unique_fields('positioname');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');

//          $crud->set_rules('jobtitle_id', lang('jobtitle_id'), 'trim|required|min_length[3]|max_length[225]');



        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('position');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    /* Moved to Hr */

    public function create_competency() {
        $this->data['title'] = $this->lang->line('create_competency_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_competencylevel')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Competency Level');
        $crud->set_table_title(lang('Competency Level'));
        //To display on view(form)
        $crud->columns('competencylevel', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'competencylevel', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'competencylevel', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('competencylevel', lang('competencylevel'), 'trim|required|min_length[2]|max_length[25]', 'alpha');
        $crud->unique_fields('competencylevel');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('competency');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    /* Moved to Hr */

    public function create_education() {
        $this->data['title'] = $this->lang->line('create_education_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_education_level')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Education Level');
        $crud->set_table_title(lang('Education Level'));
        //To display on view(form)
        $crud->columns('educational_level', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'educational_level', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'educational_level', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('educational_level', lang('educational_level'), 'trim|required|min_length[2]|max_length[10]', 'alpha');
        $crud->unique_fields('educational_level');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('education');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function nationality() {
        $this->data['title'] = $this->lang->line('create_nationality_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_nationality')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Nationality');
        $crud->set_table_title(lang('nationality'));
        //To display on view(form)
        $crud->columns('nationalitycode', 'description', 'isactive')
                ->display_as('nationalitycode', lang('nationalitycode'));

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'nationalitycode', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'nationalitycode', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('nationalitycode', lang('nationalitycode'), 'trim|required|min_length[2]|max_length[10]', 'alpha');
        $crud->unique_fields('nationalitycode');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('nationalitycode');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function create_ethniccode() {
        $this->data['title'] = $this->lang->line('create_ethniccode_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_ethniccode')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Ethnic Code');
        $crud->set_table_title(lang('ethniccode'));
        //To display on view(form)
        $crud->columns('ethniccode', 'ethnicname', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'ethniccode', 'ethnicname', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'ethniccode', 'ethnicname', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('ethniccode', lang('ethniccode'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('ethniccode');

        $crud->set_rules('ethnicname', lang('ethnicname'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('ethnicname');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('ethniccode');
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function create_language() {
        $this->data['title'] = $this->lang->line('create_language_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_language')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Language');
        $crud->set_table_title(lang('language'));
        //To display on view(form)
        $crud->columns('languagename', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'languagename', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'languagename', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('languagename', lang('languagename'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('languagename');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('language');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function create_weekdays() {
        $this->data['title'] = $this->lang->line('create_weekdays_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_weekdays')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Weekdays');
        $crud->set_table_title(lang('weekdays'));
        //To display on view(form)
        $crud->columns('day_name', 'dayshortcode', 'daylongcode', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'day_name', 'dayshortcode', 'daylongcode', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'day_name', 'dayshortcode', 'daylongcode', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('day_name', lang('day_name'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('day_name');

        $crud->set_rules('dayshortcode', lang('dayshortcode'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('dayshortcode');

        $crud->set_rules('daylongcode', lang('daylongcode'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('daylongcode');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('weekdays');
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    /* Moved to Hr */

    public function create_holidaygroups() {
        $this->data['title'] = $this->lang->line('create_holidaygroups_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_holidaygroups')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Holiday Groups');
        $crud->set_table_title(lang('holidaygroups'));
        //To display on view(form)
        $crud->columns('groupname', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'groupname', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'groupname', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('groupname', lang('groupname'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('groupname');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('holidaygroups');
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function create_holidaydates() {
        $this->data['title'] = $this->lang->line('create_holidaydates_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_holidaydates')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Holiday Dates');
        $crud->set_table_title(lang('holidaydates'));

        $crud->columns('holidayname', 'groupid', 'holidaydate', 'holidayyear', 'description', 'isactive');

        $crud->set_relation('groupid', 'main_holidaygroups', 'groupname');

        $crud->add_fields('createddate', 'holidayname', 'groupid', 'holidaydate', 'holidayyear', 'description', 'isactive', 'createdby');
        $crud->edit_fields('modifieddate', 'holidayname', 'groupid', 'holidaydate', 'holidayyear', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        //Set Rules
        $crud->set_rules('holidayname', lang('holidayname'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('holidayname');

        $crud->set_rules('holidaydate', lang('holidaydate'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('holidaydate');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        $data['output'] = $crud->render();
        $data['title'] = lang('holidaydates');
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function privileges() {
        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_privileges');

        $crud->set_subject('Privileges');
        $crud->columns('role', 'group_id', 'object', 'addpermission', 'editpermission', 'deletepermission', 'viewpermission', 'isactive')
                ->display_as('role', lang('role'))
                ->display_as('group_id', lang('group_id'))
                ->display_as('object', lang('object'))
                ->display_as('addpermission', lang('addpermission'))
                ->display_as('editpermission', lang('editpermission'))
                ->display_as('deletepermission', lang('deletepermission'))
                ->display_as('viewpermission', lang('viewpermission'))
                ->display_as('isactive', lang('status'));

        //$crud->set_rules('skillname', lang('skill'), 'required|min_length[1]|max_length[25]');
        //crud->set_rules('yearsofexp', lang('yearsofexp'), 'required');

        $crud->set_relation('role', 'main_roles', 'rolename');
        $crud->set_relation('group_id', 'groups', 'name');
        $crud->set_relation('object', 'main_menu', 'menuname');


//        $crud->unique_fields(lang('skill'), 'skillname');

        $crud->add_fields('group_id', 'role', 'object', 'addpermission', 'editpermission', 'deletepermission', 'viewpermission', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');

        $crud->edit_fields('group_id', 'role', 'object', 'addpermission', 'editpermission', 'deletepermission', 'viewpermission', 'isactive', 'id', 'modifiedby', 'modifieddate');

//        $state_code = $crud->getState();
//        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
//            
//        }
//        var_dump($this->session->userdata('user_id'));die;

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));



//        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['output'] = $crud->render();
        $data['title'] = lang('privileges_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    //Prajwal: 18-10-2016

    public function gender() {
        $this->data['title'] = $this->lang->line('create_gender_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_gender')
                ->display_as('isactive', lang('status'));

        $crud->set_subject('Gender');
        $crud->set_table_title(lang('gender'));
        //To display on view(form)
        $crud->columns('gendercode', 'gendername', 'description', 'isactive')
                ->display_as('gendercode', lang('gendercode'))
                ->display_as('gendername', lang('gendername'));

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'gendercode', 'gendername', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'gendercode', 'gendername', 'description', 'isactive', 'id', 'modifiedby');

        // Set Rules
        $crud->set_rules('gendercode', lang('gendercode'), 'trim|required|min_length[2]|max_length[5]');
        $crud->unique_fields('gendercode');

        $crud->set_rules('gendername', lang('gendername'), 'trim|required|min_length[3]|max_length[55]');
        $crud->unique_fields('gendername');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }



        $data['output'] = $crud->render();
        $data['title'] = lang('gender');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function martialstatus() {
        $this->data['title'] = $this->lang->line('create_martialstatus_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_maritalstatus')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Marital Status');
        $crud->set_table_title(lang('martialstatus'));
        //To display on view(form)
        $crud->columns('maritalcode', 'maritalstatusname', 'description', 'isactive')
                ->display_as('maritalcode', lang('maritalcode'))
                ->display_as('maritalstatusname', lang('maritalstatusname'));
        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'maritalcode', 'maritalstatusname', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'maritalcode', 'maritalstatusname', 'description', 'isactive', 'id', 'modifiedby');

        // Set Rules
        $crud->set_rules('maritalcode', lang('maritalcode'), 'trim|required|min_length[2]|max_length[5]');
        $crud->unique_fields('maritalcode');

        $crud->set_rules('maritalstatusname', lang('maritalstatusname'), 'trim|required|min_length[3]|max_length[55]');
        $crud->unique_fields('maritalstatusname');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */


        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('martialstatus');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function country() {
        $this->data['title'] = $this->lang->line('create_country_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_country')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Country');
        $crud->set_table_title(lang('country'));
        //To display on view(form)
        $crud->columns('countryname', 'isactive')
                ->display_as('countryname', lang('countryname'));

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'countryname', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'countryname', 'isactive', 'id', 'modifiedby');

        // Set Rules
        $crud->set_rules('countryname', lang('countryname'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('countryname');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */


        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['output'] = $crud->render();
        $data['title'] = lang('country');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function state() {
        $this->data['title'] = $this->lang->line('create_state_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_state')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('State');
        $crud->set_table_title(lang('state'));
        //To display on view(form)
        $crud->columns('statename', 'isactive')
                ->display_as('statename', lang('statename'))
                ->display_as('countryname', lang('countryname'));

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'country_id', 'statename', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'country_id', 'statename', 'isactive', 'id', 'modifiedby');

        $crud->set_relation('country_id', 'main_country', 'countryname');

        // Set Rules
        $crud->set_rules('statename', lang('statename'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('statename');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['output'] = $crud->render();
        $data['title'] = lang('state');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    public function city() {
        $this->data['title'] = $this->lang->line('create_city_title');

        if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_city')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('City');
        $crud->set_table_title(lang('city'));
        //To display on view(form)
        $crud->columns('cityname', 'isactive')
                ->display_as('cityname', lang('cityname'))
                ->display_as('statename', lang('statename'))
                ->display_as('countryname', lang('countryname'));

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'country_id', 'state_id', 'cityname', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'country_id', 'state_id', 'cityname', 'isactive', 'id', 'modifiedby');

        $crud->set_relation('country_id', 'main_country', 'countryname');
        $crud->set_relation('state_id', 'main_state', 'statename');

        // Set Rules
        $crud->set_rules('cityname', lang('cityname'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('cityname');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        //current_login_user_details
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['output'] = $crud->render();
        $data['title'] = lang('city');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_master', (isset($data) ? $data : NULL));
        $this->template->render();
    }

    //to get all menu list
    public function getMenuList() {
        //variables
        $k = 1;
        $menuobj = new ArrayObject();
        $i = 1;

        /* start of get menu list */
        $this->data['users'] = $this->ion_auth->users()->result();

        $user_id = $this->ion_auth->get_user_id();
        foreach ($this->data['users'] as $user) {
            if ($user->id == $user_id)
                $user_role_id = $user->emprole;
        }

        $this->data['group_id'] = $this->menu->get_group_id_by_role($user_role_id);

        $this->data['menu'] = $this->menu->get_allmenu_by_group_id($this->data['group_id'][0]->group_id);
        $data['submenu'] = $this->menu->get_submenu_by_group_id($this->data['group_id'][0]->group_id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($this->data['group_id'][0]->group_id);

        for ($i = 0; $i < count($data['mainmenu']); $i++) {
            foreach ($data['submenu'] as $sub) {

                if ($data['mainmenu'][$i]->id == $sub->parent) {
                    if ($k == 1) {
                        $menuobj->append(array('menu', $data['mainmenu'][$i]->menuName, $data['mainmenu'][$i]->iconPath));
                        $k++;
                    }
                    $menuobj->append(array('submenu', $sub->menuName, $sub->url));
                }
            }
            $k = 1; //restrict repetative menu
        }
        $menulist = (array) $menuobj;
        return (array) $menuobj;
        /* end of get menu list */
    }

}
