<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Notifications extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language')); //employeesholiday
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails', 'leavetypes'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language'));

        /* dashboard */
        $this->load->model(array('blogdetail', 'years', 'holidaydates', 'timelinecomment', 'employeeawards', 'leavetypesAllocation'));
        /* request actions */

        $this->load->model(array('frontend/leaverequest', 'frontend/notification', 'frontend/leavededuction'));
        $this->load->model(array('frontend/eventsmain', 'frontend/eventscomments', 'frontend/eventsgallery'));

        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'workstation', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {
        
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);
       
        $data['notification_details'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'],$user_id=null,$all='all');
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'profile/_view_all_notification', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }
    public function leaves() {
        
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);
       
        $data['notification_details'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'],$user_id=null,$all='all');
        
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'profile/_view_all_leave_notification', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    /* Start save post blog data */

    public function post_blog() {
//        var_dump($_POST);
//        var_dump($_FILES);
//        die;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        if (isset($_POST)) {
//            var_dump($_POST);
//            var_dump($_FILES);die;

            $postBlogDetail = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'description' => $this->input->post('blog_detail'),
                'title' => substr($this->input->post('blog_detail'), 0, 25),
                'publish_group_id' => $this->input->post('publish_group_id'),
                'image_url' => '',
                'video_url' => '',
                'blog_post_type' => '1',
                'blog_date' => date("F d, Y"),
                'blog_time' => date('Y-m-d H:i:s'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            $associate_id = $this->input->post('associate_id');
            $slug = $this->users->get_slug_by_id($associate_id);
            /* Upload Image */
            if (isset($_FILES['upload_post_file_id']['name']) && $_FILES['upload_post_file_id']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['upload_post_file_id']['name'];
                $targetFile = $targetDir . $fileName;

                $fileExt = pathinfo($_FILES['upload_post_file_id']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $fileParts = pathinfo($_FILES['upload_post_file_id']['name']);
                $fileName = $_FILES['upload_post_file_id']['name'];
                $tempFile = $_FILES['upload_post_file_id']['tmp_name'];

                $uploded_file_path = $this->handleUploadPost($slug, $fileParts, $tempFile, $fileName);
                if ($uploded_file_path != '')
                    $postBlogDetail['image_url'] = $slug . '/post/' . $uploded_file_path;
            }


            $data['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $data['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);

//            var_dump($data['current_associate_slug']);die;
            $insert_id = $this->blogdetail->insert($postBlogDetail);

            /* notification entry */

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'blog_post_type' => '1',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Posted on timeline',
                'notification_icon' => 'fa-rss text-yellow',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard',
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */

            $data = $this->get_all_view_data($user_id);
            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData));
            die;
        }
    }

    public function get_blogs() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $data = $this->get_all_view_data($user_id);
        if (isset($_POST)) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['current_status']) {
//                var_dump($_POST['current_status']);die;
                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status']);
            } else if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_current_start'])) {
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], NULL, $_POST['post_current_start']);
            } else
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
        }
        if ($_SERVER['REQUEST_METHOD'] == 'GET') {

            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
        }

        $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
        echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        die;
    }

    /* End save post blog data */

    /* Start save post blog data */



    /* End save post blog data */

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['user_birthday_summary'] = $this->employeesummary->associate_birthday();
        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole']);
        
        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);

        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);

        //Associate Holiday & Leaves
        $data['leave_status'] = (array('' => 'Select Country', '1' => 'Pending For Approval', '2' => 'Approved', '3' => 'Rejected', '4' => 'Cancel')); //'Approved','Rejected','Cancel';

        $data['leave_type_list'] = $this->leavetypes->get_all();
        $data['leave_type_all'] = $this->leavetypes->get_all_types();
        $data['leave_type'] = $this->employeesleave->get_by_id($associate_id);
//        $data['leave_type'] = $this->employeesleave->get_by_id($associate_id);
//        var_dump($data['leave_type_list']);die;
//        var_dump($data['leave_type']);die;
        $options = array();
        if (isset($data['leave_type'])) {
            foreach ($data['leave_type'] as $value) {
//            var_dump($value);die;
                if ($value['used_leaves'] >= $value['alloted_leaves']) {
                    
                } else {
                    foreach ($data['leave_type_list'] as $val) {
                        if ($val->id == $value['leavetype'] && $val->id != 5) {
                            $options[$val->id] = $val->leavetype . '(' . ($value['alloted_leaves'] - $value['used_leaves']) . '/' . $value['alloted_leaves'] . ')';
                        }
                    }
                }
            }
            $data['leave_type'] = $options;
        }
        /* Dashboard */
        $data['publish_group'] = (array('0' => 'All Department')) + (array($data['user_summary']['department_id'] => $data['user_summary']['department_name'])) + (array('99' => 'Only Me'));
        $data['timeline_comment'] = $this->timelinecomment->get_by_id($associate_id);
        $data['hall_of_fame'] = $this->employeeawards->hall_of_fame();
        $data['leaves'] = $this->leavetypesAllocation->get_leaveList($associate_id);
        $data['balnce_leaves'] = $this->leavetypesAllocation->get_balanceLeaves($associate_id);
        $data['leave_history'] = $this->leaverequest->getOwnLeaveSummary($associate_id);

        return $data;
    }

    /* Autogenerate Employee ID  */

    public function _get_employeeid() {

        $this->load->model(array('employees'));
        $curId = $this->employees->get_employee_id();

        $new_var = (int) substr($curId->employeeId, 4, strpos($curId->employeeId, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

    public function delete_post_blog() {

        if (isset($_POST['delete_post_id'])) {
            $post_id = $_POST['delete_post_id'];
            $this->blogdetail->delete($post_id);

            $this->timelinecomment->delete_by_blog_id($post_id);
        }
    }

    public function add_comment() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {

            $dataPostComment = array(
                'user_id' => $_POST['associate_id'],
                'blog_id' => $_POST['blog_id'],
                'comment' => $_POST['comment'],
                'comment_date' => date('Y-m-d H:i:s'),
                'comment_time' => date('Y-m-d H:i:s'),
                'createdby' => $_POST['associate_id'],
                'createddate' => date('Y-m-d H:i:s'),
            );
//            echo '<pre>',  print_r($dataPostComment);die;
            $this->timelinecomment->insert($dataPostComment);
            $data = $this->get_all_view_data($user_id);


            /* notification entry */

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
//                'blog_post_type' => '1',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Commented on post',
                'notification_icon' => 'fa-comments text-yellow',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard/',
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */


            if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['current_status']) {
//                var_dump($_POST['current_status']);die;
                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status']);
            } else
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        }
    }

    /* Leave Module */

    public function apply_leave($associate_id) {
//        var_dump($_POST);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $postBlogDetail['image_url'] = NULL;
        $data = $this->get_all_view_data($user_id);

        $fromDate = '';
        $toDate = '';

        if (isset($_POST)) {

            /* Upload seek leave certificate */
            /* Upload Image */
            if (isset($_FILES['sl_attachment']['name']) && $_FILES['sl_attachment']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['sl_attachment']['name'];
                $targetFile = $targetDir . $fileName;

                $fileExt = pathinfo($_FILES['sl_attachment']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $fileParts = pathinfo($_FILES['sl_attachment']['name']);
                $fileName = $_FILES['sl_attachment']['name'];
                $tempFile = $_FILES['sl_attachment']['tmp_name'];

                $uploded_file_path = $this->handleUploadSeekLeave($data['associate_slug'], $fileParts, $tempFile, $fileName);
                if ($uploded_file_path != '')
                    $postBlogDetail['image_url'] = $data['associate_slug'] . '/leave/' . $uploded_file_path;
            }

            /* holiday list */
            $holidaydates = '';
            $current_year = date("Y");
            $cur_year_id = $this->years->get_current_yearId($current_year);
            $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);
            foreach ($data['holiday_list'] as $holidaydate) {
//                array_push($holidaydates, $holidaydate['holidaydate']);
                $holidaydates .= ',' . $holidaydate['holidaydate'];
            }


            $ltype_id = $this->input->post('id_leave_type');
            $leave_type = $this->leavetypes->get_by_id($ltype_id);
            /* blog entry */
            /* insert data in blog */
            $postBlogDetail = array(
                'user_id' => $associate_id,
                'department_id' => $data['user_summary']['department_id'],
                'description' => $this->input->post('leave_reason'),
                'title' => $leave_type,
                'publish_group_id' => $this->input->post('department_id'),
                'image_url' => $postBlogDetail['image_url'] ? $postBlogDetail['image_url'] : '',
                'video_url' => '',
                'blog_date' => date("F d, Y"),
                'blog_time' => date('Y-m-d H:i:s'),
                'blog_post_type' => '2',
                'createdby' => $associate_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            $insert_id = $this->blogdetail->insert($postBlogDetail);


            //check for full day | half day

            $leave_day = $this->input->post('leave_day');
            //var_dump($leave_day);die;

            $dataLeaveRequest = array(
                'user_id' => $associate_id,
                'blog_id' => $insert_id,
                'department_id' => $data['user_summary']['department_id'],
                'leave_day' => $this->input->post('leave_day'),
                'leave_status' => '1',
                'leave_type_id' => $this->input->post('id_leave_type'),
                'reason' => $this->input->post('leave_reason'),
                'rep_mang_one_id' => $data['user_summary']['reporting_manager'],
                'rep_mang_two_id' => $data['user_summary']['reporting_manager_twoup'],
                'createdby' => $associate_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            //if halfday
            if ($leave_day == '1') {

                $date = $this->input->post('single_datepicker');

                $fromDate = date('Y-m-d', strtotime($date));

                $toDate = date('Y-m-d', strtotime($date));
                $dataLeaveRequest['leave_for'] = $this->input->post('leave_for');
                $dataLeaveRequest['from_date'] = $fromDate;
                $dataLeaveRequest['to_date'] = $toDate;
//                $diff = date_diff($fromDate, $toDate);                
                $dataLeaveRequest['no_of_days'] = '0.5';
                $holidaydates = array($holidaydates);
                if (in_array($fromDate, $holidaydates)) {
                    return false;
                }
            }
            //fullday
            if ($leave_day == '2') {
                $fromDate = date('Y-m-d', strtotime($this->input->post('single_datepicker_from')));
                $toDate = date('Y-m-d', strtotime($this->input->post('single_datepicker_to')));
                $dataLeaveRequest['from_date'] = $fromDate;
                $dataLeaveRequest['to_date'] = $toDate;
                $diff = date_diff(date_create($this->input->post('single_datepicker_from')), date_create($this->input->post('single_datepicker_to')));

                $datetime1 = new DateTime($fromDate);
                $datetime2 = new DateTime($toDate);
                $woweekends = 0;
                $dataLeaveRequest['no_of_days'] = $diff->d + 1;

                $startDate = new DateTime($fromDate);
                $endDate = new DateTime($toDate);
                $holidaydates = array($holidaydates);
                $interval = new DateInterval('P1D'); //for one day interval
                $daterange = new DatePeriod($startDate, $interval, $endDate);
//                var_dump($daterange);die;


                foreach ($daterange as $date) {
                    if ($date->format("N") == 6 || $date->format("N") == 7 && !in_array($date->format("Y-m-d"), $holidaydates))
                        $dataLeaveRequest['no_of_days'] --;
                }
            }
            $this->leaverequest->insert($dataLeaveRequest);
        }
        /* notification entry */

        $notificationDetails = array(
            'user_id' => $user_id,
            'department_id' => $data['user_summary']['department_id'],
            //'blog_post_type' => $this->input->post('department_id'),
            'userfullname' => $data['user_summary']['userfullname'],
            'profileimg' => $data['user_summary']['profileimg'],
            'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Applied leave',
            'notification_icon' => 'fa-calendar-check-o text-light-blue',
            'notification_date' => date('Y-m-d H:i:s'),
            'url_path' => 'dashboard/leave_summary',
        );
        $this->notification->insert($notificationDetails);
        /* notification entry */


        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

        $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
        echo json_encode(array('content' => $timelineData));
        die;
    }

    function handleUploadSeekLeave($user_slug, $fileParts, $tempFile, $fileName) {

        $fileTypes = array('jpeg', 'png', 'jpg'); // File extensions

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $this->session->set_flashdata('msg', 'File type not supported.');
            return false;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/leave'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/leave';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $fileName = $user_slug . '-leave-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        //var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadPost($user_slug, $fileParts, $tempFile, $fileName) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $this->session->set_flashdata('msg', 'File type not supported.');
            return false;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/post'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/post';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $fileName = $user_slug . '-post-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        //var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    //Approve Leave
    public function approveLeave() {
//        var_dump($_POST);die;
        if ($_POST) {
            $leave_id = $this->input->post('leave_id');

            $dataLeaveRequest = array(
                'approver_comments' => 'I am pleased to inform you that your leave request is approved. Kindly check there is no pending task from your side',
                'leave_status' => '2',
            );
            $this->leaverequest->update($leave_id, $dataLeaveRequest);

            /* Update associate leave counts */
            $leave_type_id = $this->input->post('leave_type_id');
            $associate_id = $this->input->post('user_id');
            $used_leaves = $this->input->post('no_of_days');
            $approveData = array(
                'used_leaves' => (float) ($used_leaves),
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s'),
            );


            $leaveDeductionData = $this->employeesleave->update_leaves_count($leave_type_id, $associate_id, $approveData);
            $leaveDeductionDataArray = array(
                'user_id' => $associate_id,
                'leave_id' => $leave_type_id,
                'priviledge_deduction' => $leaveDeductionData['pl_cnt'],
                'casual_deduction' => $leaveDeductionData['cl_cnt'],
                'paid_count' => $leaveDeductionData['paid_cnt'],
                'sl_cnt' => $leaveDeductionData['sl_cnt'],
            );
            $this->leavededuction->insert($leaveDeductionDataArray);
            /* notification entry */

//            $notificationDetails = array(
//                'user_id' => $user_id,
//                'department_id' => $data['user_summary']['department_id'],
//                'userfullname' => $data['user_summary']['userfullname'],
//                'profileimg' => $data['user_summary']['profileimg'],                
//                'notification' => '<span class="text-bold">'.$data['user_summary']['userfullname'].'</span>,Approved leave',
//                'notification_icon' => 'fa-pencil-square-o',
//                'notification_date' => date('Y-m-d H:i:s'),  
//                'url_path' => 'dashboard/leave_summary',
//            );
//            $this->notification->insert($notificationDetails);
            /* notification entry */

//            echo $this->db->last_query();
//            die;
            return true;
        }
    }

    //Reject Leave
    public function rejectLeave() {
//        var_dump($_POST);
//        die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        if ($_POST) {
            $data = $this->get_all_view_data($user_id);
            $leave_id = $this->input->post('leave_id');
            $leave_reason = $this->input->post('leave_reason');
            $dataLeaveRequest = array(
                'approver_comments' => $leave_reason,
                'leave_status' => '3',
            );
            $this->leaverequest->update($leave_id, $dataLeaveRequest);

            /* notification entry */

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'blog_post_type' => $data['user_summary']['department_id'],
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Leave Rejected',
                'notification_icon' => 'fa-times-circle text-red',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard/leave_summary',
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */

//            echo $this->db->last_query();die;
            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
            echo json_encode(array('content' => $timelineData));
            die;
        }
    }

    /* Leave Summary */

    public function leave_summary() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
//        if (!$this->ion_auth->in_group('manager')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/dashboard', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);
        $data['team_count'] = 0;
        $data['own_count'] = 0;
        $data['reg_count'] = 0;
        /* getblog data */
        $data['blog_data'] = '';
        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

        /* Holiday List */
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);

        /* Get all leave summary list */
        $data['leave_summary_details'] = $this->leaverequest->getAllLeaveSummary($data['user_summary']['user_id'], $data['user_summary']['emprole']);
        $data['leave_summary_details_all'] = $this->leaverequest->getAllLeaveSummaryList($data['user_summary']['department_id']);
        if (isset($data['leave_summary_details_all']))
            foreach ($data['leave_summary_details_all'] as $cntData) {
                if ($cntData['rep_mang_one_id'] || $cntData['rep_mang_two_id'] == $data['user_summary']['user_id'])
                    $data['team_count'] ++;
                if ($cntData['leave_user_id'] == $data['user_summary']['user_id']) {
                    $data['own_count'] ++;
                    if ($cntData['leave_status'] == '2')
                        $data['reg_count'] ++;
                }
            }

//to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'leave/_view_leave_summary', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function searchLeaveSummary() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['filter_term']) {
            $filterTerm = $this->input->post('filter_term');
            $data['leave_type_list'] = $this->leavetypes->get_all();

            if (isset($_POST['filter_type']) && $_POST['filter_type'] == 'own')
                $filterByOwn = $user_id;
            else
                $filterByOwn = NULL;

            $data['leave_summary_details'] = $this->leaverequest->getFilterLeaveSummary($filterTerm, $user_id, $filterByOwn);
            $filterLSD = $this->load->view('leave/_filter_leave_summary', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $filterLSD));
            die;
        }
    }

    public function LeaveSummary() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data['leave_type_list'] = $this->leavetypes->get_all();

            if ($_POST['action'] == 'list') {
                $action = $this->input->post('action');
                $managerId = $this->input->post('manager_id');
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, $managerId, $user_id);
            }

            if ($_POST['action'] == 'list_dept') {
                $action = $this->input->post('action');
                $managerId = $this->input->post('manager_id');
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, $managerId, NULL);
            }
            
            if ($_POST['action'] == 'list_reg') {
                $action = $this->input->post('action');                
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, NULL, $user_id);
            }

            $leaveListData = $this->load->view('leave/_filter_leave_summary', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $leaveListData));
            die;
        }
    }

}
