<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Profile extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
        self::__construct();
       
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails'));
        $this->load->model(array('marital_status', 'nationality', 'language'));
        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'work_station', 'gender',));
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        if (!$this->ion_auth->logged_in()) {
            redirect('auth/login', 'refresh');
        }
        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'profile/_view_profile', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function test() {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        //Get Menu & Sub Menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        //$this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header');
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_wizard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);

        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);
        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->work_station->dropdown('work_station_code'));
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
        $data['department_id'] = $data['user_summary']['department_id'];
        $data['emprole'] = $data['user_summary']['emprole'];

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        $data['position_list'] = $this->employees->get_all_position_by_id($data['user_summary']['jobtitle_id']);

        //Associate Holiday & Leaves
        $data['leaves'] = $this->employeesleave->get_by_id($associate_id);
        //Associate Communication & Personal Details
        $data['personal_detail'] = $this->personaldetails->get_by_id($associate_id);
        $data['communication_detail'] = $this->communication->get_by_id($associate_id);
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = (array('' => 'Select Hobbies', 'disabled' => 'disabled') + $this->hobbies->dropdown('hobbies_title'));

        /* Document */
        $data['document_details'] = $this->documents->get_by_id($associate_id);

        /* job history */
        $data['jobhistroy_details'] = NULL;
//        var_dump($data['user_summary']);die;
        /* Experience */
        $data['tag_type'] = (array('' => 'Select Tag')) + $this->tag->dropdown('tag_name');
        $data['experience_details'] = $this->experiencedetails->get_by_id($associate_id);



        /* Skills */
        $data['skills_details'] = $this->employeeskills->get_by_id($associate_id);
        $data['skills_list'] = (array('' => 'Select Level')) + $this->skills->dropdown('skill_title');
        $data['compentency_level'] = (array('' => 'Select Level')) + $this->compentencylevel->dropdown('competencylevel');

        /* education */
        $data['education_details'] = $this->educationdetails->get_by_id($associate_id);
        $data['education_level'] = (array('' => 'Select Level')) + $this->educationlevel->dropdown('educational_level');
//        var_dump($data['education_details']);die;
        /* education */
        $data['certification_details'] = $this->certificationdetails->get_by_id($associate_id);


        $data['visa_details'] = $this->visa->get_by_id($associate_id);
//        $
//        var_dump($data['certification_details']);
//        die;
        return $data;
    }

    /* Autogenerate Employee ID  */

    public function _get_employeeid() {

        $this->load->model(array('employees'));
        $curId = $this->employees->get_employee_id();

        $new_var = (int) substr($curId->employeeId, 4, strpos($curId->employeeId, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

}
