<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Dashboard Controller *  
 */

class Dashboard extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language')); //employeesholiday
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails', 'leavetypes'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language'));

        /* dashboard */
        $this->load->model(array('blogdetail', 'years', 'holidaydates', 'timelinecomment', 'employeeawards', 'leavetypesAllocation'));
        /* request actions */

        $this->load->model(array('frontend/leaverequest', 'frontend/notification', 'frontend/notificationread', 'frontend/leavededuction'));
        $this->load->model(array('frontend/eventsmain', 'frontend/eventscomments', 'frontend/eventsgallery'));

        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'workstation', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        //        $current_year = date("Y");
        //        $cur_year_id = $this->years->get_current_yearId($current_year);
        //        $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);
        //        $this->output->enable_profiler(TRUE);
        //        $this->db->cache_on();
//        $this->output->cache(1);
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        /* getblog data */
        $data['blog_data'] = '';
        if ($data['user_summary']['emprole'] == 1)
            $dept = null;
        else
            $dept = $data['user_summary']['department_id'];

        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $dept);
//        if(!isset($data['blog_data']))
//            $data['blog_data'] =


        $data['events_data'] = $this->eventsmain->get_all('id', 'DESC');

        /* Holiday List */
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);
        /* end holiday list */

        //block holidays
        $data['disabled_holiday'] = '';
        foreach ($data['holiday_list'] as $disableData)
            $data['disabled_holiday'] .= '"' . date('m-d-Y', strtotime($disableData['holidaydate'])) . '",';
        //        var_dump($data['disabled_holiday']);die;
        /* total experience */
        $date_of_joinign = date('Y-m-d', strtotime($data['user_summary']['date_of_joining']));


        $current_date = date('Y-m-d');
        $date1 = date_create($date_of_joinign);
        $date2 = date_create($current_date);
        $diff = date_diff($date1, $date2);
//        var_dump($diff);die;
        if ($diff->days > 365)
            $data['user_summary']['member_since'] = $diff->y . '.' . $diff->m . ' years In Mindowrx Family';
        else
            $data['user_summary']['member_since'] = 'Member Since ' . date('F Y', strtotime($data['user_summary']['date_of_joining']));

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'profile/_view_profile', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    /* Start save post blog data */

    public function post_blog() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        if (isset($_POST)) {
//            var_dump($_POST);
//            var_dump($_FILES);die;
            if ($this->input->post('blog_category_id'))
                $blog_category_id = $this->input->post('blog_category_id');
            else
                $blog_category_id = 1;

            $postBlogDetail = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'description' => $this->input->post('blog_detail'),
                'title' => 'Posted on timeline', //substr($this->input->post('blog_detail'), 0, 25)
                'publish_group_id' => $this->input->post('publish_group_id'),
                'image_url' => '',
                'video_url' => '',
                'blog_post_type' => '1',
                'blog_category_id' => $blog_category_id,
                'blog_date' => date("F d, Y"),
                'blog_time' => date('Y-m-d H:i:s'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            $associate_id = $this->input->post('associate_id');
            $slug = $this->users->get_slug_by_id($associate_id);
            /* Upload Image */
            if (isset($_FILES['upload_post_file_id']['name']) && $_FILES['upload_post_file_id']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['upload_post_file_id']['name'];
                $targetFile = $targetDir . $fileName;

                $fileExt = pathinfo($_FILES['upload_post_file_id']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $fileParts = pathinfo($_FILES['upload_post_file_id']['name']);
                $fileName = $_FILES['upload_post_file_id']['name'];
                $tempFile = $_FILES['upload_post_file_id']['tmp_name'];

                $uploded_file_path = $this->handleUploadPost($slug, $fileParts, $tempFile, $fileName);
                if ($uploded_file_path != '')
                    $postBlogDetail['image_url'] = $slug . '/post/' . $uploded_file_path;
            }


            $data['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $data['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);

//            var_dump($data['current_associate_slug']);die;
            $insert_id = $this->blogdetail->insert($postBlogDetail);

            $publish_g_id = $this->input->post('publish_group_id');
            /* notification entry */
            if ($publish_g_id == 99)
                $iscommon = 1;
            else
                $iscommon = 0;

            if ($publish_g_id == '99') {
                $publish_status = 5;
                $publish_department = $data['user_summary']['department_id'];
            } else if ($publish_g_id == '0') {

                if (isset($blog_category_id))
                    $publish_status = $blog_category_id;
                else
                    $publish_status = 1;

                $publish_department = 0;
            } else {
                if (isset($blog_category_id)) {
                    if ($blog_category_id == 1 && $publish_g_id == 0)
                        $publish_department = 0;
                } if ($publish_g_id == 0)
                    $publish_department = 0;
                else {
                    $publish_status = $blog_category_id;
                    $publish_department = $publish_g_id;
                }
            }

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'blog_post_type' => '1',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Posted on timeline',
                'notification_icon' => 'fa-rss text-yellow',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard',
                'is_common' => $iscommon,
                'publish_status' => $publish_status,
                'publish_department' => $publish_department,
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */


            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData));
            die;
        }
    }

    public function get_blogs() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        $data = $this->get_all_view_data($user_id);

        if (isset($_POST)) {

            //if load more
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['current_status']) && isset($_POST['post_current_start'])) {

                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status'], $_POST['post_current_start']);
            } else if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['filter_by'])) {

                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], null, null, $_POST['filter_by']);
            } else if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_current_start'])) {

                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status'], null);
            } else {

                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
            }
        }
        if ($_SERVER['REQUEST_METHOD'] == 'GET') {

            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
        }

        $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
        echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        die;
    }

    /* End save post blog data */

    /* Start save post blog data */



    /* End save post blog data */

    public function get_all_view_data($associate_id) {
//        var_dump($associate_id);die;
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['reporting_manager_summary'] = $this->employeesummary->as_array()->get_by('user_id', $data['user_summary']['reporting_manager']);
        $data['user_birthday_summary'] = $this->employeesummary->associate_birthday();

        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);

        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);


        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);

        //Associate Holiday & Leaves
        $data['leave_status'] = (array('' => 'Select Country', '1' => 'Pending For Approval', '2' => 'Approved', '3' => 'Rejected', '4' => 'Cancel')); //'Approved','Rejected','Cancel';

        $data['leave_type_list'] = $this->leavetypes->get_all();
        $data['leave_type_all'] = $this->leavetypes->get_all_types();


        $data['leave_type'] = $this->employeesleave->get_by_id($associate_id);
        $maternitystatus = $this->leavetypesAllocation->get_maternityLeaveDetails($associate_id);
//        $data['leave_type'] = $this->employeesleave->get_by_id($associate_id);
//        var_dump($data['leave_type_list']);die;
//        var_dump($data['leave_type']);die;
        $options = array();
        if (isset($data['leave_type'])) {
            foreach ($data['leave_type'] as $value) {
//            var_dump($value);die;
                if ($value['used_leaves'] >= $value['alloted_leaves']) {
                    foreach ($data['leave_type_list'] as $val) {
                        if ($val->id == $value['leavetype'])
                            $optionsbal[$val->id] = ($value['alloted_leaves'] - $value['used_leaves']);
                    }
                } else {
                    foreach ($data['leave_type_list'] as $val) {
                        if ($value['isactive'] == '1') {
                            if ($val->id == $value['leavetype']) {
                                $optionsbal[$val->id] = ($value['alloted_leaves'] - $value['used_leaves']);
                                $options[$val->id] = $val->leavetype . '(' . ($value['alloted_leaves'] - $value['used_leaves']) . ')'; //. '/' . $value['alloted_leaves'] . ')'
                            }
                        }
                    }
                }
            }

            $data['leave_type_summary'] = $optionsbal;
//            var_dump($options);die;
            if ($options == '' || empty($options))
                $data['leave_type'] = array('6' => 'LOP (Loss of Pay)');
            else
                $data['leave_type'] = array('' => 'Select Type') + $options;
        }

        $data['annoucement'] = $this->blogdetail->get_annoucement($user_id, $data['user_summary']['department_id']);

        /* Dashboard */

        if ($data['user_summary']['emprole'] == '1' || $data['user_summary']['emprole'] == '4') {
            $data['department_list'] = $this->department->dropdown('deptname');
            $data['publish_group'] = (array('0' => 'All Department')) + $data['department_list'] + (array('99' => 'Only Me'));
        } else
            $data['publish_group'] = (array('0' => 'All Department')) + (array($data['user_summary']['department_id'] => $data['user_summary']['department_name'])) + (array('99' => 'Only Me'));
        $data['timeline_comment'] = $this->timelinecomment->get_by_id($associate_id);
        $data['hall_of_fame'] = $this->employeeawards->hall_of_fame();
//        var_dump($data['hall_of_fame']);die;
        $data['leaves'] = $this->leavetypesAllocation->get_leaveList($associate_id);
        $data['leaves_label'] = '';
        foreach ($data['leaves'] as $key => $leaveData) {
            if ($leaveData['leavecode'] != "Paid") {
                $data['leaves_label'] .= '"' . $leaveData['leavecode'] . '",';
                $data['data_bal'] .= $leaveData['alloted_leaves'] . ',';
                $data['data_used'] .= $leaveData['used_leaves'] . ',';
            }
        }
//        var_dump($data['data_bal']);die;
        $data['balnce_leaves'] = $this->leavetypesAllocation->get_balanceLeaves($associate_id);
        $data['leave_history'] = $this->leaverequest->getOwnLeaveSummary($associate_id);

        return $data;
    }

    /* Autogenerate Employee ID  */

    public function _get_employeeid() {

        $this->load->model(array('employees'));
        $curId = $this->employees->get_employee_id();

        $new_var = (int) substr($curId->employeeId, 4, strpos($curId->employeeId, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

    public function delete_post_blog() {

        if (isset($_POST['delete_post_id'])) {
            $post_id = $_POST['delete_post_id'];
            $this->blogdetail->delete($post_id);

            $this->timelinecomment->delete_by_blog_id($post_id);
        }
    }

    public function add_comment() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        $data = $this->get_all_view_data($user_id);

        if (isset($_POST)) {

            $dataPostComment = array(
                'user_id' => $_POST['associate_id'],
                'blog_id' => $_POST['blog_id'],
                'comment' => $_POST['comment'],
                'comment_date' => date('Y-m-d H:i:s'),
                'comment_time' => date('Y-m-d H:i:s'),
                'createdby' => $_POST['associate_id'],
                'createddate' => date('Y-m-d H:i:s'),
            );
//            echo '<pre>',  print_r($dataPostComment);die;
            $this->timelinecomment->insert($dataPostComment);



            /* notification entry */

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'is_common' => '1',
                'publish_status' => '1',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Commented on post',
                'notification_icon' => 'fa-comments text-yellow',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => base_url() . 'dashboard/',
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */


            if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['current_status']) {
//                var_dump($_POST['current_status']);die;
                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status']);
            } else
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        }
    }

    /* Leave Module */

    public function apply_leave($associate_id) {

//        var_dump($associate_id);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $postBlogDetail['image_url'] = NULL;
        $data = $this->get_all_view_data($user_id);

        $sandwich = 0;
        $fromDate = '';
        $toDate = '';
        $data['leaves'] = $this->leavetypesAllocation->get_all($associate_id);
        foreach ($data['leaves'] as $val) {
            if ($val->leavetype == 5)
                $mat_leave = $val->leavepreallocated;
        }

        if (isset($_POST)) {
            /* levae type id */
            $leave_type_id = (int) $this->input->post('id_leave_type');
            /* Upload seek leave certificate */

            /* Upload Image */
            if (isset($_FILES['sl_attachment']['name']) && $_FILES['sl_attachment']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['sl_attachment']['name'];
                $targetFile = $targetDir . $fileName;

                $fileExt = pathinfo($_FILES['sl_attachment']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $fileParts = pathinfo($_FILES['sl_attachment']['name']);
                $fileName = $_FILES['sl_attachment']['name'];
                $tempFile = $_FILES['sl_attachment']['tmp_name'];

                $uploded_file_path = $this->handleUploadSeekLeave($data['associate_slug'], $fileParts, $tempFile, $fileName);
                if ($uploded_file_path != '')
                    $postBlogDetail['image_url'] = $data['associate_slug'] . '/leave/' . $uploded_file_path;
            }

            /* holiday list */
            $holidaydates = array();
            $current_year = date("Y");
            $cur_year_id = $this->years->get_current_yearId($current_year);
            $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);
            foreach ($data['holiday_list'] as $holidaydate) {
                array_push($holidaydates, $holidaydate['holidaydate']);
//                $holidaydates .= ',' . $holidaydate['holidaydate'];
            }


            $ltype_id = $this->input->post('id_leave_type');
            $leave_type = $this->leavetypes->get_by_id($ltype_id);



            /* blog entry */
            /* insert data in blog */
            $postBlogDetail = array(
                'user_id' => $associate_id,
                'department_id' => $data['user_summary']['department_id'],
                'description' => $this->input->post('leave_reason'),
                'title' => $leave_type,
                'publish_group_id' => $this->input->post('department_id'),
                'image_url' => $postBlogDetail['image_url'] ? $postBlogDetail['image_url'] : '',
                'video_url' => '',
                'blog_date' => date("F d, Y"),
                'blog_time' => date('Y-m-d H:i:s'),
                'blog_post_type' => '2',
                'blog_category_id' => '2',
                'createdby' => $associate_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            $insert_id = $this->blogdetail->insert($postBlogDetail);


            //check for full day | half day

            $leave_day = $this->input->post('leave_day');
            //var_dump($leave_day);die;

            $dataLeaveRequest = array(
                'user_id' => $associate_id,
                'blog_id' => $insert_id,
                'department_id' => $data['user_summary']['department_id'],
                'leave_day' => $this->input->post('leave_day'),
                'leave_status' => '1',
                'leave_type_id' => $this->input->post('id_leave_type'),
                'reason' => $this->input->post('leave_reason'),
                'rep_mang_one_id' => $data['user_summary']['reporting_manager'],
                'rep_mang_two_id' => $data['user_summary']['reporting_manager_twoup'],
                'createdby' => $associate_id,
                'createddate' => date('Y-m-d H:i:s'),
            );
            //if halfday
            if ($leave_day == '1') {

                $date = $this->input->post('single_datepicker');

                $fromDate = date('Y-m-d', strtotime($date));

                $toDate = date('Y-m-d', strtotime($date));
                $dataLeaveRequest['leave_for'] = $this->input->post('leave_for');
                $dataLeaveRequest['from_date'] = $fromDate;
                $dataLeaveRequest['to_date'] = $toDate;
//                $diff = date_diff($fromDate, $toDate); 
                if ($leave_type_id == 5)
                    $dataLeaveRequest['no_of_days'] = $mat_leave;
                else
                    $dataLeaveRequest['no_of_days'] = '0.5';
                $holidaydates = array($holidaydates);
                if (in_array($fromDate, $holidaydates)) {
                    return false;
                }
            }

            //fullday
            if ($leave_day == '2') {
                $fromDate = date('Y-m-d', strtotime($this->input->post('single_datepicker_from')));

                if ($leave_type_id == '5') {//maternity applied{
                    $date = strtotime(date($this->input->post('single_datepicker_from')));  // if today :2013-05-23
                    $toDate = date('Y-m-d', strtotime('+' . $mat_leave . ' days', $date));
                } else
                    $toDate = date('Y-m-d', strtotime($this->input->post('single_datepicker_to')));

                $dataLeaveRequest['from_date'] = $fromDate;
                $dataLeaveRequest['to_date'] = $toDate;
                if ($leave_type_id == 5)//maternity applied
                    $days = $mat_leave;
                else
                    $diff = date_diff(date_create($this->input->post('single_datepicker_from')), date_create($this->input->post('single_datepicker_to')));

                $datetime1 = new DateTime($fromDate);
                $datetime2 = new DateTime($toDate);
                $woweekends = 0;
                if ($leave_type_id == 5)
                    $dataLeaveRequest['no_of_days'] = $days;
                else
                    $dataLeaveRequest['no_of_days'] = $diff->days + 1;

                $dataLeaveRequest['is_sat_holiday'] = 0;

                $startDate = new DateTime($fromDate);
                $endDate = new DateTime($toDate);

                $interval = new DateInterval('P1D'); //for one day interval
                $daterange = new DatePeriod($startDate, $interval, $endDate);
//                var_dump($daterange);die;
                if ($startDate == $endDate) {
                    $dataLeaveRequest['no_of_days'] = 1;
                } else {
                    if ($leave_type_id != 5) {//to check leave type is not maternity leave
                        foreach ($daterange as $date) {
                            if ($date->format("N") == '6') {

                                $dataLeaveRequest['no_of_days'] --;
                            }
                            if ($date->format("N") == '7') {
                                $sandwich ++;
                                $dataLeaveRequest['no_of_days'] --;
                            }
                            if (in_array($date->format("Y-m-d"), $holidaydates)) {
                                $dataLeaveRequest['no_of_days'] --;
                            }
                        }
                        $toDate = date('Y-m-d', strtotime($this->input->post('single_datepicker_to')));
                        if (in_array(date('Y-m-d', strtotime($toDate)), $holidaydates)) {
                            $dataLeaveRequest['no_of_days'] --;
                        }

                        $dataLeaveRequest['no_of_days'] = $sandwich + $dataLeaveRequest['no_of_days'];
                        $dataLeaveRequest['is_sat_holiday'] = $diff->days + 1 - $dataLeaveRequest['no_of_days'];
                    }
                }
                //total holiday, sat sunday deduction
            }
//            var_dump($dataLeaveRequest);die;
            $leave_id = $this->leaverequest->insert($dataLeaveRequest);

            $associate_id = $this->input->post('associate_id');
            $leaveDeductionDataArray = array(
                'user_id' => $associate_id,
                'leave_id' => $leave_id,
                'priviledge_deduction' => $this->input->post('temp_pl_' . $associate_id),
                'casual_deduction' => $this->input->post('temp_cl_' . $associate_id),
                'paid_count' => $this->input->post('temp_loss_' . $associate_id),
                'sl_cnt' => $this->input->post('temp_sl_' . $associate_id),
                //'mat_cnt' => $this->input->post('temp_mat_' . $associate_id)? $this->input->post('temp_mat_' . $associate_id):'',
                //'par_cnt' => $this->input->post('par_cnt' . $associate_id)? $this->input->post('par_cnt' . $associate_id):'',
                'createddate' => date('Y-m-d H:i:s'),
            );
            //if maternity applied or isset

            if (($this->input->post('temp_mat_' . $associate_id)) || ($this->input->post('temp_mat_' . $associate_id)) >= 0)
                $leaveDeductionDataArray['mat_cnt'] = $this->input->post('temp_mat_' . $associate_id);
//
            //if partental applied or isset
            if (($this->input->post('temp_par_' . $associate_id)) || ($this->input->post('temp_par_' . $associate_id)) >= 0)
                $leaveDeductionDataArray['par_cnt'] = $this->input->post('temp_par_' . $associate_id);

//            var_dump($leaveDeductionDataArray);die;
            if ($leaveDeductionDataArray)
                $this->leavededuction->insert($leaveDeductionDataArray);
        }
        /* notification entry */

        $applied_user_id = $this->input->post('applied_user_id');
        $applied_user_name = $this->employeesummary->get_user_fullname($applied_user_id);

        $notificationDetails = array(
            'user_id' => $user_id,
            'show_user_id' => $user_id,
            'department_id' => $data['user_summary']['department_id'],
            'blog_post_type' => 2,
            'is_common' => '1',
            'publish_status' => '2',
            'userfullname' => $data['user_summary']['userfullname'],
            'profileimg' => $data['user_summary']['profileimg'],
            'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,Applied leave',
            'notification_icon' => 'fa-calendar-check-o text-light-blue',
            'notification_date' => date('Y-m-d H:i:s'),
            'url_path' => 'dashboard/leave_summary',
        );
        $this->notification->insert($notificationDetails);
        /* notification entry */


        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

        $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
        echo json_encode(array('content' => $timelineData));
        die;
    }

    function handleUploadSeekLeave($user_slug, $fileParts, $tempFile, $fileName) {

        $fileTypes = array('jpeg', 'png', 'jpg'); // File extensions

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $this->session->set_flashdata('msg', 'File type not supported.');
            return false;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/leave'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/leave';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $fileName = $user_slug . '-leave-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        //var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadPost($user_slug, $fileParts, $tempFile, $fileName) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $this->session->set_flashdata('msg', 'File type not supported.');
            return false;
        }

        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/post'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/post';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $fileName = $user_slug . '-post-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        //var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    //Approve Leave
    public function approveLeave() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        if ($_POST) {
            $leave_id = $this->input->post('leave_id');

            $dataLeaveRequest = array(
                'approver_comments' => 'I am pleased to inform you that your leave request is approved. Kindly check there is no pending task from your side',
                'leave_status' => '2',
                'modifieddate' => date('Y-m-d H:i:s'),
            );
            //update leave
            $this->leaverequest->update($leave_id, $dataLeaveRequest);

            /* Update associate leave counts */
            $leave_type_id = $this->input->post('leave_type_id');
            $associate_id = $this->input->post('user_id');
            $used_leaves = $this->input->post('no_of_days');
            $approveData = array(
                'used_leaves' => (float) ($used_leaves),
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s'),
            );

//            $leaveDeductionData = $this->employeesleave->update_leaves_count($leave_type_id, $associate_id, $approveData);
//            $leaveDeductionDataArray = array(
//                'user_id' => $associate_id,
//                'leave_id' => $leave_id,
//                'priviledge_deduction' => $this->input->post('temp_pl'),
//                'casual_deduction' => $this->input->post('temp_cl'),
//                'paid_count' => $this->input->post('temp_loss'),
//                'sl_cnt' => $this->input->post('temp_sl'),
//            );
//            
//            $this->leavededuction->insert($leaveDeductionDataArray);
            /* notification entry */
            $applied_user_id = $this->input->post('applied_user_id');
            $applied_user_name = $this->employeesummary->get_user_fullname($applied_user_id);

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => $applied_user_name . ' Leaves Approved By <span class="text-bold">' . $data['user_summary']['userfullname'] . '</span>',
                'notification_icon' => 'fa-pencil-square-o',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard/leave_summary',
                'blog_post_type' => '2',
                'publish_status' => '2',
                'is_common' => '1',
                'is_common' => '1',
                'publish_status' => '2',
                'show_user_id' => $applied_user_id
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */

//            echo $this->db->last_query();
//            die;
            return true;
        }
    }

    //Reject Leave
    public function rejectLeave() {
//        var_dump($_POST);
//        die;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        if ($_POST) {
            $data = $this->get_all_view_data($user_id);
            $leave_id = $this->input->post('leave_id');

            $applied_user_id = $this->input->post('applied_user_id');
            $applied_user_name = $this->employeesummary->get_user_fullname($applied_user_id);

            $leave_reason = $this->input->post('leave_reason');
            $dataLeaveRequest = array(
                'approver_comments' => $leave_reason,
                'leave_status' => '3',
            );
            $this->leaverequest->update($leave_id, $dataLeaveRequest);

            /* notification entry */

            $notificationDetails = array(
                'user_id' => $user_id,
                'department_id' => $data['user_summary']['department_id'],
                'blog_post_type' => '2',
                'userfullname' => $data['user_summary']['userfullname'],
                'profileimg' => $data['user_summary']['profileimg'],
                'notification' => '<span class="">' . $data['user_summary']['userfullname'] . '</span>,' . ' Rejected ' . $applied_user_name . ' Leave',
                'notification_icon' => 'fa-times-circle text-red',
                'notification_date' => date('Y-m-d H:i:s'),
                'url_path' => 'dashboard/leave_summary',
                'is_common' => '1',
                'publish_status' => '2',
                'show_user_id' => $applied_user_id
            );
            $this->notification->insert($notificationDetails);
            /* notification entry */

//            echo $this->db->last_query();die;
            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
            echo json_encode(array('content' => $timelineData));
            die;
        }
    }

    /* Leave Summary */

    public function leave_summary() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
//        if (!$this->ion_auth->in_group('manager')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/dashboard', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);
        $data['team_count'] = 0;
        $data['own_count'] = 0;
        $data['reg_count'] = 0;
        /* getblog data */
        $data['blog_data'] = '';
        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

        /* Holiday List */
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);


        /* Get all leave summary list */
        if ($data['user_summary']['emprole'] == '5')
            $managerId = $user_id;
        else
            $managerId = $data['user_summary']['reporting_manager'];

        $data['own_lv'] = $this->leaverequest->LeaveSummary('list', $managerId, $user_id);

        $data['team_lv'] = $this->leaverequest->LeaveSummary('list_dept', $managerId, $user_id);
        $data['reg_lv'] = $this->leaverequest->LeaveSummary('list_reg', $managerId, $user_id);
        $data['leave_type_list'] = $this->leavetypes->get_all('isactive', '0');

        if ($data['user_summary']['emprole'] == '4') {
            $data['all_lv'] = $this->leaverequest->getAllLeaveSummary($data['user_summary']['user_id'], $data['user_summary']['emprole']);
            $data['all_reg_lv'] = $this->leaverequest->getAllLeaveSummary($data['user_summary']['user_id'], $data['user_summary']['emprole']);
        }
//        var_dump($data['all_lv']);die;
        $option = array();
        $data['leave_summary_details'] = $this->leaverequest->getAllLeaveSummary($data['user_summary']['user_id'], $data['user_summary']['emprole']);

        if ($data['user_summary']['emprole'] == '4')
            $data['leave_summary_reg'] = $this->leaverequest->getLeaveSummaryReg(NULL, NULL);
        else
            $data['leave_summary_reg'] = $this->leaverequest->getLeaveSummaryReg($data['user_summary']['user_id'], $data['user_summary']['department_id']);

        if (isset($data['leave_summary_reg']))
            foreach ($data['leave_summary_reg'] as $keyIndex => $lsrData) {
                $data['leave_summary_reg'][$keyIndex]['leave_balance'] = $this->employeesleave->get_by_id_all($lsrData['user_id']); //
//                $data['leave_summary_reg'][$keyIndex]['leave_tempded_balance'] = $this->leavededuction->get_by_id($lsrData['id']);
//                var_dump($data['leave_summary_reg'][$keyIndex]['leave_balance']);
                if (isset($data['leave_summary_reg'][$keyIndex]['leave_balance']))
                    foreach ($data['leave_summary_reg'][$keyIndex]['leave_balance'] as $key => $value) {
                        if ($value['isactive'] == 1)
                            $data['leave_summary_reg'][$keyIndex]['leave_balance'][$key] = abs($value['alloted_leaves'] - $value['used_leaves']);
                        else
                            $data['leave_summary_reg'][$keyIndex]['leave_balance'][$key] = null;
                    }
            }
//        var_dump($data['leave_summary_reg']);die;

        if ($data['user_summary']['emprole'] == '4')
            $data['leave_summary_details_all'] = $this->leaverequest->getAllLeaveSummaryList(null, null);
        else if ($data['user_summary']['emprole'] == '1')
            $data['leave_summary_details_all'] = $this->leaverequest->getAllLeaveSummaryList(null, $data['user_summary']['user_id']);
        else
            $data['leave_summary_details_all'] = $this->leaverequest->getAllLeaveSummaryList($data['user_summary']['department_id'], null);

//        var_dump($data['leave_summary_details_all']);die;
        if (isset($data['leave_summary_details_all']))
            foreach ($data['leave_summary_details_all'] as $cntData) {
                if ($cntData['rep_mang_one_id'] == $data['user_summary']['user_id'] || $cntData['rep_mang_two_id'] == $data['user_summary']['user_id'])
                    $data['team_count'] ++;
                if ($cntData['leave_user_id'] == $data['user_summary']['user_id']) {
                    $data['own_count'] ++;
                    if ($cntData['leave_status'] == '2')
                        $data['reg_count'] ++;
                }
            }
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'leave/_view_leave_summary', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function searchLeaveSummary() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['filter_term']) {
            $filterTerm = $this->input->post('filter_term');
            $data['leave_type_list'] = $this->leavetypes->get_all();

            if (isset($_POST['filter_type']) && $_POST['filter_type'] == 'own')
                $filterByOwn = $user_id;
            else
                $filterByOwn = NULL;

            $data['leave_summary_details'] = $this->leaverequest->getFilterLeaveSummary($filterTerm, $user_id, $filterByOwn);
            $filterLSD = $this->load->view('leave/_filter_leave_summary', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $filterLSD));
            die;
        }
    }

    public function LeaveSummary() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data['leave_type_list'] = $this->leavetypes->get_all();

            if ($_POST['action'] == 'list') {
                $action = $this->input->post('action');
                $managerId = $this->input->post('manager_id');
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, $managerId, $user_id);
            }

            if ($_POST['action'] == 'list_dept') {
                $action = $this->input->post('action');
                $managerId = $this->input->post('manager_id');
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, $managerId, NULL);
            }

            if ($_POST['action'] == 'list_reg') {
                $action = $this->input->post('action');
                $data['leave_summary_details'] = $this->leaverequest->LeaveSummary($action, NULL, $user_id);
            }

            $leaveListData = $this->load->view('leave/_filter_leave_summary', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $leaveListData));
            die;
        }
    }

    public function generateLeaveReport() {

        $pending = 1;
        $approve = 1;
        $reject = 1;
        $deptcnt = 1;
        $data['leave_report'] = $this->leaverequest->generateLeaveReport();
        $data['all_associates'] = $this->employeesummary->as_array()->get_all();

        $leaveData = array();
        $departmentCnt = array();
        $leaveData['totalLeaveCnt'] = count($data['leave_report']);
        $data['department_list'] = $this->department->dropdown('deptname');


        foreach ($data['leave_report'] as $repotData) {

            if ($repotData['leave_status'] == '1')
                $leaveData['total_pending'] = $pending++;
            if ($repotData['leave_status'] == '2')
                $leaveData['total_approve'] = $approve++;
            if ($repotData['leave_status'] == '3')
                $leaveData['total_rejected'] = $reject++;

            foreach ($data['department_list'] as $key => $deptname) {
                if ($key == $repotData['department_id'])
                    $departmentCnt[$deptname] = $deptcnt++;
                else
                    $departmentCnt[$deptname] = 0;
            }
        }

        $this->load->library('excel');
//        $this->load->library('PHPExcel/iofactory');
        $spreadsheet = new PHPExcel();
        $spreadsheet->setActiveSheetIndex(0);

        $worksheet = $spreadsheet->getActiveSheet();
        $rowCount = count($data['leave_report']);
        $col = 0;
        foreach ($leaveData as $rowTitle => $rowVal) {
            $worksheet->SetCellValueByColumnAndRow($col, 1, $rowTitle);
            $col++;
        }
        $col = 0;
        foreach ($leaveData as $rowTitle => $rowVal) {
            $worksheet->SetCellValueByColumnAndRow($col, 2, $rowVal);
            $col++;
        }

        $worksheet->SetCellValueByColumnAndRow(0, 4, 'Department');
        $worksheet->SetCellValueByColumnAndRow(0, 5, 'Count');
        $col = 1;
        foreach ($departmentCnt as $depatname => $val) {
            $worksheet->SetCellValueByColumnAndRow($col, 4, $depatname);
            $worksheet->SetCellValueByColumnAndRow($col, 5, $val);
            $col++;
        }



        $writer = new PHPExcel_Writer_Excel2007($spreadsheet);
        $filename = 'assets/test.xlsx';
        $writer->save($filename);

        /* Employee leave summary */

        $spreadsheet = new PHPExcel();
        $spreadsheet->setActiveSheetIndex(0);

        $worksheetAss = $spreadsheet->getActiveSheet();
        $leaveSheetTitles = array(
            'associate_name', 'associate_id', 'department',
            'pending_leave', 'applied_leave', 'approved_leave',
            'rejected_leave', 'paid_leave');
        $colTitle = 0;

        foreach ($leaveSheetTitles as $title) {
            $worksheetAss->SetCellValueByColumnAndRow($colTitle, 1, $title);
            $colTitle++;
        }

        $colCnt = 0;
        $rowCnt = 1;
        foreach ($data['all_associates'] as $assData) {
            foreach ($data['leave_report'] as $lvData) {
                if ($lvData['user_id'] == $lvData['user_id']) {
                    
                }
            }
            $rowCnt++;
        }

//        $worksheetAss->SetCellValueByColumnAndRow($colCnt++, $rowCnt, $assData['userfullname']);
//        $worksheetAss->SetCellValueByColumnAndRow($colCnt++, $rowCnt, $assData['userfullname']);

        $writer = new PHPExcel_Writer_Excel2007($spreadsheet);
        $filename = 'assets/test.xlsx';
        $writer->save($filename);
    }

    public function generateFile() {
        $targetURL = '/assets/reports/leaves/'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'reports' . DIRECTORY_SEPARATOR . '/leaves/mayur.xlsx';

        $this->load->library('excel');
        $spreadsheet = new PHPExcel();
        $spreadsheet->setActiveSheetIndex(0);
        $worksheet = $spreadsheet->getActiveSheet();
        $worksheet->SetCellValueByColumnAndRow(0, 1, 'Hello World');
        $worksheet->SetCellValueByColumnAndRow(1, 1, 'Mayur');
        $worksheet->SetCellValueByColumnAndRow(2, 1, 'There');

        $writer = new PHPExcel_Writer_Excel2007($spreadsheet);
        $filename = 'assets/reports/leaves/mayur.xlsx';
        $writer->save($filename);
    }

    public function clculateNoOfDays() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            /* holiday list */

            $holidaydates = array();
            $current_year = date("Y");
            $cur_year_id = $this->years->get_current_yearId($current_year);
            $data['holiday_list'] = $this->holidaydates->get_holidayListFront($cur_year_id);
            foreach ($data['holiday_list'] as $holidaydate) {
                array_push($holidaydates, $holidaydate['holidaydate']);
//                $holidaydates .= ',' . $holidaydate['holidaydate'];
            }

//            $holidaydates = array($holidaydates);
            $fromdate = $this->input->post('fromdate');
            $todate = $this->input->post('todate');

            $fromDate = date('Y-m-d', strtotime($fromdate));
            $toDate = date('Y-m-d', strtotime($todate));
            if ($fromDate == $toDate) {
                if (!in_array($fromDate, $holidaydates))
                    $no_of_days = 1;
                else
                    $no_of_days = 0;
                echo json_encode(array('no_of_days' => $no_of_days));
                die;
            }


            $diff = date_diff(date_create($fromDate), date_create($toDate));
//            var_dump($diff->days);
            $woweekends = 0;
            $no_of_days = $diff->days + 1;
            $dataLeaveRequest['is_sat_holiday'] = 0;

            $startDate = new DateTime($fromDate);
            $endDate = new DateTime($toDate);

            $interval = new DateInterval('P1D'); //for one day interval
            $daterange = new DatePeriod($startDate, $interval, $endDate);

            $leave_type_id = $this->input->post('leave_type_id');
            $sandwich = 0;
            if ($leave_type_id != 5) {
                foreach ($daterange as $date) {

//                    echo $date->format("Y-m-d");
                    if ($date->format("N") == '6') {
//                        $sandwich ++;
                        $no_of_days --;
                    }
                    if ($date->format("N") == '7') {
                        $sandwich ++;
                        $no_of_days --;
                    }
                    if (in_array($date->format("Y-m-d"), $holidaydates)) {
                        $no_of_days --;
                    }
//                    if (in_array($toDate, $holidaydates))
                }

                if (in_array(date('Y-m-d', strtotime($todate)), $holidaydates)) {
//                    $sandwich --;
                    $no_of_days --;
                }

                $no_of_days = $sandwich + $no_of_days;
            }
            echo json_encode(array('no_of_days' => $no_of_days));
            die;
        }
    }

    public function regularize() {

        $uppl_bal = 0;
        $upcasual_bal = 0;
        $upmat_bal = 0;
        $uppar_bal = 0;
        $paid_bal = 0;
        $upsl_bal = 0;
        $leave_id = $this->input->post('leave_id');
        $associate_id = $this->input->post('associate_id_' . $leave_id);
        $casual_bal = (float) $this->input->post('cl_' . $leave_id);
        $pl_bal = (float) $this->input->post('pl_' . $leave_id);
        $sl_bal = (float) $this->input->post('sl_' . $leave_id);
        $paid_bal = (float) $this->input->post('paid_' . $leave_id);

        $par_bal = (float) $this->input->post('par_' . $leave_id);
        $mat_bal = (float) $this->input->post('mat_' . $leave_id);
        $associate_current_leave = $this->employeesleave->as_array()->get_by_id($associate_id);
        foreach ($associate_current_leave as $lvData) {
            if ($lvData['leavetype'] == 1) {//pl
                if ($pl_bal == 0)
                    $uppl_bal = (float) $lvData['alloted_leaves'];
                else
                    $uppl_bal = (float) $lvData['alloted_leaves'] - (float) $pl_bal;
            }
            if ($lvData['leavetype'] == 2) {//sick
                if ($sl_bal == 0)
                    $upsl_bal = (float) $lvData['alloted_leaves'];
                else
                    $upsl_bal = (float) $lvData['alloted_leaves'] - (float) $sl_bal;
            }
            if ($lvData['leavetype'] == 3) {//casual
                if ($casual_bal == 0)
                    $upcasual_bal = (float) $lvData['alloted_leaves'];
                else
                    $upcasual_bal = (float) $lvData['alloted_leaves'] - (float) $casual_bal;
            }

            if (isset($lvData['leavetype']) == 4 && $lvData['leavetype'] == 4) {//maternity
                if ($mat_bal == 0)
                    $upmat_bal = (float) $lvData['alloted_leaves'];
                else
                    $upmat_bal = (float) $lvData['alloted_leaves'] - (float) $mat_bal;
            }
            if (isset($lvData['leavetype']) == 5 && $lvData['leavetype'] == 5) {//parantal
                if ($par_bal == 0)
                    $uppar_bal = (float) $lvData['alloted_leaves'];
                else
                    $uppar_bal = (float) $lvData['alloted_leaves'] - (float) $par_bal;
            }
            if ($lvData['leavetype'] == 6) {
                $paid_bal = (float) $lvData['used_leaves'] + (float) $paid_bal;
            }
        }
//        if(isset($this->input->post('par_' . $leave_id)))



        $applied_bal = (float) $this->input->post('noofday_' . $leave_id);

        //balance
//        $casual_prev_bal = (float) $this->input->post('casual_actual_bal_' . $leave_id);
//        $privilege_prev_bal = (float) $this->input->post('privilege_actual_bal_' . $leave_id);
//        $sl_prev_bal = (float) $this->input->post('sick_actual_bal_' . $leave_id);
//        $paid_prev_bal = (float) $this->input->post('paid_actual_bal_' . $leave_id);
//
//        $par_prev_bal = (float) $this->input->post('par_actual_bal_' . $leave_id);
//        $mat_prev_bal = (float) $this->input->post('mat_actual_bal_' . $leave_id);
//
//
//        $upcasual_bal = (float) $casual_bal - $casual_prev_bal;
//        $uppl_bal = (float) $pl_bal - $privilege_prev_bal;
//        $upsl_bal = (float) $sl_prev_bal - $sl_bal;
//        $uppar_bal = (float) $par_prev_bal - $par_bal;
//        $upmat_bal = (float) $mat_prev_bal - $mat_bal;
//       
//        var_dump($uppl_bal);
//        var_dump($upsl_bal);
//         var_dump($upcasual_bal);
//        var_dump($upmat_bal);
//        var_dump($uppar_bal);        
//        var_dump($paid_bal);
//
//        die;
//        $paid_bal = (float) ($paid_bal + $paid_prev_bal);

        $dataPL = array(
            'used_leaves' => abs($uppl_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
        $dataCL = array(
            'used_leaves' => abs($upcasual_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
        $dataSL = array(
            'used_leaves' => abs($upsl_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
        $dataPAR = array(
            'used_leaves' => abs($uppar_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
        $dataMAT = array(
            'used_leaves' => abs($upmat_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
        $dataPaid = array(
            'used_leaves' => abs($paid_bal),
            'modifiedby' => $this->session->userdata('user_id'),
            'modifieddate' => date('Y-m-d H:i:s'),
        );
//        1-PL, 2-SL, 3-CL,6-LOP
        $this->employeesleave->update_leave_priviledged($associate_id, 1, $dataPL);
        $this->employeesleave->update_leave_seek($associate_id, 2, $dataSL);
        $this->employeesleave->update_leave_casual($associate_id, 3, $dataCL);
        $this->employeesleave->update_leave_parental($associate_id, 4, $dataPAR);
        $this->employeesleave->update_leave_maternity($associate_id, 5, $dataMAT);
        $this->employeesleave->update_leave_paid($associate_id, 6, $dataPaid);


        //update regularize status
        $regArray = array('is_regularize' => '1');
        $this->leaverequest->update_is_regularize($leave_id, $regArray);
        $this->session->set_flashdata('msg', 'Leave Regularized Succefully');
        redirect('/dashboard/leave_summary', 'refresh');
    }

    public function readNotification() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $notification_id = $this->input->post('notification_id');
            $notiArray = array(
                'isread' => '1',
                'user_id' => $user_id,
                'notification_id' => $notification_id,
                'readdate' => date('Y-m-d H:i:s'),
                'ipaddress' => $this->input->ip_address(),
            );

            $this->notificationread->insert($notiArray);
            return true;
        }
//        redirect('/dashboard');
    }

    public function blog_activity() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        /* getblog data */
        $data['blog_data'] = '';
        if ($data['user_summary']['emprole'] == 1)
            $dept = null;
        else
            $dept = $data['user_summary']['department_id'];

        $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $dept);
        $data['blog_activity'] = $this->blogdetail->as_array()->get_all_blog();
//        if(!isset($data['blog_data']))
//            $data['blog_data'] =



        $date_of_joinign = date('Y-m-d', strtotime($data['user_summary']['date_of_joining']));
//        var_dump($data['disabled_holiday']);die;

        $current_date = date('Y-m-d');
        $date1 = date_create($date_of_joinign);
        $date2 = date_create($current_date);
        $diff = date_diff($date1, $date2);
//        var_dump($diff);die;
        if ($diff->days > 365)
            $data['user_summary']['member_since'] = $diff->y . '.' . $diff->m . ' years In Mindowrx Family';
        else
            $data['user_summary']['member_since'] = 'Member Since ' . date('F Y', strtotime($data['user_summary']['date_of_joining']));

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'activity/_blog_activity', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
//        redirect('/dashboard');
    }

}
