<?php // var_dump($holiday_list);die;              ?>
<!-- appraisal block here -->

<!--<div class="col-sm-4 ">
    <div class="row white-bg">
         <canvas id="pieChart" style="height:80px"></canvas>
    </div>
   
</div>-->
<div class="row">
    <div class="col-sm-12">
        <div class="main-bg all-padding-15">
            <div class="col-sm-2 ">
                <div class="leave-heading"><h4 >Leave Summary</h4></div>

                <ul class="list-group">
                    <li class="list-group-item handle">My Leaves <span class="badge badge-secondary">2</span></li>
                    <?php if ($user_summary['emprole'] == 3) { ?>
                        <li class="list-group-item handle">Team Leaves <span class="badge badge-secondary">5</span></li>
                    <?php } ?>
                </ul>
            </div>

            <!--            <div class="col-sm-3 border-right">
                            <h4>Summary</h4>
                            <canvas id="pieChart" style="height:40px; padding:5px;"></canvas>
                        </div>-->

            <div class="col-sm-10">
                <div class="leave-own-id">
                    <div class="leave-heading"><h4 >Team Leaves Summary</h4></div>
                    <?php if (isset($leave_summary_details)) { ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-sm "><i class="fa fa-filter"></i></button>
                                    <button type="button" class="btn btn-default dropdown-toggle btn-sm" data-toggle="dropdown">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#" onclick="filterLeave('all')"><i class="fa fa-list"> </i> All</a></li>
                                        <li><a href="#" onclick="filterLeave('2')"><i class="fa fa-check-circle-o"> </i> Approved</a></li>
                                        <li><a href="#" onclick="filterLeave('1')"><i class="fa fa-ban"> </i> Pending</a></li>
                                        <li><a href="#" onclick="filterLeave('3')"><i class="fa fa-remove"> </i> Reject</a></li>
                                    </ul>

                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="table-responsive">
                                    <table class="table margin-bottom-0">
                                        <thead>
                                            <tr>
                                                <!--<th>Associate Code</th>-->
                                                <th>Associate Name</th>
                                                <th>Leave Type</th>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>Applied on</th>
                                                <th>Status</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody class="test">
                                            <?php // var_dump($leave_type_list);die;?>
                                            <?php foreach ($leave_summary_details as $listData) { ?>   
                                                <tr>
                                                    <!--<td><?php echo $listData['employeeId'] ?></td>-->
                                                    <td>
                                                        <i>
                                                            <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                                <img class="img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                                            <?php } else { ?>
                                                                <img class="img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                            <?php } ?>
                                                        </i>
                                                        <p><?php echo $listData['userfullname'] ?></p>
                                                        <p class="text-light-gray"><?php echo $listData['position_name'] ?></p>
                                                    </td>
                                                    <td>
                                                        <?php foreach ($leave_type_list as $leaveObj) { ?>
                                                            <?php // var_dump($leaveObj);die;?>
                                                            <?php echo $leaveObj->id == $listData['leave_type_id'] ? $leaveObj->leavetype : '' ?>

                                                        <?php } ?>
                                                        <p><span class="text-light-gray">applied on <?php echo date('d M Y', strtotime($listData['createddate'])) ?></span></p>
                                                    </td>
                                                    <td>
                                                        <p>
                                                            <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                                                        </p>

                                                    </td>
                                                    <td><?php echo date('d M Y', strtotime($listData['to_date'])) ?> </td>
                                                    <td><p class="label label-default "><?php echo $listData['no_of_days'] ?> days</p>

                                                    </td>
                                                    <td>
                <!-- <i class="fa fa-check text-success"></i> -->
                                                        <p>
                                                            <?php if ($listData['leave_status'] == '2') { ?>
                                                                <span class="btn btn-success btn-xs"><i class="fa fa-check-circle-o "> </i> Approved</span></p>

                                                        <?php } if ($listData['leave_status'] == '1') { ?>
                                                            <p>
                                                                <span class="btn btn-warning btn-xs"><i class="fa fa-exclamation-circle"> </i> Pending</span></p>
                                                        <?php } if ($listData['leave_status'] == '3') { ?>
                                                            <p>
                                                                <span class="btn btn-danger btn-xs"><i class="fa fa-remove"> </i> Reject</span></p>
                                                        <?php } ?>

                                                        </p>
                                                    </td>
                                                    <td>
                                                        <label class="btn btn-default btn-xs" title="View" data-toggle="modal" data-target="#leave-view-<?php echo $listData['leave_id'] ?>">
                                                            <i class="fa fa-eye text-ccc handle" ></i>
                                                        </label>


                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>

                        <div class="pull-left margin-top-20"> Showing 1 to 10 of <?php echo count($leave_summary_details) ?> entries</div>
                        <div class="pull-right">                                            
                            <ul class="pagination pagination-sm">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">&laquo;</a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">&raquo;</a>
                                </li>
                            </ul>
                        </div>
                    <?php } ?>
                </div>

            </div>
        </div>
    </div>
</div>


<!-- appraisal block here -->

<script>
    var emp_url = '<?php echo base_url(); ?>dashboard/searchLeaveSummary';
    function filterLeave(filter_term) {
        $('.test').html('');
        search_leaves_summmary(filter_term, emp_url);

    }
    function search_leaves_summmary(filter_term, url) {
        $.ajax({
            type: "POST",
            url: url,
            data: {'filter_term': filter_term},
            success: function (data) {
                $('.loader').hide();
                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
//                alert(parsed.content);
                if (parsed.content == null) {
                    $('.test').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.test').html(parsed.content);
                }
            }
        });
    }
</script>

<script src="<?php echo base_url('frontend/plugins/chartjs/Chart.min.js'); ?>"></script>
<script>
    $(function () {

        // Get context with jQuery - using jQuery's .get() method.
        var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
        var pieChart = new Chart(pieChartCanvas);
        var PieData = [
            {
                value: 3,
                color: "#00c0ef",
                highlight: "#00c0ef",
                label: "Casual leave",
                title: "balram"
            },
            {
                value: 5,
                color: "#3c8dbc",
                highlight: "#3c8dbc",
                label: "Sick Leave"
            },
            {
                value: 12,
                color: "#d2d6de",
                highlight: "#d2d6de",
                label: "Personal leave"
            }
        ];
        var pieOptions = {
            //Boolean - Whether we should show a stroke on each segment
            segmentShowStroke: true,
            //String - The colour of each segment stroke
            segmentStrokeColor: "#fff",
            //Number - The width of each segment stroke
            segmentStrokeWidth: 1,
            //Number - The percentage of the chart that we cut out of the middle
            percentageInnerCutout: 5, // This is 0 for Pie charts
            //Number - Amount of animation steps
            animationSteps: 100,
            //String - Animation easing effect
            animationEasing: "easeOutBounce",
            //Boolean - Whether we animate the rotation of the Doughnut
            animateRotate: true,
            //Boolean - Whether we animate scaling the Doughnut from the centre
            animateScale: false,
            //Boolean - whether to make the chart responsive to window resizing
            responsive: true,
            // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
            maintainAspectRatio: true,
            //String - A legend template
            legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
                    };
                    //Create pie or douhnut chart
                    // You can switch between pie and douhnut using the method below.
                    pieChart.Doughnut(PieData, pieOptions);

                    barChartOptions.datasetFill = false;
                    barChart.Bar(barChartData, barChartOptions);
                });
</script>