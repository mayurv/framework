<!--Modal View Leaves-->
<?php // var_dump($leave_summary_details);die?>
<?php if (isset($leave_summary_details_all)) { ?>
    <?php foreach ($leave_summary_details_all as $listData) { ?>  
        <div class="modal fade" id="leave-view-<?php echo $listData['leave_id'] ?>" role="dialog">
            <div class="modal-dialog modal-md">

                <div class="modal-content">   
                    <div class="modal-header padding-bottom-0">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4>Leave Application Summary</h4>
                    </div>

                    <div class="modal-body margin-top-0">
                        <div class="user-modal-slim">


                            <table class="table table-responsive">

                                <tr>
                                    <th>
                                        <span class="">
                                            <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                <img class="margin-left-20 img-rounded img-responsive img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                            <?php } else { ?>
                                                <img class="margin-left-20 img-circle img-responsive img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                            <?php } ?>
                                        </span>
                                    </th>
                                    <td>
                                        <p><?php echo $listData['userfullname'] ?> <span class="text-gray"> | <?php echo $listData['employeeId'] ?></span></p>
                                        <p><span class="text-gray"><?php echo $listData['department_name'] ?>,<?php echo $listData['position_name'] ?></span></p>

                                    </td>
                                </tr>

                                <tr>

                                    <th width="30%">Applied</th>
                                    <td><span class="clr-999">
                                            <?php echo date('d F, Y', strtotime($listData['createddate'])) ?>

                                        </span>
                                    </td>
                                </tr>
                                <?php if ($listData['leave_day'] == '1') { ?>
                                    <tr>
                                        <th> Day</th>
                                        <td><span class="text-info" title="Leave Day">Half Day</span></td>
                                    </tr>
                                <?php } ?>
                                <?php if ($listData['leave_day'] == '2') { ?>
                                    <tr>
                                        <th> Day</th>
                                        <td><span class="text-info" title="Leave Day">Full Day</span></td>
                                    </tr>
                                <?php } ?>
                                <tr>
                                    <th> No of days</th>
                                    <td><span class="label bg-aqua" title="No of Days"><?php echo $listData['no_of_days'] ?></span></td>
                                </tr>
                                <tr>
                                    <th>From | To</th>
                                    <td><span class="clr-999"><?php echo date('l d F Y', strtotime($listData['from_date'])) ?> | <?php echo date('l d F Y', strtotime($listData['to_date'])) ?></span></td>
                                </tr>
                                <tr>
                                    <th> Reason</th>
                                    <td><span class="clr-999"><?php echo $listData['reason'] ?></span></td>
                                </tr>
                                <tr>
                                    <th> Status</th>
                                    <td>
                                        <span id="leave-status_<?php echo $listData['id'] ?>">
                                            <?php if ($listData['leave_status'] == '2') { ?>
                                                                                                <!--<i class="fa fa-check-circle-o "><i class="fa fa-exclamation-circle"><i class="fa fa-times-circle"> </i>-->
                                                <span class="btn btn-success btn-xs"> Approved</span></p>

                                            <?php } if ($listData['leave_status'] == '1') { ?>
                                                <p>
                                                    <span class="btn btn-warning btn-xs">  Pending</span></p>
                                            <?php } if ($listData['leave_status'] == '3') { ?>
                                                <p>
                                                    <span class="btn btn-danger btn-xs"> Rejected</span></p>
                                            <?php } ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php if (isset($listData['image_url']) && $listData['image_url'] != '') { ?>
                                <tr>
                                    <th> Attachment</th>

                                    <td>
                                        <span id="leave-status">
                                            <p><a href="<?php echo base_url() . 'assets/uploads/' . $listData['image_url'] ?>" target="_blank"><i class="fa fa-paperclip"></i>  seek_leave_certificate_<?php echo date('d F', strtotime($listData['from_date'])) ?> | <?php echo date('d F, Y', strtotime($listData['to_date'])) ?></a></p>
                                        </span>

                                    </td>

                                </tr>
                                <?php }?>
                                <?php if ($listData['leave_status'] == '2') { ?>
                                    <tr>
                                        <th> Approved By</th>
                                        <td>
                                            <?php echo $listData['reporting_manager_name'] ?>
                                        </td>
                                    </tr>
                                <?php } else { ?>
                                    <?php if ($listData['rep_mang_one_id'] == $user_summary['user_id'] || $listData['rep_mang_two_id'] == $user_summary['user_id']) { ?>
                                        <tr>
                                            <th class="table-btn-right">
                                        <div >
                                            <?php echo form_open('', array('id' => 'form_approve_leave' . $listData['id'], 'class' => 'form_approve_leave')); ?>
<!--                                            <button type="button" class="btn btn-sm btn-warning2" onclick="approveLeave('<?php echo $listData['id'] ?>')" id="approve_leave_<?php echo $listData['id'] ?>">
                                                Click to Approve
                                            </button>-->

                                            <input type="hidden" name="user_id" value="<?php echo $listData['user_id'] ?>">    
                                            <input type="hidden" name="leave_id" value="<?php echo $listData['leave_id'] ?>">    
                                            <input type="hidden" name="leave_type_id" value="<?php echo $listData['leave_type_id'] ?>">    
                                            <input type="hidden" name="leave_day" value="<?php echo $listData['leave_day'] ?>">    
                                            <input type="hidden" name="leave_status" value="<?php echo $listData['leave_status'] ?>">    
                                            <input type="hidden" name="no_of_days" value="<?php echo $listData['no_of_days'] ?>">    
                                            <?php echo form_close(); ?>
                                        </div>
                                        </th>

                                        </tr>
                                    <?php } ?>
                                <?php } ?>

                            </table>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!--Modal View Leaves-->
<script>


    /*for leave approved*/
    function approveLeave(leave_id) {
        var leaveAprrove = $("#form_approve_leave" + leave_id).serialize();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/approveLeave',
            data: leaveAprrove,
            success: function (data) {
//                alert(data);
                $("#mn_approve_leave_" + leave_id).remove();
                $("#mn_reject_leave_" + leave_id).remove();
                $("#approve_leave_" + leave_id).remove();
                $('#leave-status_' + leave_id).html('');
                $('#leave-status_' + leave_id).html('<span class="btn btn-success btn-xs"><i class="fa fa-check"> </i> Approved </span>');
                location.reload();
            }
        });
    }


</script>