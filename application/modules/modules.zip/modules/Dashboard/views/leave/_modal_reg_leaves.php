<!--Modal View Leaves-->
<?php // var_dump($leave_summary_reg);die?>
<?php if (isset($leave_summary_reg)) { ?>
    <?php foreach ($leave_summary_reg as $listData) { ?>  

        <div class="modal fade" id="leave-reg-<?php echo $listData['id'] ?>" role="dialog">
            <div class="modal-dialog modal-xxl">
                <div class="modal-content">   
                    <div class="modal-header padding-bottom-0">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        <h4>Leave Regularize</h4>
                    </div>

                    <div class="modal-body">
                        <div class="user-modal-slim">

                            <?php echo form_open('dashboard/regularize/' . $listData['id'], array('id' => 'form_regularize_id_' . $listData['id'], 'class' => 'form-horizontal form_regularize_id_' . $listData['id'])); ?>
                            <div class="row">
                                <div class="col-sm-12 note-<?php echo $listData['id'] ?>"></div>
                                <div class="clearfix"></div>
                                <div class="col-sm-12 margin-bottom-10">

<!--                                    <span class="pull-right">
                                        <button type="button" class="btn btn-xs btn-info"><i class="fa fa-exclamation-circle" title="Note : You can Regularize Leave once its approved"></i></button>
                                    </span>-->
                                    <?php //if ($listData['is_regularize'] == '0' && $listData['leave_status'] != 1  && $listData['leave_status'] != 3) { ?>
<!--                                        <div class="well">
                                            <button class="btn btn-info btn-xs" type="button" id="id-auto-reg" onclick="regularizedAuto('<?php //echo $listData['id'] ?>')">Click Here</button> 
                                            <span class="text-light-gray">to Regularized Automatically</span>
                                        </div>-->
                                    <?php //} ?>
                                    <input hidden value="<?php echo $listData['priviledge_deduction'] ?>" id="pl_<?php echo $listData['id'] ?>" name="pl_<?php echo $listData['id'] ?>">
                                    <input hidden value="<?php echo $listData['sl_cnt'] ?>" id="sl_<?php echo $listData['id'] ?>" name="sl_<?php echo $listData['id'] ?>">
                                    <input hidden value="<?php echo $listData['casual_deduction'] ?>" id="cl_<?php echo $listData['id'] ?>" name="cl_<?php echo $listData['id'] ?>">
                                    <input  hidden value="<?php echo $listData['paid_count'] ?>" id="paid_<?php echo $listData['id'] ?>" name="paid_<?php echo $listData['id'] ?>">
                                    <?php //if (isset($listData['par_cnt'])) { ?>
                                    <input  hidden value="<?php echo $listData['par_cnt'] ?>" id="par_<?php echo $listData['id'] ?>" name="par_<?php echo $listData['id'] ?>">
                                    <?php //} ?>
                                    <?php // if (isset($listData['mat_cnt'])) { ?>
                                    <input hidden  value="<?php echo $listData['mat_cnt'] ?>" id="mat_<?php echo $listData['id'] ?>" name="mat_<?php echo $listData['id'] ?>">
                                    <?php //} ?>
                                    <input hidden value="<?php echo $listData['no_of_days'] ?>" id="noofday_<?php echo $listData['id'] ?>" name="noofday_<?php echo $listData['id'] ?>">
                                </div>

                                <!--                                <span class="">Associate leave balance</span>-->
                                <div class="clearfix"></div>

                                <div class="col-sm-2 border-right">
                                    <div  class="" >
                                        <div class="all-padding-5 text-center text-primary">
                                            <span class=""> SICK LEAVE  <p class="text-center"><i class="fa fa-thermometer-empty fa-2x"> </i></p></span>                                        
                                        </div>
                                        <div class="text-center all-padding-5">
                                            <?php $sgray = ' '; $listData['leave_balance'][1]==0 ? $sgray = 'text-gray':''?>
                                            
                                            <button class="btn btn-default btn-xs sub-sick" type="button" id="sub" ><i class="fa fa-minus <?php echo $sgray?>"></i></button>
                                            <button  type="button" class="btn btn-default btn-xs" id="sick_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][1] ?>" class="field text-center no-border" >
                                                <?php echo isset($listData['leave_balance'][1]) ? $listData['leave_balance'][1] : '0' ?>
                                            </button>
                                            <button class="btn btn-default btn-xs add-sick" type="button" id="add" ><i class="fa fa-plus <?php echo $sgray?>"></i></button>
                                            <input type="hidden" value="<?php echo isset($listData['leave_balance'][1]) ? $listData['leave_balance'][1] : '0' ?>" id="sick-deducted">
                                            <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-2 border-right">
                                    <div  class="" >
                                        <div class="all-padding-5 text-center text-gray">
                                            <span class="">PRIVILEGE LEAVE <p class="text-center"><i class="fa fa-money fa-2x"></i></p></span>                                        
                                        </div>
                                        <div class="text-center all-padding-5">
                                            <?php $pgray = ' '; $listData['leave_balance'][0]==0 ? $pgray = 'text-gray':''?>
                                            <button class="btn btn-default btn-xs sub-p" type="button" id="sub" ><i class="fa fa-minus <?php echo $pgray?>"></i></button>
                                            <button  type="button" class="btn btn-default btn-xs"id="p_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][0] ?>" class="field text-center no-border" >
                                                <?php echo isset($listData['leave_balance'][0]) ? $listData['leave_balance'][0] : '0' ?>
                                            </button>
                                            <button class="btn btn-default btn-xs add-p" type="button" id="add" ><i class="fa fa-plus <?php echo $pgray?>"></i></button>
                                            <input type="hidden" value="<?php echo isset($listData['leave_balance'][0]) ? $listData['leave_balance'][0] : '0' ?>" id="pl-deducted">
                                            <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">

                                        </div>
                                    </div>
                                </div>


                                <div class="col-sm-2 border-right">
                                    <div  class="" >
                                        <div class="all-padding-5 text-center text-info">
                                            <span class="">CASUAL LEAVE <p class="text-center"><i class="fa fa-calendar-o  fa-2x"></i></p></span>                                        
                                        </div>
                                        <div class="text-center all-padding-5">
                                            <?php $cgray = ' '; $listData['leave_balance'][2]==0 ? $cgray = 'text-gray':''?>
                                            <button class="btn btn-default btn-xs c-sub" type="button" id="sub" ><i class="fa fa-minus <?php echo $cgray?>"></i></button>
                                            <button type="button" class="btn btn-default btn-xs" id="c_bal_<?php echo $listData['id'] ?>" value="<?php echo isset($listData['leave_balance'][2]) ? $listData['leave_balance'][2] : '0' ?>" class="field text-center no-border" >
                                                <?php echo isset($listData['leave_balance'][2]) ? $listData['leave_balance'][2] : '0' ?></button>
                                            <button class="btn btn-default btn-xs c-add" type="button" id="add" ><i class="fa fa-plus <?php echo $cgray?>"></i></button>
                                            <input type="hidden" value="<?php echo isset($listData['leave_balance'][2]) ? $listData['leave_balance'][2] : '0' ?>" id="cl-deducted">
                                            <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">

                                        </div>
                                    </div>
                                </div>


                                <div class="col-sm-2 border-right">
                                    <div  class="" >
                                        <div class="all-padding-5 text-center text-success">
                                            <span class="">TOTAL ADJUST <p class="text-center"><i class="fa fa-calculator fa-2x"></i></p></span>

                                        </div>
                                        <div class="text-center all-padding-5">

                                            <button type="button" class="btn btn-default btn-xs" type="text" id="adjust_bal<?php echo $listData['id'] ?>" value="0" class="field text-center no-border" >0</button>

                                        </div>
                                    </div>
                                </div>


                                <?php if (isset($listData['leave_balance'][3])) { ?>
                                    <div class="col-sm-2 border-right">
                                        <div  class="" >
                                            <div class="all-padding-5 text-center text-info">
                                                <span class="">PARENTAL LEAVE <p class="text-center"><i class="fa fa-child fa-2x"></i></p></span>                                        
                                            </div>
                                            <div class="text-center all-padding-5">
                                                <?php $pargray = ' '; $listData['leave_balance'][3]==0 ? $pargray = 'text-gray':''?>
                                            
                                                <button class="btn btn-default btn-xs par-sub" type="button" id="sub" ><i class="fa fa-minus <?php echo $pargray?>"></i></button>
                                                <button type="button" class="btn btn-default btn-xs" id="par_bal_<?php echo $listData['id'] ?>" value="<?php echo isset($listData['leave_balance'][3]) ? $listData['leave_balance'][3] : '0' ?>" class="field text-center no-border" >
                                                    <?php echo isset($listData['leave_balance'][3]) ? $listData['leave_balance'][3] : '0' ?></button>
                                                <button class="btn btn-default btn-xs par-add" type="button" id="add" ><i class="fa fa-plus <?php echo $pargray?>"></i></button>
                                                <input type="hidden" value="<?php echo isset($listData['leave_balance'][3]) ? $listData['leave_balance'][3] : '0' ?>" id="par-deducted">
                                                <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">

                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                <?php if (isset($listData['leave_balance'][4])) { ?>
                                    <div class="col-sm-2 border-right">
                                        <div  class="" >
                                            <div class="all-padding-5 text-center text-info">
                                                <span class="">MATERNITY LEAVE <p class="text-center"><i class="fa fa-child fa-2x"></i></p></span>                                        
                                            </div>
                                            <div class="text-center all-padding-5">
                                                <?php $matgray = ' '; $listData['leave_balance'][4]==0 ? $matgray = 'text-gray':''?>
                                            

                                                <button class="btn btn-default btn-xs mat-sub" type="button" id="sub" ><i class="fa fa-minus <?php echo $matgray?>"></i></button>
                                                <button type="button" class="btn btn-default btn-xs" id="mat_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][4] ?>" class="field text-center no-border" >
                                                    <?php echo isset($listData['leave_balance'][4]) ? $listData['leave_balance'][4] : '0' ?>></button>
                                                <button class="btn btn-default btn-xs mat-add" type="button" id="add" ><i class="fa fa-plus <?php echo $matgray?>"></i></button>
                                                <input type="hidden" value="<?php echo isset($listData['leave_balance'][4]) ? $listData['leave_balance'][4] : '0' ?>" id="mat-deducted">
                                                <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                <div class="col-sm-2 ">
                                    <div  class="" >
                                        <div class="all-padding-5 text-center text-danger">
                                            <span class="">LOSS OF PAY <p class="text-center"><i class="fa fa-exclamation-triangle fa-2x"></i></p></span>
                                        </div>
                                        <div class="text-center all-padding-5">

                                            <button class="btn btn-default btn-xs sub-loss" type="button" id="sub" ><i class="fa fa-minus"></i></button>
                                            <button type="button" class="btn btn-default btn-xs" type="text" id="loss_bal_<?php echo $listData['id'] ?>" value="0" class="field text-center no-border"  readonly="">
                                                0</button>
                                            <button class="btn btn-default btn-xs add-loss" type="button" id="add" ><i class="fa fa-plus"></i></button>
                                            <input type="hidden" value="<?php echo isset($listData['leave_balance'][0]) ? $listData['leave_balance'][0] : '0' ?>" id="loss-deducted">
                                            <input type="hidden" value="<?php echo $listData['id'] ?>" id="adjust-leave<?php echo $listData['id'] ?>">


                                        </div>
                                    </div>
                                </div>


                            </div>

                            <div class="margin-top-30"></div>

                            <div class="row">
                                <div class="col-sm-12 margin-top-20">
                                    <table class="table table-responsive">

                                                                                <!--                                    <tr>

                                                                                    <th width="30%">Applied</th>
                                                                                    <td><span class="clr-999">
                                        <?php echo date('d F, Y', strtotime($listData['createddate'])) ?>

                                                                                        </span>
                                                                                    </td>
                                                                                </tr>-->    
                                        <tr>
                                            <th width="10%">
                                                <span class="">
                                                    <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                        <img class="margin-left-20 img-rounded img-responsive img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                                    <?php } else { ?>
                                                        <img class="margin-left-20 img-circle img-responsive img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                    <?php } ?>
                                                </span>
                                            </th>
                                            <td>
                                                <p class="margin-bottom-0"><?php echo $listData['userfullname'] ?> <span class="text-gray"> | <?php echo $listData['employeeId'] ?></span></p>
                                                <p><span class="text-gray"><?php echo $listData['department_name'] ?>,<?php echo $listData['position_name'] ?></span></p>

                                            </td>
                                        </tr>

                                        <?php if ($listData['leave_day'] == '1') { ?>
                                            <tr>
                                                <th > Day</th>
                                                <td ><span class="text-info" title="Leave Day">Half Day</span></td>
                                            </tr>
                                        <?php } ?>
                                        <?php if ($listData['leave_day'] == '2') { ?>
                                            <tr>
                                                <th> Day</th>
                                                <td><span class="text-info" title="Leave Day">Full Day</span></td>
                                            </tr>
                                        <?php } ?>
                                        <tr>
                                            <th> No of days</th>
                                            <td><span class="label bg-aqua" title="No of Days"><?php echo $listData['no_of_days'] ?></span></td>
                                        </tr>

                                        <tr>
                                            <th>From | To</th>
                                            <td>
                                                <span class="clr-999"><?php echo date('l d F Y', strtotime($listData['from_date'])) ?> | <?php echo date('l d F Y', strtotime($listData['to_date'])) ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th width="20%"> Reason</th>
                                            <td width="80%"><span class="clr-999"><?php echo $listData['reason'] ?></span></td>
                                        </tr>

                                        <?php if (isset($listData['image_url']) && $listData['image_url'] != '') { ?>
                                            <tr>
                                                <th> Attachment</th>

                                                <td>
                                                    <span id="leave-status">
                                                        <p><a href="<?php echo base_url() . 'assets/uploads/' . $listData['image_url'] ?>" target="_blank"><i class="fa fa-paperclip"></i>  seek_leave_certificate_<?php echo date('d F', strtotime($listData['from_date'])) ?> | <?php echo date('d F, Y', strtotime($listData['to_date'])) ?></a></p>
                                                    </span>

                                                </td>

                                            </tr>
                                        <?php } ?>

                                        <tr>
                                            <th> Status</th>
                                            <td>
                                                <span >
                                                    <?php if ($listData['leave_status'] == '2') { ?>
                                                                                                                                                                                            <!--<i class="fa fa-check-circle-o "><i class="fa fa-exclamation-circle"><i class="fa fa-times-circle"> </i>-->
                                                        <span class="btn btn-success btn-xs"> Approved</span></p>

                                                    <?php } if ($listData['leave_status'] == '1') { ?>
                                                        <p>
                                                            <span class="btn btn-warning btn-xs">  Pending</span></p>
                                                    <?php } if ($listData['leave_status'] == '3') { ?>
                                                        <p>
                                                            <span class="btn btn-danger btn-xs"> Rejected</span></p>
                                                    <?php } ?>
                                                </span>
                                            </td>
                                        </tr>

                                    </table>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="row">
                                <div class="col-sm-12 ">
                                    <div class=" text-right">
                                        <input hidden name="leave_id" value="<?php echo $listData['id'] ?>">
                                        <input hidden name="associate_id_<?php echo $listData['id'] ?>" value="<?php echo $listData['user_id'] ?>">
                                        <?php if ($listData['is_regularize'] == '1') { ?>
                                            <button type="button" class="btn btn-success btn-sm" >Already Regularize</button>
                                        <?php } ?>
                                        <?php if ($listData['leave_status'] == '2' && $listData['is_regularize'] != '1') { ?>
                                            <button type="button" class="btn btn-warning2 btn-sm" onclick="regularizeLeave('<?php echo $listData['id'] ?>')">Submit</button>
                                        <?php } if ($listData['leave_status'] == '1') { ?>
                                            <button type="button" class="btn btn-default btn-sm" >Pending for Approval</button>
                                        <?php } if ($listData['leave_status'] == '3') { ?>
                                            <button type="button" class="btn btn-default btn-sm">Rejected</button>
                                        <?php } ?>
                                    </div> 
                                </div>
                            </div>
                            <input hidden id="sick_actual_bal_<?php echo $listData['id'] ?>" name="sick_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][1] ?>">
                            <input hidden id="privilege_actual_bal_<?php echo $listData['id'] ?>" name="privilege_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][0] ?>">
                            <input hidden id="casual_actual_bal_<?php echo $listData['id'] ?>" name="casual_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo $listData['leave_balance'][2] ?>">
                            <input hidden id="paid_actual_bal_<?php echo $listData['id'] ?>" name="paid_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo isset($listData['leave_balance'][5]) ? $listData['leave_balance'][5] : '0' ?>">
                            <input hidden id="par_actual_bal_<?php echo $listData['id'] ?>" name="par_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo isset($listData['leave_balance'][3]) ? $listData['leave_balance'][3] : '0' ?>">
                            <input hidden id="mat_actual_bal_<?php echo $listData['id'] ?>" name="mat_actual_bal_<?php echo $listData['id'] ?>" value="<?php echo isset($listData['leave_balance'][4]) ? $listData['leave_balance'][4] : '0' ?>">

                            <?php echo form_close(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!--Modal View Leaves-->
<script>
    $(document).ready(function () {

        var flag = 'null';
        $('.datepicker_to').click(function () {

            var date = $('.datepicker_to').val();
            var fromdate = $('.datepicker_from').val();


            if (date != '' && fromdate != '') {
                if (flag != fromdate) {
                    $(".datepicker_to").datepicker("destroy");
                    flag = fromdate;
                }

            }

            var start_date = $("#datepicker_from").val();
            $("#datepicker_to").datepicker({
                todayHighlight: true,
                weekStart: 1,
                daysOfWeekDisabled: [0, 6],
                startView: 'days',
                maxViewMode: "years",
                startDate: start_date,
                endDate: "12-31-2017",
            });
        });

        $("#single_datepicker").datepicker({
            todayHighlight: true,
            weekStart: 1,
            daysOfWeekDisabled: [0, 6],
            startView: 'days',
            maxViewMode: "years",
            startDate: "01-01-2017",
            endDate: "12-31-2017",
        });

//        ('').slimScroll();     

    });

</script>

<script type="text/javascript">


    //Sick Leave

    $('.add-sick').click(function () {
        //to get current leqave id
        var leave_id = $(this).next().next().val();
        if ($(this).prev().val() < 5 && $(this).prev().val() < $(this).next().val()) {
            $(this).prev().prev().find('i').removeClass('text-gray');
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);

        }else
            $(this).find('i').addClass('text-gray');
            
        
    });
    $('.sub-sick').click(function () {
        //to get current leqave id
        $(this).next().next().find('i').removeClass('text-gray');
        

        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
        if($(this).next().val() ==  0)
            $(this).find('i').addClass('text-gray');
    });


    //Casual Leave

    $('.c-add').click(function () {
        //to get current leqave id
        var leave_id = $(this).next().next().val();

        $(this).next().next().find('i').removeClass('text-gray');
        
        if ($(this).prev().val() < 5 && $(this).prev().val() < $(this).next().val()) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);

        }else
        $(this).find('i').addClass('text-gray');
    
    });
    $('.c-sub').click(function () {
        //to get current leqave id
        $(this).next().next().find('i').removeClass('text-gray');
        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close" class="margin-right-10"><span aria-hidden="true">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
        
    });


    //Parental Leave

    $('.par-add').click(function () {
        //to get current leqave id
        var leave_id = $(this).next().next().val();

        if ($(this).prev().val() < 5 && $(this).prev().val() < $(this).next().val()) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);

        }
    });
    $('.par-sub').click(function () {
        //to get current leqave id

        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {

            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
    });

    //Priviledge Leave
    $('.add-p').click(function () {
    
    
    
        var leave_id = $(this).next().next().val();

        if ($(this).prev().val() < 5 && $(this).prev().val() < $(this).next().val()) {
            $(this).prev().prev().find('i').removeClass('text-gray');
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);
            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);
        }else{
            $(this).find('i').addClass('text-gray');
            
        }

    });
    
    $('.sub-p').click(function () {
        
        $(this).next().next().find('i').removeClass('text-gray');
        var leave_id = $(this).next().next().next().next().val();

        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());
        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);
            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
        if($(this).next().val() ==  0)
            $(this).find('i').addClass('text-gray');
    });

    //Maternity Leave
    $('.mat-add').click(function () {
        var leave_id = $(this).next().next().val();

        if ($(this).prev().val() < 180) {
            $(this).prev().prev().find('i').removeClass('text-gray');
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);
            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);
        }
        else
            $(this).find('i').addClass('text-gray');
        

    });
    $('.mat-sub').click(function () {
        var leave_id = $(this).next().next().next().next().val();
        $(this).next().next().find('i').removeClass('text-gray');
        
        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());
        if (noofdays == adjustBal) {
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;
        }

        if ($(this).next().val() > 0) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);
            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
        
        if($(this).next().val() ==  0)
            $(this).find('i').addClass('text-gray');
    });

    //Loss of Pay
    $('.add-loss').click(function () {
        $(this).prev().prev().find('i').removeClass('text-gray');
        var leave_id = $(this).next().next().val();
        $(this).next().next().find('i').removeClass('text-gray');
        
        var adbal = $("#adjust_bal" + leave_id).val();
        var losval = $(this).val();
        var noofdays = parseFloat($("#noofday_" + leave_id).val());
        var adjustBal = parseFloat($("#adjust_bal" + leave_id).text());

        if (adjustBal < noofdays) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() + 0.5);

            var val = +$(this).prev().val() + 0.5;
            $(this).prev().val(val);
            $(this).prev().text(val);
        }
        else {
            $(this).find('i').addClass('text-gray');
            $('.note-' + leave_id).fadeIn(100);
            var alertNotify = '<div class="alert alert-success alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Success:</strong> Leave Successfully Adjust.</div>';
            $('.note-' + leave_id).html(alertNotify);
            $('.note-' + leave_id).focus();
            //$('.note').fadeOut(1000);
            return true;

        }
       

    });
    $('.sub-loss').click(function () {
        var leave_id = $(this).next().next().next().next().val();



        if ($(this).next().val() > 0) {
            $("#adjust_bal" + leave_id).text(+$("#adjust_bal" + leave_id).text() - 0.5);
            $(this).next().next().find('i').removeClass('text-gray');
            var vals = +$(this).next().val() - 0.5;
            $(this).next().val(vals);
            $(this).next().text(vals);
        }
         if($(this).next().val() ==  0)
            $(this).find('i').addClass('text-gray');
        
    });


</script>

<script>

    function regularizedAuto(leaveId) {
//        alert(leaveId);
        var casul_lvd = $("#cl_" + leaveId).val();
        var priv_lvd = $("#pl_" + leaveId).val();
        var sick_lvd = $("#sl_" + leaveId).val();
        var paid_lvd = $("#paid_" + leaveId).val();
        var par_lvd = $("#par_" + leaveId).val();
        var mat_lvd = $("#mat_" + leaveId).val();
        var noofdays = $("#noofday_" + leaveId).val();
//        alert(mat_lvd);

//        alert($("#c_bal_" + leaveId).val());
        $("#c_bal_" + leaveId).val(casul_lvd);
        $("#c_bal_" + leaveId).text(casul_lvd);
        $("#p_bal_" + leaveId).val(priv_lvd);
        $("#p_bal_" + leaveId).text(priv_lvd);
        $("#sick_bal_" + leaveId).val(sick_lvd);
        $("#sick_bal_" + leaveId).text(sick_lvd);

        $("#par_bal_" + leaveId).val(par_lvd);
        $("#par_bal_" + leaveId).text(par_lvd);

        $("#mat_bal_" + leaveId).val(mat_lvd);
        $("#mat_bal_" + leaveId).text(mat_lvd);

        $("#loss_bal_" + leaveId).val(paid_lvd);
        $("#loss_bal_" + leaveId).text(paid_lvd);
        
        $("#adjust_bal" + leaveId).text(noofdays);

        //effect
        $("#adjust_bal" + leaveId).effect("bounce");
        $("#sick_bal_" + leaveId).effect("bounce");
        $("#p_bal_" + leaveId).effect("bounce");
        $("#c_bal_" + leaveId).effect("bounce");
        $("#par_bal_" + leaveId).effect("bounce");
        $("#mat_bal_" + leaveId).effect("bounce");
        $("#loss_bal_" + leaveId).effect("bounce");



    }

    function regularizeLeave(leaveId) {


        var noofdays = parseFloat($("#noofday_" + leaveId).val());
        var adjustBal = parseFloat($("#adjust_bal" + leaveId).text());

        if (adjustBal < noofdays) {
            $('.note-' + leaveId).fadeIn(100);
            var alertNotify = '<div class="alert alert alert-warning alert-dismissible fade in" style="border-radius:5px;"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true" class="margin-right-10">×</span></button><strong>Warning:</strong> Please Regularize Leave</div>';            
            $('.note-' + leaveId).html(alertNotify);
            $('.note-' + leaveId).focus();
        }
        else {
            $("#cl_" + leaveId).val(parseFloat($("#c_bal_" + leaveId).text()));
            $("#pl_" + leaveId).val(parseFloat($("#p_bal_" + leaveId).text()));
            $("#sl_" + leaveId).val(parseFloat($("#sick_bal_" + leaveId).text()));
            $("#par_" + leaveId).val(parseFloat($("#par_bal_" + leaveId).text()));
            $("#mat_" + leaveId).val(parseFloat($("#mat_bal_" + leaveId).text()));
            $("#paid_" + leaveId).val(parseFloat($("#loss_bal_" + leaveId).text()));

//            var privilege_actual_bal = parseFloat($("#privilege_actual_bal_" + leaveId).val());
//            var sick_actual_bal = parseFloat($("#sick_actual_bal_" + leaveId).val());
//            var casual_actual_bal = parseFloat($("#casual_actual_bal_" + leaveId).val());
//            var parental_actual_bal = parseFloat($("#parental_actual_bal_" + leaveId).val());
//            
//            var deducted_cl = $("#cl_" + leaveId).val();
//            var deducted_pl = $("#p_bal_" + leaveId).val();
//            var deducted_sl = $("#sick_bal_" + leaveId).val();

//            var deducted_cl = $("#parental_bal" + leaveId).val();

            $("#form_regularize_id_" + leaveId).submit();
        }
    }
</script>



