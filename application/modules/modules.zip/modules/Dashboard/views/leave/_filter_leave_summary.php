<?php if (isset($leave_summary_details)) { ?>
    <?php foreach ($leave_summary_details as $listData) { ?>   
        <tr>
            <td>
                <i>
                    <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                    <?php } else { ?>
                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                    <?php } ?>
                </i>
                <p><?php echo $listData['userfullname'] ?></p>
                <p class="text-light-gray"><?php echo $listData['position_name'] ?></p>
            </td>
            <td>
                <?php foreach ($leave_type_list as $leaveObj) { ?>
                    <?php // var_dump($leaveObj);die;?>
                    <?php echo $leaveObj->id == $listData['leave_type_id'] ? $leaveObj->leavetype : '' ?>

                <?php } ?>
                <p><span class="text-light-gray">applied on <?php echo date('d M Y', strtotime($listData['createddate'])) ?></span></p>
            </td>
            <td>
                <p>
                    <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                </p>

            </td>
            <td>
                <p>
                    <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                </p>

            </td>

            <td><p class="label label-default "><?php echo $listData['no_of_days'] ?> days</p>
            </td>
            <td>
        <!-- <i class="fa fa-check text-success"></i> -->
                <p>
                    <?php if ($listData['leave_status'] == '2') { ?>
                        <span class="btn btn-success btn-xs">Approved</span></p>

                <?php } if ($listData['leave_status'] == '1') { ?>
                    <p>
                        <span class="btn btn-warning btn-xs">Pending</span></p>
                <?php } if ($listData['leave_status'] == '3') { ?>
                    <p>
                        <span class="btn btn-danger btn-xs">Rejected</span></p>
                <?php } ?>

            </p>
        </td>
        <td>
            <label class="btn btn-default btn-xs" title="View" data-toggle="modal" data-target="#leave-view-<?php echo $listData['leave_id'] ?>">
                <i class="fa fa-eye text-ccc handle" ></i>
            </label>



        </td>
        </tr>
    <?php } ?>
<?php }
?>
<?php if (!isset($leave_summary_details)) { ?>
    <div class="col-sm-12 text-center margin-top-30">
        <span ><i class="fa fa-plane fa-5x text-light-gray"></i></span>
        <p class="text-light-gray">No data found!</p>
    </div>
<?php } ?>
 