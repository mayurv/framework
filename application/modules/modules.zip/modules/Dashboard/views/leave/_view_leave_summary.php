<?php // var_dump($leave_type_list);die;   ?> 
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo base_url() ?>plugins/datatables/dataTables.bootstrap.css">

<?php // var_dump($all_lv);die;                                              ?>
<!-- appraisal block here -->

<!--<div class="col-sm-4 ">
    <div class="row white-bg">
         <canvas id="pieChart" style="height:80px"></canvas>
    </div>
   
</div>-->


<div class="white-bg all-padding-15 ">
    <div class="col-sm-12">
        <div class="leave-heading"><h4 >Leave Summary</h4></div>
    </div>



    <div class="col-md-12">

        <ul class="nav nav-tabs">
            <li class="active" onclick="activeTab('own')">
                <a href="#my-leave" data-toggle="tab" aria-expanded="true">
                    <i class="fa fa-plane"></i>My Leaves
                    <span class="label label-orange"><?php echo $own_count; ?></span>

                </a>
            </li>
            <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 4 || $user_summary['emprole'] == 1) { ?>
                <li class="" onclick="activeTab('team')">
                    <a href="#team-leave" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-users"></i>My Team Leaves

                        <span class="label label-orange "><?php echo $team_count; ?></span>
                    </a>
                </li>
            <?php } ?>


            <?php if ($user_summary['emprole'] == 4) { ?>
                <li class="" onclick="activeTab('all')">
                    <a href="#all-leave" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-users "></i>All Leaves
                        <span class="label label-orange"><?php echo count($all_lv); ?></span>
                    </a>
                </li>
            <?php } ?>

            <!--            <li class="pull-right">
                            <div class="col-sm-12">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-sm "><i class="fa fa-filter"></i></button>
                                    <button type="button" class="btn btn-default dropdown-toggle btn-sm" data-toggle="dropdown">
                                        <span class="fa fa-caret-down "></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#" onclick="filterLeave('all')"><i class="fa fa-list"> </i> All</a></li>
                                        <li><a href="#" onclick="filterLeave('2')"><i class="fa fa-check-circle-o"> </i> Approved</a></li>
                                        <li><a href="#" onclick="filterLeave('1')"><i class="fa fa-exclamation-circle"> </i> Pending</a></li>
                                        <li><a href="#" onclick="filterLeave('3')"><i class="fa fa-times-circle-o"> </i> Reject</a></li>
                                    </ul>
            
                                </div>
            
                            </div>
            
                        </li>-->
        </ul>

        <div class="tab-content transparent">

            <div class="tab-pane fade active in table-responsive" id="my-leave">
                <!--Own Leave summary-->

                <table id="dt-leave-summary-ind" class="table table-responsive margin-bottom-0">
                    <thead>
                        <tr>
                            <!--<th>Associate Code</th>-->
                            <th>Associate Name</th>
                            <th>Leave Type</th>
                            <th>From</th>
                            <th>To</th>
                            <th>No of Days</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="border-bg search-my-leave">
                        <?php // var_dump($own_lv);die;   ?>
                        <?php if (isset($own_lv)) { ?>

                            <?php foreach ($own_lv as $listData) { ?>

                                <tr>
                                    <!--<td><?php echo $listData['employeeId'] ?></td>-->
                                    <td>
                                        <i>
                                            <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                            <?php } else { ?>
                                                <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                            <?php } ?>
                                        </i>
                                        <p><?php echo $listData['userfullname'] ?></p>
                                        <p class="text-light-gray"><?php echo $listData['position_name'] ?></p>
                                    </td>
                                    <td>
                                        
                                        <p><span class="text-light-gray">applied on <?php echo date('d M Y', strtotime($listData['createddate'])) ?></span></p>
                                        <?php foreach ($leave_type_list as $leaveObj) { ?>
                                            <?php // var_dump($leaveObj);die;     ?>
                                            <p><?php echo $leaveObj->id == $listData['leave_type_id'] ? $leaveObj->leavetype : '' ?></p>

                                        <?php } ?>
                                    </td>
                                    <td>
                                        <p>
                                            <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                                        </p>
                                        <p class="label label-info">
                                            <?php echo date('l', strtotime($listData['from_date'])) ?>
                                        </p>

                                    </td>
                                    <td><p><?php echo date('d M Y', strtotime($listData['to_date'])) ?></p> 
                                        <p class="label label-info">
                                            <?php echo date('l', strtotime($listData['to_date'])) ?>
                                        </p></td>
                                    <td><p class="label label-default "><?php echo $listData['no_of_days'] ?> days</p>

                                    </td>
                                    <td>
        <!-- <i class="fa fa-check text-success"></i> -->
                                        <p>
                                            <?php if ($listData['leave_status'] == '2') { ?>
                                                        <!--<i class="fa fa-check-circle-o "><i class="fa fa-exclamation-circle"><i class="fa fa-times-circle"> </i>-->
                                                <span class="btn btn-success btn-xs"> Approved</span></p>

                                        <?php } if ($listData['leave_status'] == '1') { ?>
                                            <p>
                                                <span class="btn btn-warning btn-xs">  Pending</span></p>
                                        <?php } if ($listData['leave_status'] == '3') { ?>
                                            <p>
                                                <span class="btn btn-danger btn-xs"> Rejected</span></p>
                                        <?php } ?>

                                        </p>
                                    </td>
                                    <td>
                                        <label class="btn btn-default btn-xs" title="View" data-toggle="modal" data-target="#leave-view-<?php echo $listData['leave_id'] ?>">
                                            <i class="fa fa-eye text-ccc handle" ></i>
                                        </label>



                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
                <!--End Own Leave summary-->

            </div>

            <div class="tab-pane fade table-responsive" id="team-leave">
                <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 4 || $user_summary['emprole'] == 1) { ?>
                    <input type="hidden" id="id_filter_type" value="own">
                    <input type="hidden" id="user_id" value="<?php echo $user_summary['user_id'] ?>">
                    <!--Team Leave summary-->

                    <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 4 || $user_summary['emprole'] == 1) { ?>

                        <table id="dt-leave-summary-team" class="table  margin-bottom-0">
                            <thead>
                                <tr>
                                    <!--<th>Associate Code</th>-->
                                    <th>Associate Name</th>
                                    <th>Leave Type</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>No of days</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody class="border-bg search-team-leave">
                                <?php // var_dump($team_lv);die;?>
                                <?php if (isset($team_lv)) { ?>
                                    <?php foreach ($team_lv as $listData) { ?>   
                                        <tr>
                                            <!--<td><?php echo $listData['employeeId'] ?></td>-->
                                            <td>
                                                <i>
                                                    <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                                    <?php } else { ?>
                                                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                    <?php } ?>
                                                </i>
                                                <p><?php echo $listData['userfullname'] ?></p>
                                                <p class="text-light-gray"><?php echo $listData['department_name'] ?>, <?php echo $listData['position_name'] ?></p>
                                            </td>

                                            <td>
                                                
                                                <p><span class="text-light-gray">applied on <?php echo date('d M Y', strtotime($listData['createddate'])) ?></span></p>
                                                <?php foreach ($leave_type_list as $leaveObj) { ?>
                                                    <?php // var_dump($leave_type_list);die;  ?>
                                                    <p><?php echo $leaveObj->id == $listData['leave_type_id'] ? $leaveObj->leavetype : '' ?></p>

                                                <?php } ?>
                                            </td>
                                            <td>
                                                <p>
                                                    <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                                                </p>

                                                <p class="label label-info">
                                                    <?php echo date('l', strtotime($listData['from_date'])) ?>
                                                </p>

                                            </td>
                                            <td><p><?php echo date('d M Y', strtotime($listData['to_date'])) ?></p>
                                                <p class="label label-info">
                                                    <?php echo date('l', strtotime($listData['to_date'])) ?>
                                                </p></td>
                                            <td><p class="label label-default "><?php echo $listData['no_of_days'] ?> days</p>

                                            </td>
                                            <td>
                <!-- <i class="fa fa-check text-success"></i> -->
                                                <p>
                                                    <?php if ($listData['leave_status'] == '2') { ?>
                                                        <span class="btn btn-success btn-xs"> Approved</span></p>

                                                <?php } if ($listData['leave_status'] == '1') { ?>
                                                    <p>
                                                        <span class="btn btn-warning btn-xs"></i> Pending</span></p>
                                                <?php } if ($listData['leave_status'] == '3') { ?>
                                                    <p>
                                                        <span class="btn btn-danger btn-xs">Rejected</span></p>
                                                <?php } ?>

                                                </p>
                                            </td>
                                            <td>
                                                <label class="btn btn-default btn-xs" title="View" data-toggle="modal" data-target="#leave-view-<?php echo $listData['leave_id'] ?>">
                                                    <i class="fa fa-eye text-ccc handle" ></i>
                                                </label>


                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>




                            </tbody>
                        </table>
                    <?php } ?>



                    <!--End Team Leave summary-->
                    <?php
                    $active = '';
                } else {
                    $active = 'active'
                    ?>
                    <input type="hidden" id="id_filter_type" value="own">
                <?php } ?>


            </div>

            <?php if ($user_summary['emprole'] == 4) { ?>
                <!--all-leave  summary-->
                <div class="tab-pane fade table-responsive" id="all-leave">
                    <table id="dt-leave-summary-all" class="table margin-bottom-0">
                        <thead>
                            <tr>
                                <!--<th>Associate Code</th>-->
                                <th>Associate Name</th>
                                <th>Leave Type</th>
                                <th>From</th>
                                <th>To</th>
                                <th>No of Days</th>
                                <th>Manager Status</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody class="border-bg search-all-leave">
                            <?php // var_dump($leave_summary_details);die;?>
                            <?php if (isset($all_lv)) { ?>
                                <?php foreach ($all_lv as $listData) { ?>   
                                    <tr>
                                        <!--<td><?php echo $listData['employeeId'] ?></td>-->
                                        <td>
                                            <i>
                                                <?php if (isset($listData['profileimg']) && $listData['profileimg'] != '') { ?>
                                                    <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $listData['profileimg']; ?>">  
                                                <?php } else { ?>
                                                    <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                <?php } ?>
                                            </i>
                                            <p><?php echo $listData['userfullname'] ?></p>
                                            <p class="text-light-gray"><?php echo $listData['department_name'] ?>, <?php echo $listData['position_name'] ?></p>
                                        </td>
                                        <td>
                                            
                                            <p><span class="text-light-gray">applied on <?php echo date('d M Y', strtotime($listData['createddate'])) ?></span></p>
                                            <?php foreach ($leave_type_list as $leaveObj) { ?>
                                                <?php // var_dump($leaveObj);die;     ?>
                                                <p><?php echo $leaveObj->id == $listData['leave_type_id'] ? $leaveObj->leavetype : '' ?></p>

                                            <?php } ?>
                                        </td>
                                        <td>
                                            <p>
                                                <?php echo date('d M Y', strtotime($listData['from_date'])) ?>
                                            </p>
                                            <p class="label label-info">
                                                <?php echo date('l', strtotime($listData['from_date'])) ?>
                                            </p>

                                        </td>
                                        <td><p><?php echo date('d M Y', strtotime($listData['to_date'])) ?></p> 
                                            <p class="label label-info">
                                                <?php echo date('l', strtotime($listData['to_date'])) ?>
                                            </p></td>
                                        <td><p class="label label-default "><?php echo $listData['no_of_days'] ?> days</p>

                                        </td>
                                        <td>
            <!-- <i class="fa fa-check text-success"></i> -->
                                            <p>
                                                <?php if ($listData['leave_status'] == '2') { ?>
                                                    <span class="btn btn-success btn-xs"> Approved</span></p>

                                            <?php } if ($listData['leave_status'] == '1') { ?>
                                                <p>
                                                    <span class="btn btn-warning btn-xs"> Pending</span></p>
                                            <?php } if ($listData['leave_status'] == '3') { ?>
                                                <p>
                                                    <span class="btn btn-danger btn-xs">Rejected</span></p>
                                            <?php } ?>


                                        </td>
                                        <td>
                                            <label class="btn btn-default btn-xs" title="View" data-toggle="modal" data-target="#leave-view-<?php echo $listData['leave_id'] ?>">
                                                <i class="fa fa-eye text-ccc handle" ></i>
                                            </label>

                                            <?php isset($listData['is_regularize']) && $listData['is_regularize'] == 0 ? $btnClr = "btn-warning" : $btnClr = "btn-success" ?>
                                            <?php isset($listData['is_regularize']) && $listData['is_regularize'] == 0 ? $btnTitle = "Regularize" : $btnTitle = "Already" ?>
                                            <label class="btn <?php echo $btnClr ?>  btn-xs" title="View" data-toggle="modal" data-target="#leave-reg-<?php echo $listData['leave_id'] ?>">
                                                <i class="fa fa-cog"></i>
                                            </label>



                                        </td>
                                    </tr>
                                <?php } ?>
                            <?php } ?>
                        </tbody>
                    </table>

                </div>
                <!--all-leave summary-->


            <?php } ?>
        </div>

    </div>


    <div class="col-sm-12">

        <?php if (!isset($leave_summary_details)) { ?>
            <!--            <div class="col-sm-12 text-center margin-top-30">
                            <span ><i class="fa fa-plane fa-5x text-light-gray"></i></span>
                            <p class="text-light-gray">No data found!</p>
                        </div>-->
        <?php } ?>

        <!--<div class="pull-left margin-top-20"> Showing 1 to 10 of <?php //echo count($leave_summary_details) ?> entries</div>-->
        <!--        <div class="pull-right">                                            
                    <ul class="pagination pagination-sm">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" tabindex="-1">&laquo;</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#">&raquo;</a>
                        </li>
                    </ul>
                </div>-->
        <?php /// }      ?>
    </div>
</div>


<?php $this->load->view('leave/_modal_view_leaves'); ?>
<?php $this->load->view('leave/_modal_reg_leaves'); ?>


<script>
<?php if (($this->session->flashdata())) { ?>
        showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    var url = '<?php echo base_url(); ?>dashboard/LeaveSummary';
    $("#leave-own-id").click(function () {
        return false;

        $('#leave-reg-id').removeClass('active');
        $('#leave-team-id').removeClass('active');
        $('#leave-own-id').addClass('active');
        var user_id = $('#user_id').val();
        $('#id_filter_type').val('own');
        $.ajax({
            type: "POST",
            url: url,
            data: {'action': 'list', 'user_id': user_id},
            success: function (data) {
                $('.loader').hide();
                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                //                alert(parsed.content);
                if (parsed.content == null) {
                    $('.search-rs').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.search-rs').html(parsed.content);
                }
            }
        });
    });

    $("#leave-team-id").click(function () {
        return false;
        $('#id_filter_type').val('team');
        $('#leave-team-id').addClass('active');
        $('#leave-reg-id').removeClass('active');
        $('#leave-own-id').removeClass('active');
        var user_id = $('#user_id').val();
        $.ajax({
            type: "POST",
            url: url,
            data: {'action': 'list_dept', 'manager_id': user_id},
            success: function (data) {
                $('.loader').hide();
                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                //                alert(parsed.content);
                if (parsed.content == null) {
                    $('.search-rs').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.search-rs').html(parsed.content);
                }
            }
        });
    });


    $("#leave-reg-id").click(function () {

        return false;
        $('#leave-reg-id').addClass('active');
        $('#leave-team-id').removeClass('active');
        $('#leave-own-id').removeClass('active');
        var user_id = $('#user_id').val();
        $.ajax({
            type: "POST",
            url: url,
            data: {'action': 'list_reg', 'associate_id': user_id},
            success: function (data) {
                $('.loader').hide();
                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                //                alert(parsed.content);
                if (parsed.content == null) {
                    $('.search-rs').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.search-rs').html(parsed.content);
                }
            }
        });
    });
</script>

<script>

    function activeTab(filter_tab) {
        $('#id_filter_type').val(filter_tab);
    }


    var emp_url = '<?php echo base_url(); ?>dashboard/searchLeaveSummary';

    function filterLeave(filter_term) {
        $('.test').html('');
        search_leaves_summmary(filter_term, emp_url);
    }

    function search_leaves_summmary(filter_term, url) {
        var filter_type = $("#id_filter_type").val();
        if (filter_type == 'reg')
            return false;
        if (filter_type == '')
            filter_type = 'own'
        $.ajax({
            type: "POST",
            url: url,
            data: {'filter_term': filter_term, 'filter_type': filter_type},
            success: function (data) {
                $('.loader').hide();
                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                //                alert(parsed.content);
                if (parsed.content == null) {
                    $('.search-rs').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    //search-my-leave search-team-leave search-reg-leave
                    if (filter_type == 'own')
                        $('.search-my-leave').html(parsed.content);
                    if (filter_type == 'team')
                        $('.search-team-leave').html(parsed.content);
                    if (filter_type == 'reg')
                        $('.search-reg-leave').html(parsed.content);

                }
            }
        });
    }
</script>

<script>
</script>
