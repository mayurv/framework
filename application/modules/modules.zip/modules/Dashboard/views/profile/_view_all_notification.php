<?php //var_dump($leave_notification);die; ?>
<div class="row">
    <div class="col-sm-12">
        <div class="main-bg all-padding-15">
            <div class="col-sm-12">
                <h4 >All Notifications</h4>
            </div>
            <div class="col-sm-12">
                <?php if (isset($notification_details)) { ?>
                    <table id="dt-all-notification" class="table table-responsive ">
                        <thead>
                            <tr>
                                <th>Associate</th>
                                <th>Notification</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <?php foreach ($notification_details as $notificationData) { ?> 
                            <?php if ($notificationData['blog_post_type'] != '2') { ?>
                                <tr>
                                    <td>
                                        <p>
                                            <?php if (isset($notificationData['profileimg']) && $notificationData['profileimg'] != '') { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $notificationData['profileimg']; ?>">  
                                            <?php } else { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                            <?php } ?>
                                            <span><?php echo $notificationData['userfullname']; ?></span>
                                        </p>
                                        <p class="text-light-blue"><?php echo $notificationData['position_name']; ?>, <?php echo $notificationData['department_name']; ?></p>
                                    </td>
                                    <td><?php echo $notificationData['notification'] ?></td>
                                    <td>
                                    <?php $type = '';?>
                                    <?php if($notificationData['publish_status']=='1')
                                            $type = 'Common';
                                          else if($notificationData['publish_status']=='2')
                                            $type = 'Leave';  
                                          else if($notificationData['publish_status']=='3')
                                            $type = 'Announcement';  
                                          else if($notificationData['publish_status']=='4')
                                            $type = 'Notice';  
                                          else if($notificationData['publish_status']=='5')
                                            $type = 'Private';  
                                          else if($notificationData['publish_status']=='7')
                                            $type = 'Events';  
                                        ?>
                                    <span class="btn btn-xs btn-info"><?php echo $type ?></span>
                                </td>
                                    <td>
                                        <p><?php echo date('d F, Y', strtotime($notificationData['notification_date'])) ?></p>
                                        <p><?php echo date('H:i A', strtotime($notificationData['notification_date'])) ?></p>
                                    </td>
                                    <td><a href="<?php echo base_url() . $notificationData['url_path']; ?>" title="View Details"> <i class="fa fa-eye text-ccc"> </i></a></td>
                                </tr>
                            <?php } ?> 
                        <?php } ?> 
                    </table>



                <?php } ?>
            </div>

        </div>
    </div>
</div>