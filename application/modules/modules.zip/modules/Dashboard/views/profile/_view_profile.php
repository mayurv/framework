<?php // var_dump($leaves);die;                               ?>

<div id="loader-bg" style="display: none">
    <div class="loader-txt margin-bottom-10"><h3>We Make IT simple</h3></div>
    <div class="loader-animation" style="display: block">&#9632;&#9632;&#9632;&#9632;&#9632;</div>
</div>

<div class="row">
    <a href="#" class="scrollToTop"></a>
    <section class="col-lg-3 connectedSortable">
        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12">
                <div class="profile-bg">
                    <div class="box">
                        <div class="box-header">
                            &nbsp;
                            <!-- /.user-block -->
                            <div class="box-tools">                
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                            </div>
                            <!-- /.box-tools -->
                        </div>
                        <div class="box-body text-center">
                            <div class="profile-bg-img">
                                <?php if (isset($user_summary['profileimg']) && $user_summary['profileimg'] != '') { ?>
                                    <img class="profile-user-img img-responsive img-circle official-img" src="<?php echo base_url() . 'assets/uploads/' . $user_summary['profileimg']; ?>">  
                                <?php } else { ?>
                                    <img class="profile-user-img img-responsive img-circle official-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                <?php } ?>
                            </div>


                            <div class="user-block padding-top-30">
                                <h4 class="profile-username text-center"><?php echo $user_summary['userfullname']; ?>
                                    <span><?php if ($user_summary['isactive'] == '1') { ?>
                                            <i class="fa fa-circle text-success font-size-6 active-icon" title="Active"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-circle text-warning font-size-6 active-icon" title="In-Active"></i>
                                        <?php } ?>
                                    </span>
                                    <p><?php echo $user_summary['department_name']; ?>, 
                                        <span class="clr-999"><?php echo $user_summary['position_name']; ?></span></p>
                                    <?php ?>
                                    <p><span class="text-aqua"><?php echo $user_summary['member_since'] ?></span></p>
                                </h4>
                            </div>
                        </div>

                    </div>
                    <!-- /.box -->


                </div>
            </div>
        </div>

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <!-- Custom tabs (Charts with tabs)-->
                <div class="nav-tabs-custom">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs">
                        <?php $active = 'active';if ($user_summary['emprole'] != '1') { ?>
                            <li class="active"><a href="#notleave" data-toggle="tab">Leave
                                    <?php foreach ($balnce_leaves as $list) { ?>
                                        <span class="label label-warning" title="Leave Balance"><?php echo $list['tot'] - $list['bal'] > 0 ? $list['tot'] - $list['bal'] : '0' ?></span>
                                    <?php } ?>
                                </a>
                            </li>
                        <?php $active = '';} ?>
                            <li class="<?php echo $active?>"><a href="#notholiday" data-toggle="tab">Holiday
                                <span class="label label-warning"><?php count($holiday_list) ?></span>

                            </a></li>
                            <?php if ($user_summary['emprole'] != '1') { ?>
                        <li><a href="#nothistory" data-toggle="tab">History</a></li>
                            <?php } ?>
                    </ul>
                    <div class="tab-content no-padding">
                        <!-- Morris chart - Sales -->
                        <?php if ($user_summary['emprole'] != '1') { ?>
                            <div class="tab-pane active" id="notleave">

                                <div class="leave-chart-bg">
                                    <ul class="chart-legend clearfix">
                                        <li ><span class="label label-success">x</span> - leave type</li>
                                        <li ><span class="label label-success">y</span> - No of Days</li>
                                    </ul>
                                    <canvas id="barChart" style="height:250px"></canvas>
                                    <!--<canvas id="pieChart" style="height:40px; padding:5px;"></canvas>-->
                                    <!--                                <ul class="chart-legend clearfix">
                                    <?php // var_dump($leaves)?>
                                    <?php if (isset($leaves)) { ?>
                                        <?php foreach ($leaves as $leaveData) { ?> 
                                            <?php if ($leaveData['leavecode'] !== 'Paid') { ?>
                                                <?php echo $leaveData['leavecode'] ?>
                                                                                                                                                                                                </li>
                                            <?php } ?>                                    
                                        <?php } ?>                                    
                                    <?php } ?>                                    
                                                                    </ul>-->
                                </div>




                            </div>
                        <?php } ?> 
                        <?php $flag = 1; ?>
                        <div class="tab-pane <?php echo $active?>" id="notholiday">
                            <div class="tab-pane" id="notholiday">
                                <div class="list-holiday leave-chart-bg"> 
                                    <ul>
                                        <?php foreach ($holiday_list as $list) { ?>
                                            <?php if ($list['holidaydate'] > date('Y-m-d')) { ?>
                                                <?php if ($flag == 1) { ?>
                                                    <li class="text-danger ">
                                                        <div class="row">
                                                            <div class="col-sm-6 col-xs-6"><?php echo date("j F", strtotime($list['holidaydate'])); ?> <small class="clr-999"><?php echo date("l", strtotime($list['holidaydate'])); ?></small></div>

                                                            <div class="col-sm-6 col-xs-6"><small class="btn btn-danger btn-xs"><?php echo $list['holidayname']; ?></small></div>
                                                        </div>                      
                                                    </li>
                                                    <?php
                                                    $flag = 2;
                                                } else {
                                                    ?>
                                                    <li class="text-default">
                                                        <div class="row">
                                                            <div class="col-sm-6 col-xs-6"><?php echo date("j F", strtotime($list['holidaydate'])); ?> <small class="clr-999"><?php echo date("l", strtotime($list['holidaydate'])); ?></small></div>

                                                            <div class="col-sm-6 col-xs-6"><small><?php echo $list['holidayname']; ?></small></div>
                                                        </div>                      
                                                    </li>
                                                <?php } ?>
                                            <?php } else { ?>
                                                <li class="text-light-gray">
                                                    <div class="row">
                                                        <div class="col-sm-6 col-xs-6"><?php echo date("j F", strtotime($list['holidaydate'])); ?> <small class="clr-999"><?php echo date("l", strtotime($list['holidaydate'])); ?></small></div>

                                                        <div class="col-sm-6 col-xs-6"><small><?php echo $list['holidayname']; ?></small></div>
                                                    </div>                      
                                                </li>
                                            <?php } ?>
                                        <?php } ?>
                                    </ul>
                                </div> 
                            </div>
                        </div>

                        <div class="tab-pane" id="nothistory">
                            <div class="list-holiday leave-chart-bg"> 
                                <ul>
                                    <?php // var_dump($leave_type_list)?>
                                    <?php if (isset($leave_history)) { ?>
                                        <?php foreach ($leave_history as $leaveList) { ?>
                                            <li>
                                                <div class="row">
                                                    <div class="col-sm-7 col-xs-7">
                                                        <div>
                                                            <div class="margin-left-5">
                                                                <?php if ($leaveList['leave_status'] == '2') { ?>
                                                                    <i class="fa fa-check-circle text-success" title="Approved"></i>
                                                                <?php } if ($leaveList['leave_status'] == '1') { ?>
                                                                    <i class="fa fa-exclamation-circle text-warning" title="Pending"></i>
                                                                <?php } if ($leaveList['leave_status'] == '3') { ?>
                                                                    <i class="fa fa-times-circle text-danger" title="Rejected"></i>
                                                                <?php } ?>
                                                                <?php if (isset($leave_type_all[$leaveList['leave_type_id']])) { ?>
                                                                    <span class="margin-left-5" ><?php echo $leave_type_all[$leaveList['leave_type_id']]; ?></span>
                                                                    <p class="margin-left-20 text-aqua" >
                                                                        <small>
                                                                            <span class="label label-primary" title="No of Days"><?php echo $leaveList['no_of_days']; ?></span> 
                                                                            | <span class="label label-default" title="Applied On"><?php echo date("d M Y", strtotime($leaveList['createddate'])); ?></span></small>
                                                                    </p>
                                                                <?php } ?>
                                                            </div>

                                                        </div>

                                                    </div>
                                                    <div class="col-sm-5 col-xs-5">
                                                        <p title="From | To"><?php echo date("d M", strtotime($leaveList['from_date'])); ?> | <?php echo date("d M", strtotime($leaveList['to_date'])); ?><span class="clr-999"></span></p>
                                                        <p class="text-center"><?php echo date("Y", strtotime($leaveList['from_date'])); ?></p>
                                                        <!--<p><small class="clr-999"><?php echo date("d M Y", strtotime($leaveList['createddate'])); ?></small></p>-->
                                                    </div>
                                                </div>                      
                                            </li>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <div class="col-sm-12">
                                            No history found !
                                        </div>
                                    <?php } ?>
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row right here -->
        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Events</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->

                    <div class="box-body ">


                        <div id="carousel-example-generic" class="carousel slide">

                            <div class="carousel-inner">
                                <?php
                                $active = 'active';
                                foreach ($events_data as $event) {
                                    ?>
                                    <div class="item <?php echo $active ?>">
                                        <img src="<?php echo base_url() ?>assets/uploads/<?php echo $event->filename ?>" alt="<?php echo $event->id ?> slide" class="img-responsive" />
                                        <div class="carousel-caption">
                                            <h4><a class="text-white" href="<?php echo base_url() ?>events/gallery/<?php echo $event->id ?>"><?php echo $event->title ?></a></h4>
                                        </div>

                                    </div>
                                    <?php
                                    $active = '';
                                }
                                ?>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="fa fa-angle-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="fa fa-angle-right"></span>
                            </a>
                        </div>  

                    </div>

                    <!-- /.box-body -->
                    <!--                    <div class="box-footer text-right">
                                            1/<?php echo count($events_data) ?>
                                        </div>-->
                    <!-- /.box-footer -->
                </div>
            </div>
        </div>
        <!-- 1st row right here -->








    </section>
    <!-- Left col -->
    <section class="col-lg-6 connectedSortable">
        <!-- 1st row here -->
        <div class="row">
            <div class="col-sm-12">
                <!-- Custom tabs-->
                
                <div class="nav-tabs-custom margin-bottom-10">
                
                    <ul class="nav nav-tabs pull-right">
                        
                        <!-- <li class="active"><a href="#send-message" data-toggle="tab">
                          <i class="fa fa-comment-o"></i> Message</a></li> -->
                        
                        <li class="dropdown">
                            <?php if ($user_summary['emprole'] != '1') { ?>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-ellipsis-v"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li class="">
                                        <a href="#" data-toggle="modal" data-target="#apply-leave"><i class="fa fa-plane">  </i> Apply Leave</a>
                                    </li>

                                    <!--                                    <li>
                                                                            <a href="#" data-toggle="modal" data-target="#attendance-m">Attendance Management</a>
                                                                        </li>
                                    
                                                                        <li>
                                                                            <a href="#" data-toggle="modal" data-target="#conference-book">Conference Room</a>
                                                                        </li>
                                    
                                                                        <li>
                                                                            <a href="#" data-toggle="modal" data-target="#claim-reim">Claims & Reimbursement</a>
                                                                        </li>
                                                                        <li>
                                                                            <a href="#" data-toggle="modal" data-target="#book-appoinment">Book a Appoinment</a>
                                                                        </li> 
                                                                        <li>
                                                                            <a href="#" data-toggle="modal" data-target="#request-help">Request / HelpDesk </a>
                                                                        </li>
                                    
                                                                        <li>
                                                                            <a href="#" data-toggle="modal" data-target="#timesheet">Timesheet</a>
                                                                        </li>-->

                                </ul>
                            <?php } ?>
                        </li>


                    </ul>

                    <!--<div class="loader" style="display: block"></div>-->   
                    <div class="tab-content">
                        <!-- Message start -->

                        <?php $this->load->view('blog/_post_blog'); ?>
                        <!-- Message leave start -->

                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row here -->

        <!-- filter block here -->
        
        <div class="row">
            <div class="col-sm-12 ">
                <div class="filter-block pull-right margin-bottom-5">

                    <ul>
                        <!--                        <button  type="button" class="btn btn-default btn-xs" id="clear-text"> 
                                                    <i class="fa fa-refresh"></i>
                                                </button>-->
                        <li><a href="<?php echo base_url() ?>dashboard" title="Refresh Wall">
                                <button  type="button" class="btn btn-default btn-xs"> 
                                    <i class="fa fa-refresh"></i>
                                </button>
                            </a>
                        </li>
                        <li> |</li>
                        <li>                 
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle all-padding-0" data-toggle="dropdown"> All 
                                    <i class="fa fa-filter"> </i> <span class="caret"></span></button>
                                <ul class="dropdown-menu" role="menu" id="leaveFilter">
                                    <li onclick="filterByLeave('all')"><a><i class="fa fa-list"></i> All Post</a></li>
                                    <li onclick="filterByLeave('leave')"><a><i class="fa fa-plane"></i> Leaves </a></li>
                                    <li onclick="filterByLeave('announcement')"><a><i class="fa fa-bullhorn"></i> Announcement </a></li>
                                    <li onclick="filterByLeave('notice')"><a><i class="fa fa-pencil-square-o"></i> Notice </a></li>
                                    <li onclick="filterByLeave('department')"><a><i class="fa fa-building-o"></i> My Department </a></li>
                                    <li onclick="filterByLeave('events')"><a><i class="fa fa-calendar"></i> Events </a></li>
                                    <!--<li onclick="filterByLeave('private')"><a><i class="fa fa-lock"></i> Own </a></li>-->
                                    <!--<li onclick="filterByLeave('')"><a href="#">My Department</a></li>-->                    
                                </ul>
                            </div>
                        </li>
                        <li> |</li>

                        <li>Public</li>
                        <li> 
                            <div class="slideOne">  
                                <input type="checkbox"  id="slideOne" name="check" value="0"/>
                                <label for="slideOne"></label>
                            </div>
                        </li>
                        <li>Self</li>
                    </ul>

                    <!--             <div class="box-tools pull-right">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"> All 
                                        <i class="fa fa-filter"></i> <span class="caret"></span></button>
                                      <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>                    
                                      </ul>
                                    </div>
                                  <div class="filter-check-bg"> 
                                    All
                                  </div>
                                </div> -->
                </div>


            </div>
        </div>
        <!-- filter block here -->


        <!-- 2nd row here -->
        <div class="row">
            <div class="col-sm-12 blur-bck" >
                <!--                <div class="overlay">-->

                <input type="hidden" value="<?php echo count($blog_data); ?>" id="post_count">
                <!-- The timeline -->

                <ul class="timeline timeline-inverse">                  

                    
                    <?php $this->load->view('_timeline_div'); ?>




                </ul>
                <div id="id_attachblog"></div>
                <input hidden value="10" id="post_current_start">
                <input hidden value="10" id="post_limit">
                <?php if (isset($blog_data)) { ?>
                    <p class="text-center" id="id_loadmore">
                        <span class="handle"><i class="fa fa-history font-size-18 text-ccc"> Click to Load More....</i></span>                        
                    </p> 
                <?php } ?>
                <!--</div>-->

                <?php // $this->load->view('_blog_timeline');    ?>
            </div>




        </div>
        <!-- 2nd row here -->




    </section>
    <!-- /.Left col -->



    <!-- right col-->
    <section class="col-lg-3">     

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12">
                <!--                <div class="profile-bg">
                                    <div class="profile-bg-img">
                <?php if (isset($personal_detail) && $personal_detail['profile_image'] != '') { ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    <img class=" img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        <img class="media-object margin-top-0" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">  
                <?php } else { ?>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    <img class="media-object margin-top-0" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                <?php } ?>
                                    </div>
                
                                    <div class="box box-widget collapsed-box">
                                        <div class="box-header text-center">
                                            <div class="user-block padding-top-30">
                                                <h4 class="margin-bottom-0 text-info"><?php echo $user_summary['userfullname']; ?></h4>
                                                <small><?php echo $user_summary['position_name']; ?></small>
                                            </div>
                                             /.user-block 
                                            <div class="box-tools">                
                                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                                </button>
                                                 <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> 
                                            </div>
                                             /.box-tools 
                                        </div>
                
                                        <div class="box-body">                                     
                                            <p><i class="fa fa-phone fa-fw fa-lg"></i> &nbsp; &nbsp;<span  id="contact_id"> <?php // echo $communication_detail['mobile_number'];                                ?></span></p>
                                            <p>
                                                <i class="fa fa-envelope fa-fw fa-lg"></i>
                                                <a href="mailto: <?php // echo $user_summary['emailaddress'];                                ?>" class="text-info"> &nbsp; &nbsp;<?php // echo $user_summary['emailaddress'];                                ?></p></a>
                                            </p>
                                        </div>
                
                                         /.box-footer 
                                        <div class="box-footer">
                
                                            <i class="fa fa-map-marker fa-fw fa-lg"></i>
                
                                        </div>
                                         /.box-footer 
                                    </div>
                                     /.box 
                
                
                                </div>-->
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12">                    

                <div class="nav-tabs-custom">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#hall_fame" data-toggle="tab">
                                Hall of Fame
                                <small class="text-light-gray"> <?php echo date('F', strtotime($hall_of_fame['createddate'])) ?> </small>
                            </a></li>
                        <li><a href="#birthday" data-toggle="tab">Birthdays
                                <span class="label label-warning "><?php count($holiday_list) ?></span>
                            </a></li>

                    </ul>
                    <div class="tab-content no-padding">
                        <!-- Morris chart - Sales -->
                        <div class="tab-pane active" id="hall_fame">
                            <div class="hall-fame-bg">
                                <div class="associate-bg">
                                    <div class="associate-img">
                                        <?php if (isset($hall_of_fame)) { ?>
                                            <img class="img-rounded img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $hall_of_fame['profileimg']; ?>">
                                        <?php } else { ?>
                                            <img class="img-thumbnail img-responsive" src="<?php echo base_url() . 'assets/images/halloffame.png' ?>">
                                        <?php } ?>

                                    </div>
                                    <?php // var_dump($hall_of_fame);die;   ?>
                                    <div class="associate-content text-center">
                                        <h5>
                                            <p><?php echo $hall_of_fame['userfullname'] ? $hall_of_fame['userfullname'] : 'Yet To declare' ?> <small class="clr-999"><?php echo $hall_of_fame['employeeId'] ?></small></p>
                                            <p><p class="clr-999"><?php echo $hall_of_fame['position_name'] ?> | <?php echo $hall_of_fame['department_name'] ?></p></p>
                                            <?php if (isset($hall_of_fame['project_title'])) { ?>
                                                <p >

                                                <div class="bg-warning" title="Project | Client">
                                                    <?php echo $hall_of_fame['project_title'] ?> | 
                                                    <?php echo $hall_of_fame['client_name'] ?>
                                                    <i class="fa fa-info-circle text-ccc handle" title="<?php echo $hall_of_fame['comment'] ?>" ></i>
                                                </div>
                                                </p>
                                            <?php } ?>
                                        </h5>

                                    </div>
                                </div>

                            </div>
                        </div>


                        <div class="tab-pane" id="birthday">
                            <div class="hall-fame-bg">
                                <table class="">
                                    <tr>
                                        <th></th>
                                        <th></th>

                                    </tr>
                                    <?php foreach ($user_birthday_summary as $birthday_summary) { ?>
                                        <tr class="tab-pane">  
                                            <td>
                                                <i><?php if (isset($birthday_summary['profileimg']) && $birthday_summary['profileimg'] != '') { ?>
                                                        <img class="img-responsive img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $birthday_summary['profileimg']; ?>">  
                                                    <?php } else { ?>
                                                        <img class="img-responsive img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                    <?php } ?>
                                                </i>  
                                            </td>
                                            <td>

                                                <p><?php echo $birthday_summary['userfullname'] ?></p>
                                                <small class="text-light-gray"><?php echo $birthday_summary['department_name'] ?>, <?php echo $birthday_summary['position_name'] ?></small>
                                            </td>
                                            <td>
                                                <p class="margin-left-20 text-info">
                                                    <?php echo date('d F', strtotime($birthday_summary['dob'])) ?>
                                                </p>
                                                <!--<p class="margin-left-20"><small class="text-light-gray" title="Age">(<?php echo(date('Y') - date('Y m', strtotime($birthday_summary['dob']))) ?> years)</small></p>-->
                                                <p class="margin-left-20"><small class="text-light-gray" title="Age">(<?php echo(date('l', strtotime($birthday_summary['dob']))) ?>)</small></p>
                                            </td>                                            
                                        </tr>

                                    <?php } ?>
                                </table>



                            </div> 
                        </div>



                    </div>
                </div>









            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">
                            <!--<i class="fa fa-bell-o"></i>-->
                            Notification
                        </h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="list-holiday">
                            <?php if (isset($notification)) { ?>

                                <!-- inner menu: contains the actual data -->

                                <?php foreach ($notification as $notificationData) { ?>    
                                    <div class="item">

                                        <a href="<?php echo $notificationData['url_path'] ?>" class="clr-999">

                                            <p>
                                                <?php if (isset($notificationData['profileimg']) && $notificationData['profileimg'] != '') { ?>
                                                    <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $notificationData['profileimg']; ?>">  
                                                <?php } else { ?>
                                                    <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                <?php } ?>
                                                <i class="fa <?php echo $notificationData['notification_icon'] ?> clr-999"> </i>
                                                <?php echo $notificationData['notification'] ?>
                                            </p>
                                            <small class="pull-right text-light-gray"><?php echo date('d F, Y H:m A', strtotime($notificationData['notification_date'])) ?></small>
                                        </a>
                                    </div>
                                    <div class="clearfix margin-bottom-5"></div>

                                <?php } ?>    

                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 1st row right here -->


        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">
                            <!--<i class="fa fa-bell-o"></i>--> 
                            Announcement <span class="btn btn-xs btn-danger"><?php echo count($annoucement) ?></span></h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->

                    <div class="box-body ">

                        <div class="announcement-slim">
                            <div id="carousel-announcement" class="carousel slide">

                                <div class="carousel-inner">
                                    <?php $active = 'active'; // var_dump($annoucement);?>
                                    <?php foreach ($annoucement as $annValue) { ?>
                                        <?php $annValue['blog_category_id'] == 3 ? $icon = 'fa fa-bullhorn' : $icon = 'fa fa-flag-o' ?>
                                        <div class="item <?php echo $active ?>">
                                            <div class="col-sm-12 text-center">
                                                <i class="<?php echo $icon ?> fa-4x text-light-gray"></i>
                                            </div>

                                            <div class="col-sm-12 text-center">
                                                <p class="text-gray"><?php echo $annValue['blog_date']; ?> | <?php echo date('l', strtotime($annValue['blog_date'])); ?></p>
                                                <p ><?php echo $annValue['description']; ?></p>
                                                <hr>
                                                <p class="text-warning">
                                                    [ <?php
                                                    if ($annValue['publish_group_id'] == '0')
                                                        echo $annValue['blog_category_id'] == 3 ? 'Common Announcement' : 'Common Notice';
                                                    else
                                                        echo '<span class="text-bold">' . $user_summary['department_name'] . '</span>';
                                                    ?> ]

                                                </p>

                                            </div>

                                        </div>
                                        <?php
                                        $active = '';
                                    }
                                    ?>

                                </div>
                                <a class="left carousel-control" href="#carousel-announcement" data-slide="prev">
                                    <span class="fa fa-angle-left"></span>
                                </a>
                                <a class="right carousel-control" href="#carousel-announcement" data-slide="next">
                                    <span class="fa fa-angle-right"></span>
                                </a>
                            </div>  

                        </div>
                    </div>

                    <!--                     /.box-body 
                                        <div class="box-footer text-right">
                                            1/25
                                        </div>
                                         /.box-footer -->
                </div>
            </div>
        </div>
        <!-- 1st row right here -->






    </section>
    <!-- right col -->

</div>




<?php $this->load->view('modal/_leave_modal'); ?>
<?php $this->load->view('modal/_edit_leave_modal'); ?>
<?php $this->load->view('modal/_leave_reject_modal'); ?>
<?php $this->load->view('modal/_attendance_modal'); ?>
<?php $this->load->view('profile/_conference_booking'); ?>
<?php $this->load->view('modal/_timesheet_modal'); ?>
<?php $this->load->view('modal/_help_desk'); ?>
<?php $this->load->view('modal/_claim_modal'); ?>
<?php $this->load->view('modal/_appoinment_modal'); ?>




<script>
            $(document).ready(function () {

    $('#id_loadmore').click(function () {

    var post_current_start = $('#post_current_start').val();
            if (parseInt(post_current_start) < 10){
    return false;
    }
    if (parseInt(post_current_start) >= 10){
    $('#loader-bg').show();
            $('.loader-animation').show();
    }
    var post_filter = $("#slideOne").val();
            var post_limit = $('#post_limit').val();
            $.ajax({
            type: "POST",
                    url: '<?php echo base_url(); ?>dashboard/get_blogs',
                    data: {'current_status': post_filter, 'post_current_start': post_current_start, 'post_limit': post_limit},
                    success: function (data) {
                    $('#loader-bg').hide();
                            $('.loader-animation').hide();
//                    post_current_start = post_current_start + 10;
//                            var post_current_start = $('#post_current_start').val(post_current_start);
                            var parsed = $.parseJSON(data);
                            //for post filter(self-public)

                            var postdbcount = parsed.count;
                            $('#post_count').val(postdbcount);
                            if (postdbcount < 10){
                    post_current_start = parseInt(postdbcount);
                            $('#id_loadmore').html('<p><span> <i class="fa fa-frown-o font-size-18 "> No More Post Found.. </i></span></p>');
                    } else
                            post_current_start = parseInt(post_current_start) + parseInt(postdbcount);
//                            else
//                            post_current_start = post_current_start + 10;
                            //if (postdbcount > postcnt || postdbcount < postcnt) {

                            $('#post_count').val(postdbcount);
                            $('#post_current_start').val(post_current_start)
                            //                $('#blog_detail').val('');

                            $('.timeline').append(parsed.content);
                            $("#id-clock").remove();
                            //}
                    }
            });
    });
    });</script>

<script>

            window.setInterval(function () {

            var postcnt = $('#post_count').val();
                    var postdbcount = <?php echo count($blog_data); ?>;
                    var currentStatus = $('#slideOne').val();
                    $.ajax({
                    type: "GET",
                            url: '<?php echo base_url(); ?>dashboard/get_blogs',
                            data: {current_status: currentStatus},
                            success: function (data) {

                            var parsed = $.parseJSON(data);
                                    //for post filter(self-public)

                                    var postdbcount = parsed.count;
                                    $('#post_count').val(postdbcount);
                                    //                alert(postdbcount);
                                    //if (postdbcount > postcnt || postdbcount < postcnt) {

                                    $('#post_count').val(postdbcount);
                                    //                $('#blog_detail').val('');

                                    $('.timeline').html('');
                                    $('.timeline').html(parsed.content);
                                    //}
                            }
                    });
            }, 3000000);</script>

<!--Filter for public and private post-->
<script>
            $(document).ready(function () {

    //0 = public 99 = self
    $('#slideOne').on('change', function () {
    $('#loader-bg').show();
            $('.loader-animation').show();
//    $('.loader').show();
            $('.white-bg').addClass('overlay');
            var currentStatus = $('#slideOne').val();
            if (currentStatus == '0') {
    $('#slideOne').val('99');
            currentStatus = 99;
    }
    else {
    $('#slideOne').val('0');
            currentStatus = 0;
    }

    $.ajax({
    type: "POST",
            url: '<?php echo base_url(); ?>dashboard/get_blogs',
            data: {current_status: currentStatus},
            success: function (data) {
            $('.white-bg').removeClass('overlay');
                    $('#loader-bg').hide();
                    $('.loader-animation').hide();
//                    $('.loader').hide();
                    var parsed = $.parseJSON(data);
                    //for post filter(self-public)                
                    var postdbcount = parsed.count;
                    $('#post_count').val(postdbcount);
//                alert(postdbcount);
                    //if (postdbcount > postcnt || postdbcount < postcnt) {

                    $('#post_count').val(postdbcount);
                    $('#blog_detail').val('');
                    $('.timeline').html('');
                    $('.timeline').html(parsed.content);
                    //}
            }
    });
//        alert(this.value);
    });
    });</script>
<script>
            $(document).ready(function () {
    $(window).scroll(function () {



    if ($(this).scrollTop() > 100) {
    $('#toTop').fadeIn();
    } else {
    $('#toTop').fadeOut();
    }
    });
            $('#toTop').click(function () {
    $("html, body").animate({scrollTop: 0}, 600);
            return false;
    });
    });</script>

<script>

            $("#psot_id" +<?php echo $user_summary['user_id'] ?>).click(function () {
    var user_id = <?php echo $user_summary['user_id'] ?>;
            $("#form_post_id_" + user_id).submit();
    });</script>

<script>
            $(document).ready(function () {

    //Check to see if the window is top if not then display button
    $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
    $('.scrollToTop').fadeIn();
    } else {
    $('.scrollToTop').fadeOut();
    }
    });
            //Click event to scroll to top
            $('.scrollToTop').click(function () {
    $('html, body').animate({scrollTop: 0}, 800);
            return false;
    });
    });</script>
<!--Leave chart-->
<script src="<?php echo base_url('frontend/plugins/chartjs/Chart.min.js'); ?>"></script>
<script>
            $(document).ready(function () {

    $(function () {

    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
            var pieChart = new Chart(pieChartCanvas);
            var PieData = [
<?php if (isset($leaves)) { ?>
    <?php foreach ($leaves as $leaveData) { ?>
        <?php if ($leaveData['leavecode'] == 'Paid' && $leaveData['used_leaves'] >= 0) { ?>
                        {
                        value: <?php echo $leaveData['used_leaves'] ?>,
                                color: "<?php echo $leaveData['color_code'] ?>",
                                highlight: "<?php echo $leaveData['color_code'] ?>",
                                label: "<?php echo 'LOP' ?>",
                                title: "<?php echo 'Un-Paid Leaves' ?>",
                        },
        <?php } ?>
                    {
                    value: <?php echo $leaveData['alloted_leaves'] ?>,
                            color: "<?php echo $leaveData['color_code'] ?>",
                            highlight: "<?php echo $leaveData['color_code'] ?>",
                            label: "<?php echo $leaveData['leavename'] ?>",
                            title: "<?php echo $leaveData['leavename'] ?>",
                    },
    <?php } ?>
<?php } ?>
            ];
            var pieOptions = {
            //Boolean - Whether we should show a stroke on each segment
            segmentShowStroke: true,
                    //String - The colour of each segment stroke
                    segmentStrokeColor: "#fff",
                    //Number - The width of each segment stroke
                    segmentStrokeWidth: 1,
                    //Number - The percentage of the chart that we cut out of the middle
                    percentageInnerCutout: 50, // This is 0 for Pie charts
                    //Number - Amount of animation steps
                    animationSteps: 100,
                    //String - Animation easing effect
                    animationEasing: "easeOutBounce",
                    //Boolean - Whether we animate the rotation of the Doughnut
                    animateRotate: true,
                    //Boolean - Whether we animate scaling the Doughnut from the centre
                    animateScale: false,
                    //Boolean - whether to make the chart responsive to window resizing
                    responsive: true,
                    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
                    maintainAspectRatio: true,
                    //String - A legend template
                    legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
            };
            //Create pie or douhnut chart
            // You can switch between pie and douhnut using the method below.
            pieChart.Doughnut(PieData, pieOptions);
            barChartOptions.datasetFill = false;
            barChart.Bar(barChartData, barChartOptions);
    });
    });</script>

<script>
            function filterByLeave(filter_keyword) {
            $('#loader-bg').show();
                    $('.loader-animation').show();
                    var post_filter = $("#slideOne").val();
                    var post_limit = $('#post_limit').val();
                    $.ajax({
                    type: "POST",
                            url: '<?php echo base_url(); ?>dashboard/get_blogs',
                            data: {filter_by: filter_keyword},
                            success: function (data) {
                            $('.white-bg').removeClass('overlay');
                                    $('#loader-bg').hide();
                                    $('.loader-animation').hide();
//                    $('.loader').hide();
                                    var parsed = $.parseJSON(data);
                                    //for post filter(self-public)                
                                    var postdbcount = parsed.count;
                                    $('#post_count').val(postdbcount);
//                alert(postdbcount);
                                    //if (postdbcount > postcnt || postdbcount < postcnt) {

                                    $('#post_count').val(postdbcount);
                                    $('#blog_detail').val('');
                                    $('.timeline').html('');
                                    $('.timeline').html(parsed.content);
                                    //}
                            }
                    });
//        alert(this.value);
            }</script>
<?php foreach ($leaves as $leaveData) {
    ?>

<?php } ?>

<script>

    $(function () {

    var barChartCanvas = $("#barChart").get(0).getContext("2d");
            var barChart = new Chart(barChartCanvas);
            var barChartData = {
            labels: [<?php echo $leaves_label; ?>],
<?php if (isset($leaves)) { ?>
                datasets: [
    <?php //foreach ($leaves as $leaveData) {           ?>

                {
                label: "Alloted Leaves",
                        fillColor: "rgba(210, 214, 222, 1)",
                        strokeColor: "rgba(210, 214, 222, 1)",
                        pointColor: "rgba(210, 214, 222, 1)",
                        pointStrokeColor: "#c1c7d1",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: [<?php echo $data_bal; ?>]

                },
                {
                label: "Used Leaves",
                        fillColor: "rgba(60,141,188,0.9)",
                        strokeColor: "rgba(60,141,188,0.8)",
                        pointColor: "#3b8bba",
                        pointStrokeColor: "rgba(60,141,188,1)",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(60,141,188,1)",
                        data: [<?php echo $data_used; ?>]
                }
    <?php //}           ?>
<?php } ?>



            ]



            };
            var barChartOptions = {
            //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
            scaleBeginAtZero: true,
                    //Boolean - Whether grid lines are shown across the chart
                    scaleShowGridLines: true,
                    //String - Colour of the grid lines
                    scaleGridLineColor: "rgba(0,0,0,.05)",
                    //Number - Width of the grid lines
                    scaleGridLineWidth: 1,
                    //Boolean - Whether to show horizontal lines (except X axis)
                    scaleShowHorizontalLines: true,
                    //Boolean - Whether to show vertical lines (except Y axis)
                    scaleShowVerticalLines: true,
                    //Boolean - If there is a stroke on each bar
                    barShowStroke: true,
                    //Number - Pixel width of the bar stroke
                    barStrokeWidth: 2,
                    //Number - Spacing between each of the X value sets
                    barValueSpacing: 5,
                    //Number - Spacing between data sets within X values
                    barDatasetSpacing: 1,
                    //String - A legend template
                    legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
                    //Boolean - whether to make the chart responsive
                    responsive: true,
                    maintainAspectRatio: true
            };
            barChartOptions.datasetFill = false;
            barChart.Bar(barChartData, barChartOptions);
    });
</script>






