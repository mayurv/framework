<!-- timeline item start here-->
<div class="timeline-item padding-left-10">                         

    <div class="row">
        <div class="col-sm-10">
            <div class="timeline-header">
                <div class="pull-left">

                    <span class="text-info ">Baliram Kamble</span>


                    <span class="text-primary">Sick Leave</span>

                </div>
                <div class="pull-right">

                    <span class="badge badge-success">
                        <i class="fa fa-check"></i>
                    </span>                                    
                    <span class="badge badge-warning">
                        <i class="fa fa-exclamation"></i>
                    </span>
                    <span class="badge badge-danger">
                        <i class="fa fa-remove"></i>
                    </span>


                    <small class="text-right time"> applied on 
                        <span class="clr-999">01 Jan 2017</span>
                    </small>




                </div>

            </div>
        </div>

        <div class="col-sm-2 text-right">
            <div class="box-tools">
                <div class="btn-group">
                    <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-angle-down text-bold"></i></button>
                    <ul class="dropdown-menu pull-right" role="menu">
                        <li><a href="#">Approve</a></li>                                           
                        <li><a href="#">Cancel</a></li>
                        <li><a href="#" data-toggle="modal" data-target="#reject-leave">Reject</a></li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
    
    

    <div class="row">
        <div class="col-sm-12">
            <div class="timeline-body padding-bottom-15">
                Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems
            </div>
        </div>
    </div>

    <!--hidden blog data-->
    <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->



</div>
<!-- timeline item end here-->