<div class="white-bg all-padding-15 margin-bottom-30">
    <div class="col-sm-12">
        <div class="leave-heading"><h4 >Blog Activity Stream</h4></div>
    </div>

    <div class="col-sm-12">
        <div class="ibox ">
            <table id="dt-blog-activity" class="table table-responsive">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Associate Name</th>
                        <th>Type</th>

                        <th>Title</th>
                        <th>Department</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (isset($blog_activity)) { ?>
                        <?php foreach ($blog_activity as $value) { ?>
                            <?php
                            if ($value['blog_category_id'] == 1)
                                $blog_category = 'Common';
                            else if ($value['blog_category_id'] == 2)
                                $blog_category = 'Leave';
                            else if ($value['blog_category_id'] == 3)
                                $blog_category = 'Announcement';
                            else if ($value['blog_category_id'] == 4)
                                $blog_category = 'Notice';
                            else if ($value['blog_category_id'] == 7)
                                $blog_category = 'Events';
                            else
                                $blog_category = 'Other';
                            ?>

                            <tr>
                                <td width="22%">
                                    <button class="btn btn-xs btn-default"> 
                                        <?php echo date('l d F Y ', strtotime($value['blog_time'])) ?>
                                    </button>
                                    <button class="btn btn-xs btn-default"> 
                                        <?php echo date('h:i:s A ', strtotime($value['blog_time'])) ?>
                                    </button>
                                </td>
                                <td>
                                    <i>
                                        <?php if (isset($value['profileimg']) && $value['profileimg'] != '') { ?>
                                            <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $value['profileimg']; ?>">  
                                        <?php } else { ?>
                                            <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                        <?php } ?>
                                    </i>
                                    <p><?php echo $value['userfullname'] ?></p>
                                    <p class="text-light-gray"><?php echo $value['position_name'] ?></p>
                                </td>
                                <td>
                                    <button class="btn btn-xs btn-primary"> 
                                        <?php echo $blog_category ?>
                                    </button>
                                </td>
                                <td width="30%">
                                    <p class=""> <?php echo $value['title'] ?></p>
                                    <p> <span class="text-bold">Description </span> <?php echo $value['description'] ?></p>
                                </td>
                                <td>
                                    <?php echo $value['department_name'] ?>
                                </td>
                            </tr>

                        <?php } ?>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>