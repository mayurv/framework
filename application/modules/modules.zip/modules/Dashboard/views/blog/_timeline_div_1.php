<!--Associate leave div-->
<li id="post">                
    <div class="timeline-image">     
        <img class="media-object img-circle" src="http://demo_ci.com/assets/uploads/mwx-068-smita/profile/mwx-068-smita-profile-user_female.png">
    </div>

    <!-- timeline item start here-->
    <div class="timeline-item padding-left-10">                         

        <div class="row">
            <div class="col-sm-11">
                <div class="timeline-header">
                    <div class="pull-left">

                        <span class="text-info">Baliram Kamble</span>
                        <span class="clr-999">Sick Leave</span>

                    </div>
                    <div class="pull-right">

                        <span class="badge badge-success">
                            <i class="fa fa-check"></i>
                        </span>                                    
                        <span class="badge badge-warning">
                            <i class="fa fa-exclamation"></i>
                        </span>
                        <span class="badge badge-danger">
                            <i class="fa fa-remove"></i>
                        </span>


                        <small class="text-right time">  
                            <span class="clr-999">applied on 01 Jan 2017</span>
                        </small>




                    </div>

                </div>
            </div>

            <div class="col-sm-1 text-right">
                <div class="box-tools">
                    <div class="btn-group">
                        <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-angle-down text-bold"></i></button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#">Approve</a></li>                                           
                            <li><a href="#">Cancel</a></li>
                            <li><a href="#" data-toggle="modal" data-target="#reject-leave">Reject</a></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="timeline-body padding-bottom-15">
                    Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems
                </div>
            </div>
        </div>

        <!--hidden blog data-->
        <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->



    </div>
    <!-- timeline item end here-->
</li>
<!--Associate leave div-->

<!--Manager leave div-->
<li id="post">                
    <div class="timeline-image">     
        <img class="media-object img-circle" src="http://demo_ci.com/assets/uploads/mwx-068-smita/profile/mwx-068-smita-profile-user_female.png">
    </div>

    <!-- timeline item start here-->
    <div class="timeline-item padding-left-10">     

        <div class="row">
            <div class="col-sm-11">
                <div class="timeline-header">
                    <div class="pull-left">
                        <span class="text-info ">Baliram Kamble</span>

                        <span class="text-primary">Sick Leave</span>
                    </div>

                    <div class="pull-right">
                        <small class="time">  
                            <span class="clr-999">applied on 01 Jan 2017</span></small>
                    </div>
                </div>
            </div>
            <div class="col-sm-1 text-right">

                <div class="box-tools">
                    <div class="btn-group">
                        <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-angle-down text-bold"></i></button>
                        <ul class="dropdown-menu pull-right" role="menu">
                            <li><a href="#" data-toggle="modal" data-target="#edit-leave">Edit</a></li>
                            <li><a href="#">Cancel</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="timeline-body padding-bottom-0">
                    Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems Leave Apply for Data Lorems
                </div>
            </div>
        </div>


        <!--hidden blog data-->
        <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->

        <!-- reply-comment-main-bg-here -->

        <div class="reply-comment-main-bg">
            <!-- box-here -->  
            <div class="box no-shadow-box">
                <!-- box-header -->                             
                <div class="box-header all-padding-5">
                    <div class="box-tools pull-right">
                        <?php if (isset($data['comment'])) { ?>
                            <button type="button" class="btn btn-box-tool ">
                                <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                            </button>   
                        <?php } ?>                               
                    </div>
                </div>
                <!-- /.box-header -->
                <!--box-body -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <!-- reply-comment-main-bg-here -->

                            <div class="reply-comment-public">
                                <i class="fa fa-remove-square-o text-danger"></i>
                                <div class="box-comment">
                                    <img class="img-circle img-sm" src="http://demo_ci.com/assets/uploads/mwx-068-smita/profile/mwx-068-smita-profile-user_female.png">
                                    <div class="comment-text">
                                        <span class="username">SmitaU Walwekar                                                                    

                                            <span class=""><small class="clr-999"><i class="fa fa-clock-o"></i> 2:16 PM 
                                                </small></span>

                                        </span>
                                        <p>Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles, weebly ning heekya handango imeem plugg dopplr jibjab, movity jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle quora plaxo ideeli hulu weebly balihoo... </p>
                                    </div>
                                </div>
                            </div>

                            <!-- reply-comment-main-bg-here --> 


                        </div>
                    </div>
                </div>
                <!-- ./box-body -->                              
            </div>
            <!-- box-here -->  
        </div>

        <!-- reply-comment-main-bg-here -->   

    </div>
    <!-- timeline item end here-->
</li>
<!--Manager leave div-->