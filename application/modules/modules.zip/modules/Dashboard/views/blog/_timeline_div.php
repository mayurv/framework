<!-- timeline item -->
<?php // var_dump($blog_data);die; ?>
<?php
$i = 0;
$current_date = '';
$no_bolg_data = NULL;
?>
<?php if (isset($blog_data)) { ?>
    <?php foreach ($blog_data as $data) { ?>   


        <?php if ($current_date != $data['blog_date']) { ?>
            <li class="time-label">
                <span class="timline-btn-sm">
                    <?php echo $data['blog_date']; ?>
                </span>
            </li>
        <?php } ?>  

        <!--Only private post : 99-->
        <?php if ($data['user_id'] == $user_summary['user_id'] && $data['publish_group_id'] == '99') { ?>
            <?php $no_bolg_data = 'not_null'; ?>
            <?php $bg_color = '';
            if ($data['publish_group_id'] == '99')
                $bg_color = "blog-border-danger";
            ?>
            <li id="post_<?php echo $data['id'] ?>" class="<?php echo $bg_color ?>">   
                <div class="timeline-image">     
                    <img class="media-object img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                </div>

                <!-- timeline item start here-->
                <div class="timeline-item padding-left-10">  

                    <div class="row">
                        <div class="col-sm-11">
                            <div class="timeline-header">
                                <div class="pull-left">

                                    <p>
                                        <span class="text-info "><?php echo $data['userfullname'] ?></span>

                                        <span class="clr-999"><?php echo $data['title']; ?></span>
                                    </p>
                                    <p><small class="user-position-pd"><span class="clr-999 margin-bottom-5"><?php echo $data['department_name'] ?>,<?php echo $data['position_name'] ?></span></small></p>
                                </div>
                                <div class="pull-right">

                                    <small class="time text-light-gray"><i class="fa fa-clock-o text-light-gray"></i> <?php echo date('h:i A', strtotime($data['blog_time'])); ?></small>

                                </div>

                            </div>
                        </div>
                        <div class="col-sm-1">

                            <div class="box-tools">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-angle-down text-bold"></i></button>
                                    <ul class="dropdown-menu pull-right" role="menu">
                                        <!--<li><a href="#" onclick="edit_post(<?php echo $data['id'] ?>)" >Edit</a></li>-->
                                        <li><a  onclick="delete_post(<?php echo $data['id'] ?>)">Remove Post</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-sm-12">
                            <div class="timeline-body padding-bottom-0">
            <?php echo $data['description']; ?>
                            </div>
                        </div>
                    </div>
                    <?php ?>
            <?php //var_dump($data['image_url']) ?>
            <?php if (isset($data['image_url']) && $data['image_url'] != '') { ?>
                        <div class="margin-top-15"></div>
                        <div class="row">
                            <div class="col-sm-12">

                                <img class="feed-photo img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $data['image_url'] ?>" alt="Photo">
                            </div>                        
                        </div>
            <?php } ?>

                    <!--hidden blog data-->
                    <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->

                    <!-- reply-comment-main-bg-here -->

                    <div class="reply-comment-main-bg">
                        <!-- box-here -->  
                        <div class="box no-shadow-box">
                            <!-- box-header -->                             
                            <div class="box-header all-padding-5">
                                <div class="box-tools pull-right">
            <?php if (isset($data['comment'])) { ?>
                                        <button type="button" class="btn btn-box-tool ">
                                            <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                                        </button>   
            <?php } ?>                               
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!--box-body -->
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <!-- reply comment here -->
                                        <div class="comment_div_id_<?php echo $data['id'] ?> view-comment-1">
                                            <?php if (isset($data['comment'])) { ?>
                                                <?php $cnt = count($data['comment']); ?>
                <?php foreach ($data['comment'] as $commentResult) { ?>
                    <?php // var_dump($commentResult);  ?>
                                                    <div class="reply-comment-public">
                                                        <div class="box-comment">
                                                            <i class="fa fa-remove-square-o text-danger"></i>
                                                            <img class="img-circle img-sm img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $commentResult['profileimg']; ?>">
                                                            <div class="comment-text">
                                                                <span class="username"><?php echo $commentResult['userfullname'] ?>
                                                                    <small style="padding:0px 10px;" >
                                                                        <small class="clr-999"><i class="fa "></i><?php echo date('d F h:i A', strtotime($commentResult['comment_time'])); ?> </small> </small>
                                                                </span>                                                                
                                                                <p><?php echo $commentResult['comment'] ?> </p>
                                                            </div>
                                                        </div>
                                                    </div>       
                                                <?php } ?>

            <?php } ?>
                                        </div>
                                        <!-- reply comment here -->

                                        <!-- comment icon here -->
                                        <div class="share-info-bg">
                                            <ul class="list-inline">                               
                                                <li>
                                                    <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                                                        <?php if (isset($data['comment'])) { ?>
                                                            (<?php echo $data['comment'] ? count($data['comment']) : '0' ?>)
                                                            <?php
                                                        } else {
                                                            echo "(0)";
                                                        }
                                                        ?>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <!-- comment icon here -->
                                        <!-- comment box here -->
                                        <div class="reply-comment-box">
                                            <div class="input-group">
                                                <input name="comment_box_<?php echo $data['id'] ?>" id="comment_box_<?php echo $data['id'] ?>" class="form-control input-sm" placeholder="Type message..." >
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-info btn-sm" onclick="comment_post(<?php echo $data['id'] ?>)">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- comment box here -->
                                    </div>
                                </div>
                            </div>
                            <!-- ./box-body -->                              
                        </div>
                        <!-- box-here -->  
                    </div>

                    <!-- reply-comment-main-bg-here -->   

                </div>
                <!-- timeline item end here-->
            </li>
            <!--End Only private post : 99-->

            <!--Start All Public and departmental-->    
        <?php } if ($data['publish_group_id'] != '99') { ?>

            <!--Leave POST TYPE-->
            <?php if (($data['department_id'] == $user_summary['department_id'] || $user_summary['emprole'] == '1') && $data['blog_post_type'] == '2' && isset($data['leave_rquest_details'])) { ?>
                <?php $no_bolg_data = 'not_null'; ?>
                <?php $bg_color = '';
                if ($data['blog_category_id'] == '2')
                    $bg_color = "blog-border-warning";
                ?>
                <!--Leave div-->
                <li id="post_<?php echo $data['id'] ?>" class="<?php echo $bg_color ?>">                
                    <div class="timeline-image">   
                        <img class="media-object img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                    </div>

                    <!-- timeline item start here-->
                    <div class="timeline-item padding-left-10">                         

                        <div class="row">
                            <div class="col-sm-11">
                                <div class="timeline-header">
                                    <div class="pull-left">

                                        <p>
                                            <span class="text-teal">Leave Application</span> >
                                            <span class="text-info"><?php echo $data['userfullname'] ?> ></span> 
                                            <span class="clr-999"><?php echo $data['title'] ?></span>
                                        </p>
                                        <p><small class="user-position-pd"><span class="clr-999 margin-bottom-5"><?php echo $data['department_name'] ?>,<?php echo $data['position_name'] ?></span></small></p>
                                    </div>
                                    <div class="pull-right">   



                                        <span id="leave-status_<?php echo $data['leave_rquest_details']['id'] ?>">
                <?php if ($data['leave_rquest_details']['leave_status'] == '2') { ?>
                                                <i class="fa fa-check-circle text-success" title="Approved"></i>

                <?php } if ($data['leave_rquest_details']['leave_status'] == '1') { ?>
                                                <i class="fa fa-exclamation-circle text-warning" title="Pending"></i>

                <?php } if ($data['leave_rquest_details']['leave_status'] == '3') { ?>
                                                <i class="fa fa-times-circle text-danger" title="Rejected"></i>

                <?php } ?>
                                        </span>


                                        <small class="text-right time">  
                                            <span class="clr-999"><i class="fa fa-clock-o "></i> <?php echo date('h:i A', strtotime($data['createddate'])); ?></span>
                                        </small>
                                    </div>

                                </div>
                            </div>

                            <div class="col-sm-1 text-right">
                                <div class="box-tools">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                            <i class="fa fa-angle-down text-bold"></i></button>
                                        <ul class="dropdown-menu pull-right" role="menu" >
                                            <!--&& $user_summary['user_id'] == $leave['reporting_manager']-->
                                            <?php if (($user_summary['emprole'] == '3' || $user_summary['emprole'] == '1') && $data['leave_rquest_details']['user_id'] != $user_summary['user_id'] && ($data['leave_rquest_details']['leave_status'] == '1')) { ?>
                                                <li id="mn_approve_leave_<?php echo $data['leave_rquest_details']['id'] ?>"><a onclick="approveLeave('<?php echo $data['leave_rquest_details']['id'] ?>')"><i class="fa fa-play-circle-o"></i>Approve</a></li>  
                                                <li id="mn_reject_leave_<?php echo $data['leave_rquest_details']['id'] ?>"><a href="#" data-toggle="modal" data-target="#reject-leave-<?php echo $data['leave_rquest_details']['id'] ?>"><i class="fa fa-times-circle"></i>Reject</a></li>
                                            <?php } ?>
                                            <?php if ($data['leave_rquest_details']['user_id'] == $user_summary['user_id'] && ($data['leave_rquest_details']['leave_status'] == '1')) { ?>
                                                <li id="mn_cancel_leave_<?php echo $data['leave_rquest_details']['id'] ?>"><a onclick="delete_post(<?php echo $data['id'] ?>)"><i class="fa fa-trash-o"></i>Cancel</a></li>
                                                <!--<li><a onclick="delete_post(<?php echo $data['id'] ?>)">Remove Post</a></li>-->
                                            <?php } else { ?>
                    <?php if ($data['leave_rquest_details']['user_id'] == $user_summary['user_id']) { ?>
                                                            <!--<li ><i class="fa fa-ban text-gray"></i><span class="">Leave</span></li>-->
                    <?php } ?>
                <?php } ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="timeline-body ">
                                    <div class="row">
                <?php echo form_open('', array('id' => 'form_approve_leave' . $data['leave_rquest_details']['id'], 'class' => 'form_approve_leave')); ?>
                                        <div class="col-sm-12">
                                            <table class="table table-responsive leave-box-border">

                                                <tbody>
                                                    <tr>

                                                        <th width="25%">Applied Date</th>
                                                        <td><span class="clr-999">
                                                    <?php echo date('d F, Y', strtotime($data['leave_rquest_details']['createddate'])) ?>

                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <?php if ($data['leave_rquest_details']['leave_day'] == '1') { ?>
                                                        <tr>
                                                            <th> Day</th>
                                                            <td><span class="text-info" title="Leave Day">Half Day</span></td>
                                                        </tr>
                <?php } ?>
                                                    <?php if ($data['leave_rquest_details']['leave_day'] == '2') { ?>
                                                        <tr>
                                                            <th> Day</th>
                                                            <td><span class="text-info" title="Leave Day">Full Day</span></td>
                                                        </tr>
                <?php } ?>
                                                    <tr>
                                                        <th> No of days</th>
                                                        <td><span class="label bg-aqua" title="No of Days"><?php echo $data['leave_rquest_details']['no_of_days'] ?></span></td>
                                                    </tr>
                                                    <tr>
                <?php if ($data['leave_rquest_details']['from_date'] == $data['leave_rquest_details']['to_date']) { ?>
                                                            <th> Applied Date</th>                                                        
                                                            <td><span class="clr-999"><?php echo date('l d F Y', strtotime($data['leave_rquest_details']['from_date'])) ?> </span></td>
                <?php } else { ?>
                                                            <th> Applied From | To</th>                                                        
                                                            <td><span class="clr-999"><?php echo date('l d F Y', strtotime($data['leave_rquest_details']['from_date'])) ?> | <?php echo date('l d F Y', strtotime($data['leave_rquest_details']['to_date'])) ?></span></td>
                <?php } ?>
                                                    </tr>
                                                    <tr>
                                                        <th> Reason</th>
                                                        <td><span class="clr-999"><?php echo $data['leave_rquest_details']['reason'] ?></span></td>
                                                    </tr>
                                                    

                <?php if (isset($data['image_url']) && $data['image_url'] != '') { ?>

                                                        <tr>
                                                            <th> Attachment</th>

                                                            <td>
                                                                <span id="leave-status">
                                                                    <p><a href="<?php echo base_url() . 'assets/uploads/' . $data['image_url'] ?>" target="_blank"><i class="fa fa-paperclip"></i>  seek_leave_certificate_<?php echo date('d F', strtotime($data['leave_rquest_details']['from_date'])) ?> | <?php echo date('d F, Y', strtotime($data['leave_rquest_details']['to_date'])) ?></a></p>
                                                                </span>

                                                            </td>

                                                        </tr>
                <?php } ?>
                                                </tbody>

                                            </table>
                                        </div>
                                        <!--<input name="department_id_<?php // $data['leave_rquest_details']['id']                ?>" value="<?php // $data['leave_rquest_details']['leave_day']                ?>">-->    
                                        <input type="hidden" name="applied_user_id" value="<?php echo $data['leave_rquest_details']['user_id'] ?>">    
                                        <input type="hidden" name="user_id" value="<?php echo $data['leave_rquest_details']['user_id'] ?>">    
                                        <input type="hidden" name="leave_id" value="<?php echo $data['leave_rquest_details']['id'] ?>">    
                                        <input type="hidden" name="leave_type_id" value="<?php echo $data['leave_rquest_details']['leave_type_id'] ?>">    
                                        <input type="hidden" name="leave_day" value="<?php echo $data['leave_rquest_details']['leave_day'] ?>">    
                                        <input type="hidden" name="leave_status" value="<?php echo $data['leave_rquest_details']['leave_status'] ?>">    
                                        <input type="hidden" name="no_of_days" value="<?php echo $data['leave_rquest_details']['no_of_days'] ?>">    
                <?php echo form_close(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                <?php // if (isset($data['image_url']) && $data['image_url'] != '') {   ?>
                        <!--                            <div class="margin-top-15"></div>
                                                    <div class="row">
                                                        <div class="col-sm-12">
                        
                                                            <img class="feed-photo" src="<?php // echo base_url() . 'assets/uploads/' . $data['image_url']               ?>" alt="Photo">
                                                        </div>                        
                                                    </div>-->
                        <?php // }   ?>

                        <!-- If manger reply-comment-main-bg-here -->
                <?php // var_dump($data['leave_rquest_details']); ?>
                        <!--&& $user_summary['emprole'] == '5' condition removed-->
                <?php if (isset($data['leave_rquest_details']['approver_comments']) && $data['leave_rquest_details']['user_id'] == $user_summary['user_id']) { ?>

                            <div class="reply-comment-main-bg">
                                <!-- box-here -->  
                                <div class="box no-shadow-box">
                                    <!-- box-header -->                             
                                    <div class="box-header all-padding-0">
                                        <div class="box-tools pull-right">
                                            <?php if (isset($data['comment'])) { ?>
                                                <button type="button" class="btn btn-box-tool ">
                                                    <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                                                </button>   
                    <?php } ?>                               
                                        </div>
                                    </div>
                                    <!-- /.box-header -->
                                    <!--box-body -->

                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- reply-comment-main-bg-here -->

                                                <div class="reply-comment-public">
                                                    <i class="fa fa-remove-square-o text-danger"></i>
                                                    <div class="box-comment margin-top-bottom-0">
                                                        <img class="img-circle img-sm img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $reporting_manager_summary['profileimg']; ?>">
                                                        <div class="comment-text">
                                                            <p></p>

                                                            <p><span class="text-teal"><?php echo $user_summary['reporting_manager_name'] ?></span>
                                                                <span class=""><small class="clr-999"><i class="fa fa-clock-o"></i> <?php echo date('h:i A', strtotime($data['leave_rquest_details']['modifieddate'])); ?>
                                                                    </small>
                                                                </span>
                                                            </p>



                                                            <p><small class="user-position-pd"><span class="clr-999 margin-bottom-5"><?php echo $reporting_manager_summary['department_name'] ?>, <?php echo $reporting_manager_summary['position_name'] ?></span></small></p>

                                                            </span>                                                           
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <table class="table table-responsive leave-box-border">
                                                                        <tbody>
                                                                            <tr>
                                                                                <th> Approver Comment</th>
                                                                                <td><span class="clr-999"><?php echo $data['leave_rquest_details']['approver_comments'] ?></span></td>
                                                                            </tr>
                                                                            <tr>
                    <!--                                                                                <th> Approver Status</th>
                                                                                <td>
                                                                                    <span id="leave-status">
                                                                                <?php if ($data['leave_rquest_details']['leave_status'] == '2') { ?>
                                                                                                                                            <span class="badge badge-success handle" title="Approved">
                                                                                                                                                <i class="fa fa-check"></i>
                                                                                                                                            </span>
                                                                                <?php } if ($data['leave_rquest_details']['leave_status'] == '1') { ?>
                                                                                                                                            <span class="badge badge-warning handle" title="Pending for approval">
                                                                                                                                                <i class="fa fa-exclamation-circle "></i>                                            
                                                                                                                                            </span>
                                                                                <?php } if ($data['leave_rquest_details']['leave_status'] == '3') { ?>
                                                                                                                                            <span class="badge badge-danger handle" title="Rejected">
                                                                                                                                                <i class="fa fa-times-circle"></i>
                                                                                                                                            </span>
                    <?php } ?>
                                                                                    </span>

                                                                                </td>-->
                                                                            </tr>
                                                                        </tbody>

                                                                    </table>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- reply-comment-main-bg-here --> 


                                            </div>
                                        </div>
                                    </div>

                                    <!-- ./box-body -->                              
                                </div>
                                <!-- box-here -->  
                            </div>
                <?php } ?>

                        <!-- reply-comment-main-bg-here -->   

                        <!--hidden blog data-->
                        <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->



                    </div>
                    <!-- timeline item end here-->
                </li>
                <!--Leave div-->

            <?php } else { ?>

                <!--Post Annoucement Notice-->
                <?php if ($data['blog_post_type'] != '2') { ?>
                    <?php $no_bolg_data = 'not_null'; ?>
                    <?php
                    $bg_color = '';
                    if ($data['blog_category_id'] == '4' || $data['blog_category_id'] == '3') {
                        $bg_color = "blog-border-info";
                    }
                    ?>
                    <?php
                    if ($data['blog_category_id'] == '1') {
                        $bg_color = "blog-border-gray";
                    }
                    ?>
                    <?php
                    if ($data['blog_category_id'] == '7') {
                        $bg_color = "blog-border-success";
                    }
                    ?>
                    <?php
                    $title = '';
                    if ($data['blog_category_id'] == '4') {
                        $title = 'Notice';
                        $clss = 'text-warning';
                    } else if ($data['blog_category_id'] == '3') {
                        $title = 'Announcement';
                        $clss = 'text-warning';
                    } else {
                        $title = $data['title'];
                        $clss = '';
                    }
                    ?>


                    <li id="post_<?php echo $data['id'] ?>" class="<?php echo $bg_color ?>">
                        <div class="timeline-image">     
                            <img class="media-object img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                        </div>

                        <!-- timeline item start here-->
                        <div class="timeline-item padding-left-10"> 

                            <div class="row">
                                <div class="col-sm-11">
                                    <div class="timeline-header">
                                        <div class="pull-left">

                                            <p>
                                                <span class="text-info "><?php echo $data['userfullname'] ?> > </span>
                                                <span class="clr-999 "><span class="<?php echo $clss; ?>"><?php echo $title; ?></span>
                                            </p>

                                            <p><small class="user-position-pd"><span class="clr-999 margin-bottom-5"><?php echo $data['department_name'] ?>,<?php echo $data['position_name'] ?></span></small></p>
                                        </div>
                                        <div class="pull-right">

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        <!--<small class="text-primary">on <?php echo $data['blog_date']; ?></small>-->
                                            <small class="time clr-999"><i class="fa fa-clock-o "></i> <?php echo date('h:i A', strtotime($data['blog_time'])); ?></small>
                                        </div>


                                    </div>

                                </div>
                    <?php if ($data['createdby'] == $user_summary['user_id']) { ?>
                        <?php if ($data['blog_category_id'] != '7') { ?>
                                        <div class="col-sm-1 text-right">
                                            <div class="box-tools pull-right">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                                        <i class="fa fa-angle-down text-bold"></i></button>
                                                    <ul class="dropdown-menu pull-right" role="menu">
                                                        <!--<li><a onclick="edit_post(<?php echo $data['id'] ?>)" class="clr-999"><i class="fa fa-pencil clr-999"></i> Edit (Coming soon) </a></li>-->

                                                        <li><a onclick="delete_post(<?php echo $data['id'] ?>)"><i class="fa fa-times-circle clr-999"></i> Remove Post</a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                            <?php } ?>
                    <?php } ?>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="timeline-body padding-bottom-0">
                    <?php echo $data['description']; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if (isset($data['image_url']) && $data['image_url'] != '') { ?>
                                <div class="margin-top-15"></div>
                                <div class="row">
                                    <div class="col-sm-12">

                                        <img class="feed-photo img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $data['image_url'] ?>" alt="Photo">
                                    </div>                        
                                </div>
                    <?php } ?>

                            <!--hidden blog data-->
                            <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->

                            <!-- reply-comment-main-bg-here -->

                            <div class="reply-comment-main-bg">
                                <!-- box-here -->  
                                <div class="box no-shadow-box">
                                    <!-- box-header -->                             
                                    <div class="box-header all-padding-5 ">
                                        <div class="box-tools pull-right">
                    <?php if (isset($data['comment'])) { ?>
                                                <button type="button" class="btn btn-box-tool ">
                                                    <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                                                </button>   
                    <?php } ?>
                                        </div>
                                    </div>
                                    <!-- /.box-header -->

                                    <!--box-body -->
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- reply comment here -->
                                                <div class="comment_div_id_<?php echo $data['id'] ?> view-comment-1">
                    <?php if (isset($data['comment'])) { ?>
                        <?php $cnt = count($data['comment']); ?>
                        <?php foreach ($data['comment'] as $commentResult) { ?>
                            <?php // var_dump($commentResult);    ?>
                                                            <div class="reply-comment-public">
                                                                <i class="fa fa-remove-square-o text-danger"></i>
                                                                <div class="box-comment">
                                                                    <img class="img-circle img-sm img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $commentResult['profileimg']; ?>">
                                                                    <div class="comment-text">
                                                                        <span class="username "><?php echo $commentResult['userfullname'] ?> 
                                                                            <small class="pull-right" >
                                                                                <small class="clr-999"><i class="fa "></i><?php echo date('d F h:i A', strtotime($commentResult['comment_time'])) ?> </small> 
                                                                            </small>
                                                                        </span>
                                                                        <p><?php echo $commentResult['comment'] ?> </p>
                                                                    </div>
                                                                </div>
                                                            </div>       
                        <?php } ?>

                    <?php } ?>
                                                </div>
                                                <!-- reply comment here -->

                                                <!-- comment icon here -->
                                                <div class="share-info-bg">
                                                    <ul class="list-inline">                               
                                                        <li>
                                                            <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                    <?php if (isset($data['comment'])) { ?>
                                                                    (<?php echo $data['comment'] ? count($data['comment']) : '0' ?>)
                        <?php
                    } else {
                        echo "(0)";
                    }
                    ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- comment icon here -->
                                                <!-- comment box here -->
                                                <div class="reply-comment-box">
                                                    <div class="input-group">
                                                        <input name="comment_box_<?php echo $data['id'] ?>" id="comment_box_<?php echo $data['id'] ?>" class="form-control input-sm" placeholder="Type message..." >
                                                        <div class="input-group-btn">
                                                            <button type="button" class="btn btn-info btn-sm" onclick="comment_post(<?php echo $data['id'] ?>)">Send</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- comment box here -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- ./box-body -->                              
                                </div>
                                <!-- box-here -->  
                            </div>

                            <!-- reply-comment-main-bg-here -->   

                        </div>
                        <!-- timeline item end here-->
                    </li>

                <?php } ?>
                <?php $bg_color = 'bg-success';
            }
            ?>
        <?php } ?>
        <!--End All Public and departmental-->
        <?php $current_date = $data['blog_date']; ?>
    <?php } ?>
<?php } ?>
<!-- timeline item -->

<?php if (!isset($no_bolg_data)) { ?>
    <li id="no_more_post">
        <div class="all-padding-20 text-center text-light-gray">
            <i class="fa fa-files-o fa-5x"></i>
            <h3>No More Post Found ! </h3>       
        </div>
    <li>
    <li>
        <i class="fa fa-clock-o bg-gray" id="id-clock"></i>
    </li>
<?php } ?>
<!--Levae reject modal-->
<?php $this->load->view('modal/_leave_reject_modal'); ?>
<script>
    /*to edit post*/
    function edit_post(delete_post_id) {
//        $('#post_' + delete_post_id).html('');
//        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">Removed,</strong> Post removed successfully.</div>';
//        $('#post_' + delete_post_id).html(deleteNotify);
//        $.ajax({
//            type: "POST",
//            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
//            data: {delete_post_id: delete_post_id},
//            success: function (data) {
//
//            }
//        });
    }
    /*to delete post*/
    function delete_post(delete_post_id) {
//    alert(delete_post_id); return false;
        $('#loader-bg').show();
        $('.loader-animation').show();
        $('#post_' + delete_post_id).html('');
        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px; margin-left:15%" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
        $('#post_' + delete_post_id).html(deleteNotify);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
            data: {delete_post_id: delete_post_id},
            success: function (data) {
                $('#loader-bg').hide();
                $('.loader-animation').hide();

            }
        });
    }

    /*to comment on  post*/
    function comment_post(blog_id) {
//        $('.white-bg').addClass('overlay');
        $('#loader-bg').show();
        $('.loader-animation').show();
        var comment_value = $('#comment_box_' + blog_id).val();
        var currentStatus = $('#slideOne').val();
        var associate_id = <?php echo $user_summary['user_id'] ?>;
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/add_comment',
            data: {blog_id: blog_id, comment: comment_value, associate_id: associate_id, current_status: currentStatus},
            success: function (data) {
                $('#loader-bg').hide();
                $('.loader-animation').hide();
                $('#comment_box_' + blog_id).val('');
//                $('.white-bg').removeClass('overlay');
                $('.loader').hide();
                $('#blog_detail').val('');
                $('#post_count').val();
                var parsed = $.parseJSON(data);
                $('.timeline').html('');
                $('.timeline').html(parsed.content);

            }
        });


//        $('#post_' + delete_post_id).html('');
//        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
//        $('#post_' + delete_post_id).html(deleteNotify);
//        $.ajax({
//            type: "POST",
//            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
//            data: {delete_post_id: delete_post_id},
//            success: function (data) {
//
//            }
//        });
    }
</script>

<script>
    /*to hide comment*/
    function hide_comment(id) {
        $('.' + id).toggle("slow");
    }

    /*for leave approved*/
    function approveLeave(leave_id) {
        $('#loader-bg').show();
        $('.loader-animation').show();
        var leaveAprrove = $("#form_approve_leave" + leave_id).serialize();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/approveLeave',
            data: leaveAprrove,
            success: function (data) {
                $('#loader-bg').hide();
                $('.loader-animation').hide();
//                alert(data);
                $("#mn_approve_leave_" + leave_id).remove();
                $("#mn_reject_leave_" + leave_id).remove();
                $('#leave-status_' + leave_id).html('');
                $('#leave-status_' + leave_id).html('<span class="badge badge-success handle"><i class="fa fa-check"> Approved</i></span>');

            }
        });
    }


</script>