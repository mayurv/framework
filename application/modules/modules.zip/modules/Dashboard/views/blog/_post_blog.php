<!-- Message start -->

<div class="active tab-pane" id="send-message">

    <div class="post">                  
        <!-- /.user-block -->
        <!-- form start -->
        <form role="form" id="form_post_id_<?php echo $user_summary['user_id'] ?>" class="form_post_id">
            <?php ?>
            <!--<input value="" id="slideOnePost" name="slideOnePost">-->
            <div class="box-body all-padding-0">
                <div class="form-group margin-bottom-0">     
                    <textarea id="editor1" name="editor1" >
                                            
                    </textarea>

                    <textarea name="blog_detail"  id="blog_detail" class="textarea no-border" placeholder="What's in your mind?" style="width:100%;"></textarea>

<!--<textarea name="blog_detail"  id="blog_detail" class="form-control no-border textarea" rows="3" placeholder="What's in your mind?"></textarea>-->
                </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer padding-tp">

                <div class="row"> 
                    <div class="col-sm-12 "><div class="output"><p class="clr-999"></p></div></div>
                </div>
                <?php $col_sm_7 = '4';
                if ($user_summary['emprole'] != '1' && $user_summary['emprole'] != '4')
                    $col_sm_7 = '7';
                ?>

                <div class="row">
                    <div class="col-sm-<?php echo $col_sm_7 ?>">
                        <div class="demo-droppable">
                            <i class="fa fa-paperclip fa-lg text-ccc" title="Attach File"></i>
                        </div>

                        <div class="demo-droppable1">
                            <i class="fa fa-camera fa-lg text-ccc" title="Attach Image"></i>
                        </div>
                    </div>
                            <?php if ($user_summary['emprole'] == '1' || $user_summary['emprole'] == '4') { ?>
                        <div class="col-sm-3 padding-right-15">
                            <div class="form-group margin-bottom-0">
                                <?php
//                            echo form_dropdown(array('id' => 'publish_group_id', 'name' => 'publish_group_id', 'class' => 'form-control  input-sm'), $publish_group);
                                ?>
                                <select class="form-control  input-sm" id="blog_category_id" name="blog_category_id">
                                    <option value="1">Common Post</option>
                                    <option value="3">Announcement</option>
                                    <option value="4">Notice</option>
                                </select>
                            </div>
                        </div>
<?php } ?>

                    <div class="col-sm-3 padding-right-15">
                        <div class="form-group margin-bottom-0">
                            <?php
                            echo form_dropdown(array('id' => 'publish_group_id', 'name' => 'publish_group_id', 'class' => 'form-control  input-sm'), $publish_group);
                            ?>
                        </div>
                    </div>

                    <div class="col-sm-2 padding-left-0">
                        <div class="pull-right">
                            <button type="button" class="btn btn-info btn-sm" id="btn_post_blog_id" >Post</button>
                        </div>
                    </div>
                </div>
                <input type="hidden" value="<?php echo $user_summary['user_id'] ?>" id="associate_id" name="associate_id">

            </div>
        </form>
    </div>



    <!-- /.post -->
</div>
<!-- Message leave start -->

<script>


//    $( window ).load(function() {
//        $('.form_post_id').find('.btn-group').addClass('btn-group-xs');
//  // Run code
//});
    $(document).ready(function () {

        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>dashboard/post_blog/<?php echo $user_summary['user_id'] ?>', // override for form's 'action' attribute
                        type: 'post', // 'get' or 'post', override for form's 'method' attribute 
//                        clearForm: true,
                        resetForm: true, // reset the form after successful submit 

                    };
                    $('#btn_post_blog_id').click(function () {
                        $('#loader-bg').show();
                        $('.loader-animation').show();

                        var blog_detail = $("#blog_detail").val();
                        if (blog_detail != '')
                            $("#form_post_id_<?php echo $user_summary['user_id'] ?>").ajaxSubmit(options);
                        else {
                            $('#loader-bg').hide();
                            $('.loader-animation').hide();
                            alert('Post cannot be null');
                            $("#blog_detail").focus();
                        }

                    });
                    // pre-submit callback 
                    function showRequest(formData, jqForm, options) {
                        var fileName = $(".output").val();
                        $('.loader').show();
                        $('.white-bg').addClass('overlay');
                        return true;
                    }
                    // post-submit callback 
                    function showResponse(responseText, statusText, xhr, $form) {

                        $(".appendNewNot").append('<li class=""><ul class="menu">\n\
                        <li class="bg-notify" >\n\
                        <a href=""><p><i class="fa fa-rss text-yellow clr-999 margin-right-10"> </i><?php echo $user_summary['userfullname'] ?>, Posted on Timeline</p>\n\
                        <small class="pull-right text-info"><?php echo date('d F, Y H:i A') ?></small>\n\
                        </a></li></ul></li>');
                        var current_count = parseInt($('.id-badge').text());
                        var new_count = current_count + 1;
                        $('.id-badge').html('');
                        $('.id-badge').html(new_count);


                        $('#loader-bg').hide();
                        $('.loader-animation').hide();

                        //response  

//                        $("#blog_detail").val('');
                        $('#post_count').val();
                        $('.output').html('');
                        var parsed = $.parseJSON(responseText);
                        $('.timeline').html('');
                        $('.timeline').html(parsed.content);



                        return true;
                    }
                });

</script>

