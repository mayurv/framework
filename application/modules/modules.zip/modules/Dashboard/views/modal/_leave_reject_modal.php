<!-- apply leave modal -->

<?php if (isset($blog_data)) { ?>
    <?php foreach ($blog_data as $data) { ?>

        <?php if (($user_summary['emprole'] == '3' || $user_summary['emprole'] == '1') && isset($data['leave_rquest_details']) && $data['leave_rquest_details']['user_id'] != $user_summary['user_id'] && ($data['leave_rquest_details']['leave_status'] == '1')) { ?>
            <div class="modal fade" id="reject-leave-<?php echo $data['leave_rquest_details']['id'] ?>" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header all-padding-10">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title font-16">Reason for leave reject</h4>
                        </div>
                        <!-- modal body here --> 
                        <!--<div class="loader" style="display: none"></div>-->
                        <div class="modal-body">  
                            <?php echo form_open('dashboard/reject_leave/', array('id' => 'form_reject_leave_id_' . $data['leave_rquest_details']['id'], 'class' => 'form_reject_leave_id form-horizontal')); ?>
                            <!--<div class="loader" style="display: none">-->

                            <div class="form-group">
                                <div class="col-sm-12">
                                    <textarea class="form-control" id="leave_reason" name="leave_reason" rows="3" placeholder="Enter Reason"></textarea>
                                </div>
                            </div>            
                            <div class="form-group">
                                <div class="col-sm-12 text-right">
                                    <button type="button" class="btn btn-info btn-sm" id="reject_leave_id_<?php echo $data['leave_rquest_details']['id']; ?>" onclick="rejectLeave(<?php echo $data['leave_rquest_details']['id']; ?>)">Submit</button>                      
                                </div>
                                <input type="hidden" id="leave_id" name="leave_id" value="<?php echo $data['leave_rquest_details']['id']; ?>"> 
                                <input type="hidden" id="applied_user_id" name="applied_user_id" value="<?php echo $data['leave_rquest_details']['user_id']; ?>"> 
                            </div>
                            <?php echo form_close(); ?>
                            <!-- modal body here --> 
                        </div>      
                    </div>

                </div>
            </div>
        <?php } ?>
    <?php } ?>
<?php } ?>
<!-- apply leave modal -->

<!--Apply Leave Submit & Add new-->
<script>


    function rejectLeave(leaveId) {
        $('.modal').modal('hide');

        $('#loader-bg').show();
        $('.loader-animation').show();

//                 
//            var leave_reason = $('#leave_reason').val();
//            var leave_id = $('#leave_id').val();
        var rjectFormData = $('#form_reject_leave_id_' + leaveId).serialize();

        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/rejectLeave',
            data: rjectFormData,
            success: function (data) {

                $('#loader-bg').hide();
                $('.loader-animation').hide();

                if (data) {
                    $("#reject-leave-" + leaveId + ".close").click();
                    $('#leave-status').html('');
                    $('#leave-status').html('<span class="badge badge-danger" title="Rejected"><i class="fa fa-remove"></i></span>');
                    var parsed = $.parseJSON(data);
                    $('.timeline').html('');

                    $('.timeline').html(parsed.content);
                }

            }

        });
    }


</script>
