<!-- Book Appoinment modal -->
<div class="modal fade" id="book-appoinment" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Book Appoinment</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">

                    <div class="form-group">
                        <label for="claimfor" class="col-sm-3 control-label">Person</label>

                        <div class="col-sm-8">
                            <select class="form-control" style="width:100%;">
                                <option selected="selected">Manager one</option>
                                <option selected="selected">Manager two</option>
                                <option selected="selected">Manager three</option>
                                <option selected="selected">Manager four</option>
                            </select>
                        </div>

                    </div> 

                    <div class="form-group">
                        <label for="dt2" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="dt2">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="book-appoinment" class="col-sm-3 control-label">Reason</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="book-appoinment" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>          

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->

                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- Book Appoinment modal -->