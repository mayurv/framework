<!-- apply leave modal -->
<div class="modal fade" id="reject-leave" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Reason for leave rejects</h4>
            </div>
            <!-- modal body here --> 
            <!--<div class="loader" style="display: none"></div>-->
            <div class="modal-body">  
                <?php echo form_open_multipart('dashboard/apply_leave/' . $user_summary['user_id'], array('id' => 'form_applyleave_id', 'class' => 'form_applyleave_id form-horizontal')); ?>
                <!--<div class="loader" style="display: none">-->

                <div class="form-group">
                    <div class="col-sm-12">
                        <textarea class="form-control" id="leave_reason" name="leave_reason" rows="3" placeholder="Enter Reason"></textarea>
                    </div>
                </div>            
                <div class="form-group">
                    <div class="col-sm-12 text-right">
                        <button type="button" class="btn btn-info btn-sm" id="">Submit</button>                      
                    </div>
                </div>
                <?php echo form_close(); ?>
                <!-- modal body here --> 
            </div>      
        </div>
    </div>
</div>
<!-- apply leave modal -->

<!--Apply Leave Submit & Add new-->
<script>
    $(document).ready(function () {

        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>dashboard/apply_leave/<?php echo $user_summary['user_id'] ?>', // override for form's 'action' attribute
                        type: 'post', // 'get' or 'post', override for form's 'method' attribute 
                        clearForm: true,
//                        resetForm: true, // reset the form after successful submit 

                    };
                    $('#').click(function () {

//                var validateReuslt = $("#form_validate_education_id").valid();
//                $("#ajaxPostId").val('ajaxPost');
//                if ($("#form_validate_education_id").valid())
                        $("#form_applyleave_id").ajaxSubmit(options);
//                else
//                    return false;
                    });
                    // pre-submit callback 
                    function showRequest(formData, jqForm, options) {
//                alert('sss');
//                        $('.modal-body').addClass('overlay');
//                        $('.loader').show();
                        //response
                        return true;
                    }
                    // post-submit callback 
                    function showResponse(responseText, statusText, xhr, $form) {

//                        $('.loader').hide();
//                        $('.modal-body').removeClass('overlay');
                        
                        //response  
                        $("div").removeClass('error');

                        $("#leave_for").val($("#leave_for option:first").val());
                        $("#id_leave_type").val($("#id_leave_type option:first").val());

                        var parsed = $.parseJSON(responseText);

                        $('.education_display').html(parsed.education_cards);
                        showSuccess("Leave Applied Successfully");
                        return true;
                    }
                });</script>
<script>

    $(document).ready(function () {
        //Date picker
        //Date range picker 
        $('#range_leave_date').daterangepicker();
//        $('#datepicker, #single_leave_date').datepicker({
//            autoclose: true
//        });
        $('#id_leave_type').change(function () {
            var selected_item = $(this).val()
            if (selected_item == "2") {
                $('#fileId').show();
            } else {
                $('#fileId').hide();
            }
        });
        $('#id_half').click(function () {
            $("#dayTypeId").show();
            $("#halfDivId").show();
            $("#fullDivId").hide();
        });
        $("#id_full").click(function () {
            $("#dayTypeId").hide();
            $("#halfDivId").hide();
            $("#fullDivId").show();
        });
    });

</script>