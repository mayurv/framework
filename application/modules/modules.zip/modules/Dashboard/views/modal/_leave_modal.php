<?php // var_dump(count($leave_type_summary));die;                                                          ?>
<!-- apply leave modal -->
<div class="modal fade" id="apply-leave" role="dialog">
    <div class="modal-dialog ">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Leave Management</h4>
            </div>
            <!-- modal body here --> 
            <!--<div class="loader" style="display: none"></div>-->
            <div class="modal-body">  
                <?php echo form_open_multipart('dashboard/apply_leave/' . $user_summary['user_id'], array('id' => 'form_applyleave_id', 'class' => 'form_applyleave_id form-horizontal')); ?>
                <!--<div class="loader" style="display: none">-->

                <div class="col-sm-12 alert-error-msg">

                </div>

                <div class="test" style="display: none">
                    <div class="form-group" >
                        <div class="col-sm-12 text-center">
                            <span class="btn btn-lg btn-primary no_of_days" title="Total Number of Days"> No of Days</span>
                        </div>
<!--                        <label for="single_datepicker_to" class="col-sm-3 control-label">No of Days </label>
                        <div class="col-sm-8">                            
                            <div class="badge badge-info no_of_days">

                            </div>
                        </div>-->
                    </div>
                </div>

                <div class="form-group">
                    <label for="leave_day" class="col-sm-3 control-label">Leave</label>
                    <div class="col-sm-8">
                        <label class="radio-inline" >

                            <input id="id_half" type="radio" name="leave_day" checked="checked" value="1" data-error=".errorTxt1"> Half Day
                        </label>
                        <label class="radio-inline" >
                            <input id="id_full" type="radio" name="leave_day" value="2" data-error=".errorTxt1"> Full Day
                            <div class="errorTxt1"></div>
                        </label> 
                    </div>                                                                              
                </div>


                <div id="dayTypeId">
                    <div class="form-group">
                        <label for="leave_for" class="col-sm-3 control-label">Leave For</label>
                        <div class="col-sm-8">
                            <select name="leave_for" id="leave_for" class="form-control" style="width:100%;" data-error=".errorTxt2">
                                <option value="">Select Leave For</option>
                                <option value="1">First Half</option>
                                <option value="2">Second Half</option>

                            </select>
                            <div class="errorTxt2"></div>
                        </div>
                    </div>
                </div>

                <div id="halfDivId">
                    <div class="form-group ">
                        <label for="single_datepicker" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <?php
                                echo form_input(array(
                                    'name' => 'single_datepicker',
                                    'id' => 'single_datepicker',
                                    'class' => 'form-control pull-right single_leave_add',
                                    'data-format' => 'DD/MM/YYYY',
                                    'data-error' => 'errorTxt3'
                                ));
                                ?>
                            </div>
                            <div class="errorTxt3"></div>
                        </div>
                    </div> 
                </div>



                <div id="fullDivId" style="display: none">
                    <!--                    <div class="form-group ">
                                            <label for="range_leave_date" class="col-sm-3 control-label">Date</label>
                                            <div class="col-sm-8">
                                                <div class="input-group">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                                    <input name="range_leave_date" type="text" class="form-control pull-right" id="range_leave_date" data-error=".errorTxt4">
                                                </div>
                                                <div class="errorTxt4"></div>
                                            </div>
                    
                                        </div>  -->

                    <div class="form-group ">
                        <label for="single_datepicker_from" class="col-sm-3 control-label">From Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>

                                <?php
                                echo form_input(array(
                                    'name' => 'single_datepicker_from',
                                    'id' => 'single_datepicker_from',
                                    'class' => 'form-control pull-right single_datepicker_from',
                                    'data-format' => 'DD/MM/YYYY',
                                    'data-error' => 'errorTxt8'
                                ));
                                ?>
                            </div>
                            <div class="errorTxt8"></div>
                        </div>


                    </div> 
                    <div class="form-group ">
                        <label for="single_datepicker_to" class="col-sm-3 control-label">To Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar "></i>
                                </div>

                                <?php
                                echo form_input(array(
                                    'name' => 'single_datepicker_to',
                                    'id' => 'single_datepicker_to',
                                    'class' => 'form-control pull-right single_datepicker_to',
                                    'data-format' => 'DD/MM/YYYY',
                                    'data-error' => 'errorTxt9'
                                ));
                                ?>
                            </div>
                            <div class="errorTxt9"></div>
                        </div>                       
                    </div>


                </div>


                <div class="form-group">
                    <?php // var_dump($leave_type)?>
                    <label for="id_leave_type" class="col-sm-3 control-label">Leave Type</label>
                    <div class="col-sm-8">
                        <?php $leave_type = isset($leave_type) ? $leave_type : array('' => 'Select Type'); ?>
                        <?php echo form_dropdown(array('id' => 'id_leave_type', 'name' => 'id_leave_type', 'class' => 'form-control', 'data-error' => '.errorTxt5', 'disabled' => 'disabled'), $leave_type); ?>
                        <div class="errorTxt5"></div>
                        <input hidden id="associate_id" name="associate_id" value="<?php echo $user_summary['user_id'] ?>">
                    </div>
                </div>

                <?php if (isset($leave_type_summary)) { ?>
                    <div id="id-other" class="">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Leave Balance</label>
                            <div class="col-sm-8">
                                <table class="table table-responsive text-center border-top1 border-bottom1">
                                    <tr>
                                        <?php if (isset($leave_type_summary[3])) { ?>
                                            <td>Casual</td>
                                        <?php } ?>
                                        <?php if (isset($leave_type_summary[1])) { ?>
                                            <td>Privilege</td>
                                        <?php } ?>
                                        <?php if (isset($leave_type_summary[2])) { ?>
                                            <td>Sick</td>
                                        <?php } ?>

                                        <?php if (isset($leave_type_summary[4])) { ?>
                                            <?php if (array_key_exists(4, $leave_type_summary)) { ?>
                                                <td>Parental</td>
                                            <?php } ?>
                                        <?php } ?>
                                        <?php if (isset($leave_type_summary[5])) { ?>    
                                            <?php if (array_key_exists(5, $leave_type_summary)) { ?>
                                                <td>Maternity Leave</td>
                                            <?php } ?>
                                        <?php } ?>
                                        <?php // if (count($leave_type_summary) < 2) { ?>
                                            <td>LOP</td>
                                        <?php // } ?>

                                    </tr>
                                    <tr >
                                        <?php if (isset($leave_type_summary[3])) { ?>
                                            <td><span class="badge" style="background:#00c0ef">
                                                    <div id="cl">                                            
                                                        <?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>
                                                    </div>
                                                    <input hidden id="temp_cl_<?php echo $user_summary['user_id'] ?>" name="temp_cl_<?php echo $user_summary['user_id'] ?>" value="<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>">
                                                </span>
                                            </td>
                                        <?php } ?>
                                        <?php if (isset($leave_type_summary[1])) { ?>
                                            <td>
                                                <span class="badge" style="background:#d2d6de">
                                                    <div id="pl">                                            
                                                        <?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>
                                                    </div>
                                                    <input hidden id="temp_pl_<?php echo $user_summary['user_id'] ?>" name="temp_pl_<?php echo $user_summary['user_id'] ?>" value="<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>">
                                                </span>
                                            </td>
                                        <?php } ?>
                                        <?php if (isset($leave_type_summary[2])) { ?>
                                            <td>


                                                <span class="badge" style="background:#3c8dbc">
                                                    <div id="sl">
                                                        <?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>                                            
                                                    </div>
                                                    <input hidden id="temp_sl_<?php echo $user_summary['user_id'] ?>" name="temp_sl_<?php echo $user_summary['user_id'] ?>" value="<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>">
                                                </span>
                                            </td>
                                        <?php } ?>

                                        <?php if (isset($leave_type_summary[4])) { ?>
                                            <?php if (array_key_exists(4, $leave_type_summary)) { ?>
                                                <td>
                                                    <span class="badge" style="background:#1ab394">
                                                        <div id="par">
                                                            <?php echo $leave_type_summary[4] ?>                                            
                                                        </div>
                                                        <input hidden id="temp_par_<?php echo $user_summary['user_id'] ?>" name="temp_par_<?php echo $user_summary['user_id'] ?>" value="<?php echo $leave_type_summary[4] ?>">
                                                    </span>
                                                </td>
                                            <?php } ?>
                                        <?php } ?>

                                        <?php if (isset($leave_type_summary[5])) { ?>
                                            <?php if (array_key_exists(5, $leave_type_summary)) { ?>
                                                <td>
                                                    <span class="badge" style="background:#ffb3ff">
                                                        <div id="mat">
                                                            <?php echo $leave_type_summary[5] ?>                                            
                                                        </div>
                                                        <input hidden id="temp_mat_<?php echo $user_summary['user_id'] ?>" name="temp_mat_<?php echo $user_summary['user_id'] ?>" value="<?php echo $leave_type_summary[5] ?>">
                                                    </span>
                                                </td>
                                            <?php } ?>
                                        <?php } ?>
                                                <?php // if (count($leave_type_summary) < 2) { ?>
                                        <td><span class="badge" style="background:red">
                                                <div id="loss" value="0">
                                                    0</div>
                                                <input hidden id="temp_loss_<?php echo $user_summary['user_id'] ?>" name="temp_loss_<?php echo $user_summary['user_id'] ?>" value="0">
                                            </span>
                                        </td>
                                        <?php//  } ?>
                                    </tr>                            
                                </table>

                                <!--<div class="errorTxt5"></div>-->
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <div id="fileId" style="display: none">
                    <div class="form-group">
                        <label for="Attach" class="col-sm-3 control-label">Attach</label>
                        <div class="col-sm-8">
                            <?php
                            echo form_input(array(
                                'type' => 'file',
                                'name' => 'sl_attachment',
                                'id' => 'sl_attachment',
                                'placeholder' => 'Associate ID',
                                'value' => 'sl_attachment',
                                'data-error' => '.errorTxt6'
                            ));
                            ?>
                            <!--<input type="file" name="sl_attachment" value="sl_attachment" id="sl_attachment" data-error=".errorTxt6">-->
                            <div class="errorTxt6"></div>
                        </div>

                    </div> 
                </div>

                <div class="form-group">
                    <label for="leave_reason" class="col-sm-3 control-label">Reason</label>
                    <div class="col-sm-8">
                        <textarea class="form-control" id="leave_reason" name="leave_reason" rows="3" placeholder="Enter Reason" data-error=".errorTxt7"></textarea>
                        <div class="errorTxt7"></div>
                    </div>
                </div>            
                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-1 text-right">
                        <button type="reset" class="btn btn-sm" id="id-reset">Reset</button>                        
                        <button type="button" class="btn btn-info btn-sm" id="submit_leave">Submit</button>                      
                    </div>
                </div>

                <input type="hidden" value="<?php echo $user_summary['department_id'] ?>" name="department_id">
                <input type="hidden" value="<?php echo $user_summary['user_id'] ?>" name="applied_user_id">
                <?php echo form_close(); ?>
                <!-- modal body here --> 
            </div>      
        </div>
    </div>
</div>
<!-- apply leave modal -->

<!--Apply Leave Submit & Add new-->
<script>
    $(document).ready(function () {

        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>dashboard/apply_leave/<?php echo $user_summary['user_id'] ?>', // override for form's 'action' attribute
                        type: 'post', // 'get' or 'post', override for form's 'method' attribute 
                        clearForm: true,
//                        resetForm: true, // reset the form after successful submit 

                    };
                    $('#submit_leave').click(function () {


                        if ($("#form_applyleave_id").valid()) {
                            $('.modal').modal('hide');
                            $('#loader-bg').show();
                            $('.loader-animation').show();
                            $("#form_applyleave_id").ajaxSubmit(options);
                        }
                        else
                            return false;

                    });

                    // pre-submit callback 
                    function showRequest(formData, jqForm, options) {
//                alert('sss');
//                        $('.modal-body').addClass('overlay');
//                        $('.loader').show();
                        //response


//                        $('#form_applyleave_id').modal('hide');

                        return true;
                    }
                    // post-submit callback 
                    function showResponse(responseText, statusText, xhr, $form) {

                        $(".appendNewNotLeave").append('<li class=""><ul class="menu">\n\
                        <li class="bg-notify" >\n\
                        <a href=""><p><i class="fa fa-calendar-check-o text-light-blue clr-999 margin-right-10"> </i><?php echo $user_summary['userfullname'] ?>, Applied Leave</p>\n\
                        <small class="pull-right text-info"><?php echo date('d F, Y H:i A') ?></small>\n\
                        </a></li></ul></li>');
                        var current_count = parseInt($('.id-badge-leave').text());
                        var new_count = current_count + 1;
                        $('.id-badge-leave').html('');
                        $('.id-badge-leave').html(new_count);


                        $("div").removeClass('error');
                        $('.modal').modal('hide');
                        $("#leave_for").val($("#leave_for option:first").val());
                        $("#id_leave_type").val($("#id_leave_type option:first").val());

                        var parsed = $.parseJSON(responseText);
                        $('.timeline').html('');
                        $('.timeline').html(parsed.content);
                        $('#loader-bg').hide();
                        $('.loader-animation').hide();

                        return true;
                    }
                });
</script>
<script>

    $(document).ready(function () {

        var asscoaite_id = $('#associate_id').val();
        //Date picker
        //Date range picker 
        var today = new Date();
        var lastDate = new Date(today.getFullYear(), today.getMonth(0) + 1, 31);
        var startDate = new Date(today.getFullYear(), today.getMonth(0) - 1, 1);
        $('#range_leave_date').daterangepicker({
            Default: true,
            maxDate: "+1m +1w",
            beforeShowDay: function (t)
            {
                var valid = !(t.getDay() == 0 || t.getDay() == 6);  //disable saturday and sunday
                var _class = '';
                var _tooltip = valid ? '' : 'weekends are disabled';
                return [valid, _class, _tooltip];
            }
        });

        $("#single_datepicker_from").datepicker({
            todayHighlight: true,
            weekStart: 1,
            daysOfWeekDisabled: [0, 6],
            datesDisabled: [<?php echo $disabled_holiday ?>],
            startView: 'days',
            maxViewMode: "years",
            startDate: startDate,
            endDate: lastDate,
        });

        var flag = 'null';
        $('.single_datepicker_to').click(function () {

            var date = $('.single_datepicker_to').val();
            var fromdate = $('.single_datepicker_from').val();


            if (date != '' && fromdate != '') {
                if (flag != fromdate) {
                    $(".single_datepicker_to").datepicker("destroy");
                    flag = fromdate;
                }

            }
            var today = new Date();
            var lastDate = new Date(today.getFullYear(), today.getMonth(0) + 2, 31);
//            var startDate = new Date(today.getFullYear(), today.getMonth(0) - 1, 1);
            var start_date = $("#single_datepicker_from").val();

            $(".single_datepicker_to").datepicker({
                todayHighlight: true,
                weekStart: 1,
                daysOfWeekDisabled: [0, 6],
                datesDisabled: [<?php echo $disabled_holiday ?>],
                startView: 'days',
                maxViewMode: "years",
                startDate: start_date,
                endDate: lastDate,
            });

        });
        var today = new Date();
        var lastDate = new Date(today.getFullYear(), today.getMonth(0) + 1, 31);
//        var startDate = new Date(today.getFullYear(), today.getMonth(0) - 1, 1);
//        alert(lastDate);
        $("#single_datepicker").datepicker({
            todayHighlight: true,
            weekStart: 1,
            daysOfWeekDisabled: [0, 6],
            datesDisabled: [<?php echo $disabled_holiday ?>],
            startView: 'days',
            maxViewMode: "years",
            startDate: startDate,
            endDate: lastDate,
        });
//        $('#single_datepicker').click(function () {
//            $("#single_datepicker").datepicker({
//                todayHighlight: true,
//                weekStart: 1,
//                daysOfWeekDisabled: [0, 6],
//                startView: 'days',
//                changeYear: false,
////                minDate: new Date(2, 10 - 1, 25),
//
//
//            });
//
//        });

        $('#id-reset').click(function () {
//            alert('hi');
            $('.single_datepicker_to').removeAttr("disabled");
            $('#id_leave_type').removeAttr("disabled");
            $(".test").hide();
            $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
            $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
            $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
<?php if (isset($leave_type_summary)) { ?>
    <?php if (array_key_exists(4, $leave_type_summary)) { ?>
                    $('#par').text('<?php echo $leave_type_summary[4] ?>');
    <?php } ?>

    <?php if (array_key_exists(5, $leave_type_summary)) { ?>
                    $('#mat').text('<?php echo $leave_type_summary[5] ?>');
    <?php } ?>
<?php } ?>


        });

        $('#id_leave_type').change(function () {

            var leave_day_type = $('input[name="leave_day"]:radio:checked').val();

            $("#mat_id").remove();
            $("#id-other").removeClass('hidden');


//            alert(asscoaite_id);
//            var asscoaite_id = $(this).prev().val();
            if (leave_day_type == 2)
                $(".test").show();
            //to set seek leave attachment
            var selected_item = $(this).val()
            if (selected_item == "2") {
                $('#fileId').show();
            } else {
                $('#fileId').hide();
            }

            //
            var leave_day_type = $('input[name="leave_day"]:radio:checked').val();
//            alert(leave_day_type);
<?php if (isset($leave_type_summary)) { ?>
                var leavepl = <?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : '0;'; ?>//pl
                var leavesl = <?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : '0;'; ?>//sl
                var leavecl = <?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : '0;'; ?>//cl
<?php } ?>
<?php if (isset($leave_type_summary)) { ?>
    <?php if (array_key_exists(4, $leave_type_summary)) { ?>
                    var leavepar = <?php echo $leave_type_summary[4] ?>;//par
    <?php } ?>
    <?php if (array_key_exists(5, $leave_type_summary)) { ?>
                    var leavemat = <?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : '0;'; ?>//cl
    <?php } ?>
<?php } ?>
            $('#loss').text('0');

            var losofpay = 0;
            var currentId = $(this).val();

            if (leave_day_type == '1')
                var no_of_days = 0.5;
            else
                var no_of_days = $('.no_of_days').text();

            if (currentId == '1' || currentId == '3') {
                //if pl selected
                $('#loss').text('0');
                $('#temp_loss_' + asscoaite_id).val('0');

                $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
                $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
<?php if (isset($leave_type_summary[4])) { ?>
                    $('#par').text("<?php echo $leave_type_summary[4] ?>");
<?php } ?>

                if (currentId == '1' && no_of_days > leavepl) {

                    losofpay = no_of_days - leavepl;
                    $('#pl').text('0');
                    $('#temp_pl_' + asscoaite_id).val('0');

                    if (losofpay < leavecl) {
                        losofpay = leavecl - losofpay;//after deducted from cl
                        $('#cl').text(losofpay);
                        $('#temp_cl_' + asscoaite_id).val(losofpay);
                    } else {
                        losofpay = losofpay - leavecl;//after deducted from cl
                        $('#cl').text('0');
                        $('#temp_cl_' + asscoaite_id).val('0');
                        $('#loss').text(losofpay);
                        $('#temp_loss_' + asscoaite_id).val(losofpay);
                    }

                } else {
                    if (currentId == '1') {
                        losofpay = leavepl - no_of_days;
                        $('#pl').text(losofpay);
                        $('#temp_pl_' + asscoaite_id).val(losofpay);
                        $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                        $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                    }

                }
                //if cl selected
                if (currentId == '3' && no_of_days > leavecl) {

                    losofpay = no_of_days - leavecl;
                    $('#cl').text('0');
                    $('#temp_cl_' + asscoaite_id).val('0');

                    if (losofpay < leavepl) {
                        losofpay = leavepl - losofpay;//after deducted from pl
                        $('#pl').text(losofpay);
                        $('#temp_pl_' + asscoaite_id).val(losofpay);
                    } else {
                        losofpay = losofpay - leavepl;//after deducted from pl
                        $('#pl').text('0');
                        $('#temp_pl_' + asscoaite_id).val('0');
                        $('#loss').text(losofpay);
                        $('#temp_loss_' + asscoaite_id).val(losofpay);
                    }

                }
                else {
                    if (currentId == '3') {
                        losofpay = leavecl - no_of_days;
                        $('#cl').text(losofpay);
                        $('#temp_cl_' + asscoaite_id).val(losofpay);
                        $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                        $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                    }
                }

            }
//            alert('loss of pay' + losofpay);

            //parental leave
            if (currentId == '4') {

                if (no_of_days > leavepar) {
                    $(".alert-error-msg").fadeIn();

                    $(".alert-error-msg").html('<div class="alert alert-warning"> Note : You cannot apply more then 5 Parental Leaves </div>');
                    setTimeout(function () {
                        $('.alert-error-msg').fadeOut();
                    }, 5000); // <-- time in milliseconds

//                    alert('no of day exceeds');
                    $(".single_datepicker_from").val("");
                    $(".single_datepicker_to").val("");
                    $(".single_datepicker_from").focus();

                    $("#id_leave_type").prop("selectedIndex", 0);
<?php if (isset($leave_type_summary[4])) { ?>
                        $('#par').text("<?php echo $leave_type_summary[4] ?>");
<?php } ?>
                    return false;
                    $('#temp_par_' + asscoaite_id).val("0");
                    $('#par').text('0');
                }
                else {

                    losofpay = leavepar - no_of_days;
                    $('#par').text(losofpay);
                    $('#temp_par_' + asscoaite_id).val(losofpay);

                }

                $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#loss').text('0');
                $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');


            }

            //sick
            if (currentId == '2') {

                var fromdate = new Date($(".single_datepicker_from").val());
                var todate = new Date($(".single_datepicker_to").val());
                var single = new Date($("#single_datepicker").val());
                var currentdate = new Date();

                if (single > currentdate || (fromdate > currentdate || todate > currentdate)) {
                    $(".alert-error-msg").fadeIn();

                    $(".alert-error-msg").html('<div class="alert alert-info"> Note : You cannot apply sick leave for future date </div>');
                    setTimeout(function () {
                        $('.alert-error-msg').fadeOut();
                    }, 5000); // <-- time in milliseconds
                    $("#single_datepicker").val("");
                    $(".single_datepicker_from").val("");
                    $(".single_datepicker_to").val("");
                    $(".single_datepicker_from").focus();
                    $("#single_datepicker").focus();

                    $("#id_leave_type").prop("selectedIndex", 0);
<?php if (isset($leave_type_summary[4])) { ?>
                        $('#par').text("<?php echo $leave_type_summary[4] ?>");
<?php } ?>

                    $('#temp_par_' + asscoaite_id).val("0");
                    $('#par').text('0');
                    return false;
                }



                $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
<?php if (isset($leave_type_summary[4])) { ?>
                    $('#par').text("<?php echo $leave_type_summary[4] ?>");
<?php } ?>
                $('#loss').text('0');

                $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#temp_loss').val('0');

                if (no_of_days < leavesl) {
                    losofpay = leavesl - no_of_days;
                    $('#sl').text(losofpay);
                    $('#temp_sl_' + asscoaite_id).val(losofpay);
                } else {
                    losofpay = no_of_days - leavesl;

                    if (losofpay < leavecl) {
                        losofpay = leavecl - losofpay;//after deducted from cl
                        $('#cl').text(losofpay);
                        $('#temp_cl_' + asscoaite_id).val(losofpay);
                        losofpay = 0;
                    } else {
                        losofpay = losofpay - leavecl;//after deducted from cl
                        $('#cl').text('0');
                        $('#temp_sl_' + asscoaite_id).val('0');

                        $('#loss').text(losofpay);
                        $('#temp_loss_' + asscoaite_id).val(losofpay);

                        if (losofpay < leavepl) {
                            losofpay = leavepl - losofpay;//after deducted from pl
                            $('#pl').text(losofpay);
                            $('#temp_pl_' + asscoaite_id).val(losofpay);
                            losofpay = 0;
                        } else {
                            losofpay = losofpay - leavepl;//after deducted from pl
                            $('#pl').text('0');
                            $('#temp_pl_' + asscoaite_id).val('0');

                            $('#loss').text(losofpay);
                            $('#temp_loss_' + asscoaite_id).val(losofpay);
                        }
                    }

                    $('#sl').text('0');
                    $('#temp_sl_' + asscoaite_id).val('0');
                    $('#loss').text(losofpay);
                    $('#temp_loss_' + asscoaite_id).val(losofpay);
                }
            }

            /*Maternity leave application*/
            var leave_type_id = $("#id_leave_type").val();
            if (leave_type_id == 5) {

                $("#id-other").addClass('hidden');
                $("#test").hide();

                var fromdate = $("#single_datepicker_from").val();
                var todate = $("#single_datepicker_to").val();

                $(".no_of_days").text('');
                $(".test").show();
<?php if (isset($leave_type_summary[5])) { ?>
                    $(".no_of_days").text("<?php echo $leave_type_summary[5] ?>");
<?php } ?>
                $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');

                $('#loss').text("0");

                var no_of_days = $(".no_of_days").text();

                if (no_of_days < leavemat) {
                    var bal = leavemat - no_of_days;
                    $("#mat").text(bal);

                } else
                    $("#mat").text("0");

                $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');

                $('#temp_mat_' + asscoaite_id).val("0");
                $('#loss').text("0");

                var fromdate = $('.single_datepicker_from').val();

                var date = new Date(fromdate);
                var newdate = new Date(date);
<?php if (isset($leave_type_summary[5])) { ?>
                    no_of_days = parseInt(<?php echo $leave_type_summary[5] ?>);
<?php } ?>
                newdate.setDate(newdate.getDate() + no_of_days);

                var dd = newdate.getDate();
                var mm = newdate.getMonth() + 1;
                var y = newdate.getFullYear();

                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }

                var someFormattedDate = mm + '/' + dd + '/' + y;
//                alert(someFormattedDate);

                $('#single_datepicker_to').val(someFormattedDate);
                $('.single_datepicker_to').prop('disabled', 'true');
                $('#id_leave_type').prop('disabled', 'true');
                $('#id_leave_type').append('<input id="mat_id" type="text" name="id_leave_type" value="5" >');



            }
            //LOP
            if (currentId == '6') {


                $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
                $('#loss').text(no_of_days);

                $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
                $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
                $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
                $('#temp_loss_' + asscoaite_id).val(no_of_days);

<?php if (isset($leave_type_summary[4])) { ?>
                    $('#par').text("<?php echo $leave_type_summary[4] ?>");
                    $('#temp_par_' + asscoaite_id).val('<?php echo $leave_type_summary[4] ?>');
<?php } ?>
<?php if (isset($leave_type_summary[5])) { ?>
                    $('#mat').text("<?php echo $leave_type_summary[5] ?>");
                    $('#temp_mat_' + asscoaite_id).val('<?php echo $leave_type_summary[5] ?>');
<?php } ?>
            }
        });

        $('#leave_for').change(function () {
            $("#id_leave_type").removeAttr("disabled");

        });

        $('#id_half').click(function () {

            $('#form_applyleave_id').trigger("reset");

            $('#id_full').removeAttr('checked');
            $('#id_half').attr('checked', true);

            $("#dayTypeId").show();
            $("#halfDivId").show();
            $("#fullDivId").hide();
            $(".test").hide();
            $("#id_leave_type option:first").attr('selected', 'selected');

            $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
            $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
            $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
            $('#loss').text('0');

            $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
            $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
            $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
            $('#temp_loss_' + asscoaite_id).val('0');
        });
        $("#id_full").click(function () {
            $('#form_applyleave_id').trigger("reset");
            $('#id_half').removeAttr('checked');
            $('#id_full').attr('checked', true);
            $("#dayTypeId").hide();
            $("#halfDivId").hide();
            $("#fullDivId").show();

            $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
            $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
            $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
            $('#loss').text('0');

            $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
            $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
            $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
            $('#temp_loss_' + asscoaite_id).val('0');

        });
    });

</script>

<script type="text/javascript">
    function disableDates(date) {

        var isAvailable = false;

        // Find the days to deactivate
        if (avDays != null) {
            for (i = 0; i < avDays.length; i++) {
                if (date.getMonth() == avDays[i][0] - 1 && date.getDate() == avDays[i][1] && date.getFullYear() == avDays[i][2]) {
                    isAvailable = true;
                }
            }
        }

        if (isAvailable)
            return [true, 'av_day'];
        else
            return [false, ''];
    }

</script>

<script>
    var asscoaite_id = $('#associate_id').val();
    $("#single_datepicker_to").change(function () {
         $("#id_leave_type").val($("#id_leave_type option:first").val());
        
        var fromdate = $("#single_datepicker_from").val();
        var todate = $("#single_datepicker_to").val();
        var leave_type_id = $("#id_leave_type").val();
        $(".no_of_days").text('');
        $(".test").show();
        
         
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/clculateNoOfDays',
            data: {'fromdate': fromdate, todate: todate, 'leave_type_id': leave_type_id},
            success: function (data) {
                var parsed = $.parseJSON(data);

                $(".no_of_days").text(parsed.no_of_days);
                $("#id_leave_type").removeAttr("disabled");
                if ($('#id_leave_type').val() == 6) {
                    $('#loss').text(parsed.no_of_days);
                }
            }
        });
    });
    $("#single_datepicker_from").change(function () {

    $("#id_leave_type").val($("#id_leave_type option:first").val());
        if ($("#single_datepicker_to").val() != '') {

            var fromdate = $("#single_datepicker_from").val();
            var todate = $("#single_datepicker_to").val();
            var leave_type_id = $("#id_leave_type").val();
            $(".no_of_days").text('');
            $(".test").show();

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>dashboard/clculateNoOfDays',
                data: {'fromdate': fromdate, todate: todate, 'leave_type_id': leave_type_id},
                success: function (data) {
                    var parsed = $.parseJSON(data);

                    $(".no_of_days").text(parsed.no_of_days);
                    $("#id_leave_type").removeAttr("disabled");
                    if ($('#id_leave_type').val() == 6) {
                        $('#loss').text(parsed.no_of_days);
                    }
                }
            });
        }
    });
    $("#single_datepicker").change(function () {
    
$("#id_leave_type").val($("#id_leave_type option:first").val());
        $('#pl').text('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
        $('#cl').text('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
        $('#sl').text('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
        $('#loss').text('0.5');

        $('#temp_pl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[1]) ? $leave_type_summary[1] : ''; ?>');
        $('#temp_cl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[3]) ? $leave_type_summary[3] : ''; ?>');
        $('#temp_sl_' + asscoaite_id).val('<?php echo isset($leave_type_summary[2]) ? $leave_type_summary[2] : ''; ?>');
        $('#temp_loss_' + asscoaite_id).val('0.5');

<?php if (isset($leave_type_summary[4])) { ?>
            $('#par').text("<?php echo $leave_type_summary[4] ?>");
            $('#temp_par_' + asscoaite_id).val('<?php echo $leave_type_summary[4] ?>');
<?php } ?>
<?php if (isset($leave_type_summary[5])) { ?>
            $('#mat').text("<?php echo $leave_type_summary[5] ?>");
            $('#temp_mat_' + asscoaite_id).val('<?php echo $leave_type_summary[5] ?>');
<?php } ?>
    });

    function addDays(theDate, days) {
        return new Date(theDate.getTime() + parseInt(days) * 24 * 60 * 60 * 1000);
    }


</script>