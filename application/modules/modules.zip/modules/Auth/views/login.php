<section class="login-main-bg">
    <!--left side start here-->
    <div class="left-logo-bg">                
        <div class="l-bg-w">

            <!--logo here-->
            <div class="l-logo">
                <img src="<?php echo base_url() ?>frontend/dist/img/m-logo.png" class="img-responsive" />
            </div>
            <!--logo here-->

            <div class="login-wrapper">
                <div id="login">        
                    <div id="infoMessage" class="error-m text-danger"><?php echo $message; ?></div>

                    <div id="login-con">
                        <?php echo form_open("auth/login"); ?>

                        <div class="form-group margin-bottom-30">
                            <?php echo form_input($identity); ?>
                        </div>

                        <div class="form-group">
                            <?php echo form_input($password); ?>
                        </div>

                        <div class="form-group">
                            <table>
                                <td>
                                    <label class="form-label">
                                        <?php echo form_checkbox('remember', '1', FALSE, 'id="remember" class="iCheck checkbox" style="visibility:visible"'); ?>
                                    </label>
                                </td>
                                <td><span>Remember me</span></td>
                                <td><div class="form-group text-center">
                                        <p id="hs-forgot-pass">
                                            <a class="pull-left" href="#" title="Password Lost" ><span > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Forgot password?</span></a>
                                            <!--<a class="pull-right" href="ui-register.html" title="Sign Up">Sign Up</a>-->
                                        </p>
                                    </div></td>
                            </table>
                        </div>

                        <div class="form-group margin-top-25 text-center">
                            <?php echo form_submit('submit', lang('login_submit_btn'), 'class="btn btn-info btn-signin"'); ?>
                        </div>

                        <?php echo form_close(); ?>

                    </div>
                </div>
            </div>
            <div class="forgot-password " style="display:none">
                <div class="row fg-id">
                    <div class="  ">

                        <div class="form-group">
                            <?php echo lang('login_identity_label', 'email', 'class="form-label" '); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'forgot_password',
                                'id' => 'forgot_password',
                                'type' => 'email',
                                'value' => '',
                                'class' => 'form-control login ',
                                'placeholder' => 'Enter official Email Id'
                            ));
                            ?>
                        </div>
                        <div class="form-group">
                            <!--<button type="submit" class="teal ui button btn-block">Sign In</button>-->
                            <?php echo form_submit('button', lang('forgot_password_submit_btn'), 'class="btn btn-info btn-signin id-forgot-pass "', array("id" => "id-forgot-pass")); ?>

                        </div>
                        
                    </div>
                </div>
                Click here for <a id="hs-login" class="handle">log in</a>
            </div> 
            

            <div class="mission-bg"> 
                <img src="<?php echo base_url() ?>frontend/dist/img/mission-2020.png" class="img-responsive" />
            </div>
            <!--logo 2020 here-->

            <div class="text-center"> 
                &COPY; Copyright 2017. All Rights Reserved.
            </div>
        </div>
    </div>

    <!--right side start here-->
    <div class="right-logo-bg">
        <div class="r-bg-w">
            <div class="row">
                <div class="col-md-5">                            
                    <div class="box box-solid text-center associate-user">

                        <?php if (isset($hall_of_fame)) { ?>
                            <div class="associate-user-image">
                                <?php if (isset($hall_of_fame)) { ?>
                                    <img class="img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $hall_of_fame['profileimg']; ?>">
                                <?php } else { ?>
                                    <img class="img-circle img-responsive" src="<?php echo base_url() . 'assets/images/halloffame.png' ?>">
                                <?php } ?>
                            </div>

                            <div class="box-header with-border padding-top-60">
                                <h3 class="box-title"><?php echo $hall_of_fame['userfullname'] ? $hall_of_fame['userfullname'] : 'Yet To declare' ?></h3>

                                <p><p class="clr-999"><?php echo $hall_of_fame['position_name'] ?> | <?php echo $hall_of_fame['department_name'] ?></p>
                                <?php if (isset($hall_of_fame['project_title'])) { ?>

                                    <p>
                                    <div class="bg-warning" title="Project | Client">
                                        <?php echo $hall_of_fame['project_title'] ?> | 
                                        <?php echo $hall_of_fame['client_name'] ?>
                                        <i class="fa fa-info-circle text-ccc handle" title="<?php echo $hall_of_fame['comment'] ?>" ></i>
                                    </div>
                                    </p>
                                <?php } ?>
                            </div>
                            <div class="box-body">
                                <h3 class="text-success margin-top-bottom-5">Hall Of Fame</h3>
                            </div>
                        <?php } ?>

                    </div>


                </div>

                <div class="col-md-7">
                    <div class="r-b-logo">
                        <div class="pull-right">
                            <img src="<?php echo base_url() ?>frontend/dist/img/logo.png" class="img-responsive" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--right side end here-->
</section>





















<script>

    $(document).ready(function () {

        /*
         Fullscreen background
         */

        /*
         Form validation
         */
        $('.login-form input[type="text"], .login-form input[type="password"], .login-form textarea').on('focus', function () {
            $(this).removeClass('input-error');
        });

        $('.login-form').on('submit', function (e) {

            $(this).find('input[type="text"], input[type="password"], textarea').each(function () {
                if ($(this).val() == "") {
                    e.preventDefault();
                    $(this).addClass('input-error');
                }
                else {
                    $(this).removeClass('input-error');
                }
            });

        });


    });
</script>
<script>

    $("#hs-forgot-pass").on('click', function (e) {

        $('#login-con').hide();
        $('.forgot-password').show();
    });
    $("#hs-login").on('click', function (e) {

        $('#login-con').show();
        $('.forgot-password').hide();
        $("#infoMessage").html('');
    });
    
    $(".id-forgot-pass").on('click', function (e) {
        var emailAddress = $("#forgot_password").val();
        var emailRegex = new RegExp(/^[a-z0-9](\.?[a-z0-9]){5,}@mindworx\.in$/);
        var valid = emailRegex.test(emailAddress);
        if (!valid) {
            $("#infoMessage").html('Please Enter valid email id / Mindworx Email Id ');
            $("#forgot_password").val('');
            $("#forgot_password").focus();
            return false;
        } else {
            $("#infoMessage").html('');
//            $("#infoMessage").html('<span class="text-info">We have sent you an email, click on link to reset password</span>');
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>auth/checkEmailExist',
                data: {'check_email_address': emailAddress},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    if (data.result == 1)
                        $("#infoMessage").html('Wrong email address');
                    else{
                        $('.fg-id').remove();
                        $("#infoMessage").html('<span class="text-info">Please check Your official email inbox, and follow the instruction</span>')
                    }
                }
            });
        }

    });



</script>

