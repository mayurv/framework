<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Conference extends MY_Controller {

//put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails', 'projectallocation'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language', 'associatetimesheet'));

        /* dashboard */
        $this->load->model(array('blogdetail', 'years', 'holidaydates', 'timelinecomment', 'frontend/notification', 'frontend/leaverequest'));

        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'workstation', 'gender',));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'associatetimesheetapp', 'leavetypes', 'leavetypesAllocation', 'holidaydates', 'years', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('employees', 'conferenceroomtype', 'conferencebook', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('conference');
        $this->load->language('holiday_lang');

//initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('master-template.php');
        if (!$this->ion_auth->logged_in()) {
// redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        elseif (!$this->ion_auth->in_group('hr')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        $date_varaible = date('Y-m-d');
        $time = strtotime($date_varaible);
        $month = date("m", $time);
        $data['post_condition'] = NULL;
        $data['post_condition_yr'] = NULL;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $year = $_POST['year_list'];
            $data['post_condition'] = 'active';
            $data['post_condition_yr'] = $year;
        } else
            $year = date("Y", $time);

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
//        var_dump($user_id);die;

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

//get last month timesheet submit status
        $data['mybookings'] = $this->conferencebook->get_mybooking_list($user_id);
        $data['roomdetails'] = $this->conferenceroomtype->get_roomDetails();
        $data['resources'] = $this->conferenceroomtype->get_resource_list();
        $data['submission_status'] = $this->associatetimesheet->get_submit_status($user_id, $month, $year);
        $data['my_approvals'] = '';
        $data['my_statastic'] = $this->associatetimesheetapp->get_mystatastic($user_id);
        $month_id1 = '01';
        //$month_id = array('jan' => '01', 'feb' => '02','March' => '02');
        $month_id = array('01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec');
        foreach ($month_id as $mnum => $mname) {
            if ($mnum <= $month)
                $data['my_monthstatastic'][$mname] = $this->associatetimesheet->get_my_monthstatastic($user_id, $mnum, $year);
        }

        foreach ($month_id as $mnum => $mname) {
            $data['team_monthstatastic'][$mname] = $this->associatetimesheetapp->get_team_monthstatastic($user_id, $mnum, $year);
        }


        $data['my_approvals'] = $this->associatetimesheetapp->get_myApproval_list($user_id);

        $data['associates'] = $this->associatetimesheetapp->get_associate_list($user_id);
        $data['events'] = $this->conferencebook->get_all_event();

        $data['submission_sdate'] = date('Y-m-01');
        $data['submission_edate'] = date('Y-m-05');

//  var_dump($data['team_monthstatastic']);die;
        $data['bookings'] = $this->conferencebook->get_list();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//        $dataHeader['notification'] = $this->notification->get_by_id($dataHeader['user_summary']['department_id'], $dataHeader['user_summary']['emprole']);

        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);

        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $user_id);


        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'show_conferencebooking', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function recursive_booking() {

        $date_varaible = date('Y-m-d');
        $time = strtotime($date_varaible);
        $month = date("m", $time);
        $data['post_condition'] = NULL;
        $data['post_condition_yr'] = NULL;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//            var_dump($_POST);die;
            $year = $_POST['year_list'];
            $data['post_condition'] = 'active';
            $data['post_condition_yr'] = $year;
        } else
            $year = date("Y", $time);

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
//        var_dump($user_id);die;

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

//get last month timesheet submit status

        $data['resources'] = $this->conferenceroomtype->get_resource_list();
        $data['submission_status'] = $this->associatetimesheet->get_submit_status($user_id, $month, $year);
        $data['my_approvals'] = '';
        $data['my_statastic'] = $this->associatetimesheetapp->get_mystatastic($user_id);
        $month_id1 = '01';
        //$month_id = array('jan' => '01', 'feb' => '02','March' => '02');
        $month_id = array('01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec');
        foreach ($month_id as $mnum => $mname) {
            if ($mnum <= $month)
                $data['my_monthstatastic'][$mname] = $this->associatetimesheet->get_my_monthstatastic($user_id, $mnum, $year);
        }
//var_dump($data['my_monthstatastic']);die;
//$data['my_monthstatastic'] = $this->associatetimesheet->get_my_monthstatastic($user_id, $month_id);
//        var_dump($year);die;
        foreach ($month_id as $mnum => $mname) {
            $data['team_monthstatastic'][$mname] = $this->associatetimesheetapp->get_team_monthstatastic($user_id, $mnum, $year);
        }
//        var_

        $data['my_approvals'] = $this->associatetimesheetapp->get_myApproval_list($user_id);

        $data['associates'] = $this->associatetimesheetapp->get_associate_list($user_id);
        $data['events'] = $this->associatetimesheet->get_all_event();

        $data['submission_sdate'] = date('Y-m-01');
        $data['submission_edate'] = date('Y-m-05');

//  var_dump($data['team_monthstatastic']);die;

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $dataHeader['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//        $dataHeader['notification'] = $this->notification->get_by_id($dataHeader['user_summary']['department_id'], $dataHeader['user_summary']['emprole']);


        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($dataHeader) ? $dataHeader : NULL));
//        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'recuring/show_recursivebooking', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function approve() {
        $date_varaible = date('Y-m-d');
        $time = strtotime($date_varaible);
        $month = date("m", $time);
        $data['post_condition'] = NULL;
        $data['post_condition_yr'] = NULL;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//            var_dump($_POST);die;
            $booking_id = $this->input->post('booking_id');
            $status = $this->input->post('status');
            if ($status == 1) {
                //$ispublished = '1';
                $active = '1';
            } else {
                $active = '0';
                // $ispublished = '0';
            }
            //ispublished = 1 :Un approved 0: approve
            //isactive 0 = notactive 1: active
            $data = array('isactive' => $active); // 'ispublished' => $ispublished);

            $this->conferencebook->approve_cb($booking_id, $data);
            echo json_encode(array('active' => $active));
            die;
        }



        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
//        var_dump($user_id);die;

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

//get last month timesheet submit status
        $data = $this->get_all_view_data($user_id);

        $data['bookings'] = $this->conferencebook->get_booking_list();

        

//        $data['submission_status'] = $this->associatetimesheet->get_submit_status($user_id, $month, $year);
//        $data['my_approvals'] = '';
//        $data['my_statastic'] = $this->associatetimesheetapp->get_mystatastic($user_id);
//        $month_id1 = '01';
//        //$month_id = array('jan' => '01', 'feb' => '02','March' => '02');
//        $month_id = array('01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec');
//        foreach ($month_id as $mnum => $mname) {
//            if ($mnum <= $month)
//                $data['my_monthstatastic'][$mname] = $this->associatetimesheet->get_my_monthstatastic($user_id, $mnum, $year);
//        }
//
//        foreach ($month_id as $mnum => $mname) {
//            $data['team_monthstatastic'][$mname] = $this->associatetimesheetapp->get_team_monthstatastic($user_id, $mnum, $year);
//        }
//
//
//        $data['my_approvals'] = $this->associatetimesheetapp->get_myApproval_list($user_id);
//
//        $data['associates'] = $this->associatetimesheetapp->get_associate_list($user_id);
//        $data['events'] = $this->conferencebook->get_all_event();
//
//        $data['submission_sdate'] = date('Y-m-01');
//        $data['submission_edate'] = date('Y-m-05');
//  var_dump($data['team_monthstatastic']);die;

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
//        $dataHeader['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//        $dataHeader['notification'] = $this->notification->get_by_id($dataHeader['user_summary']['department_id'], $dataHeader['user_summary']['emprole']);


        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', '_approvebooking', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function display() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data = $this->get_all_view_data($user_id);

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'show_timesheet', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);

        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);
//        $data['empId'] = $this->_get_employeeid();
//        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->workstation->dropdown('work_station_code'));
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
        $data['department_id'] = $data['user_summary']['department_id'];
        $data['emprole'] = $data['user_summary']['emprole'];

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        $data['position_list'] = $this->employees->get_all_position_by_id($data['user_summary']['jobtitle_id']);

//Associate Holiday & Leaves
        $data['leaves'] = $this->employeesleave->get_by_id($associate_id);
//echo $this->db->last_query();die;
//Associate Communication & Personal Details
        $data['personal_detail'] = $this->personaldetails->get_by_id($associate_id);
//        echo $this->db->last_query();die;
        $data['communication_detail'] = $this->communication->get_by_id($associate_id);
//        var_dump($data['leaves']);die;
//        var_dump($associate_id);die;
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = (array('' => 'Select Hobbies', 'disabled' => 'disabled') + $this->hobbies->dropdown('hobbies_title'));

        /* Document */
        $data['document_details'] = $this->documents->get_by_id($associate_id);

        /* job history */
        $data['jobhistroy_details'] = NULL;
//        var_dump($data['user_summary']);die;
        /* Experience */
        $data['tag_type'] = (array('' => 'Select Tag')) + $this->tag->dropdown('tag_name');
        $data['experience_details'] = $this->experiencedetails->get_by_id($associate_id);
//        var_dump($data['user_summary']['department_id']);die;


        /* Dashboard */
        $data['publish_group'] = (array('0' => 'All Department')) + (array($data['user_summary']['department_id'] => $data['user_summary']['department_name'])) + (array('99' => 'Only Me'));
        $data['timeline_comment'] = $this->timelinecomment->get_by_id($associate_id);
//        $data['comment_data'] = $this->timelinecomment->get_by_id($associate_id);
//        var_dump($data['timeline_comment']);
        if ($data['user_summary']['emprole'] == '5')//role is associate/employee
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);

        if ($data['user_summary']['emprole'] == '3')//role is manager/employee
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);
        else
            $data['leave_notification'] = $this->notification->get_leave_notification_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole'], $associate_id);

//        die;

        return $data;
    }

    function add_data($st, $end, $res) {
        $data = array();
        $data['resources'] = $this->associatetimesheet->get_resource_list();
        $data['timesheetdata'] = array(
            'start' => $st,
            'end' => $end,
            'resource' => $res,
        );
        $this->template->set_master_template('master-template.php');
//        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'add_data', (isset($data) ? $data : NULL));
//        $this->template->write_view('footer', 'frontend/footer', '', FALSE);
        $this->template->render();
//       $this->load->view('add_data',$data);
    }

    function backend_create() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        $recursive = $this->input->post('id_recursive');
        if (isset($recursive) && $recursive == 0) {

            //var_dump($_POST);
//            $start_time = $this->input->post('start');
//            $end_time = $this->input->post('end');
//
//            $from_date = (date('Y-m-d', strtotime($start_time))) . 'T' . date("H:i:s", strtotime($this->input->post('from_time')));
//            $to_date = (date('Y-m-d', strtotime($end_time))) . 'T' . date("H:i:s", strtotime($this->input->post('to_time')));


            /* total hours calculation */
            $start_time = $this->input->post('start');
            $end_time = $this->input->post('end');
            $d1 = strtotime(date('h:i:s A', strtotime($start_time)));
            $d2 = strtotime(date('h:i:s A', strtotime($end_time)));
            $diff = $d2 - $d1;

            $t1 = date('H:i:s', strtotime($start_time));
            $t2 = date('H:i:s', strtotime($end_time));

            $min = round(abs($diff) / 60, 2);
            $hrs = $min / 60;

//            end diff
            //$holidaydates = array($holidaydates);
            $startDate = new DateTime($this->input->post('from_date'));
            $endDate = new DateTime($this->input->post('to_date'));
            $endDate = $endDate->modify('+1 day');

            $interval = new DateInterval('P1D'); //for one day interval
            $daterange = new DatePeriod($startDate, $interval, $endDate);

            $last_id = $this->conferencebook->get_record();



            if ($last_id == null || $last_id == 0)
                $last_id = 1;
            else
                $last_id = $last_id + 1;

            //  var_dump($last_id);die;
            foreach ($daterange as $key => $date) {


                $fromdate = $date->format("Y-m-d") . 'T' . $t1;
                $todate = $date->format("Y-m-d") . 'T' . $t2;

                $dataConferencebook = array(
                    'user_id' => $user_id,
                    'room_id' => $this->input->post('resource'),
                    'name' => $this->input->post('name'),
                    'start' => $fromdate,
                    'end' => $todate,
                    'rec_status' => $last_id,
                    'total_hours' => $hrs,
                    'createdby' => $this->session->userdata('user_id'),
                    'createddate' => date('Y-m-d H:i:s')
                );

                $id = $this->conferencebook->insert($dataConferencebook);

                $dataConferencebook = array();
                //var_dump($dataConferencebook);
            }
            // die;
            if (isset($id)) {
                $this->session->set_flashdata('msg', "Conference Booked Successfully");
                redirect('conference/', 'refresh');
            }

            header('Content-Type: application/json');
            echo json_encode($response);
        } else {

            /* total hours calculation */
            $start_time = $this->input->post('start');
            $end_time = $this->input->post('end');
            $d1 = strtotime(date('h:i A', strtotime($start_time)));
            $d2 = strtotime(date('h:i A', strtotime($end_time)));
            $diff = $d2 - $d1;

            $min = round(abs($diff) / 60, 2);
            $hrs = $min / 60;

// get date
            $timesheet_date = strtotime(date('Y-m-d', strtotime($start_time)));
            $timesheet_date = date("Y-m-d", strtotime($start_time));
            $last_id = $this->conferencebook->get_record();

            if ($last_id == null || $last_id == 0)
                $last_id = 1;
            else
                $last_id = $last_id + 1;

            $dataConferencebook = array(
                'user_id' => $user_id,
                'room_id' => $this->input->post('resource'),
                'name' => $this->input->post('name'),
                'start' => $start_time,
                'end' => $end_time,
//            'date' => $timesheet_date,
                'rec_status' => $last_id,
                'total_hours' => $hrs,
                'createdby' => $this->session->userdata('user_id'),
                'createddate' => date('Y-m-d H:i:s')
            );

            $id = $this->conferencebook->insert($dataConferencebook);

            if (isset($id)) {
                $this->session->set_flashdata('msg', "Conference Booked Successfully");
                redirect('conference/', 'refresh');
            }
        }

        header('Content-Type: application/json');
        echo json_encode($response);
    }

    function recursivebackend_create() {

//         var_dump($_POST);
        $start_time = $this->input->post('start');
        $end_time = $this->input->post('end');

//         echo date("H:i:s", strtotime($this->input->post('from_time'))).'<br>';
//         echo date("H:i:s", strtotime($this->input->post('to_time'))).'<br>';
////         echo date('Y-m-d',  strtotime($start_time));
//         echo (date('Y-m-d', strtotime($start_time))).'<br>';
//         echo (date('Y-m-d', strtotime($end_time))).'<br>';
        $from_date = (date('Y-m-d', strtotime($start_time))) . 'T' . date("H:i:s", strtotime($this->input->post('from_time')));
        $to_date = (date('Y-m-d', strtotime($end_time))) . 'T' . date("H:i:s", strtotime($this->input->post('to_time')));



        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        /* total hours calculation */
        echo strtotime(date('h:i A', strtotime($this->input->post('from_time'))));
        $d1 = strtotime(date('h:i A', strtotime($this->input->post('from_time'))));
        $d2 = strtotime(date('h:i A', strtotime($this->input->post('to_time'))));
        $diff = $d2 - $d1;
        // var_dump($diff);die;

        $min = round(abs($diff) / 60, 2);
        $hrs = $min / 60;

        $fromDate = (date('Y-m-d', strtotime($start_time)));
        $toDate = (date('Y-m-d', strtotime($end_time)));

        $diff = date_diff(date_create($fromDate), date_create($toDate));


        //$holidaydates = array($holidaydates);
        $startDate = new DateTime($this->input->post('start'));
        $endDate = new DateTime($this->input->post('end'));

        $interval = new DateInterval('P1D'); //for one day interval
        $daterange = new DatePeriod($startDate, $interval, $endDate);


        foreach ($daterange as $key => $date) {

            $fromdate = $date->format("Y-m-d") . 'T' . date("H:i:s", strtotime($this->input->post('from_time')));
            $todate = $date->format("Y-m-d") . 'T' . date("H:i:s", strtotime($this->input->post('to_time')));

            $dataConferencebook = array(
                'user_id' => $user_id,
                'room_id' => $this->input->post('resource'),
                'name' => $this->input->post('name'),
                'start' => $fromdate,
                'end' => $todate,
//            'date' => $timesheet_date,
                'total_hours' => $hrs,
                'createdby' => $this->session->userdata('user_id'),
                'createddate' => date('Y-m-d H:i:s')
            );

            $id = $this->conferencebook->insert($dataConferencebook);
            $dataConferencebook = array();
        }
        if (isset($id)) {
            $this->session->set_flashdata('msg', "Conference Booked Successfully");
            redirect('conference/recursive_booking', 'refresh');
        }

        header('Content-Type: application/json');
        echo json_encode($response);
    }

    function backend_resize() {



        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* to update all recurring */
        $start_time = $this->input->post('newStart');
        $end_time = $this->input->post('newEnd');



        $new_start = (date('H:i', strtotime($start_time)));
        $new_end = (date('H:i', strtotime($end_time)));

        /* hors calculation */
        $d1 = strtotime(date('h:i A', strtotime($start_time)));
        $d2 = strtotime(date('h:i A', strtotime($end_time)));
        $diff = $d2 - $d1;

        $min = round(abs($diff) / 60, 2);
        $hrs = $min / 60;
        /* hors calculation */

        $id = $this->input->post('id');
        $rec_id = $this->conferencebook->get_recID($id);

//        check avialbility start
//        $chk_startDate = NULL;
//        $start = NULL;
//        $chk_startTime = NULL;
//
//        $chk_endDate = NULL;
//        $end = NULL;
//        $chk_endTime = NULL;
//
//        $chk_startTime = date('H:i', strtotime($this->input->post('newStart')));
//        $chk_endTime = date('H:i', strtotime($this->input->post('newEnd')));
//
//        if ($this->input->post('newStart'))
//            $chk_startDate = date('Y-m-d', strtotime($this->input->post('newStart')));
//        else {
//            echo json_encode(array('booking_status' => '2'));
//            die;
//        }
//
//        if ($this->input->post('newEnd'))
//            $chk_endDate = date('Y-m-d', strtotime($this->input->post('newEnd')));
//        else {
//            echo json_encode(array('booking_status' => '2'));
//            die;
//        }
//        
//        $resource_id = NULL;
//        
//        $chk_availability = $this->conferencebook->checkAvailability($chk_startDate, $chk_endDate, $resource_id,$chk_startTime, $chk_endTime);
//        end check avilability

        $conferenceData = $this->conferencebook->get_all_by_rec_id($rec_id);

        foreach ($conferenceData as $key => $cData) {
            $updateStartTime = explode('T', $cData['start']);
            $conferenceData[$key]['start'] = $updateStartTime[0] . 'T' . $new_start;
            $conferenceData[$key]['end'] = $updateStartTime[0] . 'T' . $new_end;
            $conferenceData[$key]['total_hours'] = $hrs;
        }

        foreach ($conferenceData as $key => $cData) {
            if ($cData['rec_status'] == $rec_id)
                $updateResult = $this->conferencebook->update($cData['id'], $cData);
        }

        /* end to update all recurring */

        $data = $this->get_all_view_data($user_id);


        if ($updateResult)
            $response = 'Update successful';

        header('Content-Type: application/json');
        echo json_encode($response);
    }

    function backend_move() {


//        var_dump($_POST);die;
        /* to update all recurring */
        $start_time = $this->input->post('newStart');
        $end_time = $this->input->post('newEnd');
        $room_id = $this->input->post('newResource');
        $id = $this->input->post('id');

        $new_start = (date('H:i', strtotime($start_time)));
        $new_end = (date('H:i', strtotime($end_time)));

        $rec_id = $this->conferencebook->get_recID($id);
        $conferenceData = $this->conferencebook->get_all_by_rec_id($rec_id);

        /* hors calculation */
        $d1 = strtotime(date('h:i A', strtotime($start_time)));
        $d2 = strtotime(date('h:i A', strtotime($end_time)));
        $diff = $d2 - $d1;

        $min = round(abs($diff) / 60, 2);
        $hrs = $min / 60;
        /* hors calculation */

        /* start check availability */
        $chk_startDate = NULL;
        $start = NULL;
        $chk_startTime = NULL;

        $chk_endDate = NULL;
        $end = NULL;
        $chk_endTime = NULL;

        $chk_startTime = date('H:i', strtotime($this->input->post('newStart')));
        $chk_endTime = date('H:i', strtotime($this->input->post('newEnd')));

        if ($this->input->post('newStart'))
            $chk_startDate = date('Y-m-d', strtotime($this->input->post('newStart')));

        if ($this->input->post('newEnd'))
            $chk_endDate = date('Y-m-d', strtotime($this->input->post('newEnd')));

        $resource_id = $this->input->post('newResource');
        $count = count($conferenceData);

        foreach ($conferenceData as $checkData) {
            $chk_startDate = date('Y-m-d', strtotime($checkData['start']));
            $chk_endDate = date('Y-m-d', strtotime($checkData['end']));
            $chk_availability = $this->conferencebook->checkAvailability($chk_startDate, $chk_endDate, $resource_id, $chk_startTime, $chk_endTime);
            if ($chk_availability == '0') {
                $response = 'Not Available';
                header('Content-Type: application/json');
                echo json_encode($response);
                die;
            }
        }



//        var_dump($chk_availability);die;

        /* end check availabitlity */



        foreach ($conferenceData as $key => $cData) {
            $updateStartTime = explode('T', $cData['start']);
            $conferenceData[$key]['start'] = $updateStartTime[0] . 'T' . $new_start;
            $conferenceData[$key]['end'] = $updateStartTime[0] . 'T' . $new_end;
            $conferenceData[$key]['total_hours'] = $hrs;
            $conferenceData[$key]['room_id'] = $room_id;
        }

        foreach ($conferenceData as $key => $cData) {
            if ($cData['rec_status'] == $rec_id)
                $updateResult = $this->conferencebook->update($cData['id'], $cData);
        }

        /* end to update all recurring */

        if ($updateResult)
            $response = 'Update successful';
        else
            $response = 'Failed';


        header('Content-Type: application/json');
        echo json_encode($response);
    }

    function backend_resources() {
//        var_dump($_REQUEST);die;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $resources = $this->conferenceroomtype->get_resource_list();

        foreach ($resources as $key => $resData) {

            $resources[$key]['name'] = '<a class="text-primary text-hover" data-toggle="modal" href="#' . $resData['name'] . '" title="View Details">  ' . $resData['name'] . '</a>';
        }

        header('Content-Type: application/json');

        echo json_encode($resources);
        die;
    }

    public function checkAvailability() {

        $startDate = NULL;
        $start = NULL;
        $startTime = NULL;

        $endDate = NULL;
        $end = NULL;
        $endTime = NULL;

        $startTime = date('H:i', strtotime($this->input->post('title_start_time')));
        $startDate = date('Y-m-d', strtotime($this->input->post('from_date')));
        $endTime = date('H:i', strtotime($this->input->post('title_end_time')));

        if ($this->input->post('from_date'))
            $startDate = date('Y-m-d', strtotime($this->input->post('from_date')));
        else {
            echo json_encode(array('booking_status' => '2'));
            die;
        }

        if ($this->input->post('to_date'))
            $endDate = date('Y-m-d', strtotime($this->input->post('to_date')));
        else {
            echo json_encode(array('booking_status' => '2'));
            die;
        }

        $start = $startDate . 'T' . $startTime . ':00';

        if (isset($endDate))
            $end = $endDate . 'T' . $endTime . ':00';


        $resource_id = $this->input->post('conf_id');
        $booking_status = $this->conferencebook->checkAvailability($startDate, $endDate, $resource_id, $startTime, $endTime);

        echo json_encode(array('booking_status' => $booking_status));
        die;
    }

    function backend_teamresources() {
//        var_dump($_REQUEST);die;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $dept_id = NULL;

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
        $dept_id = $data['user_summary']['department_id'];
        if ($data['user_summary']['emprole'] == '3' || $data['user_summary']['emprole'] == '1') {
            $manager_id = $user_id;

            if ($data['user_summary']['emprole'] == '1')
                $dept_id = NULL;
        } else
            $manager_id = NULL;


        $resources = $this->associatetimesheet->get_resource_list($user_id, $dept_id, $manager_id);
        $resources_my = $this->associatetimesheet->get_resource_list($user_id, $dept_id, $manager_id, 'self');
        header('Content-Type: application/json');

        echo json_encode($resources);
    }

    function edit($id) {
        $data['event'] = $this->conferencebook->get_event($id);

        $this->load->view('edit', $data);
    }

    function backend_events() {
        $json = file_get_contents('php://input');
        $params = json_decode($json);
        $start = $params->start;
        $end = $params->end;

        $events = $this->conferencebook->get_event_list($start, $end);

        header('Content-Type: application/json');
        echo json_encode($events);
        die;
    }

    function backend_events_busy() {
        $json = file_get_contents('php://input');
        $params = json_decode($json);
        $start = $params->start;
        $end = $params->end;

        $events = $this->conferencebook->get_event_list_busy($start, $end);

        header('Content-Type: application/json');
        echo json_encode($events);
        die;
    }

    function recuringbackend_events() {
        $start = $this->input->post('start');
        $end = $this->input->post('end');


//        $d1 = strtotime(date('h:i A', strtotime($start)));
//        $d2 = strtotime(date('h:i A', strtotime($end)));
//        $start = date('Y-m-d h:i', ($d1));
//        $end = date('Y-m-d h:i', ($d2));

        $events = $this->conferencebook->get_event_list($start, $end);
//        echo '<pre>',  print_r($events);die;
        header('Content-Type: application/json');
        echo json_encode($events);
        die;
    }

    function backend_update() {
//        echo 'in timesheet';die;
//  var_dump($_POST) ;die;
        $id = $this->input->post('id');

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        /* total hours calculation */
        $start_time = $this->input->post('newStart');
        $end_time = $this->input->post('newEnd');
        $d1 = strtotime(date('h:i A', strtotime($start_time)));
        $d2 = strtotime(date('h:i A', strtotime($end_time)));
        $diff = $d2 - $d1;

        $min = round(abs($diff) / 60, 2);
        $hrs = $min / 60;

// get date
        $timesheet_date = strtotime(date('Y-m-d', strtotime($start_time)));
        $timesheet_date = date("Y-m-d", strtotime($start_time));

        $dataTimesheet = array(
            'task_description' => $this->input->post('task_desc'),
        );



        $id = $this->associatetimesheet->update($id, $dataTimesheet);

        if ($id) {
            $response = 'Update successful';
            $start = "2017-01-01T00:00:00";
            $end = "2017-02-01T11:00:00";
            $this->session->set_flashdata('msg', "Record updated successfully");
            redirect('timesheet', 'refresh');
//            redirect('timesheet/backend_events/'.$id.'/'.$start.'/'.$end);
            echo "<script>window.location.reload();</script>";
//            $this->index();
        }

// header('Content-Type: application/json');
// echo json_encode($response);
    }

    public function submit_timesheet() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//$current_date = '2017-02-01';// date('Y-m-d');
        $tm_month = date('m', strtotime(' -1 month'));
        $tm_year = date('Y');

//echo $tm_month;

        $total_hours = $this->associatetimesheet->get_total_hours_tm($user_id, $tm_month, $tm_year);
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);

        $timesheetDataArray = array(
            'user_id' => $user_id,
            'mng_id' => $data['user_summary']['reporting_manager'],
            'total_hours' => $total_hours,
            'submission_date' => date('Y-m-d H:m:s'),
            'submission_month' => $tm_month,
            'submission_year' => $tm_year,
            'approval_status' => 0,
            'createdby' => $user_id,
            'createddate' => date('Y-m-d H:m:s'),
        );

        $this->associatetimesheetapp->insert($timesheetDataArray);
        $this->session->set_flashdata('msg', "Timesheet submitted successfully");
        redirect('timesheet', 'refresh');
    }

    public function approve_timesheet() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
//         $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);         
//         $data['associates'] = $this->associatetimesheet->get_resource_list($user_id, $data['user_summary']['department_id'], $user_id);
//     
        $data['associates'] = $this->associatetimesheetapp->get_associate_list($user_id);




        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $dataHeader['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//        $dataHeader['notification'] = $this->notification->get_by_id($dataHeader['user_summary']['department_id'], $dataHeader['user_summary']['emprole']);


        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($dataHeader) ? $dataHeader : NULL));
//        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_CandidateTimesheetList', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function team_timesheet() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);

//get last month timesheet submit status
        $date_varaible = '2017-02-02T09:00:00';
        $time = strtotime($date_varaible);
        $month = date("m", $time);
        $year = date("Y", $time);
        $data['submission_status'] = $this->associatetimesheet->get_submit_status($user_id, $month, $year);
        $data['my_approvals'] = '';
        $data['my_statastic'] = $this->associatetimesheetapp->get_mystatastic($user_id);
        $month_id = '01';
        $data['my_monthstatastic'] = $this->associatetimesheet->get_my_monthstatastic($user_id, $month_id);


        $data['associates'] = $this->associatetimesheetapp->get_associate_list($user_id);
        $data['events'] = $this->associatetimesheet->get_all_event($user_id);

        $data['submission_sdate'] = date('Y-m-01');
        $data['submission_edate'] = date('Y-m-05');

        $teamTimesheetViewData = $this->load->view('_teamTimesheet', $data, TRUE);

        echo json_encode(array('content' => $teamTimesheetViewData));
        die;
    }

    function magager_comment() {
        //var_dump($_POST);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_id = $this->input->post('user_id');
            $mng_id = $this->input->post('mng_id');
            $approval_status = $this->input->post('approval_status');
            $manager_comment = $this->input->post('manager_comment');
            $submission_month = $this->input->post('submission_month');
            $submission_year = $this->input->post('submission_year');

            $mng_appprovalArray = array(
                'approval_status' => $approval_status,
                'mng_comments' => $manager_comment,
                'approval_date' => date('Y-m-d H:m:s'),
            );

            $this->associatetimesheetapp->manager_comments($mng_appprovalArray, $user_id, $mng_id, $submission_month, $submission_year);
            $this->session->set_flashdata('msg', "Comments submitted successfully");
            redirect('timesheet', 'refresh');
        }
    }

    function generateTmReport() {



        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $user_id = $this->input->get('associate_id');
            $filter_date = $this->input->get('filter_date');
            $dlArray = explode('-', $filter_date);
            $year_id = $dlArray[0];
            $month_id = $dlArray[1];
        }


        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $tm_report = $this->associatetimesheet->generateTmReport($user_id, $month_id, $year_id);


        $this->load->library('excel');
        $excel = new PHPExcel();



        $filename = str_replace(' ', '_', $tm_report[0]['userfullname']);

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '.xlsx"');
        header('Cache-Control: max-age=0');

        $excel->setActiveSheetIndex(0);


        $worksheet = $excel->getActiveSheet();

        $worksheet->setTitle('Timesheet');


        $heading = array('No', 'Start', 'End', 'Hours', 'Description');
        $rowNumberH = 1;
        $colH = 'A';
        foreach ($heading as $h) {
            $worksheet->setCellValue($colH . $rowNumberH, $h);
            $colH++;
        }

        //$this->cellColor('A1:D1', 'F28A8C');
        //$worksheet->getStyle('A1:E1')->getFont()->setBold(true);

        $styleArray = array(
            'font' => array(
                'bold' => true,
                'color' => array('rgb' => 'FFFF'),
                'size' => 15,
                'name' => 'Verdana',
                'borders' => array(
                    'bottom' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN
                    )),
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '0000cd')
                ),
        ));

        $worksheet->getStyle('A1:E1')->applyFromArray($styleArray);
        $worksheet->getStyle('A1:E1')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '0000cd')
                    )
                )
        );

        $col = 2;
        $no = 1;
        foreach ($tm_report as $key => $val) {
            $worksheet->setCellValue('A' . $col, $no);
            $worksheet->setCellValue('B' . $col, $val['start']);
            $worksheet->setCellValue('C' . $col, $val['end']);
            $worksheet->setCellValue('D' . $col, $val['total_hours']);
            $worksheet->setCellValue('E' . $col, $val['task_description']);

            $col++;
            $no++;
        }


        $writer = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');

// This line will force the file to download
        ob_end_clean();
        $writer->save('php://output');
        exit();
    }

    function download_send_headers($filename) {
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename={$filename}");
        header("Content-Transfer-Encoding: binary");
    }

    function cellColor($cells, $color) {

        global $worksheet;
        $this->load->library('excel');
        $excel = new PHPExcel();
        $worksheet = $excel->getActiveSheet();
        //global $worksheet;


        return $worksheet->getStyle($cells)->getFill()->applyFromArray(array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'startcolor' => array(
                        'rgb' => $color
                    )
        ));
    }

    public function delete_booking() {
        $delete_id = $this->input->post('conf_id');
        $this->conferencebook->conference_delete($delete_id);
        echo $this->db->last_query();
        return true;
    }

    function format_interval(DateInterval $interval) {
        $result = "";
        if ($interval->y) {
            $result .= $interval->format("%y years ");
        }
        if ($interval->m) {
            $result .= $interval->format("%m months ");
        }
        if ($interval->d) {
            $result .= $interval->format("%d days ");
        }
        if ($interval->h) {
            $result .= $interval->format("%h hours ");
        }
        if ($interval->i) {
            $result .= $interval->format("%i minutes ");
        }
        if ($interval->s) {
            $result .= $interval->format("%s seconds ");
        }

        return $result;
    }

}
