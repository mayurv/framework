﻿<!DOCTYPE html>
<html>
<head>
    <title>HTML5 Timesheet (DayPilot Pro for JavaScript)</title>
	<!-- demo stylesheet -->
    	<link type="text/css" rel="stylesheet" href="media/layout.css" />    

	<!-- helper libraries -->
	<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
	
	<!-- daypilot libraries -->
        <script src="js/daypilot/daypilot-all.min.js" type="text/javascript"></script>
	
</head>
<body>

        <div class="main">
            
            <div class="space">
                Employee:
                <select id="employee"></select>
            </div>
                
            <div id="dp"></div>

            <script type="text/javascript">
                var dp = new DayPilot.Scheduler("dp");

                dp.viewType = "Days";
                dp.startDate = new DayPilot.Date().firstDayOfMonth();
                dp.days = dp.startDate.daysInMonth();

                dp.timeHeaders = [
                    { groupBy: "Day", format: "MMMM yyyy" },
                    { groupBy: "Hour"}
                ];

                dp.heightSpec = "Max";
                dp.height = 400;

                dp.cellWidthSpec = "Auto";
                
                dp.rowHeaderColumns = [
                    { title: "Day", width: 100},
                    { title: "Total", width: 100}
                ];

                // http://api.daypilot.org/daypilot-scheduler-oneventmoved/ 
                dp.onEventMoved = function (args) {
                    $.post("backend_move.php", 
                    {
                        id: args.e.id(),
                        newStart: args.newStart.toString(),
                        newEnd: args.newEnd.toString(),
                        newResource: args.newResource
                    }, 
                    function() {
                        updateTotals();
                        dp.message("Moved.");
                    });
                };

                // http://api.daypilot.org/daypilot-scheduler-oneventresized/ 
                dp.onEventResized = function (args) {
                    $.post("backend_resize.php", 
                    {
                        id: args.e.id(),
                        newStart: args.newStart.toString(),
                        newEnd: args.newEnd.toString()
                    }, 
                    function() {
                        updateTotals();
                        dp.message("Resized.");
                    });
                };

                // event creating
                // http://api.daypilot.org/daypilot-scheduler-ontimerangeselected/
                dp.onTimeRangeSelected = function (args) {
                    var name = prompt("New event name:", "Event");
                    dp.clearSelection();
                    if (!name) return;

                    $.post("backend_create.php", 
                        {
                            start: args.start.toString(),
                            end: args.end.toString(),
                            resource: $("#employee").val(),
                            name: name
                        }, 
                        function(data) {
                            var e = new DayPilot.Event({
                                start: args.start,
                                end: args.end,
                                id: data.id,
                                resource: args.resource,
                                text: name
                            });
                            dp.events.add(e);

                            updateTotals();
                            dp.message(data.message);
                        });
                };
                
                dp.onEventClick = function(args) {
                    var modal = new DayPilot.Modal();
                    modal.closed = function() {
                        // reload all events
                        var data = this.result;
                        if (data && data.result === "OK") {
                            loadEvents();
                        }
                    };
                    modal.showUrl("edit.php?id=" + args.e.id());
                };
                
                dp.init();

                $(document).ready(function() {
                    loadResources();
                    $("#employee").change(function() {
                        loadEvents();
                    });
                });

                function loadResources() {
                    $.post("backend_resources.php", function(data) {
                        for (var i = 0; i < data.length; i++) {
                            var item = data[i];
                            $("#employee").append($('<option/>', { 
                                value: item.id,
                                text : item.name
                            }));
                        }
                        loadEvents();
                    });
                }
                
                function loadEvents() {					
                    var url = "backend_events.php?resource=" + $("#employee").val() + "&start=" + dp.startDate + "&end=" + dp.startDate.addDays(dp.days);
                    dp.events.load(url, function() {
                        dp.message("Events for " + $("#employee option:selected").text() + " loaded.");
                        updateTotals();
                    });
                }
                
                function updateTotals() {
                    dp.rows.each(function(item) {
                        var duration = item.events.totalDuration();
                        var str;
                        if (duration.totalDays() >= 1) {
                            str = Math.floor(duration.totalHours()) + ":" + duration.toString("mm");
                        }
                        else {
                            str = duration.toString("H:mm");
                        }
                        
                        item.column(1).html(str + " hours");
                    });
                }

            </script>

        </div>
        <div class="clear">
        </div>
</body>
</html>

