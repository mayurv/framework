<?php
if(isset($my_statastic)){
$arr_name=array();
$arr_value=array();
$monthName =array();
$months = array (1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec');

                                        foreach ($my_statastic as $k => $opData) {
//                                            var_dump($opData);
                                            $arr_name[$k] = ltrim($opData['submission_month'], '0') ;
                                            $monthName[$k] =  "'". $months[$arr_name[$k]].'$k'. "'";
                                            $arr_value[$k] = "'". $opData['total_hours'] ."'";
            
                                        }
                                        //var_dump($arr_value);
                                        $string_name = implode(',', $monthName);
                                        $string_value = implode(',', $arr_value);
//                                        echo $string_name;
//                                        echo $string_value;
                                       
}

?>



<canvas id="barChart1" height="80"></canvas>
<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script>
    $(function () {
        var names = <?php echo '[' . $string_name . ']' ?>;
        var values = <?php echo '[' . $string_value . ']' ?>;
        var barData = {
            labels: names,
            datasets: [
                {
                    label: "Hours",
                    backgroundColor: 'rgba(26,179,148,0.5)',
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: values
                }
            ]
        };
        var barOptions = {
            responsive: true,
            scales: {
                xAxes: [{
                        ticks: {
                            stepSize: 10,
                        },
                        stacked: true,
                        gridLines: {
                            lineWidth: 0,
                            color: "rgba(255,255,255,0)"
                        }
                    }],
                yAxes: [{
                        stacked: true,
                        ticks: {
                            min: 0,
                            stepSize: 1,
                        }

                    }]
            }
        };
        var ctx2 = document.getElementById("barChart1").getContext("2d");
        new Chart(ctx2, {type: 'bar', data: barData, options: barOptions});
    });


        </script>