<?php // var_dump($bookings);die;   ?>
<?php $currentDate = date('Y-m-d 00:00:00'); ?>
<div class="main-bg all-padding-15">
    <div class="row">
        <div class="col-sm-12">
            <h4>Approve Booking</h4>
        </div>
        <!--        <div class="col-sm-3 border-right">
        
                    <h4>Positions/ Openings</h4>
                    <canvas id="opningsStatus" style="height:40px; padding:5px;"></canvas>
        
        
                    <div class="margin-top-10"></div>
        
                                <h4>Request Closing Openings 
                                    <span class="pull-right">
                                        <label class="label label-secondary">
        <?php
        $i = 0;
        foreach ($openings as $result) {
            ?>
            <?php if (isset($result['req_temp_id'])) { ?>
                <?php //var_dump($currentDate)?>
                <?php //var_dump($result['req_opening']['close_date']);?>
                <?php if ($currentDate <= $result['req_opening']['close_date'] && $result['req_opening']['ispublished'] == 2) { ?>
                                                                                                        
                    <?php
                    echo $i + 1;
                } else
                    echo 0;
            }
            ?>
        <?php } ?>
                    
                                        </label>
                                    </span>
                                </h4>
                    <div class="border-bottom">
                        <table class="table data-table table-hover table-responsive">
                            <tbody>
        <?php foreach ($openings as $result) { //var_dump($openings); die;    ?>
            <?php if (isset($result['req_temp_id'])) { ?>
                                        
                                        
                <?php if ($currentDate <= $result['req_opening']['close_date'] && $result['req_opening']['ispublished'] == 2) { ?>
                    <?php
                    $date1 = date_create($currentDate);
                    $date2 = date_create($result['req_opening']['close_date']);
                    $diff = date_diff($date1, $date2);
                    ?>
                                                                                            <tr>
                                                        
                                                                                                <th>
                    <?php // var_dump($diff)?>
                                                                                        <p><?php echo $result['jobtitlename']; ?> <span class="badge badge-info"><?php echo $diff->d == 0 ? 'for today' : $diff->d . ' + Days' ?></span></p>
                                                                                        <p><span class="text-orange"><?php echo date('d F Y', strtotime($result['req_opening']['close_date'])); ?></span></p>
                                                        
                                                                                        </th>
                                                                                        <td>
                                                                                            <p>
                                                        
                                                                                                <i class="fa fa-check" id="req-ic-<?php echo $result['req_opening']['id']; ?>" onclick="aprroveClosingDate(<?php echo $result['req_opening']['id']; ?>,<?php echo $result['id']; ?>)"></i></p>
                                                                                            <input type="hidden" value="<?php echo $result['close_date'] ?>" id="close_date_<?php echo $result['req_opening']['id']; ?>" name="close_date_<?php echo $result['req_opening']['id']; ?>">
                                                                                            <input type="hidden" value="<?php echo $result['req_opening']['close_date'] ?>" id="req_close_date_<?php echo $result['req_opening']['id']; ?>" name="req_close_date_<?php echo $result['req_opening']['id']; ?>">
                                                        
                                                                                        </td>
                                                        
                                                                                        </tr>
                <?php } ?>
            <?php } ?>
        <?php } ?>
                            </tbody>
                        </table>
                    </div>
        
                </div>-->
        <div class="col-md-12">

            <?php // var_dump($openings); die;    ?>
            
                 <table id="conf-approval" class="table " cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th >Requested By</th>
                        <th>Room Name</th>
                        <th>From</th>
                        <th >To</th>
                        <th >Timing</th>
                        <th>Total hours</th>                      
                        <th >Recurring Status</th>
                        <th ></th>

                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th >Requested By</th>
                        <th>Room Name</th>
                        <th>From</th>
                        <th >To</th>
                        <th >Timing</th>
                        <th>Total hours</th>                      
                        <th >Recurring Status</th>
                        <th ></th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach ($bookings as $result) { //var_dump($openings);die;   ?>
                        <tr>                      

                            <td>
                                <i>
                                    <?php if (isset($result['profileimg']) && $result['profileimg'] != '') { ?>
                                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $result['profileimg']; ?>">  
                                    <?php } else { ?>
                                        <img class="img-rounded img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                    <?php } ?>
                                </i>
                                <p><?php echo $result['userfullname'] ?></p>
                                <p class="text-light-gray"><?php echo $result['department_name'] ?>, <?php echo $result['position_name'] ?></p>


                            </td>
                            <td >
                                <p><span class="btn btn-default btn-xs"><?php echo $result['room_title'] ?></span></p>

                            </td>

                            <td>
                                <p><?php echo date('d F Y', strtotime($result['start'])); ?></p>                              
                                <p><?php echo date('l', strtotime($result['start'])); ?></p>                              
                            </td>
                            <td>
                                <p><?php echo date('d F Y', strtotime($result['end'])); ?></p>                              
                                <p><?php echo date('l', strtotime($result['end'])); ?></p>                              
                            </td>
                            <td>
                                <p><?php echo date('h:i A', strtotime($result['start'])); ?>-<?php echo date('h:i A', strtotime($result['end'])); ?></p>                              
                            </td>

                            <td>
                                <?php
                                $d1 = strtotime(date('h:i A', strtotime($result['start'])));
                                $d2 = strtotime(date('h:i A', strtotime($result['end'])));
                                $diff = $d2 - $d1;

                                $min = round(abs($diff) / 60, 2);
                                $hrs = $min / 60;
                                ?>
                                <p><?php echo $hrs . ' hrs'; ?></p>                              
                            </td>


                            <td><?php echo $result['recurring_status'] == 1 ? "<span class='btn btn-xs btn-info'>Recurring</span>" : "<span class='btn btn-xs btn-info'>One-Day</span>" ?></td>
                            <td width="5%">
                                <div class="switch">
                                    <label>      
                                        <?php
                                        $ch = '';
                                        $hideDiv = 'none';
                                        $function = 'approvebooking(' . $result['id'] . ')';
                                        if ($result['isactive'] == '1') {
                                            $ch = "'checked'=>'TRUE'";
                                            $hideDiv = 'none';
                                            $chval = 1;
                                        } else {
                                            $ch = "";
                                            $hideDiv = 'block';
                                            $chval = 0;
                                        }
                                        ?>

                                        <?php echo form_checkbox(array('id' => 'bookingStatus_' . $result['id'], 'name' => 'portalStatus', 'value' => $chval, 'checked' => $ch, 'onclick' => $function)); ?>
                                        <span class="lever"></span>                                    
                                    </label>
                                </div>

                            </td>  


                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>

    function approvebooking(openingId) {


        var isChecked = $("#bookingStatus_" + openingId).val();
        if (isChecked == 0) {
            $("#bookingStatus_" + openingId).val('1');
        } else {
            $("#bookingStatus_" + openingId).val('0')
        }
        var statusOp = $("#bookingStatus_" + openingId).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>conference/approve',
            data: {'booking_id': openingId, 'status': statusOp},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.active == '1')
                    showSuccess("Active - Booking approved successfully");
                else
                    showSuccess("Inactive - Booking not approved");
            }
        });
    }

</script>
<script>

    function aprroveClosingDate(temp_req_id, req_id) {
        var close_date = $('#close_date_' + temp_req_id).val();
        var req_close_date = $('#req_close_date_' + temp_req_id).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>admin/approve_closingdate',
            data: {'temp_req_id': temp_req_id, 'req_id': req_id, 'close_date': close_date, 'req_close_date': req_close_date},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.aprroved == '1') {
                    $('#req-ic-' + temp_req_id).addClass('text-success');
                    showSuccess("Approved - Position closing date request approved");
                    window.location.reload();
                } else {
                    showSuccess("Inactive - Position closing date request unapproved");
                }
            }
        });
    }

</script>

<!--Leave chart-->



