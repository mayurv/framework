<?php // var_dump($mybookings);die;?>

<div id="myapprovals">
    <table class="table data-table table-hover table-responsive">
        <thead>
            <tr>
                <th >Requested By</th>
                <th>Room Name</th>
                <th>From</th>
                <th>To</th>
                <th>Timing</th>
                <th>Total hours</th>                      
                <th>Recurring Status</th>
                <th>Approved Status</th>
                <th></th>
                

            </tr>
        </thead>
        <tbody>
            <?php foreach ($mybookings as $result) { //var_dump($mybookings);die;   ?>
                <tr id="conf_<?php echo $result['id']?>">                      

                    <td>                        
                        <p><?php echo $result['userfullname'] ?></p>
                        <p class="text-light-gray"><?php echo $result['department_name'] ?>, <?php echo $result['position_name'] ?></p>
                    </td>
                    <td >
                        <p><?php echo $result['room_title'] ?></p>

                    </td>

                    <td>
                        <p><?php echo date('d F Y', strtotime($result['start'])); ?></p>                              
                    </td>
                    <td>
                        <p><?php echo date('d F Y', strtotime($result['end'])); ?></p>                              
                    </td>
                    
                    <td>
                        <p><?php echo date('h:i A', strtotime($result['start'])); ?>-<?php echo date('h:i A', strtotime($result['end'])); ?></p>                              
                    </td>

                    <td>
                        <?php
                        $d1 = strtotime(date('h:i A', strtotime($result['start'])));
                        $d2 = strtotime(date('h:i A', strtotime($result['end'])));
                        $diff = $d2 - $d1;

                        $min = round(abs($diff) / 60, 2);
                        $hrs = $min / 60;
                        ?>
                        <p><?php echo $hrs . ' hrs'; ?></p>                              
                    </td>


                    <td><?php echo $result['recurring_status'] == 1 ? "<span class='btn btn-xs btn-info'>Recurring</span>" : "<span class='btn btn-xs btn-info'>One-Day</span>" ?></td>
                    <td>
                        <button class="btn btn-xs <?php echo $result['isactive'] == 1 ? 'btn-success' : 'btn-warning' ?>">
                        <?php echo $result['isactive'] == 1 ? 'Approved' : 'Not-Approved' ?>
                        </button>
                        
                    </td>
                    <td>
                        <?php if($result['recurring_status'] == 0) { ?>
                        <i class="fa fa-trash text-ccc" onclick="cancelConbooking('<?php echo $result['id']?>')"></i>
                        <?php }else{ ?>
                        <i class="fa fa-trash-o text-light-gray" title="You Can Not Delete Request"></i>
                        <?php } ?>
                    </td>


                </tr>
            <?php } ?>
        </tbody>
    </table>
    <?php $this->load->view('modal/_my_comments'); ?>
</div>
<div id="teamapprovals" class="hidden">
    <table class="table table-responsive">
        <thead>
            <tr>
                <th>Candidate Name</th>
                <th>For the Month</th>
                <th>Total Hours</th>
                <th>Submission Date</th>
<!--                                <th>Action</th>-->

            </tr>
        </thead>
        <div class="pull-right"> 

        </div>
        <tbody class="">
            <?php
            foreach ($associates as $r => $result) {
                $date = $result['submission_year'] . '-' . $result['submission_month'] . '-01';
//                            var_dump($date);die;
                ?>  
                <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">
                    <td class="">
                        <a title="Click here to view timesheet" data-toggle="modal" href="#candidatetimeline_<?php echo $result['id'] ?>"><?php echo $result['userfullname']; ?></a>

                    </td>

                    <td class=""><?php echo date('F', strtotime($date)); ?> <?php echo date('Y', strtotime($date)); ?></td>

                    <td class=""><?php echo $result['total_hours']; ?></td>

                    <td class=""><?php echo date("j F, Y", strtotime($result['submission_date'])); ?></td>
                    <td class="">
                        <?php if ($result['approval_status'] == 0) { ?>
                            <a  data-toggle="modal" href="#manager_approve_comment_<?php echo $result['id'] ?>" class="btn btn-xs btn-success" id="id-submit-tm" >
                                <i class="fa fa-check"> </i> Approve
                            </a>
                            <a  data-toggle="modal" href="#manager_reject_comment_<?php echo $result['id'] ?>" class="btn btn-xs btn-danger" id="id-submit-tm" >
                                <i class="fa fa-times"> </i> Reject
                            </a>
                        <?php } else { ?>
                            <a  data-toggle="modal" href="#manager_view_comment_<?php echo $result['id'] ?>" class="btn btn-xs btn-info" id="id-submit-tm" >
                                <i class="fa fa-external-link"> </i> View
                            </a>
                        <?php } ?>
                    </td>
                </tr>  
            <?php } ?>
        </tbody>
    </table>
    <?php $this->load->view('modal/_manager_comment'); ?>
</div>

<script>
    $(document).ready(function () {
        $("#lever_approval").click(function () {
            $('#myapprovals').toggleClass('hidden');
            $('#teamapprovals').toggleClass('hidden');
        });
    });
    
    function cancelConbooking(dId) {

        if (confirm('Are you sure, you want to cancel booking?')) {

            $("tr").remove("#conf_" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>conference/delete_booking',
                data: {'conf_id': dId},
                success: function (data) {
//                    var parsed = $.parseJSON(data);
                    showSuccess('Booking Canceled');
                }
            });
            return false;
        }
    }
</script>