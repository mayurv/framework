<div class="white-bg all-padding-15">
    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Conference Booking</h4>
                    </div>  

                    <div class="pull-right">
                        <div class="icon-bg"> 
                            <i class="fa fa-info-circle text-ccc" title="You can submit timesheet between 1st to 5th <?php echo date('F Y', (strtotime('next month', strtotime(date('m/01/y'))))); ?>"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-12">
            <div class="col-sm-2">
                <div id="nav"></div>
            </div>
            <div class="col-sm-10">                       
                <div id="dp"></div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url(); ?>assets/plugins/conference/recuring/js/daypilot/daypilot-all.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/plugins/conference/recuring/js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<link href="<?php echo base_url('assetls/plugins/conference/recuring/layout.css'); ?>" rel="stylesheet" type="text/css" media="screen"/>



<?php $this->load->view('modal/book_recursiveconference') ?>

<script type="text/javascript">
    var nav = new DayPilot.Navigator("nav");
    nav.selectMode = "month";
    nav.showMonths = 1;
    nav.skipMonths = 1;
    nav.onTimeRangeSelected = function (args) {
        loadTimeline(args.start);
        loadEvents();
    };
    nav.init();

    $("#timerange").change(function () {
        switch (this.value) {
            case "week":
                dp.days = 7;
                nav.selectMode = "Week";
                nav.select(nav.selectionDay);
                break;
            case "month":
                dp.days = dp.startDate.daysInMonth();
                nav.selectMode = "Month";
                nav.select(nav.selectionDay);
                break;
        }
    });

    $("#autocellwidth").click(function () {
        dp.cellWidth = 40;  // reset for "Fixed" mode
        dp.cellWidthSpec = $(this).is(":checked") ? "Auto" : "Fixed";
        dp.update();
    });

    $("#add-room").click(function (ev) {
        ev.preventDefault();
        var modal = new DayPilot.Modal();
        modal.onClosed = function (args) {
            loadResources();
        };
        modal.showUrl("room_new.php");
    });
</script>

<script>
    var dp = new DayPilot.Scheduler("dp");

    dp.allowEventOverlap = false;

    //dp.scale = "Day";
    //dp.startDate = new DayPilot.Date().firstDayOfMonth();
    dp.days = dp.startDate.daysInMonth();
    loadTimeline(DayPilot.Date.today().firstDayOfMonth());

    dp.eventDeleteHandling = "Update";

    dp.timeHeaders = [
        {groupBy: "Month", format: "MMMM yyyy"},
        {groupBy: "Day", format: "d"}
    ];

    dp.eventHeight = 50;
    dp.bubble = new DayPilot.Bubble({});

    dp.rowHeaderColumns = [
        {title: "Conf Room", width: 80},
//                        {title: "Capacity", width: 80},
//                        {title: "Status", width: 80}
    ];

    dp.onBeforeResHeaderRender = function (args) {
//                        var beds = function(count) {
//                            return count + " bed" + (count > 1 ? "s" : "");
//                        };
//
//                        args.resource.columns[0].html = beds(args.resource.capacity);
//                        args.resource.columns[1].html = args.resource.status;
//                        switch (args.resource.status) {
//                            case "Dirty":
//                                args.resource.cssClass = "status_dirty";
//                                break;
//                            case "Cleanup":
//                                args.resource.cssClass = "status_cleanup";
//                                break;
//                        }

        args.resource.areas = [{
                top: 3,
                right: 4,
                height: 14,
                width: 14,
                action: "JavaScript",
                js: function (r) {
                    var modal = new DayPilot.Modal();
                    modal.onClosed = function (args) {
                        loadResources();
                    };
                    modal.showUrl("room_edit.php?id=" + r.id);
                },
                v: "Hover",
                css: "icon icon-edit",
            }];
    };

    // http://api.daypilot.org/daypilot-scheduler-oneventmoved/
    dp.onEventMoved = function (args) {
        $.post("conferencebookingbackend_move",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString(),
                    newResource: args.newResource
                },
        function (data) {
            dp.message(data.message);
        });
    };

    // http://api.daypilot.org/daypilot-scheduler-oneventresized/
    dp.onEventResized = function (args) {
        $.post("conferencebooking/backend_resize",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString()
                },
        function () {
            dp.message("Resized.");
        });
    };

    dp.onEventDeleted = function (args) {
        $.post("conferencebooking/backend_delete",
                {
                    id: args.e.id()
                },
        function () {
            dp.message("Deleted.");
        });
    };

    // event creating
    // http://api.daypilot.org/daypilot-scheduler-ontimerangeselected/
    dp.onTimeRangeSelected = function (args) {
        //var name = prompt("New event name:", "Event");
        //if (!name) return;

//        var modal = new DayPilot.Modal();
//        modal.closed = function () {
//            console.log("Modal dialog closed");
////            dp.clearSelection();
////
////            // reload all events
////            var data = this.result;
////            if (data && data.result === "OK") {
////                loadEvents();
////            }
//        };
        // modal.showUrl("new.php?start=" + args.start + "&end=" + args.end + "&resource=" + args.resource);
         var resource_list = <?php echo json_encode($resources) ?>;

        var a = args.start;
        var b = args.end;
        var resource = args.resource;



        var myString = a.toString();
        var myString2 = b.toString();
        var myArray = myString.split('T');
        var myArray2 = myString2.split('T');

        var t = myArray[0] + ' ' + myArray[1];
        var t2 = myArray2[0] + ' ' + myArray2[1];

        var now = new Date(t);
        var now1 = new Date(t2);

        var currenet_date = formatDate(now);

        var start_time = formatAMPM(now);
        var end_time = formatAMPM(now1);
        var day_name = now.getWeekDay();
        var day_name1 = now1.getWeekDay();

        var diffInHours = (new Date(now1) - new Date(now)) / 1000 / 60 / 60;

        var title_date = now.getDate();
        var t_month = now.getMonthName();
        var t_year = now.getFullYear();
        
        var title_date1 = now1.getDate();
        var t_month1 = now1.getMonthName();
        var t_year1 = now1.getFullYear();
        
        
        var title_year = title_date + ' ' + t_month + ' ' + t_year;
        var title_year1 = title_date1 + ' ' + t_month1 + ' ' + t_year1;

        $(".title_day").text(day_name);
        $(".title_day1").text(day_name1);
//                $(".title_year").text(currenet_date);
        $(".title_year").text(title_year);
        $(".title_year1").text(title_year1);
        $(".title_date").text(title_date);
        $(".title_start_time").text(start_time);
        $(".title_end_time").text(end_time);
        $(".title_hours_diff").text(diffInHours);
          $(".resource_id").text(resource_list[resource - 1].name);
        $("#bookrecursiveconference-modal").addClass('show');
        $("#start_time").val(args.start);
        $("#end_time").val(args.end);
        $("#resource").val(args.resource);
//         $.post("conferencebooking/backend_create",
//                    {
//                        start: args.start.toString(),
//                        end: args.end.toString(),
//                        resource: args.resource,
//                                               //total_hours: '',
//                    },
//                      function (data) {
//                        var e = new DayPilot.Event({
//                            start: args.start,
//                            end: args.end,
//                            id: data.id,
//                            resource: args.resource,
//                            text: name
//                        });
//                        dp.events.add(e);
//                       loadEvents();
//                        dp.message(data.message);
//                    });
//                     

    };

    dp.onEventClick = function (args) {
        var modal = new DayPilot.Modal();
        modal.closed = function () {
            // reload all events
            var data = this.result;
            if (data && data.result === "OK") {
                loadEvents();
            }
        };
        modal.showUrl("edit.php?id=" + args.e.id());
    };

    dp.onBeforeCellRender = function (args) {
        var dayOfWeek = args.cell.start.getDayOfWeek();
        if (dayOfWeek === 6 || dayOfWeek === 0) {
            args.cell.backColor = "#f8f8f8";
        }
    };

    dp.onBeforeEventRender = function (args) {
        var start = new DayPilot.Date(args.e.start);
        var end = new DayPilot.Date(args.e.end);

        var today = DayPilot.Date.today();
        var now = new DayPilot.Date();

        args.e.html = args.e.text + " (" + start.toString("M/d/yyyy") + " - " + end.toString("M/d/yyyy") + ")";

//                        switch (args.e.status) {
//                            case "New":
//                                var in2days = today.addDays(1);
//
//                                if (start < in2days) {
//                                    args.e.barColor = 'red';
//                                    args.e.toolTip = 'Expired (not confirmed in time)';
//                                }
//                                else {
//                                    args.e.barColor = 'orange';
//                                    args.e.toolTip = 'New';
//                                }
//                                break;
//                            case "Confirmed":
//                                var arrivalDeadline = today.addHours(18);
//
//                                if (start < today || (start.getDatePart() === today.getDatePart() && now > arrivalDeadline)) { // must arrive before 6 pm
//                                    args.e.barColor = "#f41616";  // red
//                                    args.e.toolTip = 'Late arrival';
//                                }
//                                else {
//                                    args.e.barColor = "green";
//                                    args.e.toolTip = "Confirmed";
//                                }
//                                break;
//                            case 'Arrived': // arrived
//                                var checkoutDeadline = today.addHours(10);
//
//                                if (end < today || (end.getDatePart() === today.getDatePart() && now > checkoutDeadline)) { // must checkout before 10 am
//                                    args.e.barColor = "#f41616";  // red
//                                    args.e.toolTip = "Late checkout";
//                                }
//                                else
//                                {
//                                    args.e.barColor = "#1691f4";  // blue
//                                    args.e.toolTip = "Arrived";
//                                }
//                                break;
//                            case 'CheckedOut': // checked out
//                                args.e.barColor = "gray";
//                                args.e.toolTip = "Checked out";
//                                break;
//                            default:
//                                args.e.toolTip = "Unexpected state";
//                                break;
//                        }

        args.e.html = args.e.html + "<br /><span style='color:gray'>" + args.e.toolTip + "</span>";

        var paid = args.e.paid;
        var paidColor = "#aaaaaa";

        args.e.areas = [
            {bottom: 10, right: 4, html: "<div style='color:" + paidColor + "; font-size: 8pt;'>Paid: " + paid + "%</div>", v: "Visible"},
            {left: 4, bottom: 8, right: 4, height: 2, html: "<div style='background-color:" + paidColor + "; height: 100%; width:" + paid + "%'></div>", v: "Visible"}
        ];

    };


    dp.init();

    loadResources();
    loadEvents();

    function loadTimeline(date) {
        dp.scale = "Manual";
        dp.timeline = [];
        var start = date.getDatePart().addHours(24); //full day ..previous 12(start at 00:00 and end and 24:00.)

        for (var i = 0; i < dp.days; i++) {
            dp.timeline.push({start: start.addDays(i), end: start.addDays(i + 1)});
        }
        dp.update();
    }

    function loadEvents() {
        var start = dp.visibleStart();
        var end = dp.visibleEnd();

        $.post("conferencebooking/recuringbackend_events",
                {
                    start: start.toString(),
                    end: end.toString()
                },
        function (data) {
            dp.events.list = data;
            dp.update();
        }
        );
    }

    function loadResources() {
        $.post("conferencebooking/backend_resources",
//                        { capacity: $("#filter").val() },
                function (data) {
                    dp.resources = data;
                    dp.update();
                });
    }

    $(document).ready(function () {
        $("#filter").change(function () {
            loadResources();
        });
    });

</script>
<script>
    Date.prototype.getWeekDay = function () {
        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        return weekday[this.getDay()];
    };

    Date.prototype.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    Date.prototype.getMonthName = function () {
        return this.monthNames[this.getMonth()];
    };

    function formatAMPM(date)
    {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        // the hour '0' should be '12' 
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    }

    function getMonthAll(date) {
        var month = date.getMonth() + 1;
        return month < 10 ? '0' + month : '' + month; // ('' + month) for string result
    }

    function formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }
    $(".add_close").click(function () {
        $('#bookrecursiveconference-modal').removeClass('show');
        window.location.reload();
    });
</script>