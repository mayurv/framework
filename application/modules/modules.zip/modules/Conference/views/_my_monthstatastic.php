<?php
$barChartData = array();
$arr_name = array();
$arr_value = array();
$months = array(1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec');
$resM = array();
foreach ($my_monthstatastic as $monthNm => $opDataM) {

    foreach ($opDataM as $k => $data) {
        $resM[$monthNm]['lbl'][$k] = "'" . date("d", strtotime($data['start'])) .' '.$monthNm ."'";
        $resM[$monthNm]['val'][$k] = "'" . $data['total_hours'] . "'";
    }
}

foreach ($resM as $lbl => $label) {
    $barChartData[$lbl]['lbl'] = implode(',', $label['lbl']);
    $barChartData[$lbl]['val'] = implode(',', $label['val']);
}
?>

<div class="row">
    <div class="col-sm-6">
        <h4 class="text-bold">Statasctic</h4>
    </div>
    <div class="col-sm-2 ">

        <div>
            <form method="POST" action="<?php echo base_url() ?>timesheet" id="id-filtertm-year">
                <?php $post_condition?$active='selected':$active ='';?>

                <select class="browser-default" name="year_list" id="year_list">
                    <!--//if post_condition_yr == val-->
                    <?php  if($post_condition_yr)?>
                    <option value="2017" <?php echo $post_condition_yr=='2017'?$active:''?>>2017</option>
                    <option value="2016" <?php echo $post_condition_yr=='2016'?$active:''?>>2016</option>
                    <option value="2015" <?php echo $post_condition_yr=='2015'?$active:''?>>2015</option>
                </select>
            </form> 

        </div>

    </div>
    <div class="col-sm-4 ">
        <div class="switch pull-right">
            <label>      
                <!--onclick="activateJobOpenings(1)"-->
                My Statistics
                <input type="checkbox" name="portalStatus" value="1"  id="openingStatus_1" >
                <span class="lever" id="id-mstatistic"></span>     
                Team Statistics
            </label>
        </div>

    </div>


</div>
<div class="clearfix margin-bottom-30"></div>
<div id="my-statistic">
    <div class="row">
        <div class="col-sm12">
            <ul class="nav nav-tabs vertical col-sm-2 left-aligned">
                <?php $i = 1; ?>
                <?php foreach ($resM as $lbl => $label) { ?>
                    <?php $i == 1 ? $active = 'active' : $active = ''; ?>

                    <li class="<?php echo $active ?>" onclick="changePane('<?php echo $lbl ?>')">
                        <a href="#<?php echo $lbl ?>" data-toggle="tab" aria-expanded="true">
                            <i class="fa fa-home"></i> <?php echo $lbl ?>
                        </a>
                    </li>

                    <?php
                    $i++;
                }
                ?>



            </ul>					

            <div class="tab-content vertical col-sm-10 left-aligned primary">

                <?php $i = 1; ?>
                <?php foreach ($resM as $lbl => $label) { ?>
                    <?php $i == 1 ? $active = 'active in' : $active = ''; ?>

                    <div class="tab-pane fade <?php echo $active ?>" id="<?php echo $lbl ?>" >


                        <canvas id="barChart<?php echo $i; ?>" height="120"></canvas>

                    </div>


                    <?php
                    $i++;
                }
                ?>

            </div>


        </div>

    </div>
</div>
<div id="teamstatastic" class="hidden" >   
    <?php $this->load->view('_team_statasctic'); ?>
</div>

<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script>
                        $(function () {



<?php $i = 1; ?>

<?php foreach ($barChartData as $chartData) { ?>

                                var values = <?php echo '[' . $chartData['val'] . ']' ?>;
                                var names = <?php echo '[' . $chartData['lbl'] . ']' ?>;
                                var barData<?php echo $i; ?> = {
                                    labels: names,
                                    datasets: [
                                        {
                                            label: "Hours",
                                            backgroundColor: 'rgba(26,179,148,0.5)',
                                            borderColor: "rgba(26,179,148,0.7)",
                                            pointBackgroundColor: "rgba(26,179,148,1)",
                                            pointBorderColor: "#fff",
                                            data: values
                                        }
                                    ]

                                };

                                var barOptions = {
                                    responsive: true,
                                    scales: {
                                        xAxes: [{
                                                ticks: {
                                                    stepSize: 10,
                                                },
                                                stacked: true,
                                                gridLines: {
                                                    lineWidth: 0,
                                                    color: "rgba(255,255,255,0)"
                                                }
                                            }],
                                        yAxes: [{
                                                stacked: true,
                                                ticks: {
                                                    min: 0,
                                                    stepSize: 1,
                                                }

                                            }]
                                    }
                                };

                                var ctx = document.getElementById("barChart<?php echo $i; ?>").getContext("2d");

                                new Chart(ctx, {type: 'bar', data: barData<?php echo $i; ?>, options: barOptions});
                                ctx = '';
                                barData = '';
                                names = '';
                                values = '';

    <?php
    $i++;
}
?>
                        });


</script>
<script>
    var cnt = '0';
    function changePane(paneMonth) {
        if (cnt == '0')
            $('#jan').removeClass('active in');
        if (cnt == '1')
            $('#' + last_pane).removeClass('active in');

        $('#' + paneMonth).addClass('active in');
        cnt = '1';
        last_pane = paneMonth;

    }
</script>

<script>
    $(document).ready(function () {
        $("#id-mstatistic").click(function () {
            $('#my-statistic').toggleClass('hidden');
            $('#teamstatastic').toggleClass('hidden');
        });
    });
</script>

<script>
    $(document).ready(function () {
        $("select[id='year_list']").change(function () {
//            alert('ss');
            $('#id-filtertm-year').submit();

//            var year_list_id = $("select[id='year_list']").val();
            //alert(year_list_id);
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url(); ?>timesheet',
//                data: {'year_list_id': year_list_id},
//                success: function (data) {
//                    var parsed = $.parseJSON(data);
//
//                    $("input[name='email']").val(parsed.email);
//                }
//            });

        });
    });
</script>