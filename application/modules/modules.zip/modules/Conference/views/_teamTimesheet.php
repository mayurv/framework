<div class="team-view">
    <div class="row">
    <div class="col-sm-8">
        <h4 class="text-bold">Timesheet</h4>
    </div>

    <div class="col-sm-1">
        <div class="margin-top-5">
            <form action="<?php echo base_url(); ?>timesheet/submit_timesheet" method="post">
                <?php $current_date = '2017-02-01'; //date('Y-m-d');?>
                <?php if ($submission_status == 0 && $submission_sdate >= $current_date && $current_date <= $submission_edate) { ?>
                    <button type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                        <i class="fa fa-list"> </i> Submit
                    </button>
                <?php } ?>
            </form>
        </div>

    </div>
    <div class="col-sm-1 pull-right">                    

        <i class="fa fa-info-circle text-ccc" title="You can submit timesheet between 1st to 5th <?php echo date('F Y', (strtotime('next month', strtotime(date('m/01/y'))))); ?>"></i>
    </div>
    <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 1) { ?>
        <div class="col-sm-2">
            <div class="margin-top-5">
                <a href="<?php echo base_url() ?>timesheet/approve_timesheet" type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                    <i class="fa fa-list"> </i> Approve Timesheet
                </a>
            </div>
        </div>
    <?php } ?>
</div>
<div class="clearfix"></div>
<div class="row">
    <div class="col-sm-6">
        <?php
        $user_id = $this->session->userdata('user_id');
        echo form_label(lang('employee_team'), 'employee_team', array('for' => 'employee_team'));
        ?>
        <?php
        echo form_dropdown(array(
            'id' => 'employee_team',
            'name' => 'employee_team',
            'class' => 'browser-default',
            'data-error' => '.timesheet1',
            'value' => $user_id
        ));
        ?>
        <div class="input-field">
            <div class="timesheet1"></div>
            <?php echo form_error('employee_team'); ?> 
        </div>                    
    </div>
    <div class="col-sm-3">

        <div class="form-group">
            <div class="controls ">
                <input type="text" name="end_date" id="end_date" class="form-control date" data-format="MM yyyy" placeholder="Select Month">

            </div>

        </div>

<!--<input type="button" name="end_date" id="end_date" class="filter-textfields end_date" placeholder="Enter date"/>-->
    </div>
    <div class="col-sm-1 pull-left">
        <div class="margin-top-5">
            <button type="submit" class="btn btn-sm" id="id-search-tm"><i class="fa fa-search"></i></button>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div id="team_dp"></div>
    </div>
</div>
</div>

<?php $this->load->view('modal/add_timesheet') ?>
<?php $this->load->view('modal/edit_timesheet') ?>
<script src="<?php echo base_url(); ?>assets/plugins/timesheet/js/daypilot/daypilot.js" type="text/javascript"></script> 
<style>
    .modal_min_main { border: 1px solid #ccc !important; }
    .modal_min_background { opacity: 0.3; background-color: #000; }
</style>


<script>

    Date.prototype.getWeekDay = function () {
        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        return weekday[this.getDay()];
    }

    Date.prototype.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    Date.prototype.getMonthName = function () {
        return this.monthNames[this.getMonth()];
    };

    function formatAMPM(date)
    {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        // the hour '0' should be '12' 
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    }

    function getMonthAll(date) {
        var month = date.getMonth() + 1;
        return month < 10 ? '0' + month : '' + month; // ('' + month) for string result
    }

    function formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }

    $(document).ready(function () {

        var currentTime = new Date()
        var minDate = new Date(currentTime.getFullYear(), currentTime.getMonth() - 3); //one day next before month
        var maxDate = new Date(currentTime.getFullYear(), currentTime.getMonth()); // one day before next month

        $(".date").datepicker({
            format: "yyyy-mm",
            startDate: minDate,
            endDate: maxDate,
            startView: "year",
            minViewMode: "months"
        });

        $("#id-search-tm").click(function () {
            var filter_month = $('#end_date').val();
            filter_month = filter_month + '-01T00:00:00';
            var a = new Date(filter_month);
            var mm = ("0" + (a.getMonth() + 1)).slice(-2);
            var year = a.getFullYear();
            var cm_date = year + '-' + mm;
            filter_month = cm_date + '-01T00:00:00';
            teamp_dp.startDate = new DayPilot.Date(filter_month).firstDayOfMonth();
            teamp_dp.days = teamp_dp.startDate.daysInMonth();
            var url = "timesheet/backend_events/" + $("#employee").val() + "/" + teamp_dp.startDate + "/" + teamp_dp.startDate.addDays(teamp_dp.days);
            teamp_dp.events.load(url, function () {
                teamp_dp.message("Events for " + $("#employee option:selected").text() + " loaded.");
                updateTotals();
            });
        });


<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>

        $(".close").click(function () {
            $('#timesheet-modal').removeClass('show');
            window.location.reload();
        });
    });

</script>


<script type="text/javascript">
    var team_dp = new DayPilot.Scheduler("team_dp");
    team_dp.viewType = "Days";
    team_dp.startDate = new DayPilot.Date().firstDayOfMonth();
    team_dp.days = team_dp.startDate.daysInMonth();
    team_dp.timeHeaders = [
        {groupBy: "Day", format: "MMMM yyyy"},
        {groupBy: "Hour"}
    ];
//        alert(team_dp.timeHeaders);
    team_dp.heightSpec = "Max";
    team_dp.height = 400;
    team_dp.cellWidthSpec = "Auto";
    team_dp.rowHeaderColumns = [
        {title: "Day", width: 100},
        {title: "Total", width: 100}
    ];
    // http://api.daypilot.org/daypilot-scheduler-oneventmoved/ 
    team_dp.onEventMoved = function (args) {
        $.post("timesheet/backend_move",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString(),
                    newResource: args.newResource,
                },
                function () {
                    updateTotals();
                    team_dp.message("Moved.");
                });
    };
    // http://api.daypilot.org/daypilot-scheduler-oneventresized/ 
    team_dp.onEventResized = function (args) {
        $.post("timesheet/backend_resize",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString()
                },
        function () {
            updateTotals();
            team_dp.message("Resized.");
        });
    };

    team_dp.onTimeRangeSelected = function (args) {

        var modal = new DayPilot.Modal({
            onClosed: function (args) {
                console.log("Modal dialog closed");
            },
            // ...
        });
        //timesheet-modal
        // title_start_time title_end_time
        var now = new Date(t);

        var a = args.start;
        var b = args.end;

        var myString = a.toString();
        var myString2 = b.toString();
        var myArray = myString.split('T');
        var myArray2 = myString2.split('T');

        var t = myArray[0] + ' ' + myArray[1];
        var t2 = myArray2[0] + ' ' + myArray2[1];

        var now = new Date(t);
        var now1 = new Date(t2);

        var currenet_date = formatDate(now);

        var start_time = formatAMPM(now);
        var end_time = formatAMPM(now1);
        var day_name = now.getWeekDay();

        var diffInHours = (new Date(now1) - new Date(now)) / 1000 / 60 / 60;

        var title_date = now.getDate();
        var t_month = now.getMonthName();

        var t_year = now.getFullYear();
        var title_year = t_month + ' ' + t_year;

        $(".title_day").text(day_name);
//                $(".title_year").text(currenet_date);
        $(".title_year").text(title_year);
        $(".title_date").text(title_date);
        $(".title_start_time").text(start_time);
        $(".title_end_time").text(end_time);
        $(".title_hours_diff").text(diffInHours);
        $("#timesheet-modal").addClass('show');

        $("#start_time").val(args.start);
        $("#end_time").val(args.end);

        $.post("timesheet/backend_create",
                {
                    start: args.start.toString(),
                    end: args.end.toString(),
                    resource: $("#employee_team").val(),
                    name: name,
                    mang_id: 1,
                    //total_hours: '',
                },
                function (data) {
                    var e = new DayPilot.Event({
                        start: args.start,
                        end: args.end,
                        id: data.id,
                        resource: args.resource,
                        text: name
                    });
                    team_dp.events.add(e);
                    updateTotals();
                    team_dp.message(data.message);
                });
    };
    team_dp.onEventClick = function (args) {
        var modal = new DayPilot.Modal();
        modal.closed = function () {
            // reload all events
            var data = this.result;
            if (data && data.result === "OK") {
                loadEvents();
            }
        };
        // modal.showUrl("timesheet/edit/" + args.e.id());
        $("#edit_timesheet-modal" + args.e.id()).addClass('show');
    };
    team_dp.init();
    $(document).ready(function () {

        loadResources();
        $("#employee_team").change(function () {

            loadEvents();
        });
    });
    function loadResources() {
        $.post("timesheet/backend_teamresources", function (data) {
//                        alert(data);
            for (var i = 0; i < data.length; i++) {

                var item = data[i];
                $("#employee_team").append($('<option/>', {
                    value: item.id,
                    text: item.name
                }));
            }
            loadEvents();
        });

    }

    function loadEvents() {

        var filter_month = $('#end_date').val();

        if (filter_month != '') {
            filter_month = filter_month + '-01T00:00:00';
            var a = new Date(filter_month);

            var mm = ("0" + (a.getMonth() + 1)).slice(-2);
            var year = a.getFullYear();
            var cm_date = year + '-' + mm;
            filter_month = cm_date + '-01T00:00:00';
            team_dp.startDate = new DayPilot.Date(filter_month).firstDayOfMonth();
            team_dp.days = team_dp.startDate.daysInMonth();
        }

        var url = "timesheet/backend_events/" + $("#employee_team").val() + "/" + team_dp.startDate + "/" + team_dp.startDate.addDays(team_dp.days);
        team_dp.events.load(url, function () {
            team_dp.message("Events for " + $("#employee_team option:selected").text() + " loaded.");
            updateTotals();
        });

    }

    function updateTotals() {
        team_dp.rows.each(function (item) {
//                        alert(JSON.stringify(item));
//                        return false;
//                        alert(item);
            var duration = item.events.totalDuration();
            var str;
            if (duration.totalDays() >= 1) {
                str = Math.floor(duration.totalHours()) + ":" + duration.toString("mm");
            }
            else {
                str = duration.toString("H:mm");
            }

            item.column(1).html(str + " hours");
        });

    }


</script>
