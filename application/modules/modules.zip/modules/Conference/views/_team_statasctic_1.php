<?php
$arr_name=array();
$arr_value=array();


                                        foreach ($team_monthstatastic as $k => $opData) {
                                          // var_dump($opData);die;
                                            $arr_name[$k] = "'". ($opData['userfullname'])."'" ;
                             //               $monthName[$k] =  "'". $months[$arr_name[$k]]. "'";
                                            $arr_value[$k] = "'". $opData['total_hours'] ."'";
            
                                        }
                                        //var_dump($arr_value);
                                        $string_name = implode(',', $arr_name);
                                        $string_value = implode(',', $arr_value);
                                       // echo $string_name;
                                       // echo $string_value;
                                       


?>



<canvas id="barChart1" height="80"></canvas>
<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script>
    $(function () {
        var names = <?php echo '[' . $string_name . ']' ?>;
        var values = <?php echo '[' . $string_value . ']' ?>;
        var barData = {
            labels: names,
            datasets: [
                {
                    label: "Hours",
                    backgroundColor: 'rgba(26,179,148,0.5)',
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: values
                }
            ]
        };
        var barOptions = {
            responsive: true,
            scales: {
                xAxes: [{
                        ticks: {
                            stepSize: 50,
                        },
                        stacked: true,
                        gridLines: {
                            lineWidth: 0,
                            color: "rgba(255,255,255,0)"
                        }
                    }],
                yAxes: [{
                        stacked: true,
                        ticks: {
                            min: 0,
                            stepSize: 25,
                        }

                    }]
            }
        };
        var ctx2 = document.getElementById("barChart1").getContext("2d");
        new Chart(ctx2, {type: 'bar', data: barData, options: barOptions});
    });


        </script>