<div class="white-bg all-padding-15">


    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Conference Booking</h4>
                    </div>  

                </div>
            </div>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#conference_booking" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-square"></i> Conference Booking
                    </a>
                </li>
                <li class="">
                    <a href="#my_booking" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-history"></i> My Bookings
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="conference_booking">
                    <div class="my-timesheet">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="col-sm-2 ">
                                    <button class="btn btn-default btn-sm"><i class="fa fa-file-pdf-o"></i> Rules & Regulations</button>
                                    <div class="margin-top-32">
                                        <div id="nav" class=""></div>
                                            
                                    </div>
                                    
                                </div>

                                <div class="col-sm-10 ">
                                    <div class="col-sm-12">
                                        <table class="table table-bordered">
                                            <thead class="no-border">
                                            <th  width="20%"> <i class="fa fa-square text-white-cf "> </i> Available</th>
                                            <th width="20%"> <i class="fa fa-square text-orange-cf "> </i> Already Booked</th>
                                            <th  width="20%"> <i class="fa fa-square text-success-cf "> </i> Approved</th>
                                            <th  width="20%"> <i class="fa fa-square text-yellow-cf "> </i> Pending Approval </th>
                                            
                                            </thead>
                                        </table>
                                    </div>
                                    <div class="col-sm-12">
                                        <div id="dp"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade " id="my_booking">
                    <div class="my-timesheet">
                        <div class="row">                            
                            <div class="col-sm-12">
                                <?php $this->load->view('_mybookings'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>





<?php $this->load->view('modal/book_conference') ?>
<?php $this->load->view('modal/_roomDetails') ?>
<?php $this->load->view('modal/show_booking') ?>
<script src="<?php echo base_url(); ?>assets/plugins/conference/js/daypilot/daypilot-all.min.js" type="text/javascript"></script> 
<!--<script src="<?php echo base_url(); ?>assets/plugins/conference/js/jquery-1.9.1.min.js" type="text/javascript"></script>--> 
<link href="<?php // echo base_url('assets/plugins/conference/layout.css');        ?>" rel="stylesheet" type="text/css" media="screen"/>
<script type="text/javascript">

    var nav = new DayPilot.Navigator("nav");
    nav.onTimeRangeSelected = function (args) {
        var day = args.day;

        if (dp.visibleStart() <= day && day < dp.visibleEnd()) {
            dp.scrollTo(day, "fast");
        }
        else {
            var start = day.firstDayOfMonth();
            var days = day.daysInMonth();
            dp.startDate = start;
            dp.days = days;
            dp.update();
            dp.scrollTo(day, "fast");
            loadEvents();
        }
    };
    nav.init();


    var dp = new DayPilot.Scheduler("dp");

    dp.treeEnabled = true;

    dp.heightSpec = "Max";
    dp.height = 300;

    dp.scale = "Hour";
    dp.startDate = DayPilot.Date.today().firstDayOfMonth();
    dp.days = DayPilot.Date.today().daysInMonth();
    dp.cellWidth = 50;

    dp.eventHeight = 50;
    dp.durationBarVisible = false;

    //dp.rowMarginTop = 15;
    dp.treePreventParentUsage = true;

    dp.onBeforeEventRender = function (args) {
    };

    var slotPrices = {
        "00:00": 0,
        "01:00": 0,
        "02:00": 0,
        "03:00": 0,
        "04:00": 0,
        "05:00": 0,
        "06:00": 0,
        "07:00": 0,
        "08:00": 0,
        "09:00": 0,
        "10:00": 0,
        "11:00": 0,
        "12:00": 0,
        "13:00": 0,
        "14:00": 0,
        "15:00": 0,
        "16:00": 0,
        "17:00": 0,
        "18:00": 0,
        "19:00": 0,
        "20:00": 0,
        "21:00": 0,
        "22:00": 0,
        "23:00": 0,
        "24:00": 0
    };

    dp.onBeforeCellRender = function (args) {

        if (args.cell.isParent) {
            return;
        }

        if (args.cell.start < new DayPilot.Date()) {  // past
            return;
        }

        if (args.cell.utilization() > 0) {
            return;
        }

        var color = "green";

        var slotId = args.cell.start.toString("HH:mm");
        var price = slotPrices[slotId];

        var min = 5;
        var max = 15;
        var opacity = (price - min) / max;
        var text = "$" + price;
        args.cell.html = "<div style='cursor: default; position: absolute; left: 0px; top:0px; right: 0px; bottom: 0px; padding-left: 3px; text-align: center; background-color: " + color + "; color:white; opacity: " + opacity + ";'>" + text + "</div>";
    };

    dp.timeHeaders = [
        {groupBy: "Month", format: "MMMM yyyy"},
        {groupBy: "Day", format: "dddd, MMMM d"},
        {groupBy: "Hour", format: "h tt"}
    ];

    dp.businessBeginsHour = 6;
    dp.businessEndsHour = 24;
    dp.businessWeekends = true;
    dp.showNonBusiness = false;

    dp.allowEventOverlap = false;

    dp.bubble = new DayPilot.Bubble();
    dp.rowHeaderColumns = [
        {title: "Conf Room", width: 80}
//                        {title: "Capacity", width: 80},
//                        {title: "Status", width: 80}
    ];
    
    
      dp.onTimeRangeSelecting = function (args) {
        if (args.start < new DayPilot.Date()) {
            args.right.enabled = true;
            args.right.html = "You can't create a reservation in the past";
            args.allowed = false;
        }
        else if (args.duration.totalHours() > 4) {
            args.right.enabled = true;
            args.right.html = "You can only book up to 4 hours";
            args.allowed = false;
        }
    };
    
    dp.onTimeRangeSelected = function (args) {
        // var name = prompt("New event name:", "Event");
        //  dp.clearSelection();
        // if (!name) return;
        var resource_list = <?php echo json_encode($resources) ?>;

        var a = args.start;
        var b = args.end;
        var resource = args.resource;



        var myString = a.toString();
        var myString2 = b.toString();
        var myArray = myString.split('T');
        var myArray2 = myString2.split('T');

        var t = myArray[0] + ' ' + myArray[1];
        var t2 = myArray2[0] + ' ' + myArray2[1];

        var now = new Date(t);
        var now1 = new Date(t2);

        var currenet_date = formatDate(now);

        var start_time = formatAMPM(now);
        var end_time = formatAMPM(now1);
        var day_name = now.getWeekDay();

        var diffInHours = (new Date(now1) - new Date(now)) / 1000 / 60 / 60;

        var title_date = now.getDate();
        var t_month = now.getMonthName();

        var t_year = now.getFullYear();
        var title_year = title_date + ' ' + t_month + ' ' + t_year;


        $(".title_day").text(day_name);
//                $(".title_year").text(currenet_date);
        $(".title_year").text(title_year);
        $(".title_date").text(title_date);
        $(".title_start_time").text(start_time);
        $(".title_end_time").text(end_time);
        $(".title_hours_diff").text(diffInHours);
        $(".resource_id").text(resource_list[resource - 1].name);
        $(".conference_id").text(resource);
        $(".min_from_date").text(title_year);


        $("#bookconference-modal").addClass('show');
        $("#start_time").val(args.start);
        $("#end_time").val(args.end);
        $("#resource").val(args.resource);

        var date = new Date(title_year);

        var minFromDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();

        $(".from_date").click(function () {
            $('.from_date').pickadate({
                selectYears: true,
                selectMonths: true,
                min: new Date(minFromDate)
            });
        });

//        $("#conference_id").val(resource);

//                    $.post("conference/backend_create", 
//                        {
//                            start: args.start.toString(),
//                            end: args.end.toString(),
//                            resource: args.resource,
//                            name: name
//                        }, 
//                        function(data) {
//                            var e = new DayPilot.Event({
//                                start: args.start,
//                                end: args.end,
//                                id: data.id,
//                                resource: args.resource,
//                                text: name
//                            });
//                            dp.events.add(e);
//
//                            dp.message(data.message);
//                        });
    };

    // http://api.daypilot.org/daypilot-scheduler-oneventmoved/ 
    dp.onEventMoved = function (args) {
        
        $.post("conference/backend_move",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString(),
                    newResource: args.newResource
                },
        function () {
            dp.message("Moved.");
        });
        
    };

    // http://api.daypilot.org/daypilot-scheduler-oneventresized/ 
    dp.onEventResized = function (args) {
        
        $.post("conference/backend_resize",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString()                   
                },
        function () {
            dp.message("Resized.");
        });
    };

    // event creating
    // http://api.daypilot.org/daypilot-scheduler-ontimerangeselected/


  
    

    dp.onEventClicked = function (args) {
        //     alert(args.e.id());
//        new DayPilot.Modal({
//            onClosed: function (args) {
//                loadEvents();
//            }
//        }).showUrl("conference/edit?id=" + args.e.id());
//alert('#edit_timesheet-modal'+args.e.id());
        $("#show_booking-modal" + args.e.id()).addClass('show');

    };

    dp.init();
    dp.scrollTo(new DayPilot.Date());

    loadResources();
    loadEvents();

    function loadResources() {
        $.post("conference/backend_resources", function (data) {
            
            dp.resources = data;
            dp.update();
        });
    }

    function loadEvents() {
//        dp.events.load("<?php echo base_url(); ?>conference/backend_events");
        dp.events.load("<?php echo base_url(); ?>conference/backend_events_busy");
    }

</script>

<script>
    Date.prototype.getWeekDay = function () {
        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        return weekday[this.getDay()];
    };

    Date.prototype.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    Date.prototype.getMonthName = function () {
        return this.monthNames[this.getMonth()];
    };

    function formatAMPM(date)
    {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        // the hour '0' should be '12' 
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    }

    function getMonthAll(date) {
        var month = date.getMonth() + 1;
        return month < 10 ? '0' + month : '' + month; // ('' + month) for string result
    }

    function formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }
//    $(".add_close").click(function () {
//        $('#bookconference-modal').removeClass('show');
//        window.location.reload();
//    });
//    $(".show_close").click(function () {
////        close
////        $(this).click('close');
//        $('#show_booking-modal').removeClass('show');
//        $('#show_booking-modal').addClass('hide');
////        window.location.reload();
//    });
</script>
