<?php
$barChart_teamData = array();
$arr_name = array();
$arr_value = array();
$months = array(1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec');
$resM = array();

foreach ($team_monthstatastic as $monthNm => $opDataM) {

    foreach ($opDataM as $k => $data) {
        $resM[$monthNm]['lbl'][$k] = "'" . ($data['userfullname']) . "'";
        $resM[$monthNm]['val'][$k] = "'" . $data['total_hours'] . "'";
    }
}
foreach ($resM as $lbl => $label) {
    $barChart_teamData[$lbl]['lbl'] = implode(',', $label['lbl']);
    $barChart_teamData[$lbl]['val'] = implode(',', $label['val']);
}

?>
<div class="row">
    <div class="col-sm12">
        <ul class="nav nav-tabs vertical col-sm-2 left-aligned">
            <?php $i = 1; ?>
            <?php foreach ($resM as $lbl => $label) { ?>
                <?php $i == 1 ? $active = 'active' : $active = ''; ?>

                <li class="<?php echo $active ?>" onclick="changePane_team('<?php echo $lbl ?>')">
                    <a href="#team<?php echo $lbl ?>" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-home"></i> <?php echo $lbl ?>
                    </a>
                </li>

                <?php
                $i++;
            }
            ?>



        </ul>					

        <div class="tab-content vertical col-sm-10 left-aligned primary">

            <?php $i = 1; ?>
            <?php foreach ($resM as $lbl => $label) { ?>
                <?php $i == 1 ? $active = 'active in' : $active = ''; ?>

                <div class="tab-pane fade <?php echo $active ?>" id="team<?php echo $lbl ?>" >


                    <canvas id="barChart_team<?php echo $i; ?>" height="120"></canvas>

                </div>


                <?php
                $i++;
            }
            ?>

        </div>


    </div>

</div>
<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script>
                $(function () {



<?php $i = 1; ?>

<?php foreach ($barChart_teamData as $chartData) { ?>

                        var values = <?php echo '[' . $chartData['val'] . ']' ?>;
                        var names = <?php echo '[' . $chartData['lbl'] . ']' ?>;
                        var barData<?php echo $i; ?> = {
                            labels: names,
                            datasets: [
                                {
                                    label: "Total Hours",
                                    backgroundColor: 'rgba(26,179,148,0.5)',
                                    borderColor: "rgba(26,179,148,0.7)",
                                    pointBackgroundColor: "rgba(26,179,148,1)",
                                    pointBorderColor: "#fff",
                                    data: values
                                }
                            ]

                        };

                        var barOptions = {
                            responsive: true,
                            scales: {
                                xAxes: [{
                                        ticks: {
                                            stepSize: 10,
                                        },
                                        stacked: true,
                                        gridLines: {
                                            lineWidth: 0,
                                            color: "rgba(255,255,255,0)"
                                        }
                                    }],
                                yAxes: [{
                                        stacked: true,
                                        ticks: {
                                            min: 0,
                                            stepSize: 25,
                                        }

                                    }]
                            }
                        };

                        var ctx = document.getElementById("barChart_team<?php echo $i; ?>").getContext("2d");

                        new Chart(ctx, {type: 'bar', data: barData<?php echo $i; ?>, options: barOptions});
                        ctx = '';
                        barData = '';
                        names = '';
                        values = '';

    <?php
    $i++;
}
?>
                });


</script>
<script>
    var cnt = '0';
    function changePane_team(paneMonth) {
        if (cnt == '0')
            $('#teamjan').removeClass('active in');
        if (cnt == '1')
            $('#team' + last_pane).removeClass('active in');

        $('#team' + paneMonth).addClass('active in');
        cnt = '1';
        last_pane = paneMonth;

    }
</script>

