<div class="white-bg all-padding-15">
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12">
            <h4>Screening Summary</h4>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#mytimesheet" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-bar-chart"></i> My Timesheet
                    </a>
                </li>
                <li class="">
                    <a href="#myapproval" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i> My Approvals
                    </a>
                </li>
                <li class="">
                    <a href="#mystatastic" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i> My Statastic
                    </a>
                </li>
                <li class="">
                    <a href="#team" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i> Team
                    </a>
                </li>

                <li class="">
                    <a href="#approval" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i> Approvals
                    </a>
                </li>
                <li class="">
                    <a href="#teamstatastic" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-list"></i> Statastic
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="mytimesheet">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4 class="text-bold">Timesheet</h4>
                        </div>

                        <div class="col-sm-1">
                            <div class="margin-top-5">
                                <form action="<?php echo base_url(); ?>timesheet/submit_timesheet" method="post">
                                    <?php $current_date = '2017-03-01'; //date('Y-m-d');?>
                                    <?php if ($submission_status == 0 && $submission_sdate >= $current_date && $current_date <= $submission_edate) { ?>
                                        <button type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                                            <i class="fa fa-list"> </i> Submit
                                        </button>
                                    <?php } ?>
                                </form>
                            </div>

                        </div>
                        <div class="col-sm-1 pull-right">                    

                            <i class="fa fa-info-circle text-ccc" title="You can submit timesheet between 1st to 5th <?php echo date('F Y', (strtotime('next month', strtotime(date('m/01/y'))))); ?>"></i>
                        </div>
                        <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 1) { ?>
                            <div class="col-sm-2">
                                <div class="margin-top-5">
                                    <a href="<?php echo base_url() ?>timesheet/approve_timesheet" type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                                        <i class="fa fa-list"> </i> Approve Timesheet
                                    </a>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-sm-6">
                            <?php
                            $user_id = $this->session->userdata('user_id');
                            echo form_label(lang('employee'), 'employee', array('for' => 'employee'));
                            ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'employee',
                                'name' => 'employee',
                                'class' => 'browser-default',
                                'data-error' => '.timesheet1',
                                'value' => $user_id
                            ));
                            ?>
                            <div class="input-field">
                                <div class="timesheet1"></div>
                                <?php echo form_error('employee'); ?> 
                            </div>                    
                        </div>

                        <div class="col-sm-3">

                            <div class="form-group">
                                <div class="controls ">
                                    <input type="text" name="end_date" id="end_date" class="form-control date" data-format="MM yyyy" placeholder="Select Month">

                                </div>

                            </div>

<!--<input type="button" name="end_date" id="end_date" class="filter-textfields end_date" placeholder="Enter date"/>-->
                        </div>
                        <div class="col-sm-1 pull-left">
                            <div class="margin-top-5">
                                <button type="submit" class="btn btn-sm" id="id-search-tm"><i class="fa fa-search"></i></button>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div id="dp"></div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="team">
                    <div class="row">
                        <div class="col-sm-8">
                            <h4 class="text-bold">Timesheet</h4>
                        </div>

                        <div class="col-sm-1">
                            <div class="margin-top-5">
                                <form action="<?php echo base_url(); ?>timesheet/submit_timesheet" method="post">
                                    <?php $current_date = '2017-03-01'; //date('Y-m-d');?>
                                    <?php if ($submission_status == 0 && $submission_sdate >= $current_date && $current_date <= $submission_edate) { ?>
                                        <button type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                                            <i class="fa fa-list"> </i> Submit
                                        </button>
                                    <?php } ?>
                                </form>
                            </div>

                        </div>
                        <div class="col-sm-1 pull-right">                    

                            <i class="fa fa-info-circle text-ccc" title="You can submit timesheet between 1st to 5th <?php echo date('F Y', (strtotime('next month', strtotime(date('m/01/y'))))); ?>"></i>
                        </div>
                        <?php if ($user_summary['emprole'] == 3 || $user_summary['emprole'] == 1) { ?>
                            <div class="col-sm-2">
                                <div class="margin-top-5">
                                    <a href="<?php echo base_url() ?>timesheet/approve_timesheet" type="submit" class="btn btn-sm btn-warning2" id="id-submit-tm" >
                                        <i class="fa fa-list"> </i> Approve Timesheet
                                    </a>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-sm-6">
                            <?php
                            $user_id = $this->session->userdata('user_id');
                            echo form_label(lang('employee'), 'employee', array('for' => 'employee'));
                            ?>
                            <?php
                            echo form_dropdown(array(
                                'id' => 'employee',
                                'name' => 'employee',
                                'class' => 'browser-default',
                                'data-error' => '.timesheet1',
                                'value' => $user_id
                            ));
                            ?>
                            <div class="input-field">
                                <div class="timesheet1"></div>
                                <?php echo form_error('employee'); ?> 
                            </div>                    
                        </div>

                        <div class="col-sm-3">

                            <div class="form-group">
                                <div class="controls ">
                                    <input type="text" name="end_date" id="end_date" class="form-control date" data-format="MM yyyy" placeholder="Select Month">

                                </div>

                            </div>

<!--<input type="button" name="end_date" id="end_date" class="filter-textfields end_date" placeholder="Enter date"/>-->
                        </div>
                        <div class="col-sm-1 pull-left">
                            <div class="margin-top-5">
                                <button type="submit" class="btn btn-sm" id="id-search-tm"><i class="fa fa-search"></i></button>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div id="dp"></div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="myapproval">
                </div>
                <div class="tab-pane fade" id="mystatastic">
                    uuu
                    <canvas id="barChart1" height="80"></canvas>
                    <canvas id="barChart" height="140"></canvas>
                </div>
                <div class="tab-pane fade" id="approval">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th>Candidate Name</th>
                                <th>For the Month</th>
                                <th>Total Hours</th>
                                <th>Submission Date</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <div class="pull-right"> 

                        </div>
                        <tbody class="">
                            <?php
                            foreach ($associates as $r => $result) {
                                $date = $result['submission_year'] . '-' . $result['submission_month'] . '-01';
//                            var_dump($date);die;
                                ?>  
                                <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">
                                    <td class="">
                                        <a title="Click here to view timesheet" data-toggle="modal" href="#candidatetimeline_<?php echo $result['id'] ?>"><?php echo $result['userfullname']; ?></a>

                                    </td>

                                    <td class=""><?php echo date('F', strtotime($date)); ?> <?php echo date('Y', strtotime($date)); ?></td>

                                    <td class=""><?php echo $result['total_hours']; ?></td>

                                    <td class=""><?php echo date("j F, Y", strtotime($result['submission_date'])); ?></td>
                                    <td class="">
                                        <a  data-toggle="modal" href="#manager_comment_<?php echo $result['id'] ?>" class="btn btn-xs btn-success" id="id-submit-tm" >
                                            <i class="fa fa-check"> </i> Approve
                                        </a>
                                        <a  data-toggle="modal" href="#manager_comment_<?php echo $result['id'] ?>" class="btn btn-xs btn-danger" id="id-submit-tm" >
                                            <i class="fa fa-times"> </i> Reject
                                        </a>
                                    </td>
                                </tr>  
<?php } ?>
                        </tbody>
                    </table>
<?php $this->load->view('modal/_manager_comment'); ?>
                </div>
                <div class="tab-pane fade" id="teamstatastic">
                </div>
            </div>
        </div>
    </div>
</div>









<!--<link href="<?php echo base_url(); ?>assets/plugins/timesheet/css/layout.css" rel="stylesheet" />-->
<!--<script src="<?php echo base_url(); ?>assets/plugins/timesheet/js/jquery-1.9.1.min.js" type="text/javascript"></script>--> 
<script src="<?php echo base_url(); ?>assets/plugins/timesheet/js/daypilot/daypilot.js" type="text/javascript"></script> 
<?php // var_dump($submission_status); ?>

<!-- Left col -->






<style>
    .modal_min_main { border: 1px solid #ccc !important; }
    .modal_min_background { opacity: 0.3; background-color: #000; }

    /* border-radius: 5px; */
</style>

<!--        <script type="text/javascript">
            var dp = new DayPilot.Scheduler("dp");
            $(document).ready(function () {
                
                $("#week").change(function () {
                    
                    dp.viewType = "Days";
                    dp.startDate = $(this).val();
                    dp.days = dp.startDate.daysInMonth();
                    dp.timeHeaders = [
                        {groupBy: "Day", format: "MMMM yyyy"},
                        {groupBy: "Hour"}
                    ];
                    dp.heightSpec = "Max";
                    dp.height = 400;
                    dp.cellWidthSpec = "Auto";
                    dp.rowHeaderColumns = [
                        {title: "Day", width: 100},
                        {title: "Total", width: 100}
                    ];

                   //dp.update();
                });
            });
        </script>-->
</scrip>
<script type="text/javascript">

    var dp = new DayPilot.Scheduler("dp");
    dp.viewType = "Days";
    dp.startDate = new DayPilot.Date().firstDayOfMonth();

//     alert(dp.startDate);
//        console.log(dp.startDate);
    //'2017-04-01T00:00:00';//new DayPilot.Date().firstDayOfMonth();
    dp.days = dp.startDate.daysInMonth();
//        alert(dp.days);
    dp.timeHeaders = [
        {groupBy: "Day", format: "MMMM yyyy"},
        {groupBy: "Hour"}
    ];
//        alert(dp.timeHeaders);
    dp.heightSpec = "Max";
    dp.height = 400;
    dp.cellWidthSpec = "Auto";
    dp.rowHeaderColumns = [
        {title: "Day", width: 100},
        {title: "Total", width: 100}
    ];
    // http://api.daypilot.org/daypilot-scheduler-oneventmoved/ 
    dp.onEventMoved = function (args) {
        $.post("timesheet/backend_move",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString(),
                    newResource: args.newResource,
                },
                function () {
                    updateTotals();
                    dp.message("Moved.");
                });
    };
    // http://api.daypilot.org/daypilot-scheduler-oneventresized/ 
    dp.onEventResized = function (args) {
        $.post("timesheet/backend_resize",
                {
                    id: args.e.id(),
                    newStart: args.newStart.toString(),
                    newEnd: args.newEnd.toString()
                },
        function () {
            updateTotals();
            dp.message("Resized.");
        });
    };
// dp.onTimeRangeSelected = function (args) {
//        var modal = new DayPilot.Modal();
//        modal.onClosed = function(args) {
//            dp.clearSelection();
//            var data = args.result;
//            if (data && data.result === "OK") { 
//                loadEvents(); 
//                dp.message(data.message); 
//            }
//        };
//        modal.showUrl("new.php?start=" + args. start + "&end=" + args.end + "&resource=" + args.resource);
//    };

    // event creating
    // http://api.daypilot.org/daypilot-scheduler-ontimerangeselected/
    dp.onTimeRangeSelected = function (args) {

        var modal = new DayPilot.Modal({
            onClosed: function (args) {
                console.log("Modal dialog closed");
            },
            // ...
        });
        //timesheet-modal
        // title_start_time title_end_time
        var now = new Date(t);

        var a = args.start;
        var b = args.end;

        var myString = a.toString();
        var myString2 = b.toString();
        var myArray = myString.split('T');
        var myArray2 = myString2.split('T');

        var t = myArray[0] + ' ' + myArray[1];
        var t2 = myArray2[0] + ' ' + myArray2[1];

        var now = new Date(t);
        var now1 = new Date(t2);

        var currenet_date = formatDate(now);

        var start_time = formatAMPM(now);
        var end_time = formatAMPM(now1);
        var day_name = now.getWeekDay();

        var diffInHours = (new Date(now1) - new Date(now)) / 1000 / 60 / 60;

        var title_date = now.getDate();
        var t_month = now.getMonthName();

        var t_year = now.getFullYear();
        var title_year = t_month + ' ' + t_year;

        $(".title_day").text(day_name);
//                $(".title_year").text(currenet_date);
        $(".title_year").text(title_year);
        $(".title_date").text(title_date);
        $(".title_start_time").text(start_time);
        $(".title_end_time").text(end_time);
        $(".title_hours_diff").text(diffInHours);
        $("#timesheet-modal").addClass('show');

        $("#start_time").val(args.start);
        $("#end_time").val(args.end);





//                $("#timesheet-modal").modal.toggle();
//               modal.showUrl("<?php echo base_url(); ?>timesheet/add_data/" + args. start + "/" + args.end + "/1" );

        //  modal.showUrl("add_data");
        //modal.showUrl("timesheet/add_data/" + args. start + "/" + args.end + "/" + args.resource);


//            var name = prompt("New event name:", "Event");
//            dp.clearSelection();
//            if (!name)
//                return;

        $.post("timesheet/backend_create",
                {
                    start: args.start.toString(),
                    end: args.end.toString(),
                    resource: $("#employee").val(),
                    name: name,
                    mang_id: 1,
                    //total_hours: '',
                },
                function (data) {
                    var e = new DayPilot.Event({
                        start: args.start,
                        end: args.end,
                        id: data.id,
                        resource: args.resource,
                        text: name
                    });
                    dp.events.add(e);
                    updateTotals();
                    dp.message(data.message);
                });
    };
    dp.onEventClick = function (args) {
        var modal = new DayPilot.Modal();
        modal.closed = function () {
            // reload all events
            var data = this.result;
            if (data && data.result === "OK") {
                loadEvents();
            }
        };
        // modal.showUrl("timesheet/edit/" + args.e.id());
        $("#edit_timesheet-modal" + args.e.id()).addClass('show');
    };
    dp.init();
    $(document).ready(function () {

        loadResources();
        $("#employee").change(function () {

            loadEvents();
        });
    });
    function loadResources() {
        $.post("timesheet/backend_resources", function (data) {
//                        alert(data);
            for (var i = 0; i < data.length; i++) {

                var item = data[i];
                $("#employee").append($('<option/>', {
                    value: item.id,
                    text: item.name
                }));
            }
            loadEvents();
        });

    }

    function loadEvents() {

        var filter_month = $('#end_date').val();

        if (filter_month != '') {
            filter_month = filter_month + '-01T00:00:00';
            var a = new Date(filter_month);

            var mm = ("0" + (a.getMonth() + 1)).slice(-2);
            var year = a.getFullYear();
            var cm_date = year + '-' + mm;
            filter_month = cm_date + '-01T00:00:00';
            dp.startDate = new DayPilot.Date(filter_month).firstDayOfMonth();
            dp.days = dp.startDate.daysInMonth();
        }


//        dp.startDate = new DayPilot.Date('2017-03-01T00:00:00').firstDayOfMonth();
//                    var url = "backend_events.php?resource=" + $("#employee").val() + "&start=" + dp.startDate + "&end=" + dp.startDate.addDays(dp.days);
//        var emp_id = $("#employee").val();
//        var load_event_id = $("#employee option:selected").val(emp_id);
//        alert(load_event_id);
        var url = "timesheet/backend_events/" + $("#employee").val() + "/" + dp.startDate + "/" + dp.startDate.addDays(dp.days);
        dp.events.load(url, function () {
            dp.message("Events for " + $("#employee option:selected").text() + " loaded.");
            updateTotals();
        });

    }

    function updateTotals() {
        dp.rows.each(function (item) {
//                        alert(JSON.stringify(item));
//                        return false;
//                        alert(item);
            var duration = item.events.totalDuration();
            var str;
            if (duration.totalDays() >= 1) {
                str = Math.floor(duration.totalHours()) + ":" + duration.toString("mm");
            }
            else {
                str = duration.toString("H:mm");
            }

            item.column(1).html(str + " hours");
        });

    }


</script>


<!-- Add Modal -->
<div class="modal" id="timesheet-modal" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <form  action="<?php echo base_url() ?>/timesheet/backend_create" id="f" method="post" >
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Timesheet : 

                        <span class="text-insp-success">
                            <span class="title_start_time"></span> -
                            <span class="title_end_time"></span>
                        </span>
                    </h4>
                </div>
                <div class="modal-body">

                    <div class="col-sm-8 col-sm-push-2">

                        <div  class="date-cal-bg" >
                            <div class="all-padding-5 text-center date-cal-head"><span class="title_day"></span></div>
                            <div class="text-center all-padding-5">
                                <div class="text-light-head"><span class="title_year"></span></div>
                                <div class="font-size-25"><span class="title_date"></span> </div>
                                <p class="text-center">
                                    <span class="text-light-head">
                                        <i class="fa fa-clock-o "> </i>  <span class="title_hours_diff"></span> hrs
                                    </span>
                                </p>
                            </div>
                        </div>

                    </div>
                    <div class="col-sm-12">
                        <div class="input-field">
                            <textarea name="task_desc" id="work_detail_desc" placeholder="Enter timesheet details" data-error=".errorTimesheet" class="materialize-textarea" required="required"></textarea>
                            <div class="errorTimesheet"></div>
                        </div>
                    </div> 



                    <div class="modal-footer no-border">
                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>

                    <input value="" id="start_time" name="start" hidden>
                    <input value="" id="end_time" name="end" hidden>
                </div>
            </div>
        </form>
    </div>
</div>
<!--End add modal timesheet-->

<script>

    Date.prototype.getWeekDay = function () {
        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        return weekday[this.getDay()];
    }

    Date.prototype.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    Date.prototype.getMonthName = function () {
        return this.monthNames[this.getMonth()];
    };

//    Date.prototype.getMonthName = function (lang) {
//        lang = lang && (lang in Date.locale) ? lang : 'en';
//        return Date.locale[lang].month_names[this.getMonth()];
//    };
//    Date.locale = { en: { month_names: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], month_names_short: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] } };

    function formatAMPM(date)
    {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        // the hour '0' should be '12' 
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    }

    function getMonthAll(date) {
        var month = date.getMonth() + 1;
        return month < 10 ? '0' + month : '' + month; // ('' + month) for string result
    }




    function formatDate(date) {
        var monthNames = [
            "January", "February", "March",
            "April", "May", "June", "July",
            "August", "September", "October",
            "November", "December"
        ];

        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        return day + ' ' + monthNames[monthIndex] + ' ' + year;
    }

    $(document).ready(function () {

        var currentTime = new Date()
        var minDate = new Date(currentTime.getFullYear(), currentTime.getMonth() - 3); //one day next before month
//alert(minDate);
        var maxDate = new Date(currentTime.getFullYear(), currentTime.getMonth()); // one day before next month

        $(".date").datepicker({
            format: "yyyy-mm",
            startDate: minDate,
            endDate: maxDate,
            startView: "year",
            minViewMode: "months"
        });

        //filter by month
        //end_date id-search-tm
        $("#id-search-tm").click(function () {

            var filter_month = $('#end_date').val();
            //alert(filter_month);
            filter_month = filter_month + '-01T00:00:00';
            var a = new Date(filter_month);


            var mm = ("0" + (a.getMonth() + 1)).slice(-2);

            var year = a.getFullYear();
            var cm_date = year + '-' + mm;
            //alert(cm_date);
            filter_month = cm_date + '-01T00:00:00';
            //alert(filter_month)
            dp.startDate = new DayPilot.Date(filter_month).firstDayOfMonth();
            dp.days = dp.startDate.daysInMonth();

//                    var url = "backend_events.php?resource=" + $("#employee").val() + "&start=" + dp.startDate + "&end=" + dp.startDate.addDays(dp.days);
            var url = "timesheet/backend_events/" + $("#employee").val() + "/" + dp.startDate + "/" + dp.startDate.addDays(dp.days);
            dp.events.load(url, function () {
                dp.message("Events for " + $("#employee option:selected").text() + " loaded.");
                updateTotals();
            });
        });


<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>

        $(".close").click(function () {
            $('#timesheet-modal').removeClass('show');
            window.location.reload();
        });

//        $("#datepicker").datepicker({ maxDate: new Date, minDate: new Date(2017, 1, 1) });
    });

</script>
<?php if (isset($events)) { ?>
    <?php foreach ($events as $result) {
        ?>

        <!--Start edit timesheet-->
        <div class="modal" id="edit_timesheet-modal<?php echo $result->id ?>" role="dialog">
            <div class="modal-dialog modal-sm">
                <!-- Modal content-->

                <div class="modal-content">
                    <div class="modal-header">
                        <?php
                        $d1 = strtotime(date('h:i A', strtotime($result->start)));
                        $d2 = strtotime(date('h:i A', strtotime($result->end)));
                        $diff = $d2 - $d1;

                        $min = round(abs($diff) / 60, 2);
                        $hrs = $min / 60;
                        ?>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Timesheet : 
                            <span class="text-insp-success ">
        <?php echo date('h:i A', strtotime(($result->start))); ?>
                                -  <?php echo date('h:i A', strtotime(($result->end))); ?>
                            </span>

                            <span class="title_year"></span>

                        </h4>

                    </div>
                    <div class="modal-body">
                        <form  action="<?php echo base_url() ?>timesheet/backend_update" id="f" method="post" >
                            <div class="col-sm-8 col-sm-push-2">

                                <div  class="date-cal-bg" >
                                    <div class="all-padding-5 text-center date-cal-head"><?php echo date('l', strtotime(($result->start))); ?></div>
                                    <div class="text-center all-padding-5">
                                        <div class="text-light-head"><?php echo date('F Y', strtotime(($result->start))); ?></div>
                                        <div class="font-size-30"><?php echo date('d', strtotime(($result->start))); ?> </div>
                                        <p class="text-center">
                                            <span class="text-light-head">
                                                <i class="fa fa-clock-o "> </i> <?php echo $hrs; ?> hrs
                                            </span>
                                        </p>
                                    </div>
                                </div>

                            </div>
                            <div class=""></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <!--<label for="feedremark" class="active">Enter work details*</label>-->
                                    <textarea name="task_desc"  value="" id="work_detail_desc" placeholder="Remark" data-error=".errorTimesheet" class="materialize-textarea" required="required"><?php echo $result->text; ?></textarea>
                                    <div class="errorTimesheet"></div>
                                </div>
                            </div> 
                            <input type="hidden" name="id" value="<?php echo $result->id; ?>" />



                            <div class="col-sm-12 padding-top-10 text-right">

                                <?php if ($submission_status == 0) { ?>
                                    <button type="submit" class="btn btn-warning2 btn-sm ">Save & Update</button>
                                <?php } else { ?>
                                    <p class="alert alert-primary"> <i class="fa fa-exclamation-circle">  </i>  You cannot edit timesheet</p>
        <?php } ?>
                                <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                            <div class="modal-footer no-border">
                                <input value="" id="start_time" name="start" hidden>
                                <input value="" id="end_time" name="end" hidden>
                            </div>
                        </form>
                    </div>

                </div>

            </div>
        </div>
        <!--End edit timesheet-->
    <?php } ?>
<?php } ?>
<!--    <script>
$(".scheduler_default_corner div:contains('DEMO')").css("display","none");

</script>-->



<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<?php
$arr_name=array();
$arr_value=array();
$months = array (1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec');

                                        foreach ($my_statastic as $k => $opData) {
//                                            var_dump($opData);
                                            $arr_name[$k] = ltrim($opData['submission_month'], '0') ;
                                            $monthName[$k] =  $months[$arr_name[$k]];
                                            $arr_value[$k] = $opData['total_hours'];
            
                                        }
                                        //var_dump($arr_value);
                                        $string_name = implode(',', $monthName);
                                        $string_value = implode(',', $arr_value);
                                        echo $string_name;
                                        echo $string_value;
                                       


?>
<script src="<?php echo base_url('assets/plugins/chart/Chart.min.js'); ?>" type="text/javascript"></script>
<script>
    $(function () {
        var names = <?php echo '[' . $string_name . ']' ?>;
        var values = <?php echo '[' . $string_value . ']' ?>;
        var barData = {
            labels: names,
            datasets: [
                {
                    label: "Hours",
                    backgroundColor: 'rgba(26,179,148,0.5)',
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: values
                }
            ]
        };
        var barOptions = {
            responsive: true,
            scales: {
                xAxes: [{
                        ticks: {
                            stepSize: 10,
                        },
                        stacked: true,
                        gridLines: {
                            lineWidth: 0,
                            color: "rgba(255,255,255,0)"
                        }
                    }],
                yAxes: [{
                        stacked: true,
                        ticks: {
                            min: 0,
                            stepSize: 1,
                        }

                    }]
            }
        };
        var ctx2 = document.getElementById("barChart1").getContext("2d");
        new Chart(ctx2, {type: 'bar', data: barData, options: barOptions});
    });

  $(function () {
    
       var barData = {
        labels: ["January", "February", "March", "April", "May", "June", "July"],
        datasets: [
            {
                label: "Data 1",
                backgroundColor: 'rgba(220, 220, 220, 0.5)',
                pointBorderColor: "#fff",
                data: [65, 59, 80, 81, 56, 55, 40]
            },
            {
                label: "Data 2",
                backgroundColor: 'rgba(26,179,148,0.5)',
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [28, 48, 40, 19, 86, 27, 90]
            }
        ]
    };

    var barOptions = {
        responsive: true
    };


    var ctx2 = document.getElementById("barChart").getContext("2d");
    new Chart(ctx2, {type: 'bar', data: barData, options:barOptions});
    
      });
        </script>

