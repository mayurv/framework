<?php
            $start = $timesheetdata['start'];
            $end = $timesheetdata['end'];
            $resource = $timesheetdata['resource'];

            // basic sanity check
            new DateTime($start) or die("invalid date (start)");
            new DateTime($end) or die("invalid date (end)");
            is_numeric($resource) or die("invalid resource id");
            
           // $resources = $db->query('SELECT * FROM resources');
        ?>

    <div class="modal-dialog">

        <div class="modal-content">   
            <div class="modal-header no-border">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
            
            <div class="modal-body">
                Content here
          


<form  action="<?php echo base_url() ?>/timesheet/backend_create" id="f" method="post" style="padding:20px;">
    <div>
        <span><h4 class="text-bold">Timesheet - <?php echo date('m Y') ?></h4> <?php echo date('h:i', strtotime($start)) ?>-<?php echo date('h:i', strtotime($end)) ?> </span>
    </div>
            <div>Description: </div>
            <div><input type="text" id="name" name="name" value="" /></div>
            <div><input type="hidden" id="start" name="start" value="<?php echo $start ?>" /></div>
            <div><input type="hidden" id="end" name="end" value="<?php echo $end ?>" /></div>
            
            </div>
            
            <div class="col-sm-12 padding-top-10 text-right">
                        <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                        <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                    </div>
            <div class="space"><input type="submit" value="Save" /> 
                <a href="javascript:close();">Cancel</a></div>
        </form>
                
                  </div>

        </div>
    </div>
        
        <script type="text/javascript">
        function close(result) {
            DayPilot.Modal.close(result);
        }

        $("#f").submit(function (ev) {
            
            // make sure it's not submitted using the default mechanism
            ev.preventDefault();
            
            // normalize the date values
            var start = $("#start").val(startPicker.date.toString("yyyy-MM-dd"));
            var end = $("#end").val(endPicker.date.toString("yyyy-MM-dd"));
            
//             submit using AJAX
            var f = $("#f");
            $.post("timesheet/backend_create", f.serialize(), function (result) {
                close(eval(result));
            });      
                 
            
        });
        
        var startPicker =  new DayPilot.DatePicker({
            target: 'start', 
            pattern: 'M/d/yyyy',
            date: "<?php echo $start ?>",
            onShow: function() {
                parent.DayPilot.ModalStatic.stretch();
            }
        });

        var endPicker =  new DayPilot.DatePicker({
            target: 'end', 
            pattern: 'M/d/yyyy',
            date: "<?php echo $end ?>",
            onShow: function() {
                parent.DayPilot.ModalStatic.stretch();
            }
        });

        $(document).ready(function () {
            $("#name").focus();
        });
    
        </script>
