<link href="<?php echo base_url(); ?>assets/plugins/timesheet/css/layout.css" rel="stylesheet" />
<script src="<?php echo base_url(); ?>assets/plugins/timesheet/js/jquery-1.9.1.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/plugins/timesheet/js/daypilot/daypilot-all.min.js" type="text/javascript"></script> 

<form  id="postEdit" action="<?php echo base_url()?>timesheet/backend_update" style="padding:20px;" >
    <input type="hidden" name="id" value="<?php echo $event[0]->id;?>" />
    <h1>Edit Event</h1>
    <div>Name: </div>
    <div>
        <input type="text" id="name" name="name" value="<?php echo $event[0]->text;?>" />
    </div>
    <div class="space"> 
        <input id="saveBtn" type="submit" value="Save" /> 
        <a href="javascript:close();">Cancel</a>
    </div>
</form>


<script type="text/javascript">
    
    $("#postEdit").submit(function () {
            var f = $("#postEdit");
            $.post(f.attr("action"), f.serialize(), function (result) {
                close(eval(result));
            });
            return false;
        });
        
//    function editTimesheet(){
//        $.ajax({
//            url: '<?php echo base_url(); ?>timesheet/backend_update',
//            type: 'POST',
//            dataType: 'json',
//            data: $('#postEdit').serialize(),
//            success: function (data) {
//               
//            }
//        });
//    }
    
  
    function close(result) {
        if (parent && parent.DayPilot && parent.DayPilot.ModalStatic) {
            parent.DayPilot.ModalStatic.close(result);
        }
    }



    $("#f").submit(function () {
        var f = $("#f");
        $.post(f.attr("action"), f.serialize(), function (result) {
            close(eval(result));
        });
        return false;
    });
    
    $('#saveBtn').click(function() {
    //    alert("hi");
   // $('.modal').modal('hide');
});


        $(document).ready(function () {
            $("#name").focus();
        });

</script>
