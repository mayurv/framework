<?php foreach ($roomdetails as $result) { ?>
    <!--modal start here-->
    <div id="<?php echo $result['room_title'] ?>" class="modal fade" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header no-border padding-bottom-0">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 ><?php echo $result['room_title'] ?></h4>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th colspan="2"><span class="">Additional Information</span></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row"><span>Room Capacity</span></th>
                                <td class="text-center">
                                    <span class="btn btn-xs btn-info"><?php echo $result['capacity'] ?></span>
                                    <span>Associates</span>                                                     
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="<?php echo $result['network_point'] == 0 ? 'text-light-gray' : '' ?>">Network Point </span></th>
                                <td class="text-center"><i class="fa <?php echo $result['network_point'] == 0 ? 'fa-times text-light-gray' : 'fa-check' ?>"></i></td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="<?php echo $result['projector'] == 0 ? 'text-light-gray' : '' ?>">Projector</span></th>
                                <td class="text-center"><i class="fa <?php echo $result['projector'] == 0 ? 'fa-times text-light-gray' : 'fa-check' ?>"></i></td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="<?php echo $result['white_board'] == 0 ? 'text-light-gray' : '' ?>">White Board</span></th>
                                <td class="text-center"><i class="fa <?php echo $result['white_board'] == 0 ? 'fa-times text-light-gray' : 'fa-check' ?>"></i></td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="<?php echo $result['aircondition'] == 0 ? 'text-light-gray' : '' ?>">A/C</span></th>
                                <td class="text-center"><i class="fa <?php echo $result['aircondition'] == 0 ? 'fa-times text-light-gray' : 'fa-check' ?>"></i></td>
                            </tr>
                            <tr>
                                <th scope="row"><span class="<?php echo $result['fan'] == 0 ? 'text-light-gray' : '' ?>">Fan</span></th>
                                <td class="text-center"><i class="fa <?php echo $result['fan'] == 0 ? 'fa-times text-light-gray' : 'fa-check' ?>"></i></td>
                            </tr>
                        </tbody>
                    </table>                     
                </div>                                                    
            </div>
        </div>
    </div>
    <!--modal end here-->
<?php } ?>