<?php if (isset($bookings)) { ?>
    <?php foreach ($bookings as $result) {
        ?>

        <!--Start edit timesheet-->
        <div class="modal" id="show_booking-modal<?php echo $result['id'] ?>" role="dialog">
            <div class="modal-dialog modal-sm">
                <!-- Modal content-->

                <div class="modal-content">
                    <div class="modal-header">
                        <?php
                        $d1 = strtotime(date('h:i A', strtotime($result['start'])));
                        $d2 = strtotime(date('h:i A', strtotime($result['end'])));
                        $diff = $d2 - $d1;

                        $min = round(abs($diff) / 60, 2);
                        $hrs = $min / 60;
                        ?>
                        <button type="button" class="close show_close_<?php echo $result['id'] ?>" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Conference Booking : 
                            <span class="text-insp-success ">
                                <?php echo date('h:i A', strtotime(($result['start']))); ?>
                                -  <?php echo date('h:i A', strtotime(($result['end']))); ?>
                            </span>

                            <span class="title_year"></span>

                        </h4>

                    </div>
                    <div class="modal-body">
                        <form  action="<?php echo base_url() ?>timesheet/backend_update" id="f" method="post" >
                            <div class="col-sm-8 col-sm-push-2">

                                <div  class="date-cal-bg" >
                                    <div class="all-padding-5 text-center date-cal-head"><?php echo date('l', strtotime(($result['start']))); ?></div>
                                    <div class="text-center all-padding-5">
                                        <div class="text-light-head"><?php echo date('d F Y', strtotime(($result['start']))); ?></div>
                                        <div><span class="font-size-30"> <?php echo $hrs; ?> hrs</span></div>
        <!--                                        <p class="text-center">
                                            <span class="text-light-head">
                                                <i class="fa fa-clock-o "> </i>  hrs
                                            </span>
                                        </p>-->
                                    </div>
                                </div>

                            </div>
                            <div class=""></div>

                            <div class="col-sm-12">
                                <div class="input-field">
                                    <!--<label for="feedremark" class="active">Enter work details*</label>-->
                                    <textarea name="task_desc"  value="" id="work_detail_desc" placeholder="Remark" data-error=".errorTimesheet" class="materialize-textarea" required="required"><?php echo $result['name']; ?></textarea>
                                    <div class="errorTimesheet"></div>
                                </div>
                            </div> 
                            <input type="hidden" name="id" value="<?php echo $result['id']; ?>" />



                            <div class="col-sm-12 padding-top-10 text-right">

                                <!--                                <?php//   if (($submission_status == 0) && ($result['user_id'] == $user_summary['user_id'])) {  ?>
                                                                    <button type="submit" class="btn btn-warning2 btn-sm ">Save & Update</button>
                                <?php // } else { ?>
                                                                    <p class="alert alert-primary"> <i class="fa fa-exclamation-circle">  </i>  You cannot edit timesheet</p>
                                <?php // } ?>
                                                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                            </div>
                            <div class="modal-footer no-border">
                                <input value="" id="start_time" name="start" hidden>
                                <input value="" id="end_time" name="end" hidden>
                            </div>
                        </form>
                    </div>

                </div>

            </div>
        </div>
        <!--End edit timesheet-->
        <script>
            $(".show_close_<?php echo $result['id'] ?>").click(function () {
        //        close
        //        $(this).click('close');
                $('#show_booking-modal<?php echo $result['id'] ?>').removeClass('show');
                //$('#show_booking-modal').addClass('hide');
        //        window.location.reload();
            });
        </script>
    <?php } ?>
<?php } ?>