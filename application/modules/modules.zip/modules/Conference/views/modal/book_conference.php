<!-- Add Modal -->
<div class="modal" id="bookconference-modal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <form  action="<?php echo base_url() ?>/conference/backend_create" id="f" method="post" >
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close add_close" data-dismiss="modal">&times;</button>

                    <h4 class="modal-title">Booking : 

                        <span class="text-insp-success">
                            <span class="title_start_time"></span> -
                            <span class="title_end_time"></span>
                        </span>
                    </h4>
                </div>
                <div class="modal-body user-normal-slim">

                    <div class="col-sm-4 text-center col-sm-push-4">
                        <div  class="date-cal-bg" >
                            <span class=" font-size-25"><div class="conf-name-bg resource_id"></div></span>
                            <div class="all-padding-5 text-center date-conf-head">

                                <span class="title_day"></span></div>
                            <div class="text-center all-padding-5">
                                <div class="text-light-head"><span class="title_year"></span></div>
                                <div class="font-size-25"> <span class="title_hours_diff"></span> hrs </div>
<!--                                <p class="text-center">
                                    <span class="text-light-head">
<span class="title_date"></span>
                                        <i class="fa fa-clock-o "> </i>  <span class="title_hours_diff"></span> hrs
                                    </span>
                                </p>-->
                            </div>
                        </div>

                    </div>




                    <div class="col-sm-12" >
                        <?php
                        echo form_checkbox(array(
                            'id' => 'id_recursive',
                            'name' => 'id_recursive',
                            'style' => 'left: 0 !important; opacity: 0 !important;',
                            'checked' => '',
                            'value' => '0',
                        ));
                        ?>
                        <?php echo form_label(lang('id_recursive'), 'id_recursive', array('for' => 'id_recursive', 'style' => 'font-size:12px !important')); ?>                                
                        <?php echo form_error('req_code'); ?> 

                    </div> 

                    <div id="fullDivId" style="display: none">

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('from_date'), 'from_date', array('for' => 'from_date')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'from_date',
                                    'name' => 'from_date',
                                    'placeholder' => 'From Date',
                                    'data-format' => 'yyyy-mm-dd',
                                    'class' => 'from_date',
                                    'data-error' => '.addOpening4',
//                                    'required' => 'required'
                                ));
                                ?>   
                                <div class="addOpening4"></div>                                
                                <?php echo form_error('from_date'); ?> 
                            </div>                                        
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('to_date'), 'to_date', array('for' => 'to_date')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'to_date',
                                    'name' => 'to_date',
                                    'placeholder' => 'To Date',
                                    'data-format' => 'yyyy-mm-dd',
                                    'class' => 'to_date',
                                    'data-error' => '.addOpening4',
//                                    'required' => 'required'
                                ));
                                ?>   
                                <div class="addOpening4"></div>                                
                                <?php echo form_error('to_date'); ?> 
                            </div>                                        
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <span id="checking" style="display: none">
                            <i class="fa fa-spinner fa-spin text-light-gray "></i> <span class="text-light-gray"> Checking Availability</span>
                        </span>
                        <div class="availability_status" style="display: none">
                            <span class="btn btn-xs" id="txt_availability_status">Conference Room Available</span>
                        </div>
                    </div>

                    <div class="col-sm-12">
                        <div class="input-field">
                            <?php echo form_label(lang('description'), 'description', array('for' => 'description')); ?>

                            <textarea name="name" id="work_detail_desc" placeholder="Enter details" data-error=".errorTimesheet" class="materialize-textarea" required="required"></textarea>
                            <div class="errorTimesheet"></div>
                        </div>
                    </div> 

                    <div class="modal-footer no-border">
                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" id="id_book_rec" class="btn btn-warning2 btn-sm ">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>

                    <input value="" id="start_time" name="start" hidden>
                    <input value="" id="end_time" name="end" hidden>
                    <input value="" id="resource" name="resource" hidden>
                    <input type="text" id="conference_id" name="conference_id" hidden>
                    <div class="conference_id hidden " ></div>
                    <div class="min_from_date hidden" ></div>
                </div>
            </div>
        </form>
    </div>
</div>
<!--End add modal timesheet-->

<script>
    //0 not available 1 - available
    $(document).ready(function () {
        $("#id_recursive").click(function () {

            $("#fullDivId").toggle();

            if ($('#id_recursive').is(":checked")) {
                $("#id_book_rec").attr('disabled', 'disabled');
            } else {
                $("#id_book_rec").removeAttr('disabled', 'disabled');
            }
        });
        

        
        $(".to_date").click(function () {
            $('.to_date').pickadate({
                selectYears: true,
                selectMonths: true,
                min: new Date(),
            });
        });
        $(".add_close").click(function () {
//            $("#f").trigger("reset");
            $('#bookconference-modal').removeClass('show');
//            $("#f").clearForm();
        });

        
        $("#to_date").change(function () {
            $('.availability_status').hide();
            $('#checking').show();
            var conf_id = $(".conference_id").text();
            var title_start_time = $(".title_start_time").text();
            var title_end_time = $(".title_end_time").text();
            var from_date = $("#from_date").val();
            var to_date = $("#to_date").val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>conference/checkAvailability',
                data: {'conf_id': conf_id, from_date: from_date, to_date: to_date, title_start_time: title_start_time, title_end_time: title_end_time},
                success: function (data) {
                    $('#checking').hide();


                    var parsed = $.parseJSON(data);

                    if (parsed.booking_status == 2) {
                        $('#from_date').focus();
                        return false;
                    }
                    if (parsed.booking_status == 0) {

                        $('.availability_status').show();
                        $('#txt_availability_status').removeClass('btn-success');
                        $('#txt_availability_status').addClass('btn-danger');
                        $('#txt_availability_status').text('Not Available');
                        $('#from_date').val('');
                        $('#to_date').val('');
                        $('#from_date').focus();
                    }
                    if (parsed.booking_status == 1) {
                        $("#id_book_rec").removeAttr('disabled', 'disabled');
                        $('.availability_status').show();
                        $('#txt_availability_status').removeClass('btn-danger');
                        $('#txt_availability_status').addClass('btn-success');
                        $('#txt_availability_status').text('Available');
                    }
                }
            });
        });
    });
</script>>