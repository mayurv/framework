<!-- Add Modal -->
<div class="modal" id="bookrecursiveconference-modal" role="dialog">
    <div class="modal-dialog modal-sm">

        <!-- Modal content-->
        <form  action="<?php echo base_url() ?>/conferencebooking/recursivebackend_create" id="f" method="post" >
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close add_close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Recursive Booking : 

<!--                        <span class="text-insp-success">
                            <span class="title_start_time"></span> -
                            <span class="title_end_time"></span>
                        </span>-->
                    </h4>
                </div>
                <div class="modal-body">

                    <div class="col-sm-8 col-sm-push-2">
                        <div class="resource_id"></div>

                        <div  class="date-cal-bg" >
                            <div class="all-padding-5 text-center date-cal-head"><span class="title_day"></span></div>
                            <div class="text-center all-padding-5">
                                <div class="text-light-head font-size-18"><span class="title_year"></span></div>
                            </div>
                        </div>

                        <div  class="date-cal-bg" >
                            <div class="all-padding-5 text-center date-cal-head"><span class="title_day1"></span></div>
                            <div class="text-center all-padding-5">
                                <div class="text-light-head font-size-18"><span class="title_year1"></span></div>
                            </div>
                        </div>
                    </div>
                    
                     <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('from_time'), 'interview_time', array('for' => 'from_time')); ?>

                                        <?php
                                        echo form_input(array(
                                            'id' => 'from_time',
                                            'name' => 'from_time',
                                            'placeholder' => 'Interview Time',
                                            'data-template' => "dropdown",
                                            'data-show-seconds' => "true",
                                            'data-default-time' => "09:45 PM",
                                            'class' => 'timepicker',
                                            'data-error' => '.addOpening5',
                                        ));
                                        ?>   

                                    <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                        <div class="addOpening5"></div>
                                    </div>
                                </div>
                            <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('to_time'), 'to_time', array('for' => 'to_time')); ?>

                                        <?php
                                        echo form_input(array(
                                            'id' => 'to_time',
                                            'name' => 'to_time',
                                            'placeholder' => 'Interview Time',
                                            'data-template' => "dropdown",
                                            'data-show-seconds' => "true",
                                            'data-default-time' => "09:45 PM",
                                            'class' => 'timepicker',
                                            'data-error' => '.addOpening5',
                                        ));
                                        ?>   

                                    <!--<input type="text" id="" class="timepicker" data-template="dropdown" data-show-seconds="true" data-default-time="09:45 PM" data-show-meridian="true" data-minute-step="5" data-error=".errorTxt97">-->
                                        <div class="addOpening5"></div>
                                    </div>
                                </div>
                    <div class="col-sm-12">
                        <div class="input-field">
                            <textarea name="name" id="work_detail_desc" placeholder="Enter details" data-error=".errorTimesheet" class="materialize-textarea" required="required"></textarea>
                            <div class="errorTimesheet"></div>
                        </div>
                    </div> 



                    <div class="modal-footer no-border">
                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>

                    <input value="" id="start_time" name="start" hidden>
                    <input value="" id="end_time" name="end" hidden>
                    <input value="" id="resource" name="resource" hidden>
                </div>
            </div>
        </form>
    </div>
</div>
<!--End add modal timesheet-->

     <script type="text/javascript">
            
            
        /* Date picker validation Fucntions */
            $(document).ready(function () {
                $(".interview_date").click(function () {
                    $('.interview_date').pickadate({
                        selectYears: true,
                        selectMonths: true,
                        min: new Date(),
                    });
                });
            });
        </script>