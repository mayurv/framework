<?php foreach ($my_approvals as $r => $result) { ?>  

    <!--view comment start -->
    <div class="modal fade" id="my_comment_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <?php $date = $result['submission_year'] . '-' . $result['submission_month'] . '-01'; ?>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4><?php echo $result['userfullname'] ?>  
                        <small class="text-gray ">  <?php echo date("F, Y", strtotime($date)); ?></small>
                    </h4>
                </div>
                <div class="modal-body">

                    <div class="user-normal-slim">

                        <div class="">               
                            <?php echo form_open('timesheet/magager_comment/', array('id' => 'form_timesheet_app_id', 'class' => 'form_timesheet_app_id')); ?>
                            <!-- 1st row start here -->
                            <div class="row">
                                
                                 <div class="col-sm-12">                                    
                                    <?php if ($result['approval_status'] == 1) { ?>
                                        <!--<a class="btn btn-xs btn-success" id="id-submit-tm" >-->
                                        <div class="text-center text-bold">
                                            <span class="btn btn-md btn-success ">
                                                <!--<i class=" fa fa-check "> </i>--> 
                                                <span class="text-bold"><?php echo $result['total_hours']; ?> hrs</span>
                                            </span>  
                                        </div>
                                        <!--</a>-->
                                    <?php } ?>

                                    <?php if ($result['approval_status'] == 2) { ?>
                                        <!--<a class="btn btn-xs btn-danger" id="id-submit-tm" >-->
                                        <div class="text-center">
                                            <span class="btn btn-md btn-danger "> 
                                                <!--<i class="fa fa-times "> </i>-->    
                                                <span class="text-bold"><?php echo $result['total_hours']; ?> hrs</span>
                                                
                                            </span>  
                                        </div>
                                         
                                        <!--</a>-->
                                    <?php } ?>


                                </div>
                                
                                <div class="col-sm-12 margin-top-15">
                                    <span class="font-size-30 text-center">
                                        <?php //echo $result['total_hours']; ?> 
                                    </span>
                                </div>
                               
                                <div class="col-sm-12">  
                                    <label>Manager Comment </label><br>
                                    <?php echo $result['mng_comments'] ?>
                                </div>

                                <div class="clearfix"></div>

                            </div>
                            <input type="hidden" id="req_id" name="user_id" value="<?php echo $result['user_id'] ?>">
                            <input type="hidden" id="req_id" name="mng_id" value="<?php echo $result['mng_id'] ?>">
                            <input type="hidden" id="submission_month" name="submission_month" value="<?php echo $result['submission_month'] ?>">
                            <input type="hidden" id="submission_year" name="submission_year" value="<?php echo $result['submission_year'] ?>">
                            <input type="hidden" id="approval_status" name="approval_status" value="2">
                            <!-- 1st row end here -->
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--view comment  -->
<?php } ?>