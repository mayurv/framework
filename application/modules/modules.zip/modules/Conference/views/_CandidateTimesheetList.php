<div class="main-bg all-padding-15"> 
<table class="table table-responsive">
                    <thead>
                        <tr>
                            <th>Candidate Name</th>
                            <th>For the Month</th>
                            <th>Total Hours</th>
                            <th>Submission Date</th>
                            <th>Action</th>
                            
                        </tr>
                    </thead>
                    <div class="pull-right"> 

                    </div>
                    <tbody class="">
                        <?php foreach ($associates as $r => $result) { 
                            $date=$result['submission_year'].'-'.$result['submission_month'].'-01';
//                            var_dump($date);die;
                            ?>  
                            <tr id="deleteLeaveRow_<?php echo $result['id']; ?>">
                                <td class="">
                                    <a title="Click here to view timesheet" data-toggle="modal" href="#candidatetimeline_<?php echo $result['id'] ?>"><?php echo $result['userfullname']; ?></a>
                                
                                </td>
                                
                                <td class=""><?php echo date('F',  strtotime($date)); ?> <?php echo date('Y',  strtotime($date)); ?></td>
                        
                                <td class=""><?php echo $result['total_hours']; ?></td>
                           
                                <td class=""><?php echo date("j F, Y", strtotime($result['submission_date'])); ?></td>
                                <td class="">
                                      <a  data-toggle="modal" href="#manager_comment_<?php echo $result['id']?>" class="btn btn-xs btn-success" id="id-submit-tm" >
                            <i class="fa fa-check"> </i> Approve
                        </a>
                                    <a  data-toggle="modal" href="#manager_comment_<?php echo $result['id']?>" class="btn btn-xs btn-danger" id="id-submit-tm" >
                            <i class="fa fa-times"> </i> Reject
                       </a>
                                </td>
                            </tr>  
                        <?php } ?>
                    </tbody>
                </table>
        <?php //echo $this->ajax_pagination->create_links(); ?>
    

    </div>

<?php $this->load->view('modal/_manager_comment'); ?>