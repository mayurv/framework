<!DOCTYPE html>
<?php //echo base_url() .'assets/css/jquery.dataTables.min.css' ; exit; ?>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title>Codeigniter Datatable Example</title>
        <!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]-->
        <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/css/jquery.dataTables.min.css"/>
        <script type= 'text/javascript' src="<?php echo base_url(); ?>assets/js/jquery-1.11.3.min.js"></script>
        <script type= 'text/javascript' src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
        <script type= 'text/javascript'>
            $(document).ready(function () {
                $('#cd-grid').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: "http://demo_ci.com/Datatable/cd_list"
                });
            });
        </script>
    </head>
    <body>
        <table id="cd-grid" class="display" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Cd Id</th>
                    <th>Title</th>
                    <th>Interpret</th>
                    <th>Release Date</th>
                    <th>No of Copies</th>
                    <th>Type</th>
                    <th>Owner</th>
                    <th>Content Type</th>
                </tr>
            </thead>

            <tfoot>
                <tr>
                    <th>Cd Id</th>
                    <th>Title</th>
                    <th>Interpret</th>
                    <th>Release Date</th>
                    <th>No of Copies</th>
                    <th>Type</th>
                    <th>Owner</th>
                    <th>Content Type</th>
                </tr>
            </tfoot>
        </table>
    </body>
</html>
