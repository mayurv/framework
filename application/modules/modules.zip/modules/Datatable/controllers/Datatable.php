<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Datatable extends MY_Controller {

 
    function __construct() {
        parent::__construct();
        $this->load->model('CdModel', 'dt');
    }
 
    function index() {
        
         $this->template->write('title', 'Data table', TRUE);
         $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('content', 'datatable', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
                        
    }
 
    function cd_list() {
        $results = $this->dt->get_cd_list();
        echo json_encode($results);
    }
 
}
 
/* End of file cdcontroller.php */
/* Location: ./application/controllers/Datatable.php */