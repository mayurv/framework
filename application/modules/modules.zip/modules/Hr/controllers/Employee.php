<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Employee extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees', 'common', 'personaldetails', 'communication'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('city', 'country', 'state', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        } elseif (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $data['employee'] = $this->employeesummary->get_all();
//        var_dump($data['employee']);die;
        //$this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_view_all_employee', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function test() {
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        //Get Menu & Sub Menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        //$this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'official/_wizard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    /*
     * Add Associate
     */

    public function addofficial() {

        $this->load->helper('form');
        $this->load->library('form_validation');

//         $this->user_unique_slug(1);
        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata(lang('not_access'), $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = $this->employees->get_prefix_name();
        $data['empmode_list'] = $this->employees->get_employement_mode_name();
        $data['emprole_list'] = $this->employees->get_emp_role();
        $data['department_list'] = $this->employees->get_department_name();
        $data['jobtitle_list'] = $this->employees->get_jobtitle();
        $data['holiday_group'] = $this->employees->get_holiday_group_name();
        $data['emp_status_list'] = $this->employees->get_employement_status();
//        $data['user_summary'] = '';
//        $data['leaves'] = $this->employeesummary->get_leaves_by_id($empId);
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');

        $data['action'] = 'add';


        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "add") {
            
//            var_dump($_POST);die;

            $config = array(
                array('field' => 'email',
                    'label' => 'email',
                    'rules' => 'trim|required|max_length[50]|valid_email|is_unique[main_users.email]'),
                array('field' => 'firstname',
                    'label' => 'First Name',
                    'rules' => 'trim|alpha|min_length[2]|max_length[25]|required'),
                array('field' => 'lastname',
                    'label' => 'Last Name',
                    'rules' => 'trim|alpha|min_length[2]|max_length[25]|required'),
                array('field' => 'prefix_id',
                    'label' => 'Prefix',
                    'rules' => 'required'),
                array('field' => 'modeofemp_id',
                    'label' => 'Mode of Employment',
                    'rules' => 'required'),
                array('field' => 'emprole_id',
                    'label' => 'Role',
                    'rules' => 'required'),
                array('field' => 'department_id',
                    'label' => 'Department',
                    'rules' => 'required'),
                array('field' => 'reporting_manager',
                    'label' => 'Manager',
                    'rules' => 'required'),
                array('field' => 'jobtitle_id',
                    'label' => 'Job Title',
                    'rules' => 'required'),
                array('field' => 'position_id',
                    'label' => 'Position',
                    'rules' => 'required'),
                array('field' => 'emp_status_id',
                    'label' => 'Employment Status',
                    'rules' => 'required'),
                array('field' => 'date_of_joining',
                    'label' => 'Date of Joining',
                    'rules' => 'required'),
                array('field' => 'yearsofexp',
                    'label' => 'Years of Experience',
                    'rules' => 'required'),
                array('field' => 'monthsofexp',
                    'label' => 'Months of Experience',
                    'rules' => 'required')
            );
            $res = $this->form_validation->set_rules($config);

//            var_dump($this->form_validation->run());die;
//            echo validation_errors();die;
            //$this->form_validation->set_rules('firstname', 'firstname', 'required|min_length[2]|max_length[12]');
            //$this->form_validation->set_rules('lastname', 'lastname', 'required');
            if ($this->form_validation->run() == TRUE) {

//                var_dump($res);die;
//            $this->form_validation->set_rules('firstname', 'firstname', 'required|min_length[5]|max_length[12]|is_unique[main_users.firstname]');
//            $this->form_validation->set_rules('lastname', 'lastname', 'required');
//                var_dump($_POST);die;
                /* For update group_id */
                $emprole = $this->input->post('emprole_id');
                $group_id = $this->groups->get_group_id_by_role_id($emprole);

                /* Password Generate */
                $passFormatData = array(
                    'employeeid' => $this->input->post('employeeid'),
                    'firstname' => $this->input->post('firstname'),
                    'lastname' => $this->input->post('lastname'),
                    'date_of_joining' => $this->input->post('date_of_joining')
                );
                $dataPass = $this->generatePassword($passFormatData);
                /* Generate Unique Slug */
                $user_slug = $this->user_unique_slug($passFormatData);

                $dataUserRegistration = array(
                    'group_id' => $group_id,
                    'emprole' => $this->input->post('emprole_id'),
                    'userfullname' => $this->input->post('firstname') . ' ' . $this->input->post('lastname'),
                    'empipaddress' => $this->input->ip_address(),
                    'password' => $dataPass['password'],
                    'password1' => $dataPass['password1'],
                    'email' => $this->input->post('email'),
                    'contactnumber' => $this->input->post('contactnumber'),
                    'reporting_manager' => $this->input->post('reporting_manager'),
                    'firstname' => $this->input->post('firstname'),
                    'lastname' => $this->input->post('lastname'),
                    'prefix_id' => $this->input->post('prefix_id'),
                    'employeeId' => $this->input->post('employeeid'),
                    'modeofentry' => $this->input->post('modeofemp_id'),
                    'department_id' => $this->input->post('department_id'),
                    'emp_status_id' => $this->input->post('emp_status_id'),
                    'position_id' => $this->input->post('position_id'),
                    'jobtitle_id' => $this->input->post('jobtitle_id'),
                    'date_of_joining' => $this->input->post('date_of_joining'),
                    'years_exp' => $this->input->post('yearsofexp'),
                    'months_exp' => $this->input->post('monthsofexp'),
                    'profileimg' => $this->input->post('profileimage'),
                    'salt' => $user_slug,
                    'createdby' => $this->session->userdata('user_id'),
                    'createddate' => date('Y-m-d H:i:s')
                );


                /* Make Unique directory */
                $this->_mkdir_user_directiory($passFormatData);

                $insertAssoId = $this->users->insert($dataUserRegistration);


                if (isset($insertAssoId)) {
                    /* employee data */
                    $dataUserEmployee = $dataUserRegistration;
                    unset($dataUserEmployee['group_id']);
                    unset($dataUserEmployee['emprole']);
                    unset($dataUserEmployee['userfullname']);
                    unset($dataUserEmployee['empipaddress']);
                    unset($dataUserEmployee['password']);
                    unset($dataUserEmployee['password1']);
                    unset($dataUserEmployee['email']);
                    unset($dataUserEmployee['contactnumber']);
                    unset($dataUserEmployee['firstname']);
                    unset($dataUserEmployee['lastname']);
                    unset($dataUserEmployee['employeeId']);
                    unset($dataUserEmployee['modeofentry']);
                    unset($dataUserEmployee['profileimg']);
                    unset($dataUserEmployee['salt']);
                    $dataUserEmployee['user_id'] = $insertAssoId;
                    $this->employees->insert($dataUserEmployee);
                    /* end employeedata */


                    /* employee summary data */
                    $dataUserEmployeeSummary = array(
                        'user_id' => $insertAssoId,
                        'holiday_group' => $this->input->post('holiday_group_id'),
                        'prefix_name' => $this->input->post('prefix_name'),
                        'emailaddress' => $this->input->post('email'),
                        'emprole_name' => $this->input->post('emprole_name'),
                        'reporting_manager_name' => $this->input->post('reporting_manager_name') ? $this->input->post('reporting_manager_name') : '',
                        'department_name' => $this->input->post('department_name') ? $this->input->post('reporting_manager_name') : '',
                        'jobtitle_name' => $this->input->post('jobtitle_name') ? $this->input->post('jobtitle_name') : '',
                        'position_name' => $this->input->post('position_name') ? $this->input->post('position_name') : '',
                        'holiday_group_name' => $this->input->post('holiday_group_name') ? $this->input->post('holiday_group_name') : '',
                        'emp_status_name' => $this->input->post('emp_status_name') ? $this->input->post('emp_status_name') : '',
                        'profile_completion' => 30,
                        'isactive' => $this->input->post('isactive'),
                    );

                    $dataUserEmployeeSummary = array_merge($dataUserRegistration, $dataUserEmployeeSummary);

                    unset($dataUserEmployeeSummary['group_id']);
                    unset($dataUserEmployeeSummary['email']);
                    unset($dataUserEmployeeSummary['password1']);
                    unset($dataUserEmployeeSummary['password']);
                    unset($dataUserEmployeeSummary['empipaddress']);
                    unset($dataUserEmployeeSummary['password']);
                    unset($dataUserEmployeeSummary['salt']);

                    $this->employeesummary->insert($dataUserEmployeeSummary);
                    /* end employee summary data */


                    /* to make entry in group */
                    $datagrp = array('user_id' => $insertAssoId, 'group_id' => $group_id);
                    $res = $this->usergroups->insert_main_user_groups($datagrp);
                    /* to make enrty in employees */

                    /* leaves & holidays */
                    $dataleave['user_id'] = $insertAssoId;
                    $dataleave['alloted_year'] = 2016;
                    $dataleave['emp_leave_limit'] = $this->input->post('emp_leave_limit');
                    $dataleave['createddate'] = date('Y-m-d H:m:s');
                    $dataleave['createdby'] = $this->session->userdata('user_id');
                    $this->employeesummary->insert_leaves($dataleave);
                    unset($dataleave);

                    $dataholiday['user_id'] = $insertAssoId;
                    $dataholiday['holiday_group_id'] = $this->input->post('holiday_group_id');
                    $dataholiday['createddate'] = date('Y-m-d H:m:s');
                    $dataholiday['createdby'] = $this->session->userdata('user_id');
                    $this->employeesummary->insert_holiday_group($dataholiday);
                    unset($dataholiday);
                    /* end leaves & holidays */

                    /* set session data */
                    $session_data = array(
                        'associate_email' => $dataUserRegistration['email'],
                        'associate_id' => $insertAssoId //everyone likes to overwrite id so we'll use user_id
                    );
                    $this->session->set_userdata($session_data);
                    /* end set session data */
                }
//                $data['user_summary'] = '';
                $data['empId'] = $this->_get_employeeid();
            }//end of post
        }
        //Get Menu & Sub Menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'official/_add_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();

//        
    }

    /* Unique Slug Generation */

    public function user_unique_slug($uniqueSlugData) {
        return strtolower($uniqueSlugData['employeeid'] . '-' . $uniqueSlugData['firstname']);
    }

    /* Create user directory */

    public function _mkdir_user_directiory($mkdirUserData) {

        $user_slug = $this->user_unique_slug($mkdirUserData);
        /* to create registered user folder directory */
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents';
        $targetPathProf = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/profile';
        if (!file_exists($targetPath) || !file_exists($targetPathProf)) {
            mkdir($targetPath, 0777, true);
            mkdir($targetPathProf, 0777, true);
            return true;
        } else
            return false;
        /* end of make directory */
    }

    /* Password Generarting */

    private function generatePassword($passFormatData) {

        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);


        $this->load->library('encrypt');

        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 4);
        $post_array['password1'] = strtolower($passFormatData['employeeid']) . '@' . $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $post_array['password'] = $this->hash_password($post_array['password1'], $salt);

        return $post_array;
    }

    /* Autogenerate Employee ID  */

    function _get_employeeid() {

        $this->load->model(array('employees'));
        $empid = $this->employees->get_employee_id();
        //echo '<pre>',  print_r($empid);die;
        if (isset($empid)) {
            return $empid;
        } else {
            return 'MWX-001';
        }
    }

    /* Get Position by jobtitle */

    function get_position_by_jt_id($jtid) {
        return $this->employees->get_position_by_jt_id($jtid);
    }

    /*
     * View Associate
     */

    public function view_user($empId) {

        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
        $data['empid'] = $empId;

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);
        $data['c_emp_communication'] = $this->employeesummary->employee_communication_data_by_id($empId);
        if (isset($data['c_emp_communication'])) {
            $data['contry'] = $this->country->get_name_by_id($data['c_emp_communication']->current_country);
            $data['state'] = $this->state->get_name_by_id($data['c_emp_communication']->current_state);
            $data['city'] = $this->city->get_name_by_id($data['c_emp_communication']->current_city);
        }
        //Associate Holiday & Leaves
        $data['holiday'] = $this->employeesummary->get_holiday_dates($empId);
        $data['leaves'] = $this->employeesummary->get_leaves_by_id($empId);

        //var_dump($data['current_employee']);die;
        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'official/_view_employee', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    /*
     * Edit Associate
     */

    public function edit($empId) {

        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['action'] = 'edit';

        /* edit employee */
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "edit") {

            var_dump($_POST);die;
//            $this->form_validation->set_rules('lastname', $this->lang('prefix_required'), 'required');

            /* For update group_id */
            $emprole = $this->input->post('emprole_id');
            $group_id = $this->groups->get_group_id_by_role_id($emprole);

            $dataUserRegistration = array(
                'group_id' => $group_id,
                'emprole' => $this->input->post('emprole_id'),
                'userfullname' => $this->input->post('firstname') . ' ' . $this->input->post('lastname'),
                'empipaddress' => $this->input->ip_address(),
                'email' => $this->input->post('email'),
                'contactnumber' => $this->input->post('contactnumber'),
                'reporting_manager' => $this->input->post('reporting_manager'),
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'prefix_id' => $this->input->post('prefix_id'),
                'employeeId' => $this->input->post('employeeid'),
                'modeofentry' => $this->input->post('modeofemp_id'),
                'department_id' => $this->input->post('department_id'),
                'emp_status_id' => $this->input->post('emp_status_id'),
                'position_id' => $this->input->post('position_id'),
                'jobtitle_id' => $this->input->post('jobtitle_id'),
                'date_of_joining' => '2009-06-02', //$this->input->post('date_of_joining'),
                'years_exp' => $this->input->post('yearsofexp'),
                'months_exp' => $this->input->post('monthsofexp'),
                'profileimg' => $this->input->post('profileimage'),
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s')
            );


            $updateAssoId = $this->users->update($empId, $dataUserRegistration);

            if (isset($updateAssoId)) {
                /* employee data */
                $dataUserEmployee = $dataUserRegistration;
                unset($dataUserEmployee['group_id']);
                unset($dataUserEmployee['emprole']);
                unset($dataUserEmployee['userfullname']);
                unset($dataUserEmployee['empipaddress']);
                unset($dataUserEmployee['password']);
                unset($dataUserEmployee['password1']);
                unset($dataUserEmployee['email']);
                unset($dataUserEmployee['contactnumber']);
                unset($dataUserEmployee['firstname']);
                unset($dataUserEmployee['lastname']);
                unset($dataUserEmployee['employeeId']);
                unset($dataUserEmployee['modeofentry']);
                unset($dataUserEmployee['profileimg']);
                unset($dataUserEmployee['salt']);
//                $dataUserEmployee['user_id'] = $updateAssoId;
                $this->employees->update($empId, $dataUserEmployee);
                /* end employeedata */


                /* employee summary data */
                $dataUserEmployeeSummary = array(
//                    'user_id' => $empId,
                    'holiday_group' => $this->input->post('holiday_group_id'),
                    'prefix_name' => $this->input->post('prefix_name'),
                    'emailaddress' => $this->input->post('email'),
                    'emprole_name' => $this->input->post('emprole_name'),
                    'reporting_manager_name' => $this->input->post('reporting_manager_name') ? $this->input->post('reporting_manager_name') : '',
                    'department_name' => $this->input->post('department_name') ? $this->input->post('reporting_manager_name') : '',
                    'jobtitle_name' => $this->input->post('jobtitle_name') ? $this->input->post('jobtitle_name') : '',
                    'position_name' => $this->input->post('position_name') ? $this->input->post('position_name') : '',
                    'holiday_group_name' => $this->input->post('holiday_group_name') ? $this->input->post('holiday_group_name') : '',
                    'emp_status_name' => $this->input->post('emp_status_name') ? $this->input->post('emp_status_name') : '',
                    'profile_completion' => 30,
                    'isactive' => $this->input->post('isactive')
                );


                $dataUserEmployeeSummary = array_merge($dataUserRegistration, $dataUserRegistration);

//                var_dump($dataUserEmployeeSummary);die;

                unset($dataUserEmployeeSummary['group_id']);
                unset($dataUserEmployeeSummary['email']);
                unset($dataUserEmployeeSummary['password1']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['empipaddress']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['salt']);

                $this->employeesummary->update($empId, $dataUserEmployeeSummary);
//                echo $this->db->last_query();die;
                /* end employee summary data */


                /* to make entry in group */
                $datagrp = array('group_id' => $group_id);
                $res = $this->usergroups->update($empId, $datagrp);
                /* to make enrty in employees */
//                echo 'updated all';
//                die;

                /* leaves & holidays */
//                $dataleave['user_id'] = $empId;
//                $dataleave['alloted_year'] = $this->input->post('emp_leave_year');
//                $dataleave['emp_leave_limit'] = $this->input->post('emp_leave_limit');
//                $dataleave['createddate'] = date('Y-m-d H:m:s');
//                $dataleave['createdby'] = $this->session->userdata('user_id');
//                $this->employeesummary->insert_leaves($dataleave);
//                unset($dataleave);
//                $dataholiday['user_id'] = $empId;
//                $dataholiday['holiday_group_id'] = $this->input->post('holiday_group_id');
//                $dataholiday['createddate'] = date('Y-m-d H:m:s');
//                $dataholiday['createdby'] = $this->session->userdata('user_id');
//                $this->employeesummary->insert_holiday_group($dataholiday);
//                unset($dataholiday);
                /* end leaves & holidays */
            }
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        /* if edit */
        $data['c_user_id'] = $empId;
//        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = $this->employees->get_prefix_name();
        $data['empmode_list'] = $this->employees->get_employement_mode_name();
        $data['emprole_list'] = $this->employees->get_emp_role();
        $data['department_list'] = $this->employees->get_department_name();
        $data['jobtitle_list'] = $this->employees->get_jobtitle();
        $data['holiday_group'] = $this->employees->get_holiday_group_name();
        $data['leaves'] = $this->employeesummary->get_leaves_by_id($empId);
//        var_dump($data['leaves']);die;
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['emp_status_list'] = $this->employees->get_employement_status();

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $empId);
        $data['position_list'] = $this->get_position_by_jt_id($data['user_summary']['jobtitle_id']);
        
//        var_dump($data['position_list']);die;

        $data['rep_manager_list'] = $this->employeesummary->get_all_rep_mang_by_dept_id($data['user_summary']['department_id']);

//        var_dump($data['user_summary']);die;
        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'official/_add_employee', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    /*
     * Add contact information
     */

    public function contactinfo($empId) {

        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "add") {


            $dob = str_replace("/", "-", $this->input->post('dob'));
            $dob = date('Y-m-d', strtotime($dob));
//            var_dump($_POST);die;

            $dataPersonalArray = array(
                'user_id' => $this->input->post('associate_id'),
                'genderid' => $this->input->post('gender'),
                'maritalstatusid' => $this->input->post('marital_status'),
                'nationalityid' => $this->input->post('nationality_name'),
                'languageid' => $this->input->post('language_name'),
                'dob' => $dob,
                'bloodgroup' => $this->input->post('blood_group'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'isactive' => 1
            );
//            var_dump($dataPersonalArray);die;
            $res = $this->personaldetails->insert($dataPersonalArray);
//            var_dump($res);die;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {

            $data['gender'] = $this->common->get_all_gender();
            $data['marital_status'] = $this->common->get_all_marital_status();
            $data['nationality_name'] = $this->common->get_all_nationality_name();
            $data['language_name'] = $this->common->get_all_language_name();


//            var_dump($data['marital_status']);die;
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        //to get main menu, sub menu
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));

        //to check is entry already exists or not
        $data['result'] = $this->employeesummary->is_contact_information_already_exist($empId);

        if (isset($data['result']['personal']) && isset($data['result']['communication'])) {

            $data['personal_detail'] = $this->employeesummary->get_personal_detail_by_id($empId);

            if (isset($data['personal_detail'])) {

                if ($data['personal_detail']->genderid == '1')
                    $data['personal_detail']->genderid = 'Male';
                else
                    $data['personal_detail']->genderid = 'Female';

                if ($data['personal_detail']->maritalstatusid)
                    $data['personal_detail']->maritalstatusid = $this->employeesummary->get_marital_status_by_id($data['personal_detail']->maritalstatusid);

                if ($data['personal_detail']->nationalityid)
                    $data['personal_detail']->nationalityid = $this->employeesummary->get_nationality_by_id($data['personal_detail']->nationalityid);

                if ($data['personal_detail']->languageid)
                    $data['personal_detail']->languageid = $this->employeesummary->get_language_by_id($data['personal_detail']->languageid);

                if ($data['personal_detail']->bloodgroup) {
                    $blood_group = array('0' => 'Select Blood Group', '1' => 'A +', '2' => 'A -', '3' => 'O +', '4' => 'O -', '5' => 'B +', '6' => 'B -', '7' => 'Ab +', '8' => 'AB -');
                    var_dump($blood_group);
                    die;
                    foreach ($blood_group as $bg) {
                        if ($data['personal_detail']->bloodgroup = $bg)
                            $data['personal_detail']->bloodgroup = $bg;
                    }
                    $data['personal_detail']->bloodgroup = $this->employeesummary->get_language_by_id($data['personal_detail']->languageid);
                }
            }

            $this->template->write_view('content', '_view_contactinfo', (isset($data) ? $data : NULL));
        } else
            $this->template->write_view('content', '_add_contactinfo', (isset($data) ? $data : NULL));

//        if(isset($result['communication']))
//        var_dump($res);die;



        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function action_delete($primary_key, $row) {
        return base_url('hr/delete_user') . '/' . $row->id;
    }

    function delete_user($id = null) {
//        var_dump($id);die;

        $this->users->update_user_status_id($id);
        redirect(base_url('hr/adduser'));
    }

    function action_newsEdit($primary_key, $row) {
        return base_url('admin/artist/newsEdit') . '/' . $row->id;
    }

    public function action_manage_artwork($primary_key, $row) {

////        var_dump($row);die;
//        $name = $this->employees->get_userfullname_by_user_id($row);
//        return $name;
    }

    public function _fullnameby_adduser($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_user_id($row);
        return $name;
    }

    function _callback_before_insert_user_data($post_array) {

//        echo '<pre>before_insert_user',  print_r($post_array);

        $this->load->library('encrypt');


        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);

        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        $post_array['password1'] = $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $post_array['password'] = $this->hash_password($password, $salt);

//        $post_array['username'] = $post_array['username'];
        $post_array['userfullname'] = $post_array['firstname'] . ' ' . $post_array['lastname'];
        $post_array['active'] = $post_array['isactive'];
        $post_array['empipaddress'] = $this->input->ip_address();
//        $post_array['createdat'] = ;
        return $post_array;
    }

    //password encryption
    function encrypt_password_callback($post_array) {

        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);


        $this->load->library('encrypt');
        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        $post_array['password1'] = $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $password = $this->hash_password($password, $salt);

        //$post_array['password'] = $this->encrypt->encode($password, $key);

        return $post_array;
    }

    public function callback_valid_password($primary_key) {
        var_dump($primary_key);
        die;
        $name = $this->employees->get_name_by_id($primary_key);
        return $name;
    }

    //to get userfull name by document id
    public function _dropdownfalse($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_doc($row);
        return $name;
    }

    /* @description : to manage associate leaves */

    //get userfullname by leave id
    public function _fullnameby_leave($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_leave_id($row);
        return $name;
    }

    public function _fullnameby_holiday($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_holiday_id($row);
        return $name;
    }

    public function _fullnameby_personal($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_personal_id($row);
        return $name;
    }

    public function _fullnameby_contact($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_contact_id($row);
        return $name;
    }

    public function _fullnameby_skill($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_skill_id($row);
        return $name;
    }

    public function _fullnameby_jobhistory($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_jobhistory_id($row);
        return $name;
    }

    public function _fullnameby_experience($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_experience_id($row);
        return $name;
    }

    public function _fullnameby_education($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_education_id($row);
        return $name;
    }

    public function _fullnameby_certification($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_certification_id($row);
        return $name;
    }

    public function _fullnameby_visa($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_visa_id($row);
        return $name;
    }

    function showStatus($value) {

        if ($value == 0)
            return "Inactive";
        else
            return "Active";
    }

    function edit_tags_field() {
        return "<div style='font-size:16px;font-family:Arial'>Permanent Address</div>";
    }

    function getRepMan() {
        $this->load->model(array('employees'));
        if (isset($_GET['department_id'])) {
            $deptid = $_GET['department_id'];
//        $country_id = $this->input->get('country_id');
            $department = $this->employees->get_repman_by_id($deptid);
        }
//        $st = '';
//        foreach ($states as $state) {
//            $st .= '<option value="' . $state->id . '">' . $state->name . '</option>';
//        }
//        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $department));
    }

    function getPosition() {
        $this->load->model(array('employees'));

        if (isset($_GET['jobtitle_id'])) {

            $jobtitle_id = $_GET['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
            $st = '';
//            $st = '<option value="">Select Position</option>';
            foreach ($jobtitle as $title) {
                $st .= '<option value="' . $title->position_id . '">' . $title->positioname . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getEmployeeId() {

        $empid = $this->employees->get_employee_id();

        if (isset($empid)) {
            $st = '<input type="text" name="employeeId" id="field-employeeId" value="MWX-' . $empid . '" />';
        } else {
            $st = 'MWX-001';
        }

        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getPositionName() {

        if (isset($_POST['jobtitle_id'])) {

            $jobtitle_id = $_POST['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
//            $st = '';
            $st = '<option value="">Select Position</option>';
            $li = '';
            foreach ($jobtitle as $title) {
                $st .= ' <option value="' . $title->position_id . '">' . $title->positioname . '</option>';
                $li .= '<li class="selected"><span>' . $title->positioname . '</span></li>';
            }
//            $st .='</select>';
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st, 'li' => $li));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => '', 'li' => ''));
        }
    }

    function getEmployementStatus() {

        $employmentstatus = $this->employees->get_employement_name();
        $st = '<option value="">Select Employment Status</option>';
//            $st .= '<option value=""  selected="selected">Select Position</option>';
        foreach ($employmentstatus as $title) {
            $st .= '<option value="' . $title->emp_status_id . '">' . $title->emp_status . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getReportingManager() {


        if (isset($_POST)) {

//            echo '<pre>', print_r($_POST);die;
            $department_id = $_POST['department_id'];

            $rep_manager = $this->employeesummary->get_all_rep_mang_by_dept_id($_POST);
            $st = '';
            $st = '<option value="">Select Manager</option>';
            foreach ($rep_manager as $title) {
                $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    public function hash_password($password, $salt = false, $use_sha1_override = FALSE) {
        if (empty($password)) {
            return FALSE;
        }

        // bcrypt
        if ($use_sha1_override === FALSE && $this->hash_method == 'bcrypt') {
            return $this->bcrypt->hash($password);
        }


        if ($this->store_salt && $salt) {
            return sha1($password . $salt);
        } else {
            $salt = $this->salt();
            return $salt . substr(sha1($salt . $password), 0, -$this->salt_length);
        }
    }

    public function salt() {

        $raw_salt_len = 16;

        $buffer = '';
        $buffer_valid = false;

        if (function_exists('mcrypt_create_iv') && !defined('PHALANGER')) {
            $buffer = mcrypt_create_iv($raw_salt_len, MCRYPT_DEV_URANDOM);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && function_exists('openssl_random_pseudo_bytes')) {
            $buffer = openssl_random_pseudo_bytes($raw_salt_len);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && @is_readable('/dev/urandom')) {
            $f = fopen('/dev/urandom', 'r');
            $read = strlen($buffer);
            while ($read < $raw_salt_len) {
                $buffer .= fread($f, $raw_salt_len - $read);
                $read = strlen($buffer);
            }
            fclose($f);
            if ($read >= $raw_salt_len) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid || strlen($buffer) < $raw_salt_len) {
            $bl = strlen($buffer);
            for ($i = 0; $i < $raw_salt_len; $i++) {
                if ($i < $bl) {
                    $buffer[$i] = $buffer[$i] ^ chr(mt_rand(0, 255));
                } else {
                    $buffer .= chr(mt_rand(0, 255));
                }
            }
        }

        $salt = $buffer;

        // encode string with the Base64 variant used by crypt
        $base64_digits = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        $bcrypt64_digits = './ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $base64_string = base64_encode($salt);
        $salt = strtr(rtrim($base64_string, '='), $base64_digits, $bcrypt64_digits);

        $salt = substr($salt, 0, $this->salt_length);

        return $salt;
    }

    public function getMenuList() {
        //variables
        $k = 1;
        $menuobj = new ArrayObject();
        $i = 1;

        /* start of get menu list */
        $this->data['users'] = $this->ion_auth->users()->result();

        $current_user_id = $this->ion_auth->get_user_id();
        foreach ($this->data['users'] as $user) {
            if ($user->id == $current_user_id)
                $user_role_id = $user->emprole;
        }

        $this->data['group_id'] = $this->menu->get_group_id_by_role($user_role_id);

        $this->data['menu'] = $this->menu->get_allmenu_by_group_id($this->data['group_id'][0]->group_id);
        $data['submenu'] = $this->menu->get_submenu_by_group_id($this->data['group_id'][0]->group_id);
//        $data['submenu'] = $this->menu->get_submenu_by_group_id1($this->data['group_id'][0]->group_id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($this->data['group_id'][0]->group_id);
//
//        for ($i = 0; $i < count($data['mainmenu']); $i++) {
//            foreach ($data['submenu'] as $sub) {
//
//                if ($data['mainmenu'][$i]->id == $sub->parent) {
//                    if ($k == 1) {
//                        $menuobj->append(array('menu',$data['mainmenu'][$i]->menuName,$data['mainmenu'][$i]->iconPath));
//                        $k++;
//                    }
//                    $menuobj->append(array('submenu',$sub->menuName,$sub->url));
//                }               
//            }
//            $k = 1;//restrict repetative menu
//        }
//        $menulist = (array)$menuobj;
        return $this->data;
        /* end of get menu list */
    }

    public function activity_log($data) {
        
    }

    public function upload_file($file) {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $user_id = $this->session->userdata('user_id');

        if (isset($user_id))
            $user_data = $this->employeesummary->get_by_id($user_id);

//        echo 'hi';
//        echo '<pre>',  print_r($user_data);die;
//        var_dump($user_data->userfullname);
//        die;
//        die;
        $targetDir = "uploads/";
        $fileName = $_FILES['file']['name'];
        $targetFile = $targetDir . $fileName;

        if (!empty($_FILES)) {
            $filename = $this->handleUpload($user_data);
            echo json_encode(true);
            die;
        }
//        var_dump($data);
//        die;
//        if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
//            //insert file information into db table
////        $conn->query("INSERT INTO files (file_name, uploaded) VALUES('".$fileName."','".date("Y-m-d H:i:s")."')");
//        }
    }

    function handleUpload($user_data) {

        if (!empty($_FILES)) {

            // Validate the file type
            $fileTypes = array('jpg', 'jpeg', 'gif', 'png'); // File extensions
            $fileParts = pathinfo($_FILES['file']['name']);

            if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
                //$this->session->set_error_flashdata('msg', 'Oops! An Error Occurred.');
                $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
                return false;
            }

            $user_slug = $user_data->userfullname;

            $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
//            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'users'
//                    . DIRECTORY_SEPARATOR . $user_slug.DIRECTORY_SEPARATOR .'articles';
//            
            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents';


            if (!file_exists($targetPath)) {
                mkdir($targetPath, 0777, true);
            }

            $tempFile = $_FILES['file']['tmp_name'];
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

            //$rand = randString(4);
//            $targetURL .= '/' . $user_slug . '.' . $ext;
//            $targetPath .= DIRECTORY_SEPARATOR . $user_slug . '.' . $ext;

            $rand = randString(4);
            $targetURL .= '/' . $user_slug . $rand . '.' . $ext;
            $targetPath .= DIRECTORY_SEPARATOR . $user_slug . $rand . '.' . $ext;

            move_uploaded_file($tempFile, $targetPath);

            $data['image'] = $targetURL;


            return $targetPath;
            //  return true;
        }
    }

}
