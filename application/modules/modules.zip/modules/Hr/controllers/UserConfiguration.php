<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   CategoryName
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @see        NetOther, Net_Sample::Net_Sample()
 * @since      File available since Release 1.2.0
 * @deprecated File deprecated in Release 2.0.0
 */
class UserConfiguration extends MY_Controller{
    //put your code here
    public function __construct() {
        parent::__construct();
        
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
//        $this->load->model(array('user_model', 'group_model'));
        $this->load->library('grocery_CRUD');
        $this->load->language('master');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        elseif(!$this->ion_auth->in_group('hr')){
            $this->session->set_flashdata('message', $this->ion_auth->errors());
                redirect('/', 'refresh');
        }        
        
    }
    public function index() {
        
        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', '', TRUE);
        $this->template->write_view('content', '_configuser', '', TRUE);
        //$this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        $this->load->view('index', 'hrdashboard');
    }
    
    //Employement Master entry
    public function emp_mode() {
        
        $crud = new grocery_CRUD();
        $crud->set_theme('flexigrid');
        $crud->set_table('main_employmentmode')
                ->display_as('isactive', lang('status'));

        $crud->set_subject('Employment Mode');
        $crud->columns('mode', 'isactive');

//        $crud->set_relation('group_id', 'main_groups', 'group_name');
        //$crud->set_relation('levelid', 'main_groups', 'level');

        $crud->add_fields('mode', 'description', 'isactive','createdby');
        $crud->edit_fields('mode', 'description', 'isactive', 'modifiedby');

//        $crud->change_field_type('id', 'hidden');
//        $crud->change_field_type('levelid', 'hidden');

        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
//        $crud->change_field_type('levelid',  'hidden', 'addlevelid');
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));
        //  $crud->callback_column('levelid', array($this, 'fieldgroupID'));

        $crud->set_rules('mode', 'Mode', 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('mode');

        $output = $crud->render();
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', NULL);
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'crud', (isset($output) ? $output : NULL));
        $this->template->render();
    }
    
    function showStatus($value) {
        if ($value == 0)
            return "Inactive";
        else
            return "Active";
    }
    
}
