<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   CategoryName
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @see        NetOther, Net_Sample::Net_Sample()
 * @since      File available since Release 1.2.0
 * @deprecated File deprecated in Release 2.0.0
 */
class UserManagement extends MY_Controller{
    //put your code here
    public function __construct() {
        parent::__construct();
        
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
//        $this->load->model(array('user_model', 'group_model'));
        $this->load->library('grocery_CRUD');
        $this->load->language('master');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        elseif(!$this->ion_auth->in_group('hr')){
            $this->session->set_flashdata('message', $this->ion_auth->errors());
                redirect('/', 'refresh');
        }        
        
    }
    public function index() {
        
        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', '', TRUE);
        $this->template->write_view('content', '_adduser', '', TRUE);
        //$this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        $this->load->view('index', 'hrdashboard');
    }
    //
    public function official() {
        
        $crud = new grocery_CRUD();
        $crud->set_theme('flexigrid');
        $crud->unset_export()
                ->unset_print();

        $crud->set_table('users')
                ->set_subject('User')
                ->columns('username', 'firstname', 'lastname', 'email', 'active')              
                ->display_as('firstname', lang('firstname'))
                ->display_as('lastname', lang('lastname'))
                ->display_as('email', lang('email'));

        $crud->set_rules('firstname', lang('firstname'), 'trim|required|min_legth[2]|max_legth[25]');
        $crud->set_rules('lastname', lang('lastname'), 'trim|required|min_legth[2]|max_legth[25]');
        $crud->set_rules('firstname', lang('firstname'), 'trim|required|min_legth[2]|max_legth[25]');
        
        $crud->unique_fields(lang('email'), 'email');

        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));
        
        $crud->change_field_type('created_at', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('updated_at', 'hidden', date('Y-m-d H:i:s'));
        
        $output = $crud->render();    
        $output->title = lang('officiale');
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', NULL);
        //$this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'crud', (isset($output) ? $output : NULL));
        $this->template->render();
    }
}
