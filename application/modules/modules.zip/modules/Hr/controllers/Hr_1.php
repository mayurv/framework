<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Hr extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'menu'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('hr_lang');

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        } elseif (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($data) ? $data : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function adduser() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $this->data['title'] = $this->lang->line('create_deptartment_title');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();
        $crud->set_theme('flexigrid');
        $crud->unset_export()
                ->unset_print();

        $crud->set_table('main_users')
                ->set_subject('Users')
                ->columns('userfullname', 'firstname', 'lastname', 'email')
                ->display_as('firstname', lang('firstname'))
                ->display_as('lastname', lang('lastname'))
                ->display_as('department_id', lang('department_id'))
                ->display_as('prefix_id', lang('prefix_id'))
                ->display_as('modeofentry', lang('modeofentry'))
                ->display_as('emprole', lang('emprole'))
                ->display_as('position_id', lang('position_id'))
                ->display_as('emprole', lang('emprole'))
                ->display_as('department_id', lang('department_id'))
                ->display_as('email', lang('email'));
 
        $check_count = $this->employees->get_record_count();
        $state_code = $crud->getState();

        //to check if first time user resigtration if yes/no
        if ($state_code == 'add') {
//            var_dump($check_count);die;
            if ($check_count == '1') {
                $crud->add_fields('employeeId', 'prefix_id', 'firstname', 'lastname', 'emprole', 'email', 'jobtitle_id', 'position_id', 'date_of_joining', 'createddate', 'createdby', 'isactive');
            } else {
                $crud->add_fields('employeeId', 'prefix_id', 'firstname', 'lastname', 'modeofentry', 'emprole', 'email', 'department_id', 'reporting_manager', 'jobtitle_id', 'position_id', 'emp_status_id', 'date_of_joining', 'years_exp', 'password', 'createdby', 'createddate', 'isactive');
            }
            $crud->callback_column('employeeId', array($this, '_callback_empid'));
        } else {
            $crud->callback_field('user_name', array($this, '_fullnameby_adduser'));
        }

        $crud->callback_field('employeeId', array($this, '_callback_empid'));
        $crud->callback_field('position_id', array($this, '_callback_feild_pos_all'));


        $crud->callback_field('reporting_manager', array($this, '_callback_feild_repman'));
        $crud->callback_field('position_id', array($this, '_callback_feild_pos'));
        $crud->callback_field('employeeId', array($this, '_callback_empid'));
        $crud->callback_field('emp_status_id', array($this, '_callback_feild_empstatus'));


        $crud->callback_before_insert(array($this, '_callback_before_insert_user_data'));
        $crud->callback_after_insert(array($this, '_callback_after_insert_data'));

        $crud->callback_after_update(array($this, '_callback_before_update_user_data'));
//        $crud->callback_before_update(array($this, '_callback_before_update_user_data'));
        //$crud->callback_before_insert(array($this, '_callback_before_insert_user_data'));
        $crud->callback_column('isactive', array($this, 'showStatus'));

        $crud->edit_fields('user_name', 'employeeId', 'prefix_id', 'firstname', 'lastname', 'modeofentry', 'emprole', 'email', 'department_id', 'reporting_manager', 'jobtitle_id', 'position_id', 'emp_status_id', 'date_of_joining', 'date_of_leaving', 'years_exp', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $crud->set_rules('firstname', lang('firstname'), 'trim|required|min_length[2]|max_length[25]');
        $crud->set_rules('lastname', lang('lastname'), 'trim|required|min_length[2]|max_length[25]');
        $crud->set_rules('email', lang('email'), 'required|valid_email|max_length[50]');
        $crud->set_rules('years_exp', lang('years_exp'), 'required|integer|max_length[2]|min_length[1]');
        $crud->set_rules('modeofentry', lang('modeofentry'), 'required');
        $crud->set_rules('emprole', lang('emprole'), 'required');
        $crud->set_rules('prefix_id', lang('prefix_id'), 'required');
        $crud->set_rules('department_id', lang('department_id'), 'required');
        $crud->set_rules('reporting_manager', lang('reporting_manager'), 'required');
        $crud->set_rules('jobtitle_id', lang('jobtitle_id'), 'required');
        $crud->set_rules('position_id', lang('position_id'), 'required');
        $crud->set_rules('date_of_joining', lang('date_of_joining'), 'required');


        $crud->field_type('prefix_id', 'dropdown', array('1' => 'MR', '2' => 'MISS'));

        $crud->field_type('password', 'hidden');
        $crud->field_type('date_of_joining', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('date_of_leaving', 'date', date('Y-m-d H:i:s'));

        $crud->set_relation('modeofentry', 'main_employmentmode', 'mode');
        $crud->set_relation('emprole', 'main_roles', 'rolename');
        $crud->set_relation('department_id', 'main_departments', 'deptname');
//        $crud->set_relation('emp_status_id', 'main_', 'emp_status');
        $crud->set_relation('jobtitle_id', 'main_jobtitle', 'jobtitlename');

        $crud->unique_fields(lang('email'), 'email');

//        $crud->callback_field('reporting_manager', array($this, '_callback_feild_repman'));
//        $crud->callback_column('position_id',array($this,'add_field_callback_1'));


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_adduser($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_user_id($row);
        return $name;
    }

    function _callback_before_insert_user_data($post_array) {

//        echo '<pre>before_insert_user',  print_r($post_array);

        $this->load->library('encrypt');


        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);


        $this->load->library('encrypt');
        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        $post_array['password1'] = $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $post_array['password'] = $this->hash_password($password, $salt);

//        $post_array['username'] = $post_array['username'];
        $post_array['userfullname'] = $post_array['firstname'] . ' ' . $post_array['lastname'];
        $post_array['active'] = $post_array['isactive'];
        $post_array['empipaddress'] = $this->input->ip_address();
//        $post_array['createdat'] = ;
        return $post_array;
    }

    function _callback_before_update_user_data($post_array, $primary_key) {

//        echo '<pre>before_update_user',  print_r($post_array);
//        unset($post_array['date_of_joining']);

        if (isset($primary_key))
            $employeedata['user_id'] = $primary_key;

        if (isset($post_array['date_of_joining']))
            $employeedata['date_of_joining'] = $post_array['date_of_joining'];

        if (isset($post_array['date_of_leaving']))
            $employeedata['date_of_leaving'] = $post_array['date_of_leaving'];

        if (isset($post_array['emp_status_id']))
            $employeedata['emp_status_id'] = $post_array['emp_status_id'];

        if (isset($post_array['businessunit_id']))
            $employeedata['businessunit_id'] = $post_array['businessunit_id'];

        if (isset($post_array['department_id']))
            $employeedata['department_id'] = $post_array['department_id'];

        if (isset($post_array['jobtitle_id']))
            $employeedata['jobtitle_id'] = $post_array['jobtitle_id'];

        if (isset($post_array['position_id']))
            $employeedata['position_id'] = $post_array['position_id'];

        if (isset($post_array['years_exp']))
            $employeedata['years_exp'] = $post_array['years_exp'];

        if (isset($post_array['holiday_group']))
            $employeedata['holiday_group'] = $post_array['holiday_group'];

        if (isset($post_array['prefix_id']))
            $employeedata['prefix_id'] = $post_array['prefix_id'];


        if (isset($post_array['modifiedby']))
            $employeedata['modifiedby'] = $post_array['modifiedby'];


        if (isset($post_array['modifieddate']))
            $employeedata['modifieddate'] = $post_array['modifieddate'];

        //insert data into employees
        $this->employees->update($primary_key, $employeedata);
        $employeesummary = $post_array;
        unset($employeesummary['password']);
        unset($employeesummary['password1']);

        if (isset($post_array['firstname']))
            $employeesummary['firstname'] = $post_array['firstname'];

        if (isset($post_array['lastname']))
            $employeesummary['lastname'] = $post_array['lastname'];

        $employeesummary['userfullname'] = $post_array['firstname'] . ' ' . $post_array['lastname'];
        $employeesummary['isactive'] = $post_array['isactive'];
//        $employeesummary['empipaddress'] = $this->input->ip_address();

        if (isset($post_array['email'])) {
            $employeesummary['emailaddress'] = $post_array['email'];
            unset($employeesummary['email']);
        }

        if (isset($post_array['active'])) {
            $employeesummary['isactive'] = $post_array['active'];
            unset($employeesummary['active']);
        }

//        if (isset($primary_key))
//            $employeesummary['user_id'] = $primary_key;
//        unset($employeesummary['empipaddress']);
        if (isset($employeesummary['reporting_manager'])) {
            $manager_name = $this->employeesummary->get_reporting_manager_name_by_id($employeesummary['reporting_manager']);
            $employeesummary['reporting_manager_name'] = $manager_name;
        }
//        echo '<pre>postfinal array', print_r($employeesummary);
//        die;
        $res = $this->employeesummary->update($primary_key, $employeesummary);
        // var_dump($res);die;
//        echo '<pre>',  print_r($employeesummary);die;


        return $post_array;
    }

    function _callback_after_insert_data($post_array, $primary_key) {

//        echo '<pre>firstdata',  print_r($post_array);die;
        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);
        $this->load->library('encrypt');

        if (isset($primary_key))
            $employeedata['user_id'] = $primary_key;

        if (isset($post_array['date_of_joining']))
            $employeedata['date_of_joining'] = $post_array['date_of_joining'];

        if (isset($post_array['date_of_leaving']))
            $employeedata['date_of_leaving'] = $post_array['date_of_leaving'];

        if (isset($post_array['emp_status_id']))
            $employeedata['emp_status_id'] = $post_array['emp_status_id'];

        if (isset($post_array['businessunit_id']))
            $employeedata['businessunit_id'] = $post_array['businessunit_id'];

        if (isset($post_array['department_id']))
            $employeedata['department_id'] = $post_array['department_id'];

        if (isset($post_array['jobtitle_id']))
            $employeedata['jobtitle_id'] = $post_array['jobtitle_id'];

        if (isset($post_array['position_id']))
            $employeedata['position_id'] = $post_array['position_id'];

        if (isset($post_array['years_exp']))
            $employeedata['years_exp'] = $post_array['years_exp'];

        if (isset($post_array['holiday_group']))
            $employeedata['holiday_group'] = $post_array['holiday_group'];

        if (isset($post_array['prefix_id']))
            $employeedata['prefix_id'] = $post_array['prefix_id'];

        if (isset($post_array['createdby']))
            $employeedata['createdby'] = $post_array['createdby'];

        if (isset($post_array['modifiedby']))
            $employeedata['modifiedby'] = $post_array['modifiedby'];

        if (isset($post_array['createddate']))
            $employeedata['createddate'] = $post_array['createddate'];

        if (isset($post_array['modifieddate']))
            $employeedata['modifieddate'] = $post_array['modifieddate'];

        //unset($employeedata['firstname']);
        //unset($employeedata['lastname']);
        //var_dump($employeedata);die;

        $this->load->library('encrypt');


        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        $post_array['password1'] = $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $post_array['password'] = $this->hash_password($password, $salt);
//        echo '<pre>employeedata',  print_r($employeedata);die;

        $this->employees->insert($employeedata);


//        $employeesummary = $employeedata;
        $employeesummary = $post_array;
        unset($employeesummary['password']);
        unset($employeesummary['password1']);

//        $post_array['userfullname'] = $post_array['firstname'] . ' ' . $post_array['lastname'];
//        $post_array['active'] = $post_array['isactive'];
//        $post_array['empipaddress'] = $this->input->ip_address();

        if (isset($post_array['email'])) {
            $employeesummary['emailaddress'] = $post_array['email'];
            unset($employeesummary['email']);
        }

        if (isset($post_array['active'])) {
            $employeesummary['isactive'] = $post_array['active'];
            unset($employeesummary['active']);
        }

        if (isset($primary_key))
            $employeesummary['user_id'] = $primary_key;

        unset($employeesummary['empipaddress']);
        if (isset($employeesummary['reporting_manager'])) {
            $manager_name = $this->employeesummary->get_reporting_manager_name_by_id($employeesummary['reporting_manager']);
            $employeesummary['reporting_manager_name'] = $manager_name;
        }
//         echo '<pre>postfinal array',  print_r($employeesummary);die;
        $this->employeesummary->insert($employeesummary);
//        echo '<pre>',  print_r($employeesummary);die;
    }

    function fieldStatusmedium($value, $primary_key) {
        $this->db->select('id');
        $this->db->from('work');
        $this->db->where('medium_id', $primary_key);
        $query = $this->db->get();
        $res = $query->result_array();
        $st = '';
        if (empty($res)) {
            $st .= '<input type="hidden" name="status" id="field-status" value="' . $value . '" /><input type="checkbox" id="field-statust" name="statust" ' . ($value == 0 ? ' checked="checked" ' : '') . ' value="' . $value . '" />';
            $st .= '<script>$(document).ready(function(){$("#field-statust").change(function(){$(\'input[name="status"]\').val(($(this).is(":checked") ? "0" : "1"));});});</script>';
        } else {
            $st .= '<input type="hidden" name="status" id="field-status" value="' . $value . '" /><input type="checkbox" id="field-statust" name="statust" ' . ($value == 0 ? ' checked="checked" ' : '') . ' value="' . $value . '" disabled="disabled"/>';
        }
        return $st;
    }

    //password encryption
    function encrypt_password_callback($post_array) {

        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);


        $this->load->library('encrypt');
        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 8);
        $post_array['password1'] = $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $password = $this->hash_password($password, $salt);

        //$post_array['password'] = $this->encrypt->encode($password, $key);

        return $post_array;
    }

    function _callback_empid($value = null, $primary_key = null) {


        $this->load->model(array('employees'));
        $empid = $this->employees->get_employee_id();
        //echo '<pre>',  print_r($empid);die;
        if (isset($empid)) {
            $st = '<input type="text" name="employeeId" id="field-employeeId" value="MWX-' . $empid . '" />';
//                $st = $empid;
        } else {
            $st = 'MWX-001';
        }
        return $st;
    }

    function _callback_feild_pos($value = null, $primary_key = null) {
        $st = '<select name="position_id" id="field-position_id" class="chosen-select"></select>';
        $st .= '<script>$(document).ready(function(){var jobtitle_id = $(\'select[name="jobtitle_id"]\').val();
        $(\'#field_position_id_chosen\').hide();
        var position_id = ' . ($value == null ? '0' : $value) . ';
        $(\'select[name="jobtitle_id"]\').change(function(){
            $.ajax({
                url: \'/hr/getPosition\',
                data: {\'jobtitle_id\': $(this).val()},
                success: function(data) {
                    if(data) {
                    $(\'select[name="position_id"]\').show();
                   
                    
                        $(\'select[name="position_id"]\').html(data.content).trigger(\'liszt:updated\').val(position_id);
                        $(document).ready(function(){
                            $(\'select[name="position_id"]\').val(position_id);
                            //$(\'select[name="position_id"] option[value="\'+position_id+\'"]\').attr(\'selected\', \'selected\');
                            $(\'select[name="position_id"]\').trigger(\'liszt:updated\').val(position_id);
                        });
                    }
                }
            }); 
        });
        $(\'select[name="jobtitle_id"]\').val(jobtitle_id).trigger(\'change\');});</script>';

        return $st;
    }

    function _callback_feild_repman($value = null, $primary_key = null) {
        $st = '<select name="reporting_manager" id="field-reporting_manager" class="chosen-select"></select>';
        $st .= '<script>$(document).ready(function(){var department_id = $(\'select[name="department_id"]\').val();
        $(\'#field_reporting_manager_chosen\').hide();
        var reporting_manager = ' . ($value == null ? '0' : $value) . ';
        $(\'select[name="department_id"]\').change(function(){
            $.ajax({
                url: \'/hr/getReportingManager\',
                data: {\'department_id\': $(this).val()},
                success: function(data) {
                    if(data) {
                    $(\'select[name="reporting_manager"]\').show();
                    
                        $(\'select[name="reporting_manager"]\').html(data.content).trigger(\'liszt:updated\').val(reporting_manager);
                        $(document).ready(function(){
                            $(\'select[name="reporting_manager"]\').val(reporting_manager);
                            //$(\'select[name="reporting_manager"] option[value="\'+reporting_manager+\'"]\').attr(\'selected\', \'selected\');
                            $(\'select[name="reporting_manager"]\').trigger(\'liszt:updated\').val(reporting_manager);
                        });
                    }
                }
            }); 
        });
        $(\'select[name="department_id"]\').val(department_id).trigger(\'change\');});</script>';

        return $st;
    }

    function _callback_feild_prefix($value = null, $primary_key = null) {

        $st = '<select name="prefix_id" id="field-prefix_id" class="chosen-select"></select>';
        $st .= '<input type="hidden" name="prefix_id" id="field-prefix_id" value="1" />';
        $st .= '<script>$(document).ready(function(){
            $(\'#field_prefix_id_chosen\').hide();
            
       var prefix_id = ' . ($value == null ? '0' : $value) . ';
            $.ajax({
                url: \'/hr/getPrefix\',
                success: function(data) {
                    if(data) {
                    
                    $(\'select[name="prefix_id"]\').show();
                        $(\'select[name="prefix_id"]\').html(data.content).trigger(\'liszt:updated\').val(prefix_id);
                        $(document).ready(function(){
                            $(\'select[name="prefix_id"]\').val(prefix_id);
                            //$(\'select[name="prefix_id"] option[value="\'+prefix_id+\'"]\').attr(\'selected\', \'selected\');
                            $(\'select[name="prefix_id"]\').trigger(\'liszt:updated\').val(prefix_id);
                        });
                    }
                }
            }); 
       
        });</script>';

        return $st;
    }

    function _callback_feild_pos_all($value = null, $primary_key = null) {

        $st = '<select name="position_id" id="field-position_id" class="chosen-select"></select>';
        $st .= '<script>$(document).ready(function(){
            $(\'#field_position_id_chosen\').hide();
        
       var position_id = ' . ($value == null ? '0' : $value) . ';
            $.ajax({
                url: \'/hr/getPositionName\',
                success: function(data) {
                    if(data) {
                    
                    $(\'select[name="position_id"]\').show();
                        $(\'select[name="position_id"]\').html(data.content).trigger(\'liszt:updated\').val(position_id);
                        $(document).ready(function(){
                            $(\'select[name="position_id"]\').val(position_id);
                            //$(\'select[name="position_id"] option[value="\'+position_id+\'"]\').attr(\'selected\', \'selected\');
                            $(\'select[name="position_id"]\').trigger(\'liszt:updated\').val(position_id);
                        });
                    }
                }
            }); 
       
        });</script>';

        return $st;
    }

    function _callback_feild_empstatus($value = null, $primary_key = null) {

        $st = '<select name="emp_status_id" id="field-emp_status_id" class="chosen-select"></select>';
        $st .= '<script>$(document).ready(function(){
            $(\'#field_emp_status_id_chosen\').hide();
        
       var emp_status_id = ' . ($value == null ? '0' : $value) . ';
            $.ajax({
                url: \'/hr/getEmployementStatus\',
                success: function(data) {
                    if(data) {
                    
                    $(\'select[name="emp_status_id"]\').show();
                        $(\'select[name="emp_status_id"]\').html(data.content).trigger(\'liszt:updated\').val(emp_status_id);
                        $(document).ready(function(){
                            $(\'select[name="emp_status_id"]\').val(emp_status_id);
                            //$(\'select[name="emp_status_id"] option[value="\'+emp_status_id+\'"]\').attr(\'selected\', \'selected\');
                            $(\'select[name="emp_status_id"]\').trigger(\'liszt:updated\').val(emp_status_id);
                        });
                    }
                }
            }); 
       
        });</script>';

        return $st;
    }

    public function add_field_callback_1() {
        return '+30 <input type="password" maxlength="50" value="YOUR VALUE" name="phone" style="width:462px">';
    }

    public function document() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

//        var_dump('sss');die;

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_associatedocuments')
                ->display_as('user_id', lang('user_id'))
                ->display_as('name', lang('document_name'))
                ->display_as('isactive', lang('status'));



        $crud->set_subject('Associate Document');
        $crud->columns('user_id', 'name', 'attachments', 'isactive');

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('name', lang('document_name'), 'trim|required|min_length[2]|max_length[30]');

        $crud->add_fields('user_id', 'name', 'attachments', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_name', 'name', 'attachments', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            var_dump($crud);die;
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_dropdownfalse'));
//            $crud->unique_fields('user_id');
//            $crud->set_rules('user_id', 'main_users', 'callback_valid_password');
//            $crud->unique_fields('user_id');
        }
//        $crud->callback_field('user_name', array($this, '_dropdownfalse'));
        $crud->set_relation('user_id', 'main_users', '{firstname}  {lastname}');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        $output->title = lang('document');
        //if action is get, to add selected class
        $output->currentTab = 'document';
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
    }

    public function callback_valid_password($primary_key) {
        var_dump($primary_key);
        die;
        $name = $this->employees->get_name_by_id($primary_key);
        return $name;
    }

    //to get userfull name by document id
    public function _dropdownfalse($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_doc($row);
        return $name;
    }

    /* @description : to manage associate leaves */

    public function leaves() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_employeeleaves');

        $crud->set_subject('Associate Leaves');
        $crud->columns('user_id', 'emp_leave_limit', 'used_leaves', 'alloted_year', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('emp_leave_limit', lang('emp_leave_limit_add'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required|integer|min_length[1]|max_length[2]');
        $crud->set_rules('alloted_year', lang('alloted_year'), 'required|integer|min_length[4]|max_length[4]');
        //
        $crud->add_fields('user_id', 'emp_leave_limit', 'alloted_year', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_name', 'emp_leave_limit', 'alloted_year', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_leave'));
        }

        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
    }

    //get userfullname by leave id
    public function _fullnameby_leave($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_leave_id($row);
        return $name;
    }

    public function holidays() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empholidays');

        $crud->set_subject('Associate Holidays');
        $crud->columns('user_id', 'holiday_group_id', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('holiday_group_id', lang('holiday_group_id'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
//        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required');

        $crud->add_fields('user_id', 'holiday_group_id', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_name', 'holiday_group_id', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_leave'));
        }

        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('holiday_group_id', 'main_holidaygroups', 'groupname');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_holiday($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_holiday_id($row);
        return $name;
    }

    public function personal() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_emppersonaldetails');

        $crud->set_subject('Associate Personal Details');
        $crud->columns('user_id', 'genderid', 'maritalstatusid', 'nationalityid', 'languageid', 'dob', 'bloodgroup', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('genderid', lang('genderid'))
                ->display_as('maritalstatusid', lang('maritalstatusid'))
                ->display_as('nationalityid', lang('nationalityid'))
                ->display_as('languageid', lang('languageid'))
                ->display_as('dob', lang('dob'))
                ->display_as('bloodgroup', lang('bloodgroup'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('genderid', lang('genderid'), 'required');
        $crud->set_rules('maritalstatusid', lang('maritalstatusid'), 'required');
        $crud->set_rules('nationalityid', lang('nationalityid'), 'required');
        $crud->set_rules('languageid', lang('languageid'), 'required');
        $crud->set_rules('dob', lang('dob'), 'required');


//        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required');

        $crud->add_fields('user_id', 'genderid', 'maritalstatusid', 'nationalityid', 'languageid', 'dob', 'bloodgroup', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_id', 'genderid', 'maritalstatusid', 'nationalityid', 'languageid', 'dob', 'bloodgroup', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
//            $crud->callback_field('user_name', array($this, '_fullnameby_personal'));
        }


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('genderid', 'main_gender', 'gendername');
        $crud->set_relation('maritalstatusid', 'main_maritalstatus', 'maritalstatusname');
        $crud->set_relation('nationalityid', 'main_nationality', 'nationalitycode');
        $crud->set_relation('languageid', 'main_language', 'languagename');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_personal($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_personal_id($row);
        return $name;
    }

    public function contact() {
        
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empcommunicationdetails');

        $crud->set_subject('Associate Personal Details');
        $crud->columns('user_id', 'personalemail', 'perm_streetaddress', 'perm_country', 'perm_state', 'perm_city', 'perm_pincode', 'emergency_email', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('personalemail', lang('personalemail'))
                ->display_as('perm_streetaddress', lang('streetaddress'))
                ->display_as('perm_country', lang('country'))
                ->display_as('perm_state', lang('state'))
                ->display_as('perm_city', lang('city'))
                ->display_as('perm_pincode', lang('pincode'))
                ->display_as('emergency_email', lang('emergency_email'))
                ->display_as('isactive', lang('status'));

        /* Extras feilds */
//        'current_streetaddress' , 'current_country','current_state','current_city','current_pincode', 
//                'emergency_number','emergency_name',
//        ->display_as('current_country', lang('country'))
//                ->display_as('current_state', lang('state'))
//                ->display_as('current_city', lang('city'))
//                ->display_as('current_pincode', lang('pincode'))
//                ->display_as('emergency_number', lang('emergency_number'))
//                ->display_as('emergency_name', lang('emergency_name'))
//        ->display_as('current_streetaddress', lang('streetaddress'))                
//        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required');

        $crud->set_rules('personalemail', lang('email'), 'required|valid_email');
        $crud->set_rules('perm_streetaddress', lang('streetaddress'), 'required|max_length[100]');
        $crud->set_rules('perm_country', lang('country'), 'required');
        $crud->set_rules('perm_state', lang('state'), 'required');
        $crud->set_rules('perm_city', lang('city'), 'required');
        $crud->set_rules('perm_pincode', lang('pincode'), 'required|integer|max_length[6]');


        $crud->add_fields('user_id', 'personalemail', 'perm_streetaddress', 'perm_country', 'perm_state', 'perm_city', 'perm_pincode', 'current_streetaddress', 'current_country', 'current_state', 'current_city', 'current_pincode', 'emergency_number', 'emergency_name', 'emergency_email', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');



        $crud->edit_fields('user_name', 'personalemail', 'perm_country', 'perm_state', 'perm_city', 'perm_pincode', 'current_streetaddress', 'current_country', 'current_state', 'current_city', 'current_pincode', 'emergency_number', 'emergency_name', 'emergency_email', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();

        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_contact'));
        }


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('perm_country', 'main_country', 'countryname');
        $crud->set_relation('perm_state', 'main_state', 'statename');
        $crud->set_relation('perm_city', 'main_city', 'cityname');


        $crud->set_relation('current_country', 'main_country', 'countryname');
        $crud->set_relation('current_state', 'main_state', 'statename');
        $crud->set_relation('current_city', 'main_city', 'cityname');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


//        $crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_contact($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_contact_id($row);
        return $name;
    }

    public function skills() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empskills');

        $crud->set_subject('Associate Skills');
        $crud->columns('user_id', 'skillname', 'yearsofexp', 'competencylevelid', 'year_skill_last_used', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('skillname', lang('skill'))
                ->display_as('yearsofexp', lang('yearsofexp'))
                ->display_as('competencylevelid', lang('competencylevelid'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('skillname', lang('skill'), 'required|min_length[1]|max_length[25]');
        $crud->set_rules('yearsofexp', lang('yearsofexp'), 'required|integer|max_length[2]');
        $crud->set_rules('competencylevelid', lang('competencylevelid'), 'required');

        $crud->unique_fields(lang('skill'), 'skillname');

        $crud->add_fields('user_id', 'skillname', 'yearsofexp', 'competencylevelid', 'year_skill_last_used', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');



        $crud->edit_fields('user_name', 'skillname', 'yearsofexp', 'competencylevelid', 'year_skill_last_used', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_skill'));
        }


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        $data['menu_list'] = $this->getMenuList();

        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_skill($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_skill_id($row);
        return $name;
    }

    public function jobhistory() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empjobhistory');

        $crud->set_subject('Associate Job History');
        $crud->columns('user_id', 'positionheld', 'department', 'jobtitle', 'start_date', 'end_date', 'clientname', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('positionheld', lang('positionheld'))
                ->display_as('department', lang('department'))
                ->display_as('jobtitle', lang('jobtitle'))
                ->display_as('clientname', lang('clientname'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('positionheld', lang('positionheld'), 'required|max_length[25]');
        $crud->set_rules('department', lang('department'), 'required|max_length[25]');
        $crud->set_rules('jobtitle', lang('jobtitle'), 'required|max_length[25]');


        $crud->set_relation('positionheld', 'main_position', 'positioname');
        $crud->set_relation('department', 'main_departments', 'deptname');
        $crud->set_relation('jobtitle', 'main_jobtitle', 'jobtitlename');


        $crud->add_fields('user_id', 'positionheld', 'department', 'jobtitle', 'start_date', 'end_date', 'clientname', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');



        $crud->edit_fields('user_name', 'positionheld', 'department', 'jobtitle', 'start_date', 'end_date', 'clientname', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_jobhistory'));
        }


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        //$crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_jobhistory($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_jobhistory_id($row);
        return $name;
    }

    public function experience() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empexperiancedetails');

        $crud->set_subject('Associate Experience Details');
        $crud->columns('user_id', 'comp_name', 'comp_website', 'designation', 'from_date', 'to_date', 'reason_for_leaving', 'reference_name', 'reference_contact', 'reference_email', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('comp_name', lang('comp_name'))
                ->display_as('comp_website', lang('comp_website'))
                ->display_as('designation', lang('designation'))
                ->display_as('from_date', lang('from_date'))
                ->display_as('to_date', lang('to_date'))
                ->display_as('reason_for_leaving', lang('reason_for_leaving'))
                ->display_as('reference_name', lang('reference_name'))
                ->display_as('reference_contact', lang('reference_contact'))
                ->display_as('reference_email', lang('reference_email'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('comp_name', lang('comp_name'), 'required|max_length[25]');
        $crud->set_rules('comp_website', lang('comp_website'), 'max_length[50]');
        $crud->set_rules('designation', lang('designation'), 'required|max_length[20]');
        $crud->set_rules('reference_email', lang('reference_email'), 'valid_email|max_length[50]');
        $crud->set_rules('reference_contact', lang('reference_contact'), 'integer|max_length[15]');


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
//        $crud->set_relation('positionheld', 'main_position', 'positioname');
//        $crud->set_relation('department', 'main_departments', 'deptname');
//        $crud->set_relation('jobtitle', 'main_jobtitle', 'jobtitlename');


        $crud->add_fields('user_id', 'comp_name', 'comp_website', 'designation', 'from_date', 'to_date', 'reason_for_leaving', 'reference_name', 'reference_contact', 'reference_email', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');

        $crud->edit_fields('user_name', 'comp_name', 'comp_website', 'designation', 'from_date', 'to_date', 'reason_for_leaving', 'reference_name', 'reference_contact', 'reference_email', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_experience'));
        }

        $crud->field_type('from_date', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('to_date', 'date', date('Y-m-d H:i:s'));

        //$crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));


        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_experience($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_experience_id($row);
        return $name;
    }

    public function education() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empeducationdetails');

        $crud->set_subject('Associate Education Details');
        $crud->columns('user_id', 'educationlevel', 'institution_name', 'course', 'from_date', 'to_date', 'percentage', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('educationlevel', lang('educationlevel'))
                ->display_as('institution_name', lang('institution_name'))
                ->display_as('course', lang('course'))
                ->display_as('from_date', lang('from_date'))
                ->display_as('to_date', lang('to_date'))
                ->display_as('percentage', lang('percentage'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('institution_name', lang('comp_name'), 'required|max_length[25]');
        $crud->set_rules('course', lang('comp_website'), 'required|max_length[25]');
        $crud->set_rules('percentage', lang('percentage'), 'required|max_length[5]');
//        $crud->set_rules('reference_email', lang('reference_email'), 'valid_email|max_length[50]');
//        $crud->set_rules('percentage', lang('reference_contact'), 'integer');


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('educationlevel', 'main_education_level', 'educational_level');
//        $crud->set_relation('positionheld', 'main_position', 'positioname');
//        $crud->set_relation('department', 'main_departments', 'deptname');
//        $crud->set_relation('jobtitle', 'main_jobtitle', 'jobtitlename');


        $crud->add_fields('user_id', 'educationlevel', 'institution_name', 'course', 'from_date', 'to_date', 'percentage', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');


        $crud->edit_fields('user_name', 'educationlevel', 'institution_name', 'course', 'from_date', 'to_date', 'percentage', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_education'));
        }

        $crud->field_type('from_date', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('to_date', 'date', date('Y-m-d H:i:s'));

        //$crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_education($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_education_id($row);
        return $name;
    }

    public function certificate() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empcertificationdetails');

        $crud->set_subject('Associate Certification');
        $crud->columns('user_id', 'course_name', 'description', 'course_level', 'course_offered_by', 'certification_name', 'issued_date', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('course_name', lang('course_name'))
                ->display_as('description', lang('description'))
                ->display_as('course_level', lang('course_level'))
                ->display_as('course_offered_by', lang('course_offered_by'))
                ->display_as('certification_name', lang('certification_name'))
                ->display_as('issued_date', lang('issued_date'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('course_name', lang('course_name'), 'required|max_length[55]');
        $crud->set_rules('course_level', lang('course_level'), 'required|max_length[25]');
        $crud->set_rules('certification_name', lang('certification_name'), 'required|max_length[25]');

        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');


        $crud->add_fields('user_id', 'course_name', 'description', 'course_level', 'course_offered_by', 'certification_name', 'issued_date', 'isactive', 'createdby', 'createddate');

//        $crud->change_field_type('check', 'hidden');



        $crud->edit_fields('user_name', 'course_name', 'description', 'course_level', 'course_offered_by', 'certification_name', 'issued_date', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_certification'));
        }


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        //$crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_certification($primary_key, $row) {

//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_certification_id($row);
        return $name;
    }

    public function visa() {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empvisadetails');

        $crud->set_subject('Associate Visa Details');
        $crud->columns('user_id', 'passport_number', 'passport_expiry_date', 'visa_number', 'visa_expiry_date', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('passport_number', lang('passport_number'))
                ->display_as('passport_expiry_date', lang('passport_expiry_date'))
                ->display_as('visa_number', lang('visa_number'))
                ->display_as('visa_expiry_date', lang('visa_expiry_date'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('passport_number', lang('passport_number'), 'required|max_length[25]');
        $crud->set_rules('passport_issue_date', lang('passport_issue_date'), 'required');
        $crud->set_rules('passport_expiry_date', lang('passport_expiry_date'), 'required');
        $crud->set_rules('visa_number', lang('visa_number'), 'integer');
        $crud->set_rules('visa_type', lang('visa_type'), 'required|min_length[2]|max_length[15]');


        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');


        $crud->add_fields('user_id', 'passport_number', 'passport_issue_date', 'passport_expiry_date', 'visa_number', 'visa_type', 'visa_issue_date', 'visa_expiry_date', 'isactive', 'createdby', 'createddate');



        $crud->edit_fields('user_name', 'passport_number', 'passport_issue_date', 'passport_expiry_date', 'visa_number', 'visa_type', 'visa_issue_date', 'visa_expiry_date', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $crud->unique_fields(lang('user_id'), 'user_id');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
//            $crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_visa'));
        }

        $crud->field_type('passport_issue_date', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('passport_issue_date', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('visa_issue_date', 'date', date('Y-m-d H:i:s'));
        $crud->field_type('visa_expiry_date', 'date', date('Y-m-d H:i:s'));

        //$crud->set_relation('competencylevelid', 'main_competencylevel', 'competencylevel');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));


        //$crud->callback_field('current_country', array($this, '_callback_feildstate'));
//        $crud->set_field_upload('attachments', 'assets/uploads/files');
//        $crud->set_rules('personalemail', lang('emp_leave_limit'), 'required');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_wizard', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_visa($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_visa_id($row);
        return $name;
    }

    function _callback_feildstate($value, $row) {
////        var_dump($row);die;
//        $this->load->model('masters/state'); // your model
//        $data = $this->state->get_name_by_id('offices', 'officeCode, city', "state = '" . $this->session->userdata('state') . "'"); // iam using session here
//        $hasil = '<select name="officeCode">';
//        foreach ($data as $x) {
//            $hasil .='<option value="' . $x->officeCode . '">' . $x->city . '</option>';
//        }
//        return $hasil . '</select>';
    }

    function showStatus($value) {
        if ($value == 0)
            return "Inactive";
        else
            return "Active";
    }

    function edit_tags_field() {
        return "<div style='font-size:16px;font-family:Arial'>Permanent Address</div>";
    }

    function getRepMan() {
        $this->load->model(array('employees'));
        if (isset($_GET['department_id'])) {
            $deptid = $_GET['department_id'];
//        $country_id = $this->input->get('country_id');
            $department = $this->employees->get_repman_by_id($deptid);
        }
//        $st = '';
//        foreach ($states as $state) {
//            $st .= '<option value="' . $state->id . '">' . $state->name . '</option>';
//        }
//        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $department));
    }

    function getPosition() {
        $this->load->model(array('employees'));

        if (isset($_GET['jobtitle_id'])) {

            $jobtitle_id = $_GET['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
            $st = '';
            foreach ($jobtitle as $title) {
                $st .= '<option value="' . $title->position_id . '">' . $title->positioname . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getEmployeeId() {
        $this->load->model(array('employees'));
        $empid = $this->employees->get_employee_id();
        //echo '<pre>',  print_r($empid);die;
        if (isset($empid)) {
            $st = '<input type="text" name="employeeId" id="field-employeeId" value="MWX-' . $empid . '" />';
//                $st = $empid;
        } else {
            $st = 'MWX-001';
        }

//            $st .= '<input id="field-employeeId"' . $title->position_id . '">' . $title->positioname . '</option>';
//            $st = '';
//            $st .= '<option value="" class="">Select Position</option>';
//            foreach ($positionname as $title) {
//                $st .= '<option value="' . $title->position_id . '">' . $title->positioname . '</option>';
//            }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getPrefix() {
        $this->load->model(array('employees'));

        $prefix = $this->employees->get_prefix_name();
        $st = '';
//            $st .= '<option value=""  selected="selected">Select Position</option>';
        foreach ($prefix as $title) {
            $st .= '<option value="' . $title->prefix_id . '">' . $title->prefix . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getPositionName() {
        $this->load->model(array('employees'));

        $positionname = $this->employees->get_position_name();
        $st = '';
//            $st .= '<option value=""  selected="selected">Select Position</option>';
        foreach ($positionname as $title) {
            $st .= '<option value="' . $title->position_id . '">' . $title->positioname . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getEmployementStatus() {
        $this->load->model(array('employees'));

        $employmentstatus = $this->employees->get_employement_name();
        $st = '';
//            $st .= '<option value=""  selected="selected">Select Position</option>';
        foreach ($employmentstatus as $title) {
            $st .= '<option value="' . $title->emp_status_id . '">' . $title->emp_status . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getReportingManager() {
        $this->load->model(array('employees'));

        if (isset($_GET['department_id'])) {

            $department_id = $_GET['department_id'];
            $rep_manager = $this->employees->get_reporting_manager_by__id($department_id);
            $st = '';
            foreach ($rep_manager as $title) {
                $st .= '<option value="' . $title->reporting_manager . '">' . $title->firstname . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        }
    }

    public function hash_password($password, $salt = false, $use_sha1_override = FALSE) {
        if (empty($password)) {
            return FALSE;
        }

        // bcrypt
        if ($use_sha1_override === FALSE && $this->hash_method == 'bcrypt') {
            return $this->bcrypt->hash($password);
        }


        if ($this->store_salt && $salt) {
            return sha1($password . $salt);
        } else {
            $salt = $this->salt();
            return $salt . substr(sha1($salt . $password), 0, -$this->salt_length);
        }
    }

    public function salt() {

        $raw_salt_len = 16;

        $buffer = '';
        $buffer_valid = false;

        if (function_exists('mcrypt_create_iv') && !defined('PHALANGER')) {
            $buffer = mcrypt_create_iv($raw_salt_len, MCRYPT_DEV_URANDOM);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && function_exists('openssl_random_pseudo_bytes')) {
            $buffer = openssl_random_pseudo_bytes($raw_salt_len);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && @is_readable('/dev/urandom')) {
            $f = fopen('/dev/urandom', 'r');
            $read = strlen($buffer);
            while ($read < $raw_salt_len) {
                $buffer .= fread($f, $raw_salt_len - $read);
                $read = strlen($buffer);
            }
            fclose($f);
            if ($read >= $raw_salt_len) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid || strlen($buffer) < $raw_salt_len) {
            $bl = strlen($buffer);
            for ($i = 0; $i < $raw_salt_len; $i++) {
                if ($i < $bl) {
                    $buffer[$i] = $buffer[$i] ^ chr(mt_rand(0, 255));
                } else {
                    $buffer .= chr(mt_rand(0, 255));
                }
            }
        }

        $salt = $buffer;

        // encode string with the Base64 variant used by crypt
        $base64_digits = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        $bcrypt64_digits = './ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $base64_string = base64_encode($salt);
        $salt = strtr(rtrim($base64_string, '='), $base64_digits, $bcrypt64_digits);

        $salt = substr($salt, 0, $this->salt_length);

        return $salt;
    }

    public function getMenuList() {
        //variables
        $k = 1;
        $menuobj = new ArrayObject();
        $i = 1;

        /* start of get menu list */
        $this->data['users'] = $this->ion_auth->users()->result();

        $current_user_id = $this->ion_auth->get_user_id();
        foreach ($this->data['users'] as $user) {
            if ($user->id == $current_user_id)
                $user_role_id = $user->emprole;
        }

        $this->data['group_id'] = $this->menu->get_group_id_by_role($user_role_id);

        $this->data['menu'] = $this->menu->get_allmenu_by_group_id($this->data['group_id'][0]->group_id);
        $data['submenu'] = $this->menu->get_submenu_by_group_id($this->data['group_id'][0]->group_id);
//        $data['submenu'] = $this->menu->get_submenu_by_group_id1($this->data['group_id'][0]->group_id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($this->data['group_id'][0]->group_id);
//
//        for ($i = 0; $i < count($data['mainmenu']); $i++) {
//            foreach ($data['submenu'] as $sub) {
//
//                if ($data['mainmenu'][$i]->id == $sub->parent) {
//                    if ($k == 1) {
//                        $menuobj->append(array('menu',$data['mainmenu'][$i]->menuName,$data['mainmenu'][$i]->iconPath));
//                        $k++;
//                    }
//                    $menuobj->append(array('submenu',$sub->menuName,$sub->url));
//                }               
//            }
//            $k = 1;//restrict repetative menu
//        }
//        $menulist = (array)$menuobj;
        return $this->data;
        /* end of get menu list */
    }

}
