<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LeaveManagement
 *
 * @author admin
 */
class Manage extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'activitylog'));
        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('employees', 'menu'));
        $this->load->model(array('user_model'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('hr_lang');

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        elseif (!$this->ion_auth->in_group('hr')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $this->data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $this->data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($this->data) ? $this->data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        //        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();

//        echo 'in leave';
//        die;
    }

    public function leave_summary() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_leaverequest_summary');

        $crud->set_subject('Associate Leave Summary');
//        $crud->columns('user_id', 'emp_leave_limit', 'used_leaves', 'alloted_year', 'isactive')
//                ->display_as('user_id', lang('user_id'))
//                ->display_as('emp_leave_limit', lang('emp_leave_limit_add'))
//                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required|integer|min_length[1]|max_length[2]');
        $crud->set_rules('alloted_year', lang('alloted_year'), 'required|integer|min_length[4]|max_length[4]');
        //
        $crud->unset_add();
        $crud->unset_edit();
        //$crud->add_fields('user_id', 'emp_leave_limit', 'alloted_year', 'isactive', 'createdby', 'createddate');
        //$crud->edit_fields('user_name', 'emp_leave_limit', 'alloted_year', 'isactive', 'id', 'modifiedby', 'modifieddate');
//        unset();
        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_leave'));
        }

        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
    }

    public function leave() {

//        var_dump();die;


        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $crud = new grocery_CRUD();


        $crud->set_theme('flexigrid');
        $crud->set_table('main_employeeleaves');

        $crud->set_subject('Associate Leaves');
        $crud->columns('user_id', 'emp_leave_limit', 'used_leaves', 'alloted_year', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('emp_leave_limit', lang('emp_leave_limit_add'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required|integer|min_length[1]|max_length[2]');
        $crud->set_rules('alloted_year', lang('alloted_year'), 'required|integer|min_length[4]|max_length[4]');
        //
        $crud->add_fields('user_id', 'emp_leave_limit', 'alloted_year', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_name', 'emp_leave_limit', 'alloted_year', 'isactive', 'id', 'modifiedby', 'modifieddate');



        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_leave'));
        }



        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();

        /* Activity Log */
        $activity_log_data = array(
            'user_id' => $user_id,
            'userfullname' => $this->employeesummary->get_user_fullname($user_id),
            'request_path' => $_SERVER['REQUEST_URI'],
            'user_action' => $crud->getState(),
            'detail' => $crud->getState() . ' ' . __FUNCTION__,
            'activity_time ' => date('Y-m-d H:m:s'),
            'ip_address' => $this->input->ip_address(),
            'activity_by' => $user_id
        );
        $this->_activity_log($activity_log_data);

//        var_dump($activity_log_data);die;
        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
    }

    //get userfullname by leave id
    public function _fullnameby_leave($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_leave_id($row);
        return $name;
    }

    /* Start Holiday Management */

    public function holidaygroups() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $this->data['title'] = $this->lang->line('create_holidaygroups_title');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_holidaygroups')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Holiday Groups');
        $crud->set_table_title(lang('holidaygroups'));
        //To display on view(form)
        $crud->columns('groupname', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'groupname', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'groupname', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('groupname', lang('groupname'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('groupname');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        $output->title = lang('holidaygroups');
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function holidaydates() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $this->data['title'] = $this->lang->line('create_holidaydates_title');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_holidaydates')
                ->display_as('main_holidaydates.description', lang('description'))
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Holiday Dates');
        $crud->set_table_title(lang('holidaydates'));

        $crud->columns('holidayname', 'groupid', 'holidaydate', 'main_holidaydates.description', 'isactive');

        $crud->set_relation('groupid', 'main_holidaygroups', 'groupname');

        $crud->add_fields('createddate', 'holidayname', 'groupid', 'holidaydate', 'main_holidaydates.description', 'isactive', 'createdby');
        $crud->edit_fields('modifieddate', 'holidayname', 'groupid', 'holidaydate', 'main_holidaydates.description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('holidayname', lang('holidayname'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('holidayname');

        $crud->set_rules('holidaydate', lang('holidaydate'), 'trim|required|min_length[2]|max_length[50]', 'numeric');
        $crud->unique_fields('holidaydate');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $output = $crud->render();
        $data['title'] = lang('holidaydates');
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'gd', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function holidays() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_empholidays');

        $crud->set_subject('Associate Holidays');
        $crud->columns('user_id', 'holiday_group_id', 'isactive')
                ->display_as('user_id', lang('user_id'))
                ->display_as('holiday_group_id', lang('holiday_group_id'))
                ->display_as('isactive', lang('status'));

        $crud->set_rules('user_id', lang('user_id'), 'required');
//        $crud->set_rules('emp_leave_limit', lang('emp_leave_limit'), 'required');

        $crud->add_fields('user_id', 'holiday_group_id', 'isactive', 'createdby', 'createddate');
        $crud->edit_fields('user_name', 'holiday_group_id', 'isactive', 'id', 'modifiedby', 'modifieddate');

        $state_code = $crud->getState();
        if ($state_code == 'edit') {
            //$crud->field_type('user_id', 'readonly');
            $crud->callback_field('user_name', array($this, '_fullnameby_holiday'));
        }

        $crud->set_relation('user_id', 'main_users', '{firstname} {lastname}');
        $crud->set_relation('holiday_group_id', 'main_holidaygroups', 'groupname');

        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

//        $crud->set_field_upload('attachments', 'assets/uploads/files');

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);



        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo json_encode(array('content' => (isset($output) ? $output : NULL)));
            die;
        }
        //var_dump($data['output']); die;
        //$this->_example_output($output);
        $output = $crud->render();
        $output->title = lang('title_holiday');
        $this->template->write_view('header', 'snippets/header', NULL);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function _fullnameby_holiday($primary_key, $row) {
//        var_dump($row);die;
        $name = $this->employees->get_userfullname_by_holiday_id($row);
        return $name;
    }

    /* End Holiday Management */

    function showStatus($value) {
        if ($value == 0)
            return "Inactive";
        else
            return "Active";
    }

    /* Start Menu : Associate Configuration */

    public function employment() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        $this->data['title'] = $this->lang->line('title_employment');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_employment_status')
                ->display_as('isactive', lang('status'))
                ->display_as('emp_status', lang('employment_status'));
        $crud->set_subject('Employee Status');
        $crud->set_table_title(lang('employment Status'));
        //To display on view(form)
        $crud->columns('emp_status', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'emp_status', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'emp_status', 'isactive', 'description', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('emp_status', lang('Emp Status'), 'trim|required|min_length[2]|max_length[30]');
        $crud->unique_fields('emp_status');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');




        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

//        var_dump($this->data);die;

        $output = $crud->render();
        $output->title = lang('title_employment');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function jobtitle() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $this->data['title'] = $this->lang->line('title_jobtitle');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_jobtitle')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Job Title');
        $crud->set_table_title(lang('jobtitle'));

        $crud->columns('jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'isactive')
                ->display_as('jobtitlecode', lang('jobtitlecode'))
                ->display_as('jobtitlename', lang('jobtitlename'))
                ->display_as('jobdescription', lang('jobdescription'));

        $crud->add_fields('createddate', 'jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'comments', 'isactive', 'createdby');
        $crud->edit_fields('modifieddate', 'jobtitlecode', 'jobtitlename', 'jobdescription', 'minexprequired', 'comments', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('jobtitlecode', lang('jobtitlecode'), 'trim|required|min_length[2]|max_length[10]');
        $crud->unique_fields('jobtitlecode');

        $crud->set_rules('jobtitlename', lang('jobtitlename'), 'required|min_length[2]|max_length[30]');
        $crud->unique_fields('jobtitlename');

        $crud->set_rules('jobdescription', lang('jobdescription'), 'required|min_length[3]|max_length[500]');

        $crud->set_rules('minexprequired', 'minexprequired', 'integer', 'trim|integer|required|min_length[1]|max_length[5]');
        // $this->form_validation->set_rules('number', 'Number', 'callback_less_than_or_equal[9]');
        $crud->set_rules('comments', lang('comments'), 'required|min_length[3]|max_length[500]');
        // $crud->unique_fields('Comments');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        $output->title = lang('title_employment');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function position() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $this->data['title'] = $this->lang->line('title_position');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_position')
                ->display_as('positioname', lang('positioname'))
                ->display_as('jobtitle_id', lang('jobtitle_id'))
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Position');
        $crud->set_table_title(lang('Position'));
        //To display on view(form)
        $crud->columns('positioname', 'jobtitle_id', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'positioname', 'jobtitle_id', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'positioname', 'jobtitle_id', 'description', 'isactive', 'id', 'modifiedby');


        $crud->set_relation('jobtitle_id', 'main_jobtitle', 'jobtitlename');

        //Set Rules
        $crud->set_rules('positioname', lang('positioname'), 'trim|required|min_length[2]|max_length[25]', 'alpha');
        $crud->unique_fields('positioname');

        $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');

//          $crud->set_rules('jobtitle_id', lang('jobtitle_id'), 'trim|required|min_length[3]|max_length[225]');



        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        $output->title = lang('jobtitle');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function competency() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_competencylevel')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Competency Level');
        $crud->set_table_title(lang('Competency Level'));
        //To display on view(form)
        $crud->columns('competencylevel', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'competencylevel', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'competencylevel', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('competencylevel', lang('competencylevel'), 'trim|required|min_length[2]|max_length[25]', 'alpha');
        $crud->unique_fields('competencylevel');

        $crud->set_rules('description', lang('description'), 'min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        $output->title = lang('title_competency');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function education() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_education_level')
                ->display_as('educational_level', lang('educational_level'))
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Education Level');
        $crud->set_table_title(lang('Education Level'));
        //To display on view(form)
        $crud->columns('educational_level', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'educational_level', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'educational_level', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('educational_level', lang('educational_level'), 'trim|required|min_length[2]|max_length[25]', 'alpha');
        $crud->unique_fields('educational_level');

        $crud->set_rules('description', lang('description'), 'min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


        $output = $crud->render();
        $output->title = lang('title_education');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    public function language() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        $crud = new grocery_CRUD();

        $crud->set_theme('flexigrid');
        $crud->set_table('main_language')
                ->display_as('isactive', lang('status'));
        $crud->set_subject('Language');
        $crud->set_table_title(lang('language'));
        //To display on view(form)
        $crud->columns('languagename', 'description', 'isactive');

        //While adding / inserting reocrds
        $crud->add_fields('createddate', 'languagename', 'description', 'isactive', 'createdby');
        //While edit / existance record reocrds
        $crud->edit_fields('modifieddate', 'languagename', 'description', 'isactive', 'id', 'modifiedby');

        //Set Rules
        $crud->set_rules('languagename', lang('languagename'), 'trim|required|min_length[2]|max_length[50]', 'alpha');
        $crud->unique_fields('languagename');

        // $crud->set_rules('description', lang('description'), 'trim|required|min_length[3]|max_length[225]');


        $crud->change_field_type('id', 'hidden');
        $crud->change_field_type('createddate', 'hidden', date('Y-m-d H:i:s'));
        $crud->change_field_type('modifieddate', 'hidden', date('Y-m-d H:i:s'));
        // var_dump($this->session->userdata('user_id'));die;
        $crud->change_field_type('modifiedby', 'hidden', $this->session->userdata('user_id'));
        $crud->change_field_type('createdby', 'hidden', $this->session->userdata('user_id'));

        $crud->callback_column('isactive', array($this, 'showStatus'));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $output = $crud->render();
        $output->title = lang('title_language');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_default', (isset($output) ? $output : NULL));
        $this->template->render();
    }

    /* End Menu : Associate Configuration */

    //to get all menu list

    public function getMenuList() {
        //variables
        $k = 1;
        $menuobj = new ArrayObject();
        $i = 1;

        /* start of get menu list */
        $this->data['users'] = $this->ion_auth->users()->result();

        $current_user_id = $this->ion_auth->get_user_id();
        foreach ($this->data['users'] as $user) {
            if ($user->id == $current_user_id)
                $user_role_id = $user->emprole;
        }

        $this->data['group_id'] = $this->menu->get_group_id_by_role($user_role_id);

        $this->data['menu'] = $this->menu->get_allmenu_by_group_id($this->data['group_id'][0]->group_id);
        $this->data['submenu'] = $this->menu->get_submenu_by_group_id($this->data['group_id'][0]->group_id);
        $this->data['mainmenu'] = $this->menu->get_menuname_by_group_id($this->data['group_id'][0]->group_id);

        for ($i = 0; $i < count($this->data['mainmenu']); $i++) {
            foreach ($this->data['submenu'] as $sub) {

                if ($this->data['mainmenu'][$i]->id == $sub->parent) {
                    if ($k == 1) {
                        $menuobj->append(array('menu', $this->data['mainmenu'][$i]->menuName, $this->data['mainmenu'][$i]->iconPath));
                        $k++;
                    }
                    $menuobj->append(array('submenu', $sub->menuName, $sub->url));
                }
            }
            $k = 1; //restrict repetative menu
        }
        $menulist = (array) $menuobj;
        return (array) $menuobj;
        /* end of get menu list */
    }

    function _activity_log($log_data) {

        return $this->activitylog->insert($log_data);
    }

    public function get_current_user_data() {
        $user_id = $this->session->userdata('user_id');
//        var_dump($user_id);die;
        if (isset($user_id)) {
            $data['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $data['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $data['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        return $data;
    }

}
