<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class CronJob extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave'));
        $this->load->model(array('frontend/notification'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('city', 'country', 'state', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
    }

    public function index() {

        $associate_details = $this->employeesummary->get_all();
        $new_year = date('Y-m-d'); //'2018-01-01';
        $current_date = date('Y-01-01'); //'2018-01-01'; //

        $current_date = date('Y-m-d');
        $current_date = new DateTime($current_date);
        $this_year = date('Y-m-d', strtotime(date('Y-01-01')));
        $this_year = new DateTime($this_year);
//        var_dump($associate_details);
        foreach ($associate_details as $key => $asso) {
            if ($asso->user_id == '1')
                unset($associate_details[$key]);
            else {
                
                $leaves['alloted_leaves'] = 0;

                $date = date('Y-m-d', strtotime($asso->date_of_joining . "+ 6 months"));
                $date = new DateTime($date);

                if ($date > $this_year && $date < $current_date) {
                    $this_year = $current_date;
                    $monthCount = $current_date->diff($this_year);
                    $months = $monthCount->m;
                } else {
                    $this_year = $this_year;
                    $months = date('m');
                }


                if ($date < $this_year) {

                    /* notification entry */
                    $notificationDetails = array(
                        'user_id' => $asso->user_id,
                        'department_id' => $asso->department_id,
                        'is_common' => '1',
                        'userfullname' => $asso->userfullname,
                        'profileimg' => $asso->profileimg,
                        'notification' => '<span class="">' . $asso->userfullname . '</span>, One <span class="text-success">Privilege Leave</span> added.',
                        'notification_icon' => 'fa-calendar text-success',
                        'notification_date' => date('Y-m-d H:i:s'),
                        'url_path' => 'dashboard/leave_summary',
                    );
                    $this->notification->insert($notificationDetails);
                    /* notification entry */
//                $months = $monthCount->m;

                    $this->employeesleave->update_leave_priviledged($asso->user_id, 1, array('isactive' => '1', 'alloted_leaves' => $months > 0 ? $months - 1 : '0', 'modifieddate' => date('Y-m-d H:i:s')));
                }
            }

            /* Carry Forward Leave */
            if ($new_year == $current_date) {
                foreach ($associate_details as $asso) {

//                $leaves['alloted_leaves'] = 0;
                    $associate_leave = $this->employeesleave->get_by_id($asso->user_id);
                    foreach ($associate_leave as $asslv) {
//                    var_dump ($asslv);
                        if ($asslv['leavetype'] == 1) {

                            if ($asslv['used_leaves'] < $asslv['alloted_leaves']) {

                                $sum = (float) $asslv['alloted_leaves'] - (float) $asslv['used_leaves'];

                                $dataCarry = array(
                                    'carry_forward' => $sum
                                );
                                $dataPri = array(
                                    'alloted_leaves' => $asslv['alloted_leaves'] + $sum
                                );

                                $this->employeesleave->update_leave_carry_forward($asso->user_id, 1, $dataCarry);

                                $this->employeesleave->update_leave_priviledged($asso->user_id, $asslv['leavetype'], $dataPri);
                            }
                        }
                    }

                    /* notification entry */
                    $notificationDetails = array(
                        'user_id' => $asso->user_id,
                        'department_id' => $asso->department_id,
                        'is_common' => '1',
                        'userfullname' => $asso->userfullname,
                        'profileimg' => $asso->profileimg,
                        'notification' => '<span class="">' . $asso->userfullname . '</span>, <span class="text-success">Privilege Leave</span> Carry Forward.',
                        'notification_icon' => 'fa-calendar text-success',
                        'notification_date' => date('Y-m-d H:i:s'),
                        'url_path' => 'dashboard/leave_summary',
                    );
                    $this->notification->insert($notificationDetails);
                    /* notification entry */
//                $months = $monthCount->m;
                }
            }
            /* Carry Forward Leave */
            redirect("leave/allocation");
            return true;
        }
    }

}
