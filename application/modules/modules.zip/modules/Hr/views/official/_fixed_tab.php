<div class="content-body" style="height: 500px !important;">
    <div class="row">
            <table class="table">
                <thead>
                    <!--hr/employee/addofficial/-->
                        <?php // echo $c_emp_summary->user_id ?>
                    <tr><th scope="row" ><a href="<?php echo base_url(); ?>hr/employee/addofficial" disabled="disabled">Official</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/contactinfo/">Personal / Contact</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/document/">Document</a></th>

<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/holidays">Holiday</a></th>-->
<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/leaves">Leaves</a></th>-->

                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/skills/">Skills</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/jobhistory/">Job History</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/experience/">Experience</a>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/education/">Education</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/certificate/">Certificate</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/visa/">Visa</a></th></tr>
                </thead>
            </table>
    </div>
