<div class="content-body" style="height: 500px !important;">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <!--hr/employee/addofficial/-->
                        <?php // echo $c_emp_summary->user_id ?>
                    <tr><th scope="row" ><a href="<?php echo base_url(); ?>" disabled="disabled">Official</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/contactinfo/<?php echo $c_emp_summary->user_id ?>">Personal / Contact</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/document/<?php echo $c_emp_summary->user_id ?>">Document</a></th>

<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/holidays">Holiday</a></th>-->
<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/leaves">Leaves</a></th>-->

                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/skills/<?php echo $c_emp_summary->user_id ?>">Skills</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/jobhistory/<?php echo $c_emp_summary->user_id ?>">Job History</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/experience/<?php echo $c_emp_summary->user_id ?>">Experience</a>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/education/<?php echo $c_emp_summary->user_id ?>">Education</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/certificate/<?php echo $c_emp_summary->user_id ?>">Certificate</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>hr/employee/visa/<?php echo $c_emp_summary->user_id ?>">Visa</a></th></tr>
                </thead>
            </table>
        </div>
    </div>
