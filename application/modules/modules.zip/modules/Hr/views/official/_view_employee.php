<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>

<?php ?>


<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">
    <?php  $this->load->view('official/_fixed_tab_single');?>
        
        <div class="row">
            
            <a href="<?php echo base_url();?>hr/employee/edit/<?php echo $c_emp_summary->user_id ?>" class=" pull-right"><i class="fa fa-pencil-square-o"></i></a>
        </div>
        <div class="row">
            

            <div class="col-md-3 col-sm-4 col-xs-12">
                <div class="uprofile-image">
                    <img src="<?php
                    if (isset($c_emp_summary->profileimg))
                        echo base_url() . $c_emp_summary->profileimg;
                    else
                        echo base_url() . "data/profile/user1.png"
                        ?>" class="img-circle img-responsive ">

                </div>
                <div class="text-center">
                    <?php echo $c_emp_summary->employeeId; ?>
                </div>

                <div class="uprofile-name">
                    <h3>
                        <a href="#"><?php echo $c_emp_summary->userfullname; ?></a>
                        <!-- Available statuses: online, idle, busy, away and offline -->
                        <span class="uprofile-status online"></span>
                    </h3>
                    <p class="uprofile-title"> <?php echo $c_emp_summary->jobtitle_name; ?></p>
                </div>
                <div class="uprofile-info">
                    <ul class="list-unstyled">
                        <?php if (isset($c_emp_communication)) { ?>
                            <li><i class="fa fa-home"></i> <?php echo $c_emp_communication->current_streetaddress; ?>, <?php echo $contry; ?>, <?php echo $city; ?></li>
                        <?php } else { ?>
                            <li><i class="fa fa-home"></i> -- </li>
                        <?php } ?>
                        <li><i class="fa fa-user"></i> <?php echo substr($c_emp_summary->emailaddress, 0, 15) . '..'; ?></li>
                        <li><i class="fa fa-suitcase"></i>  <?php echo $c_emp_summary->position_name; ?>, <?php echo $c_emp_summary->department_name; ?> </li>
                    </ul>
                </div>
                <!--                <div class="uprofile-buttons">
                                    <a class="btn btn-md btn-primary">Send Message</a>
                                    <a class="btn btn-md btn-primary">Add as Friend</a>
                                </div>-->

            </div>


            <div class="col-md-6">

            </div>


            <div class="col-sm-3 col-sm-6">

                <div class="information_inner ">
                    <div class="info blue_symbols"></div>

                    <div class="text-center">
                        <span>LEAVE SUMMARY</span>
                        <?php if (isset($leaves) && $leaves != NULL) { ?>
                            <h1 class="bolded"><?php echo $leaves[0]['used_leaves']; ?> / <?php echo $leaves[0]['emp_leave_limit']; ?></h1>
                            <b class=""><small>Pending for approval  <span class="label label-danger "> 1</span> </small></b>
                        <?php } else { ?>
                            <div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert">
                                Not assign!
                            </div>
                        <?php } ?>
                    </div>

                </div>

                <div class="information_inner m-t-lg">
                    <div class="info blue_symbolsex "></div>
                    <div class="text-center">
                        <span >HOLIDAY LIST</span>
                    </div>
                    <?php if (isset($holiday) && $holiday != NULL) { ?>
                        <div class="wid-weather-small weekdays bg-white">
                            <div class="weekdays bg-white">
                                <ul class="list-unstyled ps-container">
                                    <?php foreach ($holiday as $list) { ?>
                                        <li><span class="day"><?php echo $list->holidaydate; ?></span><span class="temp"><?php echo $list->holidayname; ?></span></li>
                                    <?php } ?>
                                    <div class="ps-scrollbar-x-rail" ><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div></ul>
                            </div>
                        </div>
                    <?php } else { ?>
                        <div class="alert alert-default alert-dismissible fade in text-center" style="border-radius:5px;" role="alert">
                            Not assign!
                        </div>
                    <?php } ?>

                </div>
            </div>

        </div>
    </div>
</div>
<?php ?>

<script>
    $.ajax({
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->