<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">

</div>

<div class="container">
    <!--Start Fixed Tabs-->
    <?php $this->load->view('_fixed_tab'); ?>
    <!--End Fixed Tabs-->
    <div class="row">

        <div class="col-md-6">
            <!--Start Personal Details-->
                
                <?php if (isset($personal_detail)) { ?>
                    <form>

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('gender'), 'gender', array('class' => 'form-label')); ?>:
                            <?php echo form_dropdown('gender', $personal_detail->genderid, $personal_detail->genderid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                        </div>                                      

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('marital_status'), 'marital_status', array('class' => 'form-label')); ?>:
                            <?php echo form_dropdown('marital_status', $personal_detail->genderid, $personal_detail->genderid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>                                                             
                        </div>

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('nationality'), 'nationality', array('class' => 'form-label')); ?>:
                            <?php echo form_dropdown('nationality', $personal_detail->nationalityid, $personal_detail->nationalityid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                        </div>


                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('language'), 'language', array('class' => 'form-label')); ?>:
                            <?php
                            echo form_input(array(
                                'name' => 'language',
                                'id' => 'language',
                                'class' => 'form-control',
                                'placeholder' => $personal_detail->languageid,
                                'disabled' => 'disabled'
                            ));
                            ?>
                        </div>

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('dob'), 'dob', array('class' => 'form-label')); ?>:
                            <label class="form-label">Date of Birth</label>
                            <div class="input-group date">
                                <?php
                                echo form_input(array(
                                    'name' => 'dob',
                                    'id' => 'dob',
                                    'class' => 'form-control',
                                    'placeholder' => $personal_detail->dob,
                                    'disabled' => 'disabled'
                                ));
                                ?>
                                <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                            </div>
                        </div>

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('bloodgroup'), 'bloodgroup', array('class' => 'form-label')); ?>:
                            <?php echo form_dropdown('bloodgroup', $personal_detail->bloodgroup, $personal_detail->bloodgroup, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                        </div>

                    </form>
                <?php } else { ?>
                    <p>No Data found!</p>
                <?php } ?>
            <!--End Personal Details-->
            
        </div>
    </div>
</div>


<?php ?>




<script>
    $.ajax({
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->