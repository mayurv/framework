<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/plugins/smartwizard/smart_wizard_vertical.css" rel="stylesheet" type="text/css">
<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>

<!--icon-->
<link href="<?php echo base_url(); ?>assets/css/ionicons.css" rel="stylesheet" type="text/css" media="screen" />
<!--end icon-->
<?php // var_dump($css_files);die;?>
<?php foreach ($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach ($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<?php // var_dump($selected)?>
<!-- SmartWizard start here -->


<div id="wizard" class="swMain">
    <ul>
        <li><a href="#step-1" class="<?php
            if (isset($title)) {
                if ($title == 'official')
                    echo 'selected';
            }
            ?>">
                <span class="">
                    Official Information
                </span>
            </a></li>
        <li><a href="#step-2" >
                <span class="">
                    Documents
                </span>
            </a>
        </li>
        <li><a href="#step-3" >
                <span class="">
                    Leaves
                </span>
            </a>
        </li>
        <li><a href="#step-4" >
                <span class="">
                    Holiday
                </span>
            </a>
        </li>
        <li><a href="#step-5">
                <span class="">
                    Personal Information
                </span>                   
            </a></li>
        <li><a href="#step-6">
                <span class="">
                    Contact Information
                </span>                   
            </a></li>
        <li><a href="#step-7">
                <span class="">
                    Skills
                </span>                   
            </a></li>
        <li><a href="#step-8">
                <span class="">
                    Job History
                </span>                   
            </a></li>
        <li><a href="#step-9">
                <span class="">
                    Experience
                </span>                   
            </a></li>
        <li><a href="#step-10">
                <span class="">
                    Education
                </span>                   
            </a></li>
        <li><a href="#step-11">
                <span class="">Certificate
                </span>                   
            </a>
        </li>
        <li><a href="#step-12">
                <span class="">
                    Visa
                </span>                   
            </a></li>


    </ul>

    <div id="step-1">
        <?php if (isset($output)) echo $output; ?>   			
    </div>
    <div id="step-2">

    </div>                      
    <div id="step-3">
        <!--<h2 class="StepTitle">Step 3 Content</h2>-->	

    </div>
    <div id="step-4">

    </div>

    <div id="step-5">
        <h2 class="StepTitle">Step 1 Content</h2>


    </div>
    <div id="step-6">
        <h2 class="StepTitle">Step 6 Content</h2>


    </div>

    <div id="step-7">   
        <h2 class="StepTitle">Step 7 Content</h2>


    </div>

    <div id="step-8">   
        <h2 class="StepTitle">Step 8 Content</h2>


    </div>

    <div id="step-9">   
        <h2 class="StepTitle">Step 9 Content</h2>


    </div>

    <div id="step-10">   
        <h2 class="StepTitle">Step 10 Content</h2>


    </div>
    <div id="step-11">   
        <h2 class="StepTitle">Step 11 Content</h2>


    </div>
    <div id="step-12">   
        <h2 class="StepTitle">Step 12 Content</h2>


    </div>

</div>

<!--wizard javascript start here -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/smartwizard/jquery.smartWizard-2.0.js"></script>
<!-- icons js file -->
<script src="<?php echo base_url(); ?>assets/plugins/viewport/viewportchecker.js" type="text/javascript"></script>   
<!-- icons js file -->
<script type="text/javascript">

    $(window).load(function () {

        var url = window.location.href;

        $("div").remove(".actionBar");  //to remove action button

        if (url.split("/")[4]) {
            tabNameUrl = url.split("/")[4];

            if (tabNameUrl == "adduser")
                tabIdUrl = "step-1";
            if (tabNameUrl == "document")
                tabIdUrl = "step-2";
            if (tabNameUrl == "leaves")
                tabIdUrl = "step-3";
            if (tabNameUrl == "holidays")
                tabIdUrl = "step-4";
            if (tabNameUrl == "personal")
                tabIdUrl = "step-5";
            if (tabNameUrl == "contact")
                tabIdUrl = "step-6";
            if (tabNameUrl == "skills")
                tabIdUrl = "step-7";
            if (tabNameUrl == "jobhistory")
                tabIdUrl = "step-8";
            if (tabNameUrl == "experience")
                tabIdUrl = "step-9";
            if (tabNameUrl == "education")
                tabIdUrl = "step-10";
            if (tabNameUrl == "certificate")
                tabIdUrl = "step-11";
            if (tabNameUrl == "visa")
                tabIdUrl = "step-12";

            $('ul.anchor li a').attr("isDone", 1);
            $('ul.anchor li a').removeClass('disabled').addClass('done');

            $("a[href$='" + tabIdUrl + "']").removeClass('done');
            $("a[href$='" + tabIdUrl + "']").addClass('selected');
            //$("a[href$='"+tabIdUrl+"']").addClass('selected');

        }
        else {
            $('ul.anchor li a').removeClass('disabled').addClass('done');
            $('ul.anchor li a').attr("isDone", 1);
            $("a[href$='step-1']").removeClass('done');
            $("a[href$='step-1']").addClass('selected');
        }
    });

    $(document).ready(function () {
        var url = window.location.href;

        if (url.indexOf("success") > -1) {
        }

        $('#wizard').smartWizard({transitionEffect: 'slide'});

        $(".buttonNext").click(function () {
            $('ul.anchor li a').removeClass('disabled').addClass('done');
            $('ul.anchor li a').attr("isDone", 1);
        });
        /*start second*/

        $('.anchor a').click(function () {

            $("ul.anchor li a.selected").addClass('done');
            var currHref = $("ul.anchor li a.selected").attr('href');
            var tabHref = $(this).attr('href');
            var tabId = tabHref.substring(1);


            $('.stepContainer div').hide();
            $('.stepContainer div').html("<h2 style='text-align: center; margin-top:15%'>Please wait while data is loading..!</h2><div id='idloadIcon' style='text-align: center; margin-top:1%'><i class='fa ion-loading-a icon-sm icon-rounded icon-primary inviewport animated animated-delay-600ms' data-vp-add-class='visible rollIn'></i></div>");

            if (tabId == 'step-1')
                getByTab('adduser', tabId);

            if (tabId == 'step-2')
                getByTab('document', tabId);

            if (tabId == 'step-3')
                getByTab('leaves', tabId);

            if (tabId == 'step-4')
                getByTab('holidays', tabId);

            if (tabId == 'step-5')
                getByTab('personal', tabId);

            if (tabId == 'step-6')
                getByTab('contact', tabId);

            if (tabId == 'step-7')
                getByTab('skills', tabId);

            if (tabId == 'step-8')
                getByTab('jobhistory', tabId);

            if (tabId == 'step-9')
                getByTab('experience', tabId);

            if (tabId == 'step-10')
                getByTab('education', tabId);

            if (tabId == 'step-11')
                getByTab('certificate', tabId);

            if (tabId == 'step-12')
                getByTab('visa', tabId);

        });
        /*end second*/
    });

    //function to call tabName to controller function
    function getByTab(tabName, tabId) {
        $.ajax({
            type: 'POST',
            url: '/hr/' + tabName,
            dataType: 'json',
            success: function (response) {
//                alert(response.content);
                $('#idloadIcon').hide();

                $('#' + tabId).show();
                //                        $('#step-1').html('<i class="fa ion-looping icon-sm icon-rounded icon-primary inviewport animated animated-delay-600ms visible rollIn" data-vp-add-class="visible rollIn"></i>')
                $('ul.anchor li a').removeClass('disabled');
                $('ul.anchor li a').removeClass('selected');
                $("a[href$='" + tabId + "']").addClass('selected');


                $('#' + tabId).show();
                $('#' + tabId).html(response.content.output);
                //location.replace("/hr/adduser");
                // window.location.assign("/hr/adduser");
            }
        });
    }
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->