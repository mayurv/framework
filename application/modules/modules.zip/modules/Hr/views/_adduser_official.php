<head>
    <?php foreach ($css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
    <?php endforeach; ?>
    <?php foreach ($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>

<!--wizard css-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/wizard/jquery.steps.css" />
<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
</head>
<section id="main-content" class=" sidebar_shift ">
    <section class="wrapper">
        <!-- containt page row start here -->
        <div class="row">



            <!-- second row start here -->
            <div class="row">
                <div class="col-sm-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Add User</h2>

                        </header>
                        
                        <div class="content-body">    <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">

                                    <div id="wizard">
                                        <h2 class="test">Official Information</h2>
                                        <section>
                                            <form action="javascript:;" novalidate>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Employee ID</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="controls">
                                                        <input type="text" class="form-control" required>
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Prefix</label>
                                                    <select class="form-control input-sm m-bot15 ">
                                                        <option>Mr</option>
                                                        <option>Ms</option>
                                                        <option>Mrs</option>                                            
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">First Name</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="controls">
                                                        <input type="text" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Last Name</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="controls">
                                                        <input type="text" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Mode of Employment</label>
                                                    <span class="desc desc-red">*</span>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Direct</option>
                                                        <option>Contract</option>                                           
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Role</label>
                                                    <span class="desc desc-red">*</span>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Employee</option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Email</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="controls">
                                                        <input type="text" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Department</label>
                                                    <span class="desc desc-red">*</span>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>IT</option>
                                                        <option>Design</option>
                                                        <option>Hardware</option>
                                                        <option>HR</option>
                                                        <option>Marketing</option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Reporting Manager</label>
                                                    <span class="desc desc-red">*</span>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Team Leader</option>
                                                        <option>HR Manager</option>
                                                        <option>IT Head</option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Job Title</label>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Developer</option>
                                                        <option>Designer</option>
                                                        <option>DBA</option>
                                                        <option></option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Position</label>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Manager</option>
                                                        <option>HR</option>
                                                        <option>IT Head</option>
                                                        <option>Project Manager</option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Employment Status</label>
                                                    <span class="desc desc-red">*</span>
                                                    <select class="form-control input-sm m-bot15">
                                                        <option>Full Time</option>
                                                        <option>Part Time</option>
                                                        <option>Contract</option>
                                                    </select>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Date of Joining</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="input-group date">
                                                        <input type="text" class="form-control datepicker" data-format="D, dd MM yyyy" value="Mon, 02 February 2015">
                                                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Experience</label>
                                                    <span class="desc desc-red">*</span>
                                                    <div class="controls">
                                                        <input type="text" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group col-sm-4">
                                                    <label class="form-label" for="field-1">Work Telephone Number</label>
                                                    <div class="controls">
                                                        <input type="text" class="form-control">
                                                    </div>
                                                </div>                                        

                                            </form>

                                        </section>

                                        <h2>Documents</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>

                                        <h2>Personal Information</h2>
                                        <section>
                                            <p>Morbi ornare tellus at elit ultrices id dignissim lorem elementum. Sed eget nisl at justo condimentum dapibus. Fusce eros justo, 
                                                pellentesque non euismod ac, rutrum sed quam. Ut non mi tortor. Vestibulum eleifend varius ullamcorper. Aliquam erat volutpat. 
                                                Donec diam massa, porta vel dictum sit amet, iaculis ac massa. Sed elementum dui commodo lectus sollicitudin in auctor mauris 
                                                venenatis.</p>
                                        </section>

                                        <h2>Contact Information</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section> 

                                        <h2>Skills</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>

                                        <h2>Job History</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>  

                                        <h2>Experience</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>   

                                        <h2>Education</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>   

                                        <h2>Visa</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>

                                        <h2>Holiday</h2>
                                        <section>
                                            <p>Quisque at sem turpis, id sagittis diam. Suspendisse malesuada eros posuere mauris vehicula vulputate. Aliquam sed sem tortor. 
                                                Quisque sed felis ut mauris feugiat iaculis nec ac lectus. Sed consequat vestibulum purus, imperdiet varius est pellentesque vitae. 
                                                Suspendisse consequat cursus eros, vitae tempus enim euismod non. Nullam ut commodo tortor.</p>
                                        </section>      

                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>                          
                </div>
            </div>
            <!-- second row start here -->








        </div>
        <!--column 8 left center part end here -->



        </div>
        <!-- containt page row end here -->
    </section>
</section>


<script src="<?php echo base_url(); ?>assets/plugins/datepicker/js/datepicker.js" type="text/javascript"></script> 

<!--wizard script -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/wizard/jquery.steps.js"></script>
<script>
//    alert('ss');
    $("#next-step").click(function () {
        alert($(this).val());
    });
    $(function ()
    {
        $("#wizard").steps({
            headerTag: "h2",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            stepsOrientation: "vertical"
        });
    });
</script>
<!--wizard script -->

<script>
 
        alert( 'aaa');
//  $('.current').click(function() {
//    alert($(this).val());
//   
//});

//////    $( "li.item-a" ).closest( "ul" )
//
</script>