<head>
    <?php foreach ($css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
    <?php endforeach; ?>
    <?php foreach ($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>

<!--wizard css-->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/wizard/jquery.steps.css" />
<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
</head>
<section id="main-content" class=" sidebar_shift ">
    <section class="wrapper">
        <!-- containt page row start here -->
        <div class="row">



            <!-- second row start here -->
            <div class="row">
                <div class="col-sm-12">
                    <section class="box ">
                        <header class="panel_header">
                            <h2 class="title pull-left">Add User</h2>

                        </header>
                        
                        <div class="content-body">    <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">

                                    <div id="wizard">
                                        <h2>Official Information</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>

                                        <h2>Documents</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>

                                        <h2>Personal Information</h2>
                                        <section>
                                           <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div> 
                                        </section>

                                        <h2>Contact Information</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section> 

                                        <h2>Skills</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>

                                        <h2>Job History</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>  

                                        <h2>Experience</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>   

                                        <h2>Education</h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                            </div>
                                        </section>   

                                        <h2>Visa</h2>
                                        <section>
                                            <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                        </section>

                                        <h2>Holiday</h2>
                                        <section>
                                            <div class="col-sm-12">
                                                    <?php if (isset($output)) echo $output; ?>
                                                    <!--<div class="no-record">No data found</div>-->
                                                </div>
                                        </section>      

                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>                          
                </div>
            </div>
            <!-- second row start here -->








        </div>
        <!--column 8 left center part end here -->



        </div>
        <!-- containt page row end here -->
    </section>
</section>


<script src="<?php echo base_url(); ?>assets/plugins/datepicker/js/datepicker.js" type="text/javascript"></script> 

<!--wizard script -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/wizard/jquery.steps.js"></script>
<script>

    $(function ()
    {
//        alert($("#wizard .steps .first  a").val());
        $("#wizard").steps({
            headerTag: "h2",
            bodyTag: "section",
            transitionEffect: "slideLeft",
            stepsOrientation: "vertical"
        });
    });
    
</script>
<!--wizard script -->

