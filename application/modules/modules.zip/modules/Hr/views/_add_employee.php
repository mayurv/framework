<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<div class="">
    <input type="text" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">
    <div class="content-body">
        <div class="row">


            <div class="col-md-12">
                <?php form_open('hr/employee/addofficial'); ?>
                <form acion="hr/employee/addofficial" method="post"> 



                <div class="form-group col-sm-6">

                    <?php echo form_label(lang('employeeid'), 'employeeid', array('class' => 'form-label')); ?>
                    <br>
                    <div class="controls">
                        <?php
                        echo form_input(array(
                            'name' => 'employeeid',
                            'id' => 'employeeid',
                            'class' => 'form-control',
                            'placeholder' => 'MWX' . $empId,
                            'value' => 'MWX-' . $empId,
//                        
                        ));
                        ?>
                    </div>
                    <br>

                    <?php echo form_label(lang('prefix_id'), 'prefix_id', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();

                    foreach ($prefix as $category)
                        $options[$category['id']] = $category['prefix'];
                    echo form_dropdown(array('id' => 'prefix_id', 'name' => 'prefix_id'), $options);
                    ?>
                    <br>
                    <?php echo form_label(lang('firstname'), 'firstname', array('class' => 'form-label')); ?>:
                    <?php
                    echo form_input(array(
                        'type' => 'text',
                        'name' => 'firstname',
                        'class' => 'form-control'
                    ));
                    ?>
                    <br>
                    <?php echo form_label(lang('lastname'), 'lastname', array('class' => 'form-label')); ?>:
                    <?php
                    echo form_input(array(
                        'type' => 'text',
                        'name' => 'lastname',
                        'class' => 'form-control'
                    ));
                    ?>

                    <?php echo form_label(lang('modeofemp'), 'modeofemp', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();
                    foreach ($empmode as $category)
                        $options[$category['id']] = $category['mode'];
                    echo form_dropdown(array('id' => 'modeofemp_id', 'name' => 'modeofemp_id'), $options);
                    ?>
                    <br>


                    <?php echo form_label(lang('emprole'), 'emprole', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();
                    foreach ($emprole as $category)
                        $options[$category['id']] = $category['rolename'];

                    echo form_dropdown(array('id' => 'emprole_id', 'name' => 'emprole_id'), $options);
                    ?>
                    <br>



                    <?php echo form_label(lang('email'), 'email', array('class' => 'form-label')); ?>:
                    <?php
                    echo form_input(array(
                        'type' => 'text',
                        'name' => 'email',
                        'class' => 'form-control'
                    ));
                    ?>
                    <br>

                    <?php echo form_label(lang('department_id'), 'department_id', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();
                    foreach ($department as $category)
                        $options[$category['id']] = $category['deptname'];

                    echo form_dropdown(array('id' => 'department_id', 'name' => 'department_id'), $options);
                    ?>
                    <br>

                    <?php echo form_label(lang('reportind_manager'), 'reportind_manager', array('class' => 'form-label')); ?>:
                    <?php
                    echo form_dropdown(array('id' => 'reporting_manager', 'name' => 'reporting_manager', 'style' => 'display:none'));
                    ?>


                    <?php // echo form_dropdown('prefix_id', $prefix, $prefix, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled'));   ?>                                                                
                </div>
                <div class="col-md-6">
                    <?php echo form_label(lang('jobtitle'), 'jobtitle', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();
                    foreach ($jobtitle as $category)
                        $options[$category['id']] = $category['jobtitlename'];

                    echo form_dropdown(array('id' => 'jobtitle_id', 'name' => 'jobtitle_id'), $options);
                    ?>
                    <br>

                    <?php echo form_label(lang('position_id'), 'position_id', array('class' => 'form-label')); ?>:
                    <?php
                    echo form_dropdown(array('id' => 'position_id', 'name' => 'position_id', 'style' => 'display:none'));
                    ?>
                    <br>

                    <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('class' => 'form-label')); ?>:
                    <?php
                    $options = array();
                    foreach ($emp_status as $category)
                        $options[$category['id']] = $category['emp_status'];
                    echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $options);
                    ?>

                    <br>
                    <?php echo form_label(lang('date'), 'date_of_joining', array('class' => 'form-label')); ?>:

                    <?php
                    echo form_input(array(
                        'name' => 'date_of_joining',
                        'id' => 'date_of_joining',
                        'data-format' => 'D, dd MM yyyy',
                        'class' => 'form-control datepicker',
                    ));
                    ?>

                    <br>
                    <div class="row text-center">
                        <?php echo form_label(lang('expericence'), 'expericence', array('class' => 'form-label')); ?>:
                    </div>
                    <div class="col-md-6">

                        <div class="col-md-6">
                            <?php echo form_label(lang('yearsofexp'), 'yearsofexp', array('class' => 'form-label')); ?>:
                            <?php
                            echo form_input(array(
                                'name' => 'yearsofexp',
                                'id' => 'yearsofexp',
                                'class' => 'form-control',
                                'placeholder' => '(eg. 1)'
                            ));
                            ?>
                        </div>
                        <div class="col-md-6">
                            <?php echo form_label(lang('monthsofexp'), 'monthsofexp', array('class' => 'form-label')); ?>:

                            <?php
                            echo form_input(array(
                                'name' => 'monthsofexp',
                                'id' => 'monthsofexp',
                                'class' => 'form-control',
                                'placeholder' => 'eg. 2)'
                            ));
                            ?>
                        </div>

                        <div class="form-group col-sm-6">
                            <?php echo form_label(lang('isactive'), 'isactive', array('class' => 'form-label')); ?>:
                            <?php
                            $options = array();
                            $status = array('0' => 'In-Active', '1' => 'Active');
                            foreach ($status as $category)
                                $options[$category['id']] = $category;
                            echo form_dropdown(array('id' => 'isactive', 'name' => 'isactive'),'isactive', $options);
                            ?>
                        </div>
                    </div>


                </div>
                <input type="submit" name="submit" value="add">
                </form>
                <?php form_close(); ?>


            </div>
        </div>


    </div>
</div>

<?php ?>




<script>
    $.ajax({
        timeout:600,
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });

    var department_id = $("select#department_id option:selected").val();
    $.ajax({
        type: "POST",
        timeout:600,
        url: '<?php echo base_url(); ?>hr/employee/getReportingManager',
        data: {'department_id': department_id},
        success: function (data) {
            $('select[name="reporting_manager"]').show();
            $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
        }
    });

    var jobtitle_id = $("select#jobtitle_id option:selected").val();

    $.ajax({
        type: "POST",
        timeout:600,
        url: '<?php echo base_url(); ?>hr/employee/getPositionName',
        data: {'jobtitle_id': jobtitle_id},
        success: function (data) {
            if (data) {
                $('select[name="position_id"]').show();
                $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
            }
        }
    });

</script>

<script>
    $(document).ready(function () {
        //to get reporting manager 
        $("#department_id").change(function () {
            var department_id = $("select#department_id option:selected").val();
            $.ajax({
                type: "POST",
                timeout:600,
                url: '<?php echo base_url(); ?>hr/employee/getReportingManager',
                data: {'department_id': department_id},
                success: function (data) {
                    $('select[name="reporting_manager"]').show();
                    $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                }
            });
        });

        //to get position
        $("#jobtitle_id").change(function () {
            var jobtitle_id = $("select#jobtitle_id option:selected").val();

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>hr/employee/getPositionName',
                timeout:600,
                data: {'jobtitle_id': jobtitle_id},
                success: function (data) {
                    if (data) {
                        $('select[name="position_id"]').show();
                        $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                    }
                }
            });
        });

    });

</script>
