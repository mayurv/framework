<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/plugins/smartwizard/smart_wizard_vertical.css" rel="stylesheet" type="text/css">
<!--wizard css-->
<link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
<!--icon-->
<link href="<?php echo base_url(); ?>assets/css/ionicons.css" rel="stylesheet" type="text/css" media="screen" />
<!--end icon-->

<?php foreach ($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach ($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<?php // var_dump($selected)?>
<!-- SmartWizard start here -->

<div class="row-fluid">
    <div class="container">
        <?php if (isset($title)): ?>
            <div class="crud-header well">
                <?php if (isset($title_icn)): ?>
                    <div class="icn-title <?php echo $title_icn ?>"></div>
                <?php endif; ?>
                <h3><?php echo $title ?></h3></div>
        <?php endif; ?>
        <?php echo $output; ?>
    </div>
</div>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->