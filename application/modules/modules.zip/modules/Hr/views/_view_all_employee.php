<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">
    <div class="content-body">
        <div class="row">
            <div class="col-md-12 ">

                <a id="addEmployee" href="<?php echo base_url(); ?>hr/employee/addofficial" class="btn btn-primary pull-right"><i class="fa fa-plus"> Add</i></a>
            </div>

            <div class="col-md-12">
                <?php foreach ($employee as $result) { ?>
                    <div class="col-md-4 m-t-xl">
                        <div class="col-md-3">
                            <div class="">
                                <div class="pic-wrapper text-center pull-left">
                                    <img src="<?php
                                    if (isset($result->profileimg))
                                        echo base_url() . $result->profileimg;
                                    else
                                        echo base_url() . "data/profile/user1.png"
                                        ?>" class="img-circle img-responsive pull-left">
                                         <?php echo $result->employeeId; ?>  
                                </div>
                            </div>

                        </div>
                        <div>
                            <a href="<?php echo base_url() ?>hr/employee/view_user/<?php echo $result->user_id; ?>" class=" pull-right"><i class="fa fa-pencil-square-o"></i></a>
                            <ul class="list-unstyled">
                                <li><i class="fa fa-home"></i> <?php echo $result->userfullname; ?></li>
                                <li><i class="fa fa-user"></i> <?php echo substr($result->emailaddress, 0, 10) . '..'; ?></li>
                                <li><i class="fa fa-suitcase"></i> <?php echo $result->position_name; ?>,<?php echo $result->department_name; ?></li>
                                <div class="progress map_progress"><div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="62" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $result->profile_completion; ?>%; height: 30%; background-color: rgba(31, 181, 172, 1);"><small>Last Month Rise by 60%</small></div></div>
                            </ul>
                        </div>

                    </div>


                <?php } ?>


                <?php if (isset($output)) echo $output; ?>
            </div>
        </div>


    </div>
</div>

<?php ?>




<script>
    $.ajax({
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->