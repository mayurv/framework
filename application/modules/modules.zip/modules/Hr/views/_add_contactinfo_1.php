<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<div class="">
    <!--<input type="text" id="user_id" name="user_id" value="<?php isset($id) ? $id : ''; ?>">-->
    <?php ?>
</div>
<div class="container">

</div>

<div class="container">
    <!--Start Fixed Tabs-->
    <?php $this->load->view('_fixed_tab'); ?>
    <!--End Fixed Tabs-->

    <div class="row">

        <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
            <section class="box ">
                <header class="panel_header">
                    <h2 class="title pull-left">Personal</h2>
                </header>
                <div class="content-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">

                            <?php echo form_open('hr/employee/contactinfo/'.$c_emp_summary->user_id, array('class' => '', 'id' => 'profile-info')); ?>

                            <?php
                            echo form_input(array(
                                'type' => 'text',
                                'name' => 'associate_id',
                                'value' => $c_emp_summary->user_id,
                                'class' => 'form-control'
                            ));
                            ?>

                            <div>
                                <div class="controls">
                                    <?php
                                    $options = array();
                                    foreach ($gender as $category)
                                        $options[$category['id']] = $category['gendername'];
                                    echo form_dropdown('gender', $options, array('id' => 'id_gender'));
                                    ?>
                                </div>

                                <br>

                                <div class="controls">
                                    <?php
                                    $options = array();
                                    foreach ($marital_status as $category)
                                        $options[$category['id']] = $category['maritalstatusname'];
                                    echo form_dropdown('marital_status', $options, array('id' => 'id_marital_status'));
                                    ?>
                                </div>

                                <br>
                                <div class="controls">
                                    <?php
                                    $options = array();
                                    foreach ($nationality_name as $category)
                                        $options[$category['id']] = $category['nationalitycode'];
                                    echo form_dropdown('nationality_name', $options, array('id' => 'id_nationality_name'));
                                    ?>
                                </div>



                                <br>
                                <div class="controls">
                                    <?php
                                    $options = array();
                                    foreach ($language_name as $category)
                                        $options[$category['id']] = $category['languagename'];
                                    echo form_dropdown('language_name', $options, array('id' => 'id_language_name'));
                                    ?>
                                </div>
                                <br>
                                <div class="controls">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'dob',
                                        'id' => 'id_dob',
                                        'class' => 'form-control datepicker',
                                        'placeholder' => 'DOB',
                                        'data-start-view' => '2'
                                    ));
                                    ?>
                                </div>

                                <br>
                                <?php
                                echo form_dropdown('blood_group', array('0' => 'Select Blood Group', '1' => 'A +', '2' => 'A -', '3' => 'O +', '4' => 'O -', '5' => 'B +', '6' => 'B -', '7' => 'Ab +', '8' => 'AB -'), array('class' => 'form-control', 'placeholder' => 'Blood Group'));
                                ?>


                            </div>
                            <br>
                            <?php
                            echo form_input(array(
                                'type' => 'hidden',
                                'name' => 'action',
                                'value' => 'add',
                                'class' => 'form-control',
                                'placeholder' => 'Blood Group'
                            ));
                            ?>
                            <br>
                            <?php
                            echo form_input(array(
                                'type' => 'submit',
                                'name' => 'submit',
                                'value' => 'submit',
                                'class' => 'form-control'
                            ));
                            ?>
                            <!--<input type="hidden" name="action" value="add"/>-->
                            <!--<input type="submit" value="Submit">-->

                            <?php form_close(); ?>
                        </div>
                    </div>

                </div>
            </section></div>

        <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
            <section class="box ">
                <header class="panel_header">
                    <h2 class="title pull-left">Contact</h2>
                </header>
                <div class="content-body">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">

                            <div class="input-group transparent">
                                <span class="input-group-addon">
                                    <i class="fa fa-user"></i>
                                </span>
                                <input class="form-control" placeholder="Transparent" type="text">
                            </div>

                            <br>

                            <div class="input-group">
                                <span class="input-group-addon">
                                    <span class="arrow"></span>
                                    <i class="fa fa-envelope"></i>     
                                </span>
                                <input class="form-control" placeholder="Default" type="text">
                            </div>                

                            <br>

                            <div class="input-group primary">
                                <span class="input-group-addon">                
                                    <span class="arrow"></span>
                                    <i class="fa fa-user"></i>
                                </span>
                                <input class="form-control" placeholder="Primary" type="text">
                            </div>


                            <br>


                            <div class="input-group primary">
                                <input class="form-control text-right" placeholder="Right Align" aria-describedby="basic-addon1" type="text">
                                <span class="input-group-addon" id="basic-addon1"><span class="arrow"></span><i class="fa fa-user"></i></span>
                            </div>
                            <br>

                            <div class="input-group">
                                <input class="form-control" placeholder="Recipient's username" aria-describedby="basic-addon2" type="text">
                                <span class="input-group-addon" id="basic-addon2">@example.com</span>
                            </div>
                            <br>


                            <div class="input-group primary">
                                <span class="input-group-addon">$</span>
                                <input class="form-control" aria-label="Amount (to the nearest dollar)" type="text">
                                <span class="input-group-addon">.00</span>
                            </div>







                            <br>

                            <div class="input-group">
                                <span class="input-group-addon">$</span>
                                <input class="form-control" type="text">
                                <span class="input-group-addon">.00</span>
                            </div>

                            <br>

                            <div class="input-group primary">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-red dropdown-toggle" data-toggle="dropdown">
                                        Action <span class="caret"></span>
                                    </button>

                                    <ul class="dropdown-menu dropdown-red no-spacing">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>
                                        <li><a href="#">Something else here</a></li>
                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a></li>
                                    </ul>
                                </span>

                                <input class="form-control no-left-border form-focus-red" placeholder="Dropdown" type="text">
                            </div>

                            <br>


                            <div class="input-group m-bot15">
                                <span class="input-group-addon">
                                    <div class="icheckbox_minimal" style="position: relative;"><input class="iCheck" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;" type="checkbox"><ins class="iCheck-helper" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins></div>
                                </span>
                                <input class="form-control" placeholder="Input with Checkbox" type="text">
                            </div>

                        </div>
                    </div>

                </div>
            </section></div>

    </div>
</div>

<script>
    $.ajax({
        url: '/hr/getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->