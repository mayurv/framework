<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of index
 *
 * @author Mayur V
 */

echo '<p>This is hr Dashboard</p>';

?>
<div class="container">
<!--    <div class="col-md-4">
        <b><p><a href="<?php //echo base_url();?>hr/adduser">Add Associate</a></p></b>
        <div class="panel">
            <b><p><a href="">-> Configure Associate</a></p></b>
            <p><a href="userconfiguration/emp_mode">-> Employment Mode</a></p>
            <p><a href="">-> Department</a></p>
            <p><a href="">-> Job Title</a></p>
            <p><a href="">-> Position</a></p>
        </div>
    </div>-->
    
<!--    <div class="col-md-4">
        <p><a href="<?php echo base_url();?>hr/adduser">Official</a></p>
        <p><a href="<?php echo base_url();?>hr/document">Document</a></p>
        <p><a href="<?php echo base_url();?>hr/leaves">Leaves</a></p>
        <p><a href="<?php echo base_url();?>hr/holidays">Holiday</a></p>
        <p><a href="<?php echo base_url();?>hr/personal">Personal</a></p>
        <p><a href="<?php echo base_url();?>hr/contact">Contact</a></p>
        <p><a href="<?php echo base_url();?>hr/skills">Skills</a></p>
        <p><a href="<?php echo base_url();?>hr/jobhistory">Job History</a></p>
        <p><a href="<?php echo base_url();?>hr/experience">Experience</a></p>
        <p><a href="<?php echo base_url();?>hr/education">Education</a></p>
        <p><a href="<?php echo base_url();?>hr/certificate">Certificate</a></p>
        <p><a href="<?php echo base_url();?>hr/visa">Visa</a></p>
        
    </div>-->

    <div class="col-md-8">
        <?php if(isset($output)) echo $output; ?>
    </div>
</div>
