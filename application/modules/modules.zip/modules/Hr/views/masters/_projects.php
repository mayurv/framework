
<div class="white-bg all-padding-15">
    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Project and Client Management</h4>
                    </div>  

                </div>
            </div>
            
            <div class="row"> 
                <div class="col-sm-12">
                                <ul class="nav nav-tabs">

                <li class="active">
                    <a href="#client" data-toggle="tab" aria-expanded="false" class="active ">
                        <i class="fa fa-check-circle"></i> Client
                    </a>
                </li>
                <li class="">
                    <a href="#project" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> Project
                    </a>
                </li>


                <li class="">
                    <a href="#client-users" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> Client - Users
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                 <div class="tab-pane fade active in" id="client">

                    <?php $this->load->view('masters/_add_client') ?>
                </div>
                <div class="tab-pane fade " id="project">

                    <?php $this->load->view('masters/_add_project') ?>
                </div>               

                <div class="tab-pane fade " id="client-users">

                    <?php $this->load->view('masters/_add_clientUsers') ?>
                </div>

            </div>
                </div>
            </div>


        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>