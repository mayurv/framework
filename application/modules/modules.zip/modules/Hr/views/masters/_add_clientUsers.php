<div class="row">
                    <!-- left side col-sm-12 here -->
                    <div class="col-sm-12">             

                        <!-- top button bar here -->                                
                        <div class="add-candidate-bg"> 
                            <div class="pull-left">
                                <button class="btn btn-default btn-sm" data-toggle="modal" data-target="#add-client-users"> <i class="fa fa-plus-circle"></i> Client Users</button>
                              
                            </div>
                        </div>                          
                        <!-- top button bar here -->

                    </div>
                    <!-- left side col-sm-9 here -->

                </div>
                </div>
<?php $this->load->view('masters/modal/_addClientUsers')?>