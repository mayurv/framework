<?php  foreach ($client_details as $listData) { ?>
<!--add project modal start here-->
<div id="editClient_<?php echo $listData['id'] ?>" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Edit Client : <?php echo $listData['title'] ?></h4>                        
            </div>
            <div class="modal-body">
                <?php echo form_open_multipart('hr/add_client/'.$listData['id'], array('id' => 'form_addClient_id', 'class' => 'form_addClient_id')); ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="input-field">
                            <?php echo form_label(lang('client_name'), 'client_name', array('for' => 'client_name')); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'client_name',
                                'id' => 'client_name',
                                'placeholder' => 'Client Name',
                                'data-error' => '.errorTxtCl1',
                                'value' => $listData['title']
                            ));
                            ?>
                            <div class="errorTxtCl1"></div>
                            <?php echo form_error('client_name'); ?>
                        </div> 
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-6">
                        <div class="input-field">
                            <?php echo form_label(lang('email'), 'email', array('for' => 'email')); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'email',
                                'id' => 'email',
                                'placeholder' => 'Email',
                                'data-error' => '.errorTxtCl2',
                                'value' => $listData['email']
                            ));
                            ?>
                            <div class="errorTxtCl2"></div>
                            <?php echo form_error('email'); ?>
                        </div> 
                    </div>
                    <div class="col-sm-6">
                        <div class="input-field">
                            <?php echo form_label(lang('contact'), 'contact', array('for' => 'contact')); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'contact',
                                'id' => 'contact',
                                'placeholder' => 'Contact Number',
                                'data-error' => '.errorTxtCl3',
                                'value' => $listData['contact_number']
                            ));
                            ?>
                            <div class="errorTxtCl3"></div>
                            <?php echo form_error('contact'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <div class="input-field">
                            <?php echo form_label(lang('address'), 'address', array('for' => 'address')); ?>
                         
                                <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'address',
                                            'id' => 'address',
                                            'value' => set_value('address', $listData['address']),
                                            'placeholder' => 'Address',
                                            'data-error' => '.errorTxtCom11'
                                        ));
                                        ?>
                            <div class="errorTxtCl4"></div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <div class="input-field">
                            <?php echo form_label(lang('location'), 'location', array('for' => 'location')); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'location',
                                'id' => 'location',
                                'placeholder' => 'Location',
                                'data-error' => '.errorTxtCl5',
                                 'value' => $listData['location']
                            ));
                            ?>
                            <div class="errorTxtCl5"></div>
                            <?php echo form_error('contact'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>

                    <div class="col-sm-12">
                        <div class="file-field input-field">
                            <div class="btn btn-default btn-sm margin-top-5">Browse
                                <?php
                                echo form_input(array(
                                    'type' => 'file',
                                    'name' => 'profile_image',
                                    'id' => 'profile_image',
                                    'class' => 'form-control',
                                    'data-error' => '.errorTxtCl6'
                                ));
                                ?>
                            </div>                                      

                            <div class="file-path-wrapper">
                                <?php
                                echo form_input(array(
                                    'name' => 'profile_image',
                                    'id' => 'profile_image',
                                    'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                    'placeholder' => '(jpg, jpeg, png)',
                                ));
                                ?>
                            </div>
                            <div class="errorTxtCl6"></div>
                        </div>
                    </div>

                    <div class="clearfix"></div>    
                    <div class="col-sm-12 text-right">
                        <input hidden name="id" value="<?php echo $listData['id'] ?>">
                        <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                    </div>                                        
                </div>  
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>            
</div>
<!--add project modal end here-->

<?php } ?>