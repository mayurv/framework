<!--add project modal start here-->
<div id="add-project" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Project</h4>                        
            </div>
            <div class="modal-body">
                <?php echo form_open('hr/add_project', array('id' => 'form_addProject_id', 'class' => 'form_addProject_id')); ?>
                <div class="row">

                    <div class="col-sm-12">
                        <?php echo form_label(lang('project_type_id'), 'project_type_id', array('for' => 'project_type_id', 'data-error' => 'select role')); ?>
                        <?php
                        echo form_dropdown(array(
                            'id' => 'project_type_id',
                            'name' => 'project_type_id',
                            'class' => 'browser-default ',
                            'data-error' => '.errorTxtProj1'), $project_type_list);
                        ?> 
                        <div class="input-field">
                            <div class="errorTxtProj1"></div>
                        </div> 
                        <?php echo form_error('project_type_id'); ?>
                    </div> 
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                           <div class="input-field">
                            <?php echo form_label(lang('name'), 'name', array('for' => 'name')); ?>
                            <?php
                            echo form_input(array(
                                'name' => 'name',
                                'id' => 'name',
                                'placeholder' => 'Project Name',
                                'data-error' => '.errorTxtProj2'
                            ));
                            ?>
                            <div class="errorTxtProj2"></div>
                            <?php echo form_error('name'); ?>
                        </div> 
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <div class="input-field">
                            <?php echo form_label(lang('description'), 'description', array('for' => 'description')); ?>
                                                      <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'description',
                                            'id' => 'description',                                           
                                            'placeholder' => 'Description',
                                            'data-error' => '.errorTxtCom11'
                                        ));
                                        ?>
                            <div class="errorTxtProj3"></div>
                        </div>
                    </div>
                    <div class="clearfix"></div>

                   <div class="col-sm-12">
                        <?php echo form_label(lang('manager_id'), 'manager_id', array('for' => 'manager_id', 'data-error' => 'select role')); ?>
                        <?php
                        echo form_dropdown(array(
                            'id' => 'mang_id',
                            'name' => 'mang_id',
                            'class' => 'browser-default ',
                            'data-error' => '.errorTxtProj4'), $manager_list);
                        ?> 
                        <div class="input-field">
                            <div class="errorTxtProj4"></div>
                        </div> 
                        <?php echo form_error('project_type_id'); ?>
                    </div> 
                    <div class="clearfix"></div>
                 <div class="col-sm-12">
                        <?php echo form_label(lang('client_id'), 'client_id', array('for' => 'client_id', 'data-error' => 'select role')); ?>
                        <?php
                        echo form_dropdown(array(
                            'id' => 'client_id',
                            'name' => 'client_id',
                            'class' => 'browser-default ',
                            'data-error' => '.errorTxtProj5'), $client_list);
                        ?> 
                        <div class="input-field">
                            <div class="errorTxtProj5"></div>
                        </div> 
                        <?php echo form_error('client_id'); ?>
                    </div> 
                    <div class="clearfix"></div>    
                    <div class="col-sm-12 text-right">
                        <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                        <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                    </div>                                        
                </div>  
                </form>
            </div>
        </div>
    </div>            
</div>

<!--add project modal end here-->