<div class="row">
    <!-- left side col-sm-12 here -->
    <div class="col-sm-12">   
        <!-- top button bar here -->                                
        <div class="add-candidate-bg"> 
            <div class="pull-right">
                <button class="btn btn-default btn-sm" data-toggle="modal" data-target="#add-project"><i class="fa fa-plus-circle"></i> Add Project</button>                               
            </div>
        </div>                          
        <!-- top button bar here -->
    </div>
    <!-- left side col-sm-9 here -->
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 100%;">
            <div class="full-height-scroll" style="overflow: hidden; width: auto; height: 100%;">
                <div class="table-responsive">
                    <table id="project-list" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                              
                                <th>Name</th>
                                <th>Project Type</th>
                                <th>Client</th>
                                <th>Since</th>
                                <th>Status</th>
                                <th></th>

                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                             <th>Name</th>
                                <th>Project Type</th>
                                <th>Client</th>
                                <th>Since</th>
                                <th>Status</th>
                                <th></th>

                            </tr>
                        </tfoot>
                        <tbody>
                            <?php
                            foreach ($project_details as $listData) {
                                // var_dump($listData);
                                ?>
                                <tr>
                                    <td><a data-toggle="tab" href="#contact-1" class="client-link" aria-expanded="true"><?php echo $listData['name'] ?></a></td>
                                    <td> <?php echo $listData['project_type'] ?></td>
                                    <td><i class="fa fa-fw fa-user" title="Client Name"></i> <?php echo $listData['client_name'] ?></td>
                                    <td> <?php echo date('d M Y',strtotime($listData['createdat'])) ?></td>
                                    <td class="client-status"><span class="label label-primary"><?php echo $listData['isactive'] == 0 ? 'Active' : 'Inactive' ?></span></td>
                                    <td class="client-status"><a data-toggle="modal" href="#editProject_<?php echo $listData['id'] ?>"><i class="fa fa-pencil" title="Edit"></i></a></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div><div class="slimScrollBar" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 365.112px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
    </div>
</div>

<?php
$this->load->view('masters/modal/_addProject');
$this->load->view('masters/modal/_editProject');
        
        ?>