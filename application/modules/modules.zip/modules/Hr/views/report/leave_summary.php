<div class="white-bg all-padding-15">
    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Leave Summary</h4>
                    </div>  

                    <div class="pull-right">
                        <div class="icon-bg"> 
                            <i class="fa fa-info-circle text-ccc" title="You can submit timesheet between 1st to 5th <?php echo date('F Y', (strtotime('next month', strtotime(date('m/01/y'))))); ?>"></i>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#year_summary" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> 2017 Leave Summary
                    </a>
                </li>
                <li class="">
                    <a href="#dept_summary" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> Department
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="year_summary">
                    <div class="my-timesheet">
                       
                    </div>
                </div>


                <div class="tab-pane fade " id="dept_summary">
                    <?php $this->load->view('report/dept_leaveSummary') ?>
                </div>
                
            </div>
        </div>
    </div>
</div>