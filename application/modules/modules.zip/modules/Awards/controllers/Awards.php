<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Awards extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->library('Ajax_pagination');
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'employeeawards', 'department', 'holidaydates', 'years', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('employees', 'projects','projectallocation', 'awardstype', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('holiday_lang');

        $this->perPage = 5;

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        elseif (!$this->ion_auth->in_group('hr')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {
//        var_dump($this->session->userdata());die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function add_awards() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        // var_dump($_POST);die;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dataAward = array(
                'department_id' => $this->input->post('department_id'),
                'user_id' => $this->input->post('employee_name'),
                'award_id' => $this->input->post('award_name'),
                'award_date' => $this->input->post('employee_name'),
                'comment' => $this->input->post('comment'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'isactive' => 1
            );
            $this->employeeawards->insert($dataAward);
            // echo $this->db->last_query();die;
        }

        $data['user_summary'] = NULL;
        $data['rep_manager_list'] = array('' => 'Select Employee');
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['award_list'] = (array('' => 'Select Award') + $this->awardstype->dropdown('name'));
        // $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        //total rows count
        $totalRec = count($this->employeeawards->get_all_employee());

        //pagination configuration
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'awards/ajaxPaginationDataAward';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['link_func'] = 'searchFilter';
        $this->ajax_pagination->initialize($config);

        $data['associates'] = $this->employeeawards->get_all_employee(array('limit' => $this->perPage));

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'awards', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function associate_month() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        $data['project_list'] = $this->projects->dropdown('id', 'name');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $associate_id = $this->input->post('user_id');
            $updateData = array(
                'isactive' => '0',
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'award_date' => date('Y m'),
            );
            $this->employeeawards->update($associate_id, $updateData);
            return true;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $dataAward = array(
                'department_id' => $user_id,
                'user_id' => $this->input->post('employee_name'),
                'award_id' => $this->input->post('award_name'),
                'award_date' => $this->input->post('employee_name'),
                'comment' => $this->input->post('comment'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'isactive' => 1
            );
            $this->employeeawards->insert($dataAward);
            // echo $this->db->last_query();die;
        }

        $data['user_summary'] = NULL;
        $data['rep_manager_list'] = array('' => 'Select Employee');
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['award_list'] = (array('' => 'Select Award') + $this->awardstype->dropdown('name'));
        // $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');



        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        //total rows count
        $totalRec = count($this->employeeawards->get_all_employee());

        //pagination configuration
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'awards/ajaxPaginationDataAssociateOfMonth';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $config['link_func'] = 'searchFilter';
        $this->ajax_pagination->initialize($config);
        $data['associates'] = $this->employeeawards->getAsociateMonthHistory(array('limit' => NULL));

        $data['lastaom_employee'] = $this->employeeawards->getLastAsociateMonthHistory();
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_associate_month', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function ajaxPaginationDataAward() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
        if (!empty($keywords)) {
            $conditions['search']['keywords'] = $keywords;
        }
        if (!empty($sortBy)) {
            $conditions['search']['sortBy'] = $sortBy;
        }

        //total rows count
        $totalRec = count($this->employeeawards->get_all_employee());

        //pagination configuration
        $config['first_link'] = 'First';
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'awards/ajaxPaginationDataAward';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $this->ajax_pagination->initialize($config);

        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;

        //get the posts data
        $data['associates'] = $this->employeeawards->getAsociateMonthHistory($conditions);
        //echo $this->db->last_query();
        // var_dump($data['employee']);
        //load the view
        $this->load->view('awards/ajax-pagination-data-award', $data, false);
    }

    function ajaxPaginationDataAssociateOfMonth() {
        $page = $this->input->post('page');
        if (!$page) {
            $offset = 0;
        } else {
            $offset = $page;
        }

        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
        if (!empty($keywords)) {
            $conditions['search']['keywords'] = $keywords;
        }
        if (!empty($sortBy)) {
            $conditions['search']['sortBy'] = $sortBy;
        }

        //total rows count
        $totalRec = count($this->employeeawards->get_all_employee());

        //pagination configuration
        $config['first_link'] = 'First';
        $config['target'] = '#postList';
        $config['base_url'] = base_url() . 'awards/ajaxPaginationDataAssociateOfMonth';
        $config['total_rows'] = $totalRec;
        $config['per_page'] = $this->perPage;
        $this->ajax_pagination->initialize($config);

        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;

        //get the posts data
        $data['associates'] = $this->employeeawards->getAsociateMonthHistory($conditions);
        //echo $this->db->last_query();
        // var_dump($data['employee']);
        //load the view
        $this->load->view('awards/ajaxPaginationDataAssociateOfMonth', $data, false);
    }

    function getEmployeeByDept() {
        if (isset($_POST)) {
            $department_id = $_POST['department_id'];
            $employees = $this->awardstype->getEmployeeByDept($_POST);
            $st = '';
            $st = '<option value="">Select Manager</option>';
            foreach ($employees as $emp) {
                $st .= '<option value="' . $emp->user_id . '">' . $emp->userfullname . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getAutocompleteAssociateList() {
        $term = $_REQUEST['term'];
        $searchData = $this->employeeawards->getEmployeeList($term);
        $a = '<div class=\"text-grey\">';
        $b = '<\/div>';
        header('Content-Type: application/json');
        foreach ($searchData as $s) {
            // $s['userfullname'] = $s['userfullname'].$a.$s['employeeId'].$b;
            $data[] = array(
                'title' => $s['userfullname'],
                'value' => $s['userfullname'] . ', ' . $s['employeeId']
            );
        }
        echo json_encode($data);
        die;
        flush();
    }

    function getAssociateData() {
        $id = trim($_REQUEST['emp_id']);
        //$employee = $this->employeeawards->getEmployeeById($id);

        $data['project_list'] = $this->projects->dropdown('id', 'name');
        $data['employee'] = $this->employeeawards->getEmployeeById($id);
        $data['lastaom_employee'] = $this->employeeawards->getLastAsociateMonthHistory();
        $timelineData = $this->load->view('awards/_associate_view', $data, TRUE);
        echo json_encode(array('empdata' => $timelineData));
        die;
    }

    public function associateHof() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            
            $project_id = $this->input->post('project_id');
            $client_id = $this->projectallocation->get_client_id($project_id);

            $dataAward = array(
                'user_id' => $this->input->post('associate_id'),
                'department_id' => $this->input->post('department_id'),
                'project_id' => $this->input->post('project_id'),
                'client_id' => $client_id,
                'award_date' => date('Y-m-d H:m:s'),
                'award_id' => '1',
                'comment' => $this->input->post('comment'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'isactive' => 1
            );
            $this->employeeawards->insert($dataAward);
            // echo $this->db->last_query();die;
        }
    }

    public function delete_hof() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $hof_if = $this->input->post('hof_id');
            $this->employeeawards->delete($hof_if);
//            echo $this->db->last_query();
            die;
        }
    }

    public function update_hof() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $hof_id = $this->input->post('hof_id');
            $project_id = $this->input->post('project_id');
            $comment = $this->input->post('comment');
            $hodData = array(
                'project_id' => $project_id,
                'comment' => $comment,
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s'),
            );
            $this->employeeawards->update($hof_id,$hodData);
//            echo $this->db->last_query();die;
//            echo $this->db->last_query();
            die;
        }
    }

}
