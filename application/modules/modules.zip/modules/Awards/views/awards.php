<?php //var_dump($associates)                  ?>
<div class="row panel panel-body panel-custom">
    <div class="col-sm-12">
        <form id="frm-associate_of_month" method="post">
            <div class="pull-right">
                <a data-toggle="modal" href="#associate-of-month" title="Add Associate of the Month">  
                    <i class="fa fa-plus text-gray "></i>
                </a>
            </div>
        </form>
        <div class="col-sm-12">
            <div id="idSort">
                <i class="sort-data fa fa-sort-alpha-asc"><input type="hidden" value="asc" id="sortBy"></i>
            </div>
        </div>
        <div class="post-search-panel">
            <input type="text" id="keywords" placeholder="Type keywords to filter posts" onkeyup="searchFilter()"/>
<!--            <select id="sortBy" onchange="searchFilter()">
                <option value="">Sort By</option>
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
            </select>-->
        </div>
        <div class="post-list" id="postList">
            <table class="table data-table table-hover table-responsive">
                <thead>
                    <tr>
                        <th class="col-sm-1">SL</th>
                        <th class="col-sm-1">Name</th>
                        <th class="col-sm-1">Department</th>
                        <th class="col-sm-1">Position</th>
                        <th class="col-sm-1"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($associates as $r => $assocdata) { ?>
                        <tr>
                            <td><?php echo $r + 1; ?></td>
                            <td><p><?php echo $assocdata['userfullname'] ?></p></td>
                            <td><p><?php echo $assocdata['department_name'] ?></p></td>
                            <td><p><?php echo $assocdata['position_name'] ?></p></td>
                            <td><p>
                                <div class="col-sm-12">
                                    <!--                                <div class="input-field">-->
    <!--                                <input type="radio" name='group1' id="chkradio<?php echo $assocdata['id'] ?>" value="<?php echo $assocdata['id'] ?>" checked="" />
                                    <label for="chkradio<?php echo $assocdata['id'] ?>"> </label>-->
                                    <!--                                </div>-->
                                </div>
                                </p>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <?php echo $this->ajax_pagination->create_links(); ?>
        </div>
    </div>
</div>
<?php $this->load->view('_award_modal'); ?> 



<script>
    function searchFilter(page_num) {
        page_num = page_num ? page_num : 0;
        var keywords = $('#keywords').val();
        var sortBy = $('#sortBy').val();
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>awards/ajaxPaginationDataAward/' + page_num,
            data: 'page=' + page_num + '&keywords=' + keywords + '&sortBy=' + sortBy,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#postList').html(html);
                $('.loading').fadeOut("slow");
            }
        });
    }
</script>


 

<script type="text/javascript">
    $(document).ready(function () {
        
               $('.year_last_use').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });

        $('input[name="btnSave"]').attr('disabled', 'disabled');
        $('input[type="radio"].chkradio').change(function () {
            if (!$(this).hasClass('chnd')) {
                $(this).addClass('chnd');
            } else {
                $(this).removeClass('chnd');
            }

            if ($('input[type="radio"].chnd').length > 0) {
                $('input[name="btnSave"]').removeAttr('disabled');
            } else {
                $('input[name="btnSave"]').attr('disabled', 'disabled');
            }
        });

        $(".sort-data").click(function () {
            $('.sort-data').toggleClass('fa-sort-alpha-desc text-info');
            if ($('#sortBy').val() == 'asc')
                    $('#sortBy').val('desc');
            else
                $('#sortBy').val('asc');
            searchFilter();

//            $('.sort-data').addClass('fa-sort-alpha-desc');
        });

        $('input[name="btnSave"]').click(function (e) {
            e.preventDefault();
            var user_id = $("input[name='chkradio']:checked").val();

            $.ajax({
                url: '/admin/artistoftheweek/manage_artistofweek/' + user_id,
                data: {'user_id': user_id},
                type: 'POST',
                dataType: 'json',
                success: function (data) {
                    if (data) {
                        $('#msg').html('<div class="alert alert-' + data.flashdata.type + '"><button type="button" class="close" data-dismiss="alert">&times;</button>' + data.flashdata.msg + '</div>').show();
                        $('input[name="btnSave"]').attr('disabled', 'disabled');
                    }
                }
            });
        });
    });

</script>

<!--<style type="text/css">
    .datepicker {
        z-index: 1050 !important;
    }

    .bootstrap-timepicker-widget.dropdown-menu.open {
        display: inline-block;
        z-index: 99999 !important;
    }
</style>-->









