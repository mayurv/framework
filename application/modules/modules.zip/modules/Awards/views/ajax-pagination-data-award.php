<table class="table data-table table-hover table-responsive">
                <thead>
                    <tr>
                        <th class="col-sm-1">SL</th>
                        <th class="col-sm-1">Name</th>
                        <th class="col-sm-1">Department</th>
                        <th class="col-sm-1">Position</th>
                        <th class="col-sm-1"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($associates as $r => $assocdata) { ?>
                        <tr>
                            <td><?php echo $r + 1; ?></td>
                            <td><p><?php echo $assocdata['userfullname'] ?></p></td>
                            <td><p><?php echo $assocdata['department_name'] ?></p></td>
                            <td><p><?php echo $assocdata['position_name'] ?></p></td>
                            <td><p>
                                <div class="col-sm-12">
                                    <!--                                <div class="input-field">-->
    <!--                                <input type="radio" name='group1' id="chkradio<?php echo $assocdata['id'] ?>" value="<?php echo $assocdata['id'] ?>" checked="" />
                                    <label for="chkradio<?php echo $assocdata['id'] ?>"> </label>-->
                                    <!--                                </div>-->
                                </div>
                                </p>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
<?php echo $this->ajax_pagination->create_links(); ?>

