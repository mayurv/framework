<!-- Education modal start -->
<div class="modal fade" id="associate-of-month" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Award</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim"><button type="button" onclick="return updatehof(<?php echo $result['awd_id'] ?>)" id="publish_hof" class="btn btn-info btn-sm pull-right">Update</button>                                                             
                    <?php echo form_open_multipart('awards/associate_month', array('id' => 'form_validate_awards_id', 'class' => 'form_validate_award_id'));
                    ?>
                    <!-- 1st row start here -->
                    <div class="row">
                        <div class="col-sm-6">
                            <?php echo form_label(lang('department_id'), 'department_id', array('for' => 'department_id', 'data-error' => 'please select department')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'department_id', 'name' => 'department_id'), $department_list, set_value('department_id', $user_summary['department_id']), array('class' => 'browser-default ', 'data-error' => '.errorTxtOff9'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff9"></div>
                            </div>
                            <?php echo form_error('department_id'); ?>

                        </div> 

                        <div class="col-sm-6">
                            <?php echo form_label(lang('employee_name'), 'employee_name', array('for' => 'employee_name', 'data-error' => 'employee_name')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'employee_name', 'name' => 'employee_name'), $rep_manager_list, set_value('employee_name', $user_summary['employee_name']), array('class' => 'browser-default ', 'data-error' => '.errorTxtOff10'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff10"></div>
                            </div>
                            <?php echo form_error('employee_name'); ?>
                        </div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('award_name'), 'award_name', array('for' => 'award_name', 'data-error' => 'award_name')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'award_name', 'name' => 'award_name'), $award_list, set_value('award_name', $user_summary['award_name']), array('class' => 'browser-default ', 'data-error' => '.errorTxtOff10'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff10"></div>
                            </div>
                            <?php echo form_error('award_name'); ?>
                        </div>

                        <div class="col-sm-6">
                            <div class="year-view">
                                <div class="form-group">
                                    <div class="controls ">
                                        <input type="text" name="award_date" class="form-control date" data-format="D, dd MM yyyy" value="Mon, 02 February 2015">
                                    </div>
                                </div>
                            </div>
                            <div class="month-view" style="display:none">
                                <div class="input-field">
                                    <?php echo form_label(lang('award_date'), 'award_date', array('for' => 'award_date')); ?>

                                    <?php
                                    echo form_input(array(
                                        'name' => 'award_date',
                                        'id' => 'award_date',
                                        'data-format' => 'yyyy-mm-dd',
                                        'class' => 'award_date',
                                        'placeholder' => 'Date of Joining',
                                        'value' => set_value('award_date', $user_summary['award_date']),
                                        'data-error' => '.errorTxtOff15'
                                    ));
                                    ?>
                                    <div class="errorTxtOff15"></div>
                                    <?php echo form_error('date_of_joining'); ?>
                                </div> 
                            </div>
                        </div> 
                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('comment'), 'comment', array('for' => 'comment')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'comment',
                                    'name' => 'comment',
                                    'placeholder' => 'Comment',
                                    'data-error' => '.errorTxtedu8'
                                ));
                                ?>
                                <div class="errorTxtedu8"></div>
                                <?php echo form_error('comment'); ?>

                            </div> 
                        </div>
                        <div class="clearfix"></div>

                        <div class="clearfix"></div>

                        <div class="col-sm-12 padding-top-10">
                            <!--<button type="submit" class="btn btn-warning2 btn-sm">Submit</button>-->
                            <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>
                    <!-- 1st row end here -->
                    <?php echo form_close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<style> 
    .add-width {
        width: 19% !important;
    }
</style>

<script type="text/javascript">
    $(document).ready(function () {
//        $('.datepicker').pickadate({
//            selectMonths: true, // Creates a dropdown to control month
//            selectYears: 15 // Creates a dropdown of 15 years to control year
//        });
        // $('.datepicker').find('.datepicker-dropdown').addClass('add-width');
        //    $(".datepicker").addClass('add-width');
        $(".date").datepicker({
            format: "mm/yyyy",
            startView: "year",
            minViewMode: "months"
        });
        //$('.date').find('.datepicker').addClass('add-width');
    });</script>

<script>
    function ajaxCallToGetAllEmployee(department_id)
    {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>awards/getEmployeeByDept',
            data: {'department_id': department_id},
            success: function (data) {
                $("#employee_name option[value='0']").attr('selected', 'selected');
                $("#employee_name").focus;
                $('select[name="employee_name"]').html(data.content).trigger('liszt:updated').val(employee_name);
                $("#employee_name").val($("#employee_name option:first").val());
            }
        });
    }

    $(document).ready(function () {
        $("#department_id").change(function () {
            var department_id = $("select#department_id option:selected").val();
            ajaxCallToGetAllEmployee(department_id);
        });

        $(".award_date").click(function () {
            $('.award_date').pickadate({
                selectYears: true,
                selectMonths: true,
               //max: new Date()
            });

        });
        $("#award_name").change(function () {
            var award_name = $("select#award_name option:selected").val();
            //  alert(award_name);
            if (award_name != 1) {

                $(".month-view").show();
                $(".year-view").hide();
            }
            else {

                $(".month-view").hide();
                $(".year-view").show();
            }
        });
    });
</script>