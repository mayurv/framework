<style>
    .user-bg1{
        float: left;
        width: 100%;
        height: auto;
        padding: 10px;
        margin: 10px 0px 10px 0px;
        box-shadow: 0 3px 7px 0 #a8a8a8 !important;
        border: 1px solid rgba(118, 118, 118, 0.15) !important;
    }
</style>
<?php foreach ($employee as $result) { ?>
    <!-- col-sm-4 here -->
    <div class="col-sm-12">
        <div class="alert alert-warning">
            <b>Note : </b>Make sure before publishing an <b>Hall of Fame</b>, Associate is assign on project.
        </div>
    </div>
    <div class="col-sm-12" > 
        <!-- user bg -->
        <div class="" title="">
            <span class="pull-right"><a href="<?php echo base_url() ?>employee/view_user/<?php echo $result['user_id']; ?>" title="View Associate"><i class="fa fa-vcard text-ccc"></i></a></span>
            <div class="media">
                <span class="text-center">
                    <?php if (isset($result['profileimg']) && $result['profileimg'] != '') { ?>
                        <img class="img-responsive media-object margin-top-0 center-img" src="<?php echo base_url() . 'assets/uploads/' . $result['profileimg']; ?>">  
                    <?php } else { ?>
                        <img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                    <?php } ?>
                </span>
                <div class="margin-top-10">
                    <!--<img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/line.png">-->                             
                </div>
                <div class="text-center">


                    <p><span class="font-size-15 "><?php echo $result['userfullname']; ?></span> </p>
                    <p><span class="text-gray" > <?php echo $result['employeeId']; ?></span></p>
                    <p><span class="text-gray" title="Designation"> <?php echo $result['position_name']; ?>, </span> <span class="text-gray" title="Department"> <?php echo $result['department_name']; ?></span></p>
                    <div class="margin-top-10"></div>
                    <div class="text-left">
                        <div class="col-sm-12">
                            <?php echo form_label('Project List'); ?>

                            <?php
                            echo form_dropdown(array('id' => 'project_id',
                                'name' => 'project_id',
                                'class' => 'browser-default',
                                'data-error' => '.errorPA1'), $project_list, set_value('project_id', $result['project_id']));
                            ?>
                            <div class="input-field">
                                <div class="errorPA1"></div>
                            </div> 
                            <?php echo form_error('project_id'); ?> 
                        </div> 

                        <span class=""><div class="comment-box" style='dispaly:block'>
                                <input type="hidden" id="associate_id" name="associate_id" value="<?php echo $result['user_id']; ?>">
                                <input type="hidden" id="department_id" name="department_id" value="<?php echo $result['department_id']; ?>">
                                <div class="col-sm-12">
                                    <textarea id="textarea1" class="materialize-textarea" placeholder="Add comment in detail" required="required"></textarea>
                                </div>
                                <div class="error-box-text1"></div>

                                <div class="col-sm-12 pull-right">
                                    <button type="submit" onclick="return hof()" id="publish_hof" class="btn btn-info btn-sm pull-right">Publish</button>
                                </div>
                            </div>
                        </span>                        
                    </div>
                    

                </div>
            </div>  
            <h4 class="text-bold text-center">Hall of Fame - <span class="text-info"><?php echo date('F Y') ?></span></h4>
        </div>                                                  
    </div>

<?php } ?>

<script>

    function hof() {
        var comment = $('#textarea1').val();
        var department_id = $('#department_id').val();
        var project_id = $('#project_id').val();
        var associate_id = $('#associate_id').val();
        if ($('#textarea1').val() == '') {
            $('.error-box-text1').html('Comment cannot be empty');
            $('#textarea1').focus();
            return false;
        }
        $('.error-box-text1').html('');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>awards/associateHof',
            data: {'comment': comment, 'department_id': department_id, 'associate_id': associate_id,'project_id':project_id},
            success: function (data) {
                if (data) {

                    $('#prev-hof').hide();
                    window.location.reload();
                    showSuccess('Hall of fame published successfully');
                }
            }
        });
    }
</script>


