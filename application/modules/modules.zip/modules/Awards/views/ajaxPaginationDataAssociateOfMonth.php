<table class="table data-table table-hover table-responsive">
    <thead>
        <tr>

            <th >Associate Name</th>
            <th >Department</th>
            <th >Month</th>  
            <th ></th>  

        </tr>
    </thead>
    <tbody>
        <?php foreach ($associates as $r => $assocdata) { ?>
            <tr id="hof_<?php echo $assocdata['awd_id'] ?>">

                <td>
                    <p>
                        <i><?php if (isset($assocdata['profileimg']) && $assocdata['profileimg'] != '') { ?>
                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $assocdata['profileimg']; ?>">  
                            <?php } else { ?>
                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                            <?php } ?></i>
                        <?php echo $assocdata['userfullname'] ?></p>
                    <p><small class="text-light-gray"><?php echo $assocdata['position_name'] ?></small></p>
                </td>
                <td><p><?php echo $assocdata['department_name'] ?></p></td>
                <!--strtotime($user_summary['date_of_joining']))-->
                <td><p><?php echo date('M Y', strtotime($assocdata['award_date'])); ?></p></td>
                <td><i class="fa fa-trash text-ccc" onclick="deleteHofRow(<?php echo $assocdata['awd_id'] ?>)" title="Delete"></i></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<?php echo $this->ajax_pagination->create_links(); ?>
<script>

    function deleteHofRow(dId) {

        if (confirm('Are you sure, you want to delete this?')) {
            showSuccess("Record deleted successfully");
//        if()
            $("tr").remove("#hof_" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>awards/delete_hof',
                data: {'hof_id': dId},
                success: function (data) {
                    window.location.reload();
                }
            });
            return false;
        }
    }
</script>

