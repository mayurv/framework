
<?php // var_dump($lastaom_employee) ;die;                                              ?>
<div class="main-bg all-padding-10">
    <div class="row ">

        <div class="col-sm-12">

            <div class="col-sm-4 ">
                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="text-bold"> Hall of Fame</h4>
                    </div>
                </div>
                <?php
                echo form_input(array(
                    'type' => 'text',
                    'id' => 'tags',
                    'name' => 'tags',
                    'placeholder' => 'Search Associate to Publish HOF',
                    'data-error' => '.errorTxtOff3'
                ));
                ?>
                <div class="errorTxtOff3"></div>
                <?php echo form_error('firstname'); ?>

                <div class="col-sm-12 ">                            
                    <div class="panel prev-hof" >
                        <?php foreach ($lastaom_employee as $result) { ?>
                            <span class="pull-right"><a href="<?php echo base_url() ?>employee/view_user/<?php echo $result['user_id']; ?>" title="View Associate"><i class="fa fa-vcard text-ccc"></i></a></span>
                            <div class="panel-body text-center">   
                                <span class="text-center">
                                    <?php if (isset($result['profileimg']) && $result['profileimg'] != '') { ?>
                                        <img class="img-responsive media-object margin-top-0 center-img" src="<?php echo base_url() . 'assets/uploads/' . $result['profileimg']; ?>">  
                                    <?php } else { ?>
                                        <img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                    <?php } ?>
                                </span>
                                <div class="margin-top-10">
                                    <!--<img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/line.png">-->                             
                                </div>
                                <p><span class="font-size-15 "><?php echo $result['userfullname']; ?></span></p>
                                <p><span class="text-info" > <?php echo $result['employeeId']; ?></span></p>
                                <p><span class="text-info" title="Designation"> <?php echo $result['position_name']; ?>, </span> <span class="text-info" title="Department"> <?php echo $result['department_name']; ?></span></p>

                            </div>
                            <span class="pull-right">
                                <i class="fa fa-pencil text-ccc" id="editComment" class="text-ccc" data-toggle="modal" class="text-primary" href="#edit-hof-comment"></i></span>
                            <div class="panel-footer text-center">

                                <span class="pull-left">
                                    <img style="height: 44px; margin-top: 10px; margin-right: 10px;" class="img-responsive" src="<?php echo base_url() ?>assets/images/hof3.png">           
                                </span>


                                <p class="text-light-gray">
                                <div class="prev_com">
                                    <?php echo $result['comment'] ?>
                                </div>
                                </p>

                                <h4 class="text-bold">Hall of Fame - <?php echo date('F Y', strtotime($result['award_date'])); ?></h4>
                            </div>

                            <!--start modal-->
                            <div class="modal fade" id="edit-hof-comment" role="dialog">
                                <div class="modal-dialog modal-sm">

                                    <div class="modal-content">   
                                        <div class="modal-header no-border">
                                            Update Record
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>

                                        <div class="modal-body user-modal-slim">
                                            <div class="panel-body text-center">   
                                                <span class="text-center">
                                                    <?php if (isset($result['profileimg']) && $result['profileimg'] != '') { ?>
                                                        <img class="img-responsive media-object margin-top-0 center-img" src="<?php echo base_url() . 'assets/uploads/' . $result['profileimg']; ?>">  
                                                    <?php } else { ?>
                                                        <img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                    <?php } ?>
                                                </span>
                                                <div class="margin-top-10">
                                                    <!--<img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/line.png">-->                             
                                                </div>
                                                <p><span class="font-size-15 "><?php echo $result['userfullname']; ?></span></p>
                                                <p><span class="text-info" > <?php echo $result['employeeId']; ?></span></p>
                                                <p><span class="text-info" title="Designation"> <?php echo $result['position_name']; ?>, </span> <span class="text-info" title="Department"> <?php echo $result['department_name']; ?></span></p>

                                            </div>
                                            <div class="col-sm-12">
                                                <?php echo form_label('Project List'); ?>

                                                <?php
                                                echo form_dropdown(array('id' => 'project_id',
                                                    'name' => 'project_id',
                                                    'class' => 'browser-default',
                                                    'data-error' => '.errorPA1'), $project_list, set_value('project_id', $result['project_id']));
                                                ?>
                                                <div class="input-field">
                                                    <div class="errorPA1"></div>
                                                </div> 
                                                <?php echo form_error('project_id'); ?> 
                                            </div> 
                                            <div class="col-sm-12">
                                                <div class="input-field">
                                                    <label>Comments</label>
                                                    <textarea id="comment-textarea" class="materialize-textarea" placeholder="Add comment in detail" required="required" ><?php echo $result['comment'] ?></textarea>
                                                    <div class="error-box-text text-danger"></div>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <button type="button" onclick="return updatehof(<?php echo $result['awd_id'] ?>)" id="publish_hof" class="btn btn-info btn-sm pull-right">Update</button>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!--end modal-->

                        <?php } ?>
                    </div>


                </div>
                <div class="clearfix"></div>
                <div class="emp_display" style="display: none">
                    <?php $this->load->view('_associate_view') ?>
                </div>
            </div>

            <div class="col-sm-8 border-left">

                <div class="row">
                    <div class="col-sm-12">
                        <h4 class="text-bold"> List of Hall of Fame</h4>
                    </div>
                </div>
                <div class="row">
                    <!--                    <div class="col-sm-6">
                                            <div class="post-search-panel">
                    
                                                <input type="text" id="keywords" placeholder="Type keywords to filter Associate" onkeyup="searchFilter()"/>
                    
                                            </div>
                                        </div>-->
                    <!--                    <div class="col-sm-3">
                                            <div id="idSort">
                    
                                                <i class="sort-data fa fa-sort-alpha-asc"><input type="hidden" value="asc" id="sortBy"></i>
                    
                                            </div>
                                        </div>-->
                </div>

                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-sm-12">

                        <div class="post-list" id="postList">
                            <table id="dt-associate-of-months" class="table">
                                <thead>
                                    <tr>                           
                                        <th >Associate Name</th>
                                        <th >Department</th>
                                        <th >Month</th>                         
                                        <th ></th>                         
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (isset($associates) && $associates != NULL) { ?>
                                        <?php foreach ($associates as $r => $assocdata) { ?>
                                            <tr id="hof_<?php echo $assocdata['awd_id'] ?>">                                
                                                <td>
                                                    <i>
                                                        <?php if (isset($assocdata['profileimg']) && $assocdata['profileimg'] != '') { ?>
                                                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $assocdata['profileimg']; ?>">  
                                                        <?php } else { ?>
                                                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                                        <?php } ?>
                                                    </i>                               
                                                    <p><?php echo $assocdata['userfullname'] ?></p>
                                                    <p><small class="text-info"><?php echo $assocdata['position_name'] ?></small></p>
                                                </td>
                                                <td><p><?php echo $assocdata['department_name'] ?></p></td>
                                                <td><p><?php echo date('M Y', strtotime($assocdata['award_date'])); ?></p></td>                           
                                                <td><i class="fa fa-trash text-ccc" onclick="deleteHofRow(<?php echo $assocdata['awd_id'] ?>)" title="Delete"></i></td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <?php // echo $this->ajax_pagination->create_links(); ?>
                        </div>
                    </div> 
                </div>  
            </div> 
        </div>

    </div>
</div>







<script>
    function searchFilter(page_num) {
        page_num = page_num ? page_num : 0;
        var keywords = $('#keywords').val();
        var sortBy = $('#sortBy').val();
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url(); ?>awards/ajaxPaginationDataAssociateOfMonth/' + page_num,
            data: 'page=' + page_num + '&keywords=' + keywords + '&sortBy=' + sortBy,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (html) {
                $('#postList').html(html);
                $('.loading').fadeOut("slow");
            }
        });
    }
</script>

<script>
    $(document).ready(function () {
        $('.year_last_use').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });


        $(".sort-data").click(function () {
            $('.sort-data').toggleClass('fa-sort-alpha-desc text-info');
            if ($('#sortBy').val() == 'asc')
                $('#sortBy').val('desc');
            else
                $('#sortBy').val('asc');
            searchFilter();

//            $('.sort-data').addClass('fa-sort-alpha-desc');
        });


        $("#editComment").click(function () {
            $('#prev_comment').val();
        });
    });
</script>

<script type="text/javascript">

    function AjaxCallEmpData(emp_id) {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>awards/getAssociateData',
            data: {'emp_id': emp_id},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.empdata == null) {

                    $('.emp_display').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.prev-hof').hide();
                    $('.emp_display').show();
                    $('.emp_display').html(parsed.empdata);
                }
            }
        });
    }

    $('#tags').keypress(function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            if ($("#tags").val().length == 0) {
                return false;
            }
            else {
                console.log('ggg');
                event.preventDefault();
                var str = $("#tags").val();
                str = str.split(",");
                var emp_id = (str[str.length - 1]);
                AjaxCallEmpData(emp_id);
            }
        }
    });

    $(function () {
        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }
        $("#tags").autocomplete({
            source: function (request, response) {
                $.getJSON("<?php echo base_url(); ?>awards/getAutocompleteAssociateList", {
                    term: extractLast(request.term)
                }, response);
            },
            select: function (event, ui) {
                var terms = split(this.value);
                terms.pop();
                terms.push(ui.item.value);
                terms.push("");
                this.value = terms.join(" ");
                var str = ui.item.value.split(",");
                var emp_id = (str[str.length - 1]);
                AjaxCallEmpData(emp_id);
                //$("#result").toggle();
                //$("#result").html('kkkkkkkk');
                return false;
            }
        });
    });

</script>
<script>

    function deleteHofRow(dId) {

        if (confirm('Are you sure, you want to delete this?')) {
            showSuccess("Record deleted successfully");
//        if()
            $("tr").remove("#hof_" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>awards/delete_hof',
                data: {'hof_id': dId},
                success: function (data) {
                    window.location.reload();
                }
            });
            return false;
        }
    }
</script>
<script>

    function updatehof(hof_id) {
        var comment = $('#comment-textarea').val();
         var project_id = $('#project_id').val();
        if ($('#comment-textarea').val() == '') {
            $('.error-box-text').html('Comment cannot be empty');
            $('#comment-textarea').focus();
            return false;
        }
        $('.error-box-text').html('');
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>awards/update_hof',
            data: {'hof_id': hof_id, 'comment': comment,'project_id':project_id},
            success: function (data) {
                showSuccess('Record updated successfully');
                $('.prev_com').html('');
                $('.prev_com').html(comment);
                $("#edit-hof-comment .close").click();

            }
        });
    }
</script>