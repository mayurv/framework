<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Appraisal extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language'));

        /* dashboard */
        $this->load->model(array('blogdetail', 'years', 'holidaydates', 'timelinecomment', 'employeeawards', 'leavetypesAllocation'));
        $this->load->model(array('frontend/notification'));
        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('candidatedetails', 'goals', 'pa_category', 'pa_subcategory', 'pa_questions', 'pa_final', 'goals_feedback', 'prefix', 'pa_status', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'workstation', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang', 'apprisal_lang'));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {
//        $this->output->cache(1);
//        $this->db->cache_on();
//        $this->output->cache(1);
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }



        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['goal_count'] = $this->goals->get_my_goal_count($user_id);
        $data['recent_goal'] = $this->goals->get_my_recent_goal($user_id);
        $data['app_status'] = $this->pa_status->get_activated_status($user_id);


        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/appraisal', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function index1() {
//        $this->output->cache(1);
//        $this->db->cache_on();
//        $this->output->cache(1);
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('master-template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_appraisal', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function activate_appriasal() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $associate_id = $this->input->post('associate_id');
            $apprisal_status = $this->input->post('apprisal_status');
            if ($apprisal_status == 1)
                $active = '1';
            else
                $active = 'null';

            $month = date('m');
            $year = date('Y');

            $app_status = $this->pa_status->get_status($associate_id, $month, $year);



            if ($app_status == 0) {
                $data = array(
                    'user_id' => $associate_id,
                    'isactive' => $active,
                    'app_status' => 'initiated',
                    'month' => $month,
                    'year' => $year,
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $this->pa_status->insert($data);
                echo json_encode(array('active' => $active));
                die;
            } else {
                $data = array(
                    'isactive' => $active,
                );
                $this->pa_status->update_pa_status($associate_id, $month, $year, $data);
                echo json_encode(array('active' => $active));
                die;
            }
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');

        $data['department_list'] = $this->department->dropdown('deptname');
        $data['employee'] = $this->employeesummary->active_apprisal_associate();
        $dataMenu['candidates'] = $this->employeesummary->get_candidate_list();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_activate_appriasal', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    function getReportingManager($user_id) {

        if (isset($user_id)) {

            // $department_id = $_POST['department_id'];

            $rep_manager = $this->employeesummary->get_all_rep_mang_by_dept_id($user_id);
//            
            $st = '';
            $st = '<option value="">Select Manager</option>';
            foreach ($rep_manager as $title) {
                if (!empty($_POST['reporting_manager_id']) && $title['id'] != $_POST['reporting_manager_id'])
                    $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
                else if (isset($_POST['reporting_manager_id']) == FALSE)
                    $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
            }

            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    public function create_goal($id = null) {
        // die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $close_date = $this->input->post('goal_date');
        $close_date = str_replace(',', '', $close_date);
        $input_date = date('Y-m-d', strtotime($close_date));


        $goalArray = array(
            'user_id' => $user_id,
            'mang_id' => $this->input->post('mang_id'),
            'name' => $this->input->post('goalname'),
            'month' => date('m'),
            'year' => date('Y'),
            'description' => $this->input->post('goaldesc'),
            'user_status' => '0',
            'completion_date' => $input_date,
            'createdby' => $user_id,
            'createddate' => date('Y-m-d H:i:s'),
        );


        if ($id != null) {
            unset($goalArray ['createddate']);
            unset($goalArray ['createdby']);
            $goalArray = array(
                'modifieddate' => date('Y-m-d H:i:s'),
            );

            $this->goals->update($id, $goalArray);
            $this->session->set_flashdata('msg', 'Goal updated successfully');
            redirect('appraisal/goals');
        } else {
            $this->goals->insert($goalArray);
            $this->session->set_flashdata('msg', 'Goal added successfully');
            redirect('appraisal/goals');
        }
    }

    public function create_feedback($id = null) {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $feedbackArray = array(
            'user_id' => $user_id,
            'goal_id' => $this->input->post('goal_id'),
            'mang_id' => $this->input->post('mang_id'),
            'self_assesment' => $this->input->post('self_assesment'),
            'self_comment' => $this->input->post('self_comment'),
            'createdby' => $user_id,
            'createddate' => date('Y-m-d H:i:s'),
        );


        $this->goals_feedback->insert($feedbackArray);
        $this->session->set_flashdata('msg', 'Feedback Requested Successfully');
        redirect('appraisal/goals_feedback');
    }

//    public function goals() {
////        $this->output->cache(1);
////        $this->db->cache_on();
////        $this->output->cache(1);
//        if (!$this->ion_auth->logged_in()) {
//            redirect('auth', 'refresh');
//        }
//
//        if ($this->session->userdata('user_id'))
//            $user_id = $this->session->userdata('user_id');
//
//        $data = $this->get_all_view_data($user_id);
//
//        //to get current login user data
//        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//
////        var_dump($data['blog_data']);die;
//        $this->template->set_master_template('master-template.php');
//        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
////        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
//        $this->template->write_view('content', 'appraisal/goals', (isset($data) ? $data : NULL));
//        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
//        $this->template->render();
//    }

    public function display_goals() {
//        $this->output->cache(1);
//        $this->db->cache_on();
//        $this->output->cache(1);
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', '_display_goal', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    /* Start save post blog data */

    public function post_blog() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {
//            var_dump($_POST);die;
            $postBlogDetail = array(
                'user_id' => $user_id,
                'description' => $this->input->post('blog_detail'),
                'title' => substr($this->input->post('blog_detail'), 0, 20),
                'publish_group_id' => $this->input->post('publish_group_id'),
                'image_url' => '',
                'video_url' => '',
                'blog_date' => date("F d, Y"),
                'blog_time' => date("g:i"),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );


            $data['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $data['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);

//            var_dump($data['current_associate_slug']);die;
            $insert_id = $this->blogdetail->insert($postBlogDetail);

            $data = $this->get_all_view_data($user_id);
            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData));
            die;
        }
    }

    public function get_blogs() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $data = $this->get_all_view_data($user_id);
        if (isset($_POST)) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['current_status']) {
//                var_dump($_POST['current_status']);die;
                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status']);
            } else
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
        }
        if ($_SERVER['REQUEST_METHOD'] == 'GET') {

            $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);
        }

        $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
        echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        die;
    }

    /* End save post blog data */

    /* Start save post blog data */



    /* End save post blog data */

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole']);

        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);
        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->workstation->dropdown('work_station_code'));
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
        $data['department_id'] = $data['user_summary']['department_id'];
        $data['emprole'] = $data['user_summary']['emprole'];

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], 3);
        $data['position_list'] = $this->employees->get_all_position_by_id($data['user_summary']['jobtitle_id']);

        //Associate Holiday & Leaves
//        $data['holiday'] = $this->employeesholiday->get_by_id($associate_id);
//        $data['leaves'] = $this->employeesleave->get_by_id($associate_id);
//echo $this->db->last_query();die;
        //Associate Communication & Personal Details
        $data['personal_detail'] = $this->personaldetails->get_by_id($associate_id);
//        echo $this->db->last_query();die;
        $data['communication_detail'] = $this->communication->get_by_id($associate_id);
//        var_dump($data['leaves']);die;
//        var_dump($associate_id);die;
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = (array('' => 'Select Hobbies', 'disabled' => 'disabled') + $this->hobbies->dropdown('hobbies_title'));

        /* Document */
        $data['document_details'] = $this->documents->get_by_id($associate_id);

        /* job history */
        $data['jobhistroy_details'] = NULL;
//        var_dump($data['user_summary']);die;
        /* Experience */
        $data['tag_type'] = (array('' => 'Select Tag')) + $this->tag->dropdown('tag_name');
        $data['experience_details'] = $this->experiencedetails->get_by_id($associate_id);
//        var_dump($data['user_summary']['department_id']);die;


        /* Dashboard */
        $data['publish_group'] = (array('0' => 'All Department')) + (array($data['user_summary']['department_id'] => $data['user_summary']['department_name'])) + (array('99' => 'Only Me'));
        $data['timeline_comment'] = $this->timelinecomment->get_by_id($associate_id);
//        $data['comment_data'] = $this->timelinecomment->get_by_id($associate_id);
//        var_dump($data['timeline_comment']);
//        die;
        $data['hall_of_fame'] = $this->employeeawards->hall_of_fame();
        $data['leaves'] = $this->leavetypesAllocation->get_leaveList($associate_id);
        $data['balnce_leaves'] = $this->leavetypesAllocation->get_balanceLeaves($associate_id);

        return $data;
    }

    /* Autogenerate Employee ID  */

    public function _get_employeeid() {

        $this->load->model(array('employees'));
        $curId = $this->employees->get_employee_id();

        $new_var = (int) substr($curId->employeeId, 4, strpos($curId->employeeId, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

    public function delete_post_blog() {
        if (isset($_POST['delete_post_id'])) {
            $post_id = $_POST['delete_post_id'];
            $this->blogdetail->delete($post_id);
            echo $this->db->last_query();
            die;
            $this->timelinecomment->delete_by_blog_id($post_id);
        }
    }

    public function add_comment() {
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (isset($_POST)) {

            $dataPostComment = array(
                'user_id' => $_POST['associate_id'],
                'blog_id' => $_POST['blog_id'],
                'comment' => $_POST['comment'],
                'comment_date' => date("F d, Y"),
                'comment_time' => date("g:i A"),
                'createdby' => $_POST['associate_id'],
                'createddate' => date('Y-m-d H:m:s'),
            );
//            echo '<pre>',  print_r($dataPostComment);die;
            $this->timelinecomment->insert($dataPostComment);
            $data = $this->get_all_view_data($user_id);

            if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['current_status']) {
//                var_dump($_POST['current_status']);die;
                $data['blog_data'] = NULL;
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id'], $_POST['current_status']);
            } else
                $data['blog_data'] = $this->blogdetail->get_blog_data($user_id, $data['user_summary']['department_id']);

            $timelineData = $this->load->view('blog/_timeline_div', $data, TRUE);
//            $timelineData = array(
//                'blog_div' => $timelineData
//            );
//             echo '<pre>',print_r($timelineData);
            echo json_encode(array('content' => $timelineData, 'count' => count($data['blog_data'])));
        }
    }

    public function goals() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['user_summary']['department_id'], $data['user_summary']['emprole']);


        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['my_goals'] = $this->goals->get_my_goalsList($user_id);
        $data['my_teamGoals'] = $this->goals->get_my_team_goalsList($user_id);

        //var_dump($data['my_goals']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        //$this->template->write_view('content', 'appraisal/_view_goals', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function update_progress() {
        // var_dump($_POST);die;
        $goal_id = $this->input->post('goal_id');

        $update_array = array(
            'user_progress' => $this->input->post('goal_progress'),
            'remark' => $this->input->post('remark'),
            'user_status' => '1',
            'goal_submitted_date' => date('Y-m-d H:m:s'),
        );

        $update_goal = $this->goals->update_goal($goal_id, $update_array);
        $this->session->set_flashdata('msg', 'Goal submitted successfully');

        redirect('appraisal/goals');
    }

    public function add_feedback() {
        //  var_dump($_POST);die;
        $goal_id = $this->input->post('goal_id');

        $update_array = array(
            'mang_status' => $this->input->post('mang_status'),
            'mang_comment' => $this->input->post('mang_comment'),
            'feedback_status' => '1',
            'mang_createddate' => date('Y-m-d H:m:s'),
        );

        $update_goal = $this->goals_feedback->update_manager_feedback($goal_id, $update_array);
        $this->session->set_flashdata('msg', 'Feedback send successfully');

        redirect('appraisal/goals_feedback');
    }

    public function feedback() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_feedback', (isset($data) ? $data : NULL));
//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function review() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_reviews', (isset($data) ? $data : NULL));
//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function developmentplan() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_developmentplan', (isset($data) ? $data : NULL));
//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function assesment() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);
        $data['my_requested_feedback'] = $this->goals_feedback->get_my_requestedFeedbackList($user_id);

        $data['current_apprisal'] = $this->pa_status->get_user_status($user_id);
        if ($data['current_apprisal']['app_status'] == 'ass_completed') {
            $ass_id = $data['current_apprisal']['id'];

//            echo $ass_id;die;
            $data['ass_ratings'] = $this->pa_questions->get_assessement_rating($user_id, $ass_id);
            $data['assessment_status'] = $data['current_apprisal']['app_status'];
//            var_dump($data['ass_ratings']);
        }


        $data['pa_category'] = $this->pa_category->get_category_list();
        $data['pa_subcategory'] = $this->pa_subcategory->get_subcategory_list();
        $data['my_team_assesment'] = $this->pa_status->get_team_assesment_List($user_id);
//        var_dump($data['my_team_assesment']);die;
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_assesment', (isset($data) ? $data : NULL));
//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function submit_assesment() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        $arr = array();
        $splited = array();
        $pa_category = $this->pa_category->get_category_list();
        $pa_subcategory = $this->pa_subcategory->get_subcategory_list();
        foreach ($pa_category as $category) {
            foreach ($pa_subcategory as $subcategory) {
//                echo $category['id'] . '-' . $subcategory['cat_id'] . '<br>';
                if ($category['id'] == $subcategory['cat_id']) {

                    if (isset($_POST['associaterate' . $subcategory['id'] . '_' . $category['id']])) {
                        $arr = 'associaterate' . $subcategory['id'] . '_' . $category['id'];
                        $splited = $this->multiexplode(array("associaterate", "_"), $arr);
                        $self_rating = array(
                            'user_id' => $user_id,
                            'q_id' => $splited[1],
                            'assessment_id' => $this->input->post('assessment_id'),
                            'cat_id' => $splited[2],
                            'self_rating' => $_POST['associaterate' . $subcategory['id'] . '_' . $category['id']],
                            'self_createdby' => $user_id,
                            'self_createddate' => date('Y-m-d'),
                        );

                        $this->pa_questions->insert($self_rating);
                    }
                }
            }
        }


        foreach ($pa_category as $category) {
            if (isset($_POST['comment' . $category['id']])) {
                $arr = 'comment' . $category['id'];
                $splited = $this->multiexplode(array("comment"), $arr);
                $self_comment[] = array(
                    'user_id' => $user_id,
                    'cat_id' => $splited[1],
                    'assessment_id' => $this->input->post('assessment_id'),
                    'self_comment' => $_POST['comment' . $category['id']],
                    'self_createdby' => $user_id,
                    'self_createdate' => date('Y-m-d'),
                );
            }
        }



        $avg_rating = $this->pa_questions->get_avg_rating($user_id);
        foreach ($avg_rating as $key => $ratingData) {
            $self_comment[$key]['self_avg_rating'] = $ratingData['avg_selfrating'];
            $this->pa_final->insert($self_comment[$key]);
        }

        $pa_status_array = array(
            'app_status' => 'ass_completed',
            'associate_date' => date('Y-m-d')
        );

        $curr_appriasal = $this->pa_status->get_current_apprisal($user_id);
        $month = $curr_appriasal['month'];
        $year = $curr_appriasal['year'];

        $this->pa_status->update_status($pa_status_array, $user_id, $month, $year);

        $this->session->set_flashdata('msg', 'Assesment submitted successfully');
        redirect('appraisal/assesment');
    }

    public function goals_feedback() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump( $data['emprole']);die;
        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['user_summary']['department_id'], $data['user_summary']['emprole']);
//        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], 4);

        $data['goal_dropdown'] = $this->goals->get_my_goalsListdropdown($user_id);
        $data['my_requested_feedback'] = $this->goals_feedback->get_my_requestedFeedbackList($user_id);
        $data['my_teamrequested_feedback'] = $this->goals_feedback->get_my_teamrequestedFeedbackList($user_id);
        //var_dump($data['goal_dropdown']);

        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));

//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));

        $this->template->write_view('content', '_goals_feedabck_overview', (isset($data) ? $data : NULL));

//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    public function goals_report() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_goals_report', (isset($data) ? $data : NULL));
        // $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }

    function multiexplode($delimiters, $string) {
        //  var_dump($delimiters);
        //  var_dump($string);die;
        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return $launch;
    }

    public function reports() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data = $this->get_all_view_data($user_id);

        $data['current_apprisal'] = $this->pa_status->get_user_status($user_id);
        $ass_id = $data['current_apprisal']['id'];

        $data['ass_report'] = $this->pa_final->get_assesment_report($user_id, $ass_id);
        //  echo $user_id.$ass_id;
//var_dump($data['ass_report']);
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

//        var_dump($data['blog_data']);die;
        $this->template->set_master_template('box_template.php');
        $this->template->write_view('header', 'frontend/header', (isset($data) ? $data : NULL));
//        $this->template->write_view('sidebar', 'frontend/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'appraisal/_reports', (isset($data) ? $data : NULL));
//        $this->template->write_view('content', 'appraisal/_view_goals_overview', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'frontend/footer', '', TRUE);
        $this->template->render();
    }
    function getdata() 
        { 
        $data = $this->pa_status->get_all_fruits(); 
 
        //         //data to json 
 
        $responce->cols[] = array( 
            "id" => "", 
            "label" => "Topping", 
            "pattern" => "", 
            "type" => "string" 
        ); 
        $responce->cols[] = array( 
            "id" => "", 
            "label" => "Total", 
            "pattern" => "", 
            "type" => "number" 
        ); 
        foreach($data as $cd) 
            { 
            $responce->rows[]["c"] = array( 
                array( 
                    "v" => "$cd->fruits_name", 
                    "f" => null 
                ) , 
                array( 
                    "v" => (int)$cd->quantity, 
                    "f" => null 
                ) 
            ); 
            } 
 
        echo json_encode($responce); 
        } 
    

}
