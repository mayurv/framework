   <div class="row">
                                <div class="col-sm-12 white-bg">
                                <div class="all-padding-15">
                                    <h2> Development plans</h2>

                                    <!--1st dashboard here start --> 
                                    <div class="row">
                                        <div class="col-sm-6">            
                                            <div class="info-box">
                                                <div class="panel">
<div id="demo-step-wz">
<div class="wz-heading wz-w-label bg-grey">
<div class="progress progress-xs progress-wizard">
<div class="progress-bar progress-bar-dark active" style="width: 0%; margin: 0px 16.6667%;"></div>
</div>
<ul class="wz-steps wz-icon-bw wz-nav-off text-lg">
<li class="col-xs-4 active">
<a aria-expanded="true" data-toggle="tab" href="#demo-step-tab1">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">1</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Create development plan</small>
</a>
</li>
<li class="col-xs-4">
<a data-toggle="tab" href="#demo-step-tab2">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">2</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Add strengths and goals</small>
</a>
</li>
<li class="col-xs-4">
<a data-toggle="tab" href="#demo-step-tab3">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">3</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Finalise the development plan</small>
</a>
</li>
</ul>
</div>
<form class="form-horizontal">
<div class="panel-body">
<div class="tab-content no-border">
<div class="tab-pane active in" id="demo-step-tab1">
<h4>Create a new development plan</h4>
<div class="margin-bottom-10">
The process starts with the employee (you) creating your development plan. You can also create development plans for your direct reports and line of sight. A development plan contains the following key points:
</div>
<div class="margin-bottom-15 margin-top-15">
<table class="table table-striped">
<thead>
<tr>
<th class="col-md-2">Item</th>
<th class="col-md-10">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>Summary of Responsibilities</td>
<td>Include a brief summary of your current responsibilities.</td>
</tr>
<tr>
<td>Signature Strengths</td>
<td>Identify five key signature strengths you possess and rely on to add value.</td>
</tr>
<tr>
<td>Feedback Summary</td>
<td>Displays summary feedback from your feedback providers for your reference.</td>
</tr>
<tr>
<td>Individual Development Goals</td>
<td>Identify development goals that are meaningful, measureable, and memorable.</td>
</tr>
<tr>
<td>Baseline</td>
<td>Identify your baseline, which reflects your current state or starting point of area for development.</td>
</tr>
<tr>
<td>Action Steps</td>
<td>Display 3-5 intended actions to achieve development goals. Be creative and specific, and include estimated timeframes. Indicate a percentage completion over time.</td>
</tr>
<tr>
<td>Identify Support</td>
<td>Collaborate with your manager to ensure support. Seek out mentors and coaches related to development goals.</td>
</tr>
</tbody>
</table>
</div>
<div class="pull-left">
<a class="btn btn-info btn-theme btn-md" data-toggle="modal" data-target="#developement-plan" data-remote="true">
    <i class="fa fa-plus-circle fa-lg margin-right-5"></i>Create a development plan
</a>
</div>
</div>
<div class="tab-pane fade" id="demo-step-tab2">
<h4>Add strengths and goals</h4>
<div class="margin-bottom-10">
<p>You add individual signature strengths to your development plan. These should be recorded for the current period and can be modified/re-arranged.</p>
<p>You can then add development goals. These goals should contain 1-3 action points, and include a baseline estimate of where you are today, and an indication of what support requirements you need to achieve the development target.</p>
</div>
</div>
<div class="tab-pane mar-btm" id="demo-step-tab3">
<h4>Finalise the development plan</h4>
<div class="margin-bottom-10">
<p>You can request input from your manager/supervisor on your development plan before finalising it. He/she will be able to edit and update the plan from their own PeopleGoal account.</p>
<p>Once you're happy with the plan you can update the status to 'Final' and save it!</p>
</div>
</div>
</div>
</div>
<div class="panel-footer text-right">
<div class="box-inline">
<button class="previous btn btn-info btn-theme disabled" type="button">Previous</button>
<button class="next btn btn-info btn-theme" type="button">Next</button>
<button class="finish btn btn-info btn-theme" disabled="" style="display: none;" type="button">Finish</button>
</div>
</div>
</form>
</div>
</div>
                                            </div>
                                            <!-- /.col -->
                                        </div>
                                        <!--1st dashboard here end --> 
                                    </div>
                                </div>
                                </div>
                                </div>
<?php $this->load->view('modal/_add_developmentplan')?>

<!--step wizard css-->
<script src="<?php echo base_url('frontend/plugins/goal-step/js/application-main.js') ?>"></script>
<script src="<?php echo base_url('frontend/plugins/goal-step/js/v2.js') ?>"></script>
<!--step wizard css-->