<link href="<?php echo base_url('assets/css/pwerformance.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('assets/css/performance-theme.css'); ?>" rel="stylesheet" type="text/css"/>
<script src="//d3n380booc75fg.cloudfront.net/assets/application-26b040b9491d13d260cf2c1a8fb0a2be.js"></script>
<script src="https://js.stripe.com/v2/"></script>
<div class="main-bg">
<div class="row">
    <div class="col-lg-6">
        <div id="page-title">
            <h1 class="page-header text-overflow">Goals</h1>
        </div>
     
    </div>
    <div class="col-lg-6">
        <span class="btn-group margin-top-20 pull-right margin-right-20">
            <a class="active btn btn-active-default btn-default needs-loading" data-disable-with="Loading ..." href="/goals">
                <i class="fa fa-user margin-right-5"></i>
                Your goals
            </a>
            <a class="btn btn-default needs-loading" data-disable-with="Loading ..." href="/goals/all-colleagues">
                <i class="fa fa-sitemap margin-right-5"></i>
                All colleagues
            </a>
        </span>
        <span class="btn-group margin-top-20 pull-right margin-right-20">
            <button class="btn btn-default" data-toggle="dropdown">
                <i class="fa fa-cogs fa-fw margin-right-5"></i>
                Goal actions
            </button>
            <button class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu pull-left">
                <li>
                    <a class="needs-loading" data-remote="true" href="/goals/remote_new_goal_modal"><i class="fa fa-plus fa-fw"></i>
                        New individual goal
                    </a></li>
                <li class="divider"></li>
                <li>
                    <a class="needs-loading" data-remote="true" href="/goals/remote_new_individual_goal_modal"><i class="fa fa-plus fa-fw"></i>
                        New colleague goal
                    </a></li>
                <li>
                    <a class="needs-loading" data-remote="true" href="/goals/remote_new_single_teamgoal_modal"><i class="fa fa-plus fa-fw"></i>
                        New team goal
                    </a></li>
                <li>
                    <a class="needs-loading" data-remote="true" href="/goals/remote_new_single_departmentgoal_modal"><i class="fa fa-plus fa-fw"></i>
                        New department goal
                    </a></li>
                <li class="divider"></li>
                <li>
                    <a href="/goals?sort=name">
                        <i class="fa fa-list fa-fw margin-right-5"></i>
                        Sort by name
                    </a>
                </li>
                <li>
                    <a href="/goals?sort=created_at">
                        <i class="fa fa-calendar fa-fw margin-right-5"></i>
                        Sort by created
                    </a>
                </li>
                <li>
                    <a href="/goals?sort=target_date">
                        <i class="fa fa-clock-o fa-fw margin-right-5"></i>
                        Sort by target date
                    </a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="/reports/team-goals">
                        <i class="fa fa-users fa-fw margin-right-5"></i>
                        Show all team goals
                    </a>
                </li>
                <li>
                    <a href="/reports/department-goals">
                        <i class="fa fa-sitemap fa-fw margin-right-5"></i>
                        Show all department goals
                    </a>
                </li>
                <li>
                    <a href="/goals/goals_xls.xls">
                        <i class="fa fa-file-excel-o fa-fw margin-right-5"></i>
                        Export to Excel
                    </a>
                </li>
                <li>
                    <a href="/goals.pdf" target="_blank">
                        <i class="fa fa-file-pdf-o fa-fw margin-right-5"></i>
                        Export goals to PDF
                    </a>
                </li>
            </ul>
        </span>
    </div>
</div>

<div id="page-content">
    <div class="tab-content">
        <div class="tab-pane fade in active" id="personal-goals">
            <div class="padding-md">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="panel">
                                    <div id="demo-step-wz">
                                        <div class="wz-heading wz-w-label bg-grey">
                                            <div class="progress progress-xs progress-wizard">
                                                <div class="progress-bar progress-bar-dark active" style="width: 0%; margin: 0px 16.6667%;"></div>
                                            </div>
                                            <ul class="wz-steps wz-icon-bw wz-nav-off text-lg">
                                                <li class="col-xs-4 active">
                                                    <a aria-expanded="true" data-toggle="tab" href="#demo-step-tab1_goals">
                                                        <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                            <span class="wz-icon icon-txt text-bold">1</span>
                                                            <i class="wz-icon-done fa fa-check"></i>
                                                        </span>
                                                        <small class="wz-desc box-block margin-top-5">Set goals</small>
                                                    </a>
                                                </li>
                                                <li class="col-xs-4">
                                                    <a data-toggle="tab" href="#demo-step-tab2_goals" aria-expanded="false">
                                                        <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                            <span class="wz-icon icon-txt text-bold">2</span>
                                                            <i class="wz-icon-done fa fa-check"></i>
                                                        </span>
                                                        <small class="wz-desc box-block margin-top-5">Approve goals</small>
                                                    </a>
                                                </li>
                                                <li class="col-xs-4">
                                                    <a data-toggle="tab" href="#demo-step-tab3_goals" aria-expanded="false">
                                                        <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                            <span class="wz-icon icon-txt text-bold">3</span>
                                                            <i class="wz-icon-done fa fa-check"></i>
                                                        </span>
                                                        <small class="wz-desc box-block margin-top-5">Update goals</small>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <form class="form-horizontal">
                                            <div class="panel-body">
                                                <div class="tab-content">
                                                    <div class="tab-pane active in" id="demo-step-tab1_goals">
                                                        <h4>You set your own individual goals</h4>
                                                        <div class="margin-bottom-10">
                                                            You start by setting your own individual goals for the period. PeopleGoal helps you to set SMART goals:
                                                        </div>
                                                        <div class="margin-bottom-15 margin-top-15">
                                                            <table class="table table-striped col-md-6">
                                                                <thead>
                                                                    <tr>
                                                                        <th>SMART Attribute</th>
                                                                        <th>PeopleGoal asks you:</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr>
                                                                        <td>Specific</td>
                                                                        <td>What is specific about the goal?</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Measurable</td>
                                                                        <td>How should the goal be measured?</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Attainable</td>
                                                                        <td>How will the goal be achieved?</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Relevant</td>
                                                                        <td>Why is the goal relevant?</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Time-bound</td>
                                                                        <td>When is the goal due to be achieved?</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <div></div>
                                                            If you are a manager or an admin you can also create goals for your team members or whole departments.
                                                        </div>
                                                        <div class="pull-left">
                                                            <a class="needs-loading btn btn-info btn-theme btn-md" data-toggle="modal" href="#newGoalModal">
                                                                <i class="fa fa-plus-circle fa-lg margin-right-5"></i>
                                                                Create your first individual goal
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane fade" id="demo-step-tab2_goals">
                                                        <h4>Your manager reviews your goal</h4>
                                                        <div class="margin-bottom-10">
                                                            Your manager will be sent an email asking him/her to review and approve your goal. This is done to ensure that you and your manager are in alignment with what you need to achieve in this performance period.
                                                        </div>
                                                        <div class="margin-bottom-20 margin-top-20">
                                                            <button class="btn btn-success btn-md blacktip" data-placement="right" data-title="Your manager can approve the goal" data-trigger="hover" data-original-title="" title="">
                                                                <i class="fa fa-check-circle margin-right-5"></i>
                                                                Approve
                                                            </button>
                                                            <button class="btn btn-warning btn-md margin-left-10 blacktip" data-placement="right" data-title="Or your manager can reject the goal" data-trigger="hover" data-original-title="" title="">
                                                                <i class="fa fa-times-circle margin-right-5"></i>
                                                                Reject
                                                            </button>
                                                        </div>
                                                        <div class="margin-bottom-10">
                                                            Your manager will also be promted to provide comments to allow you to improve the quality of the goal (especially helpful when your goal has been rejected!). You can then make updates and re-submit it to your manager.
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane mar-btm" id="demo-step-tab3_goals">
                                                        <h4>Update your goal progress</h4>
                                                        <div class="margin-bottom-10">
                                                            You can provide regular updates on your goal progress by clicking on 'goals' in the sidebar. You can provide a written update and/or a progress update (percentage complete). It's important to keep your goal progress up-to-date!
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel-footer text-right">
                                                <div class="box-inline">
                                                    <button class="previous btn btn-info btn-theme btn-theme disabled" type="button">Previous</button>
                                                    <button class="next btn btn-info btn-theme btn-theme" type="button" style="display: inline-block;">Next</button>
                                                    <a class="needs-loading btn btn-info btn-theme finish btn-md" data-remote="true" href="/goals/remote_new_goal_modal" style="display: none;">
                                                        <i class="fa fa-plus-circle fa-lg margin-right-5"></i>
                                                        Create your first individual goal
                                                    </a></div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php $this->load->view('_create_goal');?>

