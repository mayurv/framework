<div class="row">
    <?php // var_dump($pa_subcategory) ?>
    <?php // var_dump($ass_ratings) ?>
    <div class="col-sm-8"> 
        <!-- approach to work -->
        <form action="<?php echo base_url() ?>/appraisal/submit_assesment" method="post">
            <!--<input id="id_associate_total" value="">-->
            <!--<input id="id_manager_total" value="">-->
            <!--<input id="id_hr_total" value="">-->
            <?php
            $flag = '';
            foreach ($pa_category as $category) {
                ?>
                <?php if ($flag != '')  ?>
                <div class="first-div-<?php echo $category['id'] ?>" style="display:<?php echo $flag ?>">                    
                    <?php //var_dump($category['id']);   ?>
                    <div class="approach-bg">
                        <h3 class="page-header"> <?php echo $category['category_name'] ?></h3>
                        <div class="exam-content">
                            <!-- form start here -->

                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->
                            <?php
                            if ($assessment_status == 'ass_completed') {
                                $pa_subcategory = $ass_ratings;
                            }
                            foreach ($pa_subcategory as $subcategory) {

                                if ($category['id'] == $subcategory['cat_id']) {
                                    ?>
                                    <?php // var_dump($subcategory);    ?>
                                    <!-- row start here -->
                                    <div class="row margin-bottom-10">
                                        <!-- 1st question column start here -->
                                        <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                            <p><?php echo $subcategory['name'] ?></p>
                                            <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                        </div>
                                        <!-- 1st question column end here -->
                                        <!-- 2nd  user rating column start here -->
                                        <div class="col-md-2 col-sm-3 padding-top-bottom-5">

                                            <?php if ($assessment_status == 'ass_completed') { ?>
                                                <?php// echo $subcategory['self_rating'] ?>
                                                <?php
                                                $x = 1;
                                                $rating = $subcategory['self_rating'];
                                                ?>
                                                <?php for ($x = 1; $x <= $rating; $x++) { ?>
                                                    <i class="fa fa-star text-starrr"></i>
                                                <?php } ?>
                                                <?php if (strpos($rating, '.')) { ?>

                                                    <i class="fa fa-star-half-full text-starrr"></i>
                                                    <?php
                                                    $x++;
                                                }
                                                ?>
                                                <?php while ($x <= 5) { ?>
                                                    <i class="fa fa-star-o text-starrr"></i>
                                                    <?php
                                                    $x++;
                                                   
                                                }
                                                ?> 
                                                    <p><small class="clr-999">Your rating was  
                                                        <?php echo $rating ?></small></p>
                                            <?php } else { ?>
                                                <div class="starrr" id="aw1<?php echo $subcategory['id'] ?>"></div>
                                                <input id="associate_rate<?php echo $subcategory['id'] ?>" type="text" name="associaterate<?php echo $subcategory['id'] ?>_<?php echo $category['id'] ?>" value="" hidden>
                                                <p class="your-choice-was1<?php echo $subcategory['id'] ?> text-italic" style="display: none;">
                                                    <small class="clr-999">Your rating was 
                                                        <span class="choice1<?php echo $subcategory['id'] ?>"></span></small>
                                                </p>  
                                            <?php } ?>

                                        </div>
                                        <!-- 2nd  user rating column end here -->
                                        <!-- 3rd  manager rating column start here -->
                                        <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                            <div class="starrr" id="aw2<?php echo $subcategory['id'] ?>"></div>
                                            <input id="mng_rate<?php echo $subcategory['id'] ?>" type="text" name="mng_rate<?php echo $subcategory['id'] ?>" value="" hidden>
                                            <p class="your-choice-was2<?php echo $subcategory['id'] ?> text-italic" style="display: none;">
                                                <small class="clr-999">Your rating was 
                                                    <span class="choice2<?php echo $subcategory['id'] ?>"></span></small>
                                            </p>                              
                                        </div>
                                        <!-- 3rd  user rating column end here -->
                                        <!-- 4th  HR rating column start here -->
                                        <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                            <div class="starrr" id="aw3<?php echo $subcategory['id'] ?>"></div>
                                            <input id="hr_rate<?php echo $subcategory['id'] ?>" type="text" name="hr_rate<?php echo $subcategory['id'] ?>" value="" hidden>
                                            <p class="your-choice-was3<?php echo $subcategory['id'] ?> text-italic" style="display: none;">
                                                <small class="clr-999">Your rating was 
                                                    <span class="choice3<?php echo $subcategory['id'] ?>"></span></small>
                                            </p>                              
                                        </div>
                                        <!-- 4th  HR rating column end here -->
                                    </div>
                                    <!-- row end here -->
                                    <?php
                                }
                            }
                            ?>

                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea name="comment<?php echo $category['id'] ?>" class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>


                            <!-- form end here -->
                        </div>                    
                    </div>                      
                    <button type="button" class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                    <button type="button" class="back btn btn-default pull-right">Back</button>
                </div>
                <!-- Result start here -->

                <!--result  end here -->
                <?php
                $flag = 'none';
            }
            ?>
            <div class="11" style="display:none;">
                <div class="approach-bg">
                    <!-- <h3 class="page-header">Result</h3> -->
                    <div class="exam-content all-padding-6p text-center">
                        <h3>Overall Assessment</h3>
                        <div>
                            <div class="box box-default collapsed-box">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Assessment Rating Description</h3>

                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-xs btn-default" data-widget="collapse"><i class="fa fa-plus"></i></button>
                                    </div>
                                </div>
                                <!-- /.box-header -->
                                <div class="box-body">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Level</th>
                                                <th>Percentile</th>
                                                <th>Description</th>
                                            </tr>
                                        </thead>
                                        <tbody class="table table-bordered">
                                            <tr>
                                                <td width="10%" class="text-danger">Level- 1</td>
                                                <td width="15%">0% ~ 20%</td>
                                                <td>IMPROVEMENT NEEDED Shall be under observation for 1 more month.  After which he/she may fall in Level-2 or Level-3 based on their performance.</td>
                                            </tr>
                                            <tr>
                                                <td class="text-warning">Level- 2</td>
                                                <td>21% ~ 40%</td>
                                                <td>MARGINAL Shall be given nominal increment and should be under the observation of Manager always.</td>
                                            </tr>
                                            <tr>
                                                <td class="text-info">Level- 3</td>
                                                <td>41% ~ 60%</td>
                                                <td>ACHIEVES EXPECTATIONS Shall be recommended for regular increment</td>
                                            </tr>
                                            <tr>
                                                <td class="text-primary">Level- 4</td>
                                                <td>61% ~ 90%</td>
                                                <td>EXCEEDS EXPECTATIONS Shall be promoted and given increment.</td>
                                            </tr>
                                            <tr>
                                                <td class="text-success">Level- 5</td>
                                                <td>91% ~ 100%</td>
                                                <td>OUTSTANDING Additionally with promotion and increment also incentives can be provided.</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!-- /.row -->
                                </div>
                                <!-- /.box-body -->

                            </div>


                            <div class="overall_assessment"></div>
                        </div>                                    

                        <div class="col-sm-12 margin-top-10" id="test">
                            <h3>Thank You !</h3>
                            <p class="text-center"><i class="text-white  fa fa-check-circle fa-4x"></i></p>
                            <p class="text-center text-white ">You have Given</p>
                            <h3><span id="rating"></span>/<span id="outof"></span></h3>
                            <div id="total_average"></div>
                        </div>

                        <input name="assessment_id" value="<?php echo $current_apprisal['id'] ?>" hidden>
                        <?php ?>

                                    <!--<p class="margin-top-bottom-10 text-center">Points to Yourself</p>-->
                        <div class="col-sm-12 text-center"><button class="btn btn-default margin-top-bottom-30">Submit</button></div>
                    </div>                   
                </div> 
            </div>
            <!-- approach to work -->
            <!--<button class="pull-right btn btn-sm btn-warning">Submit</button>-->
        </form>
    </div>
    <style>
        #test{ 
            background-image: url(http://demo_ci.com/assets/images/success-pa.png);
            background-repeat: repeat-y;
            width: 100%;
            background-color: #8BC34A;
            border: 1px solid #;
            height: auto;
            box-shadow: 0 1px 39px 0px #999!important;

        }
    </style>
    <div class="col-sm-4 padding-top-40">


        <?php
//var_dump($my_requested_feedback);
        foreach ($my_requested_feedback as $goal_data) {
            ?>
            <div class="box box-primary">
                <div class="box-header with-border bg-gray-light">



                    <div class="row">
                        <div class="col-sm-9">
                            <h3 class="box-title font-size-16 font-w-500 margin-top-bottom-10"><?php echo $goal_data['name'] ?></h3>
                        </div>
                        <div class="col-sm-1 padding-top-10">


                            <div class="box-tools">

                                <div class="tooltip">
                                    <i class="fa fa-angle-down fa-lg" data-widget="collapse" style="cursor:pointer"></i> <span class="tooltiptext">Expand</span>
                                </div>

                            </div>


                        </div>
                        <div class="col-sm-2 padding-top-10"> 
                            <div class="label label-primary"><?php echo $goal_data['user_progress'] ?>%</div>
                        </div>
                    </div>

                </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <div class="row">
                        <div class="col-sm-12 margin-top-bottom-15">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Manager Name</th>
                                        <th>Comment</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo $goal_data['userfullname'] ?></td>
                                        <td><?php echo $goal_data['mang_comment'] ?></td>
                                        <td><?php echo $goal_data['mang_createddate'] ?></td>
                                        <?php
                                        $data_remark = array(1 => 'Significantly underperforms',
                                            2 => 'Needs improvement',
                                            3 => 'Meets expectations',
                                            4 => 'Exceeds expectations',
                                            5 => 'Top performer'
                                        );
                                        ?>
                                        <?php $remark = $data_remark[$goal_data['mang_status']] ?>
                                        <td><?php echo $remark ?></td>
                                    </tr>



                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                <!-- /.box-body -->


            </div>
            <!-- /.box -->

        <?php } ?>
    </div>
</div>