<div class="modal fade in" id="newGoalModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" class="close blacktip" data-dismiss="modal" data-placement="right" data-title="Close" data-trigger="hover" type="button" data-original-title="" title="">×</button>
                <h4 class="modal-title">
                    New individual goal
                </h4>
            </div>
            <form class="simple_form goal-form" id="new_goal" enctype="multipart/form-data" action="/goals" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="✓"><input type="hidden" name="authenticity_token" value="JbUH5vyDrQz5dtByXw1L0Mbpz7KwEYSjDEkD4eryL76sZYoHOBPQMIBmzq/vr8uKqwknNPDhV7PhRIki6ifKTw=="><div class="form-horizontal form-border">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Your new goal details</h5>
                                <p>Please provide a name and short description for your new goal.</p>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group string required goal_short_description"><label class="string required control-label margin-bottom-5" for="goal_short_description"><abbr title="required">*</abbr> Goal name</label><div class="controls"><input class="string required form-control input-sm blacktip counter1" autocomplete="off" maxlength="255" data-placement="top" data-trigger="focus" data-title="Enter a short, memorable name for the goal" required="required" aria-required="true" size="255" type="text" name="goal[short_description]" id="goal_short_description" data-original-title="" title=""></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter1" class="safe">170</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group text optional goal_long_description"><div class="controls"><textarea class="text optional form-control input-sm blacktip counter2" autocomplete="off" maxlength="255" data-placement="top" data-trigger="focus" data-title="This is a free text field for the description of your goal" placeholder="Goal description" name="goal[long_description]" id="goal_long_description" data-original-title="" title=""></textarea></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter2" class="safe">255</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group select optional goal_parent_goal_id"><label class="select optional control-label margin-bottom-5" for="goal_parent_goal_id">Select a team/department goal to align to</label><div class="controls"><div class="select2-container select optional select2 blacktip" id="s2id_goal_parent_goal_id" title=""><a href="javascript:void(0)" class="select2-choice select2-default" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-1">Select a team/department goal</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen1" class="select2-offscreen">Select a team/department goal to align to</label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-1" id="s2id_autogen1"><div class="select2-drop select2-display-none select2-with-searchbox">   <div class="select2-search">       <label for="s2id_autogen1_search" class="select2-offscreen">Select a team/department goal to align to</label>       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input" role="combobox" aria-expanded="true" aria-autocomplete="list" aria-owns="select2-results-1" id="s2id_autogen1_search" placeholder="">   </div>   <ul class="select2-results" role="listbox" id="select2-results-1">   </ul></div></div><select class="select optional select2 select2-container blacktip select2-offscreen" autocomplete="off" placeholder="Select a team/department goal" name="goal[parent_goal_id]" id="goal_parent_goal_id" data-original-title="" title="Select a team/department goal to align to" tabindex="-1"><option value=""></option>
                                                </select></div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h5>Your new goal attributes</h5>
                                <p>This is a series of questions designed to ensure that your goals are SMART (Specific, Measurable, Attainable, Relevant and Time-bound)</p>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group string optional goal_specific"><div class="controls"><input class="string optional form-control input-sm blacktip counter3" autocomplete="off" maxlength="170" data-placement="top" data-trigger="focus" data-title="What do you want to accomplish? Why? Who is involved? Where will it be achieved?" placeholder="What is specific about your goal?" size="170" type="text" name="goal[specific]" id="goal_specific" data-original-title="" title=""></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter3" class="safe">170</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group string optional goal_measurable"><div class="controls"><input class="string optional form-control input-sm blacktip counter4" autocomplete="off" maxlength="170" data-placement="top" data-trigger="focus" data-title="A measurable goal will usually answer questions such as: &quot;How much?&quot;, &quot;How many?&quot; or &quot;How will I know when it is accomplished?" placeholder="How will it be measured?" size="170" type="text" name="goal[measurable]" id="goal_measurable" data-original-title="" title=""></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter4" class="safe">170</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group string optional goal_attainable"><div class="controls"><input class="string optional form-control input-sm blacktip counter5" autocomplete="off" maxlength="170" data-placement="top" data-trigger="focus" data-title="An attainable goal will usually answer the question: &quot;How can the goal be accomplished?&quot;" placeholder="How will you attain/achieve your goal?" size="170" type="text" name="goal[attainable]" id="goal_attainable" data-original-title="" title=""></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter5" class="safe">170</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <div class="control-group string optional goal_relevant"><div class="controls"><input class="string optional form-control input-sm blacktip counter6" autocomplete="off" maxlength="170" data-placement="top" data-trigger="focus" data-title="A relevant goal can answer yes to these questions: &quot;Does this seem worthwhile?&quot;, &quot;Is this the right time?&quot;, &quot;Does this match our other business efforts/needs?&quot;, &quot;Are you the right person?&quot;, or &quot;Is it applicable in current socio- economic- technical environment?&quot;" placeholder="How is your goal relevant?" size="170" type="text" name="goal[relevant]" id="goal_relevant" data-original-title="" title=""></div></div>
                                        <small class="pull-right char-count">
                                            <span id="counter6" class="safe">170</span>
                                            <span>characters remaining</span>
                                        </small>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-5">
                                        <abbr>*</abbr>
                                        <span>When should the goal be achieved?</span>
                                    </div>
                                    <div class="col-md-7">
                                        <div class="control-group string required goal_due_by"><div class="controls"><input class="string required form-control input-sm datepicker blacktip" autocomplete="off" data-placement="top" data-trigger="focus" data-title="When do you expect to achieve this goal?" required="required" aria-required="true" placeholder="When do you expect to achieve your goal?" type="text" name="goal[due_by]" id="goal_due_by" data-original-title="" title=""></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="control-group hidden goal_user_id"><div class="controls"><input class="hidden form-horizontal form-border goal-form" autocomplete="off" value="12699" type="hidden" name="goal[user_id]" id="goal_user_id"></div></div>
                        <div class="control-group hidden goal_status"><div class="controls"><input class="hidden form-horizontal form-border goal-form" autocomplete="off" value="Approved" type="hidden" name="goal[status]" id="goal_status"></div></div>
                        <button aria-hidden="true" class="btn btn-md btn-default" data-dismiss="modal">Cancel</button>
                        <input type="submit" name="commit" value="Create goal" class="btn btn btn-md btn-info btn-theme" data-disable-with="Working...">
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>