<?php // var_dump($profile_summary);die;                                           ?>

<link href="<?php echo base_url(); ?>assets/css/hrms-inline-input.css" rel="stylesheet" type="text/css"/>

<!--content section start-->
<section id="main-content" class=" sidebar_shift ">
    <!--style='margin-top:60px;display:inline-block;width:100%;padding:15px 0 0 15px;'-->
    <section class="wrapper" >
        <!-- containt page row start here -->
        <div>                        
            <!--column 8 left center part start here -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
                <!-- title here -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title">
                            <div class="pull-left">
                                <h1 class="title">User Management</h1>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- title here end-->

                <!-- second row start here -->
                <div class="row">
                    <div class="col-sm-12">
                        <section class="box nobox">
                            <div class="content-body">    
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12 white-bg top-padding-10">
                                        <!--                                        <div class="well primary">
                                                                                    <h3>Perspective, Similarity <span class="semi-bold">&amp; Contrast</span>, <i>Rhythm</i> </h3>
                                                                                    A good design contains elements that lead the reader through each element in order of its significance.
                                                                                </div>-->
                                        <div class="col-md-4">

                                            <div class="uprofile-image">
                                           <!-- <img src="data/profile/user.png" class="img-responsive profile-pics-border"> -->
                                                <div id="upload-profile-pics" class="img-responsive profile-pics-border"></div>  
                                                <span style="position: absolute; color:#fff; background:rgba(0,0,0,0.5); width: 35%; border-radius: 0px 0px 5px 5px; margin: 0 30%;left: 10px;top: 15%; text-align:center; font-weight:bold;">Upload Image</span> 
                                                <div class="file-button-hide">
                                                    <input id="uploadimage" type="file" />                      
                                                </div>
                                            </div>
                                        </div>



                                        <!--User Profile left side info-->
                                        <div class="col-md-8">
                                            <div class="uprofile-name profile-form-left-padding" style="">
                                                <?php echo form_open('', array('class' => 'form-inline text-left', 'id' => 'profile-info')); ?>
                                                <!--<form class="form-inline text-left">-->
                                                <div class="row">

                                                    <div class="form-group col-sm-12">
                                                        <?php echo form_label(lang('name'), 'name', array('class' => 'form-label')); ?>:
                                                        <?php echo form_label($profile_summary->userfullname, 'userfullname', array('class' => 'form-label')); ?>
                                                    </div>                                                            

                                                    <!--<div class="form-group col-sm-12">
                                                    <?php echo form_label(lang('contact'), 'contact', array('class' => 'form-label')); ?>
                                                    <?php echo form_label($profile_summary->contactnumber ? $profile_summary->contactnumber : '-', 'contact', array('class' => 'form-label', 'id' => 'contact')); ?>
                                                    </div>-->


                                                    <div class="form-group col-sm-12">
                                                        <?php echo form_label(lang('contact'), 'contact', array('class' => 'form-label contact')); ?>:
                                                        <?php // echo "<span class='editable'>".$profile_summary->contactnumber ? $profile_summary->contactnumber:'Enter Mobile'."</span>"; ?>:
                                                        <span class="editable contact-span" id="contact"><?php echo $profile_summary->contactnumber ? $profile_summary->contactnumber : 'Enter Mobile' ?></span>
                                                    </div>

                                                    <div class="form-group col-sm-12">
                                                        <?php echo form_label(lang('email'), 'email', array('class' => 'form-label')); ?>:
                                                        <?php echo form_label($profile_summary->emailaddress ? $profile_summary->emailaddress : '-', 'contact', array('class' => 'form-label')); ?>
                                                    </div> 

                                                    <div class="form-group col-sm-12">
                                                        <?php echo form_label(lang('address'), 'address', array('class' => 'form-label')); ?>:
                                                        <div class="controls">  
                                                            <!-- <textarea class="form-control" placeholder="124/283, Hadapsar, Pune- 36" cols="5" style="width:230px;"></textarea> -->
                                                            <?php echo form_label(isset($address_detail) ? $address_detail : '-', 'address', array('class' => 'form-label')); ?>
                                                            <!--<span class="editable contact-span"><?php // echo $address_detail ? $address_detail : '-'                                         ?></span>-->
                                                        </div>
                                                    </div>

                                                </div>
                                                <!--</form>--> 
                                                <?php echo form_close(); ?>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="uprofile-content">
                                            <div class="enter_post col-md-12 col-sm-12 col-xs-12">

                                                <!-- <div class="tabs-vertical-env"> -->
                                                <!--  <ul class="nav nav-tabs vertical col-lg-3 col-md-3 col-sm-4 col-xs-4 left-aligned primary"> -->
                                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
                                                    <ul class="nav vertical">                                                    

                                                        <li class="dropdown active"><a class="dropdown-toggle" href="#" data-toggle="dropdown"> <i class="fa fa-info tab-fa-icon-right-margin"></i> Information <b class="caret"></b></a>
                                                            <ul class="dropdown-menu tab-dropdown">
                                                                <li><a href="#basic-information" data-toggle="tab">Basic Information</a></li>  
                                                                <li><a href="#personal-information" data-toggle="tab">Personal Information</a></li>
                                                                <li><a href="#contact-information" data-toggle="tab">Contact Information</a></li>      
                                                            </ul>
                                                        </li>

                                                        <li>
                                                            <a href="#documents" data-toggle="tab">
                                                                <i class="fa fa-folder-open tab-fa-icon-right-margin"></i> Documents 
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#skills" data-toggle="tab">
                                                                <i class="fa fa-asterisk tab-fa-icon-right-margin"></i> Skills 
                                                            </a>

                                                        </li>
                                                        <li>
                                                            <a href="#job-history" data-toggle="tab">
                                                                <i class="fa fa-at tab-fa-icon-right-margin"></i> Job History
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="#experience" data-toggle="tab">
                                                                <i class="fa fa-star-o tab-fa-icon-right-margin"></i> Experience
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="#education" data-toggle="tab">
                                                                <i class="fa fa-graduation-cap tab-fa-icon-right-margin"></i> Education
                                                            </a>
                                                        </li>                                                    

                                                        <li>
                                                            <a href="#visa" data-toggle="tab">
                                                                <i class="fa fa-plane tab-fa-icon-right-margin"></i> Visa
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="#holiday" data-toggle="tab">
                                                                <i class="fa fa-pencil-square-o tab-fa-icon-right-margin"></i> Holiday
                                                            </a>
                                                        </li>
                                                    </ul> 
                                                </div>                  

                                                <div class="tab-content vertical col-lg-9 col-md-9 col-sm-8 col-xs-8 left-aligned primary">

                                                    <div class="tab-pane fade in active" id="basic-information">

                                                        <form>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('employeeid'), 'employeeid', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'firstname',
                                                                        'id' => 'firstname',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $profile_summary->employeeId,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('prefix_id'), 'prefix_id', array('class' => 'form-label')); ?>:
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'prefix_id',
                                                                    'id' => 'prefix_id',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => $prefix,
                                                                    'disabled' => 'disabled'
                                                                ));
                                                                ?>
                                                                <?php // echo form_dropdown('prefix_id', $prefix, $prefix, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled'));  ?>                                                                
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('firstname'), 'firstname', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'firstname',
                                                                        'id' => 'firstname',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $profile_summary->firstname,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('lastname'), 'lastname', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'lastname',
                                                                        'id' => 'lastname',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $profile_summary->lastname,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('modeofemp'), 'modeofemp', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <?php echo form_dropdown('modeofentry', $employee_mode, $employee_mode, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                                                            </div>
                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('emprole'), 'emprole', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <?php echo form_dropdown('emprole', $employee_role, $employee_role, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                                                            </div>


                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('email'), 'email', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'email',
                                                                        'id' => 'email',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $profile_summary->emailaddress,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('department_id'), 'department_id', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <?php echo form_dropdown('department_id', $department, $department, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>                                                                
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('reportind_manager'), 'reporting_manager', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'email',
                                                                    'id' => 'email',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => $profile_summary->reporting_manager_name,
                                                                    'disabled' => 'disabled'
                                                                ));
                                                                ?>

                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('jobtitle'), 'jobtitle', array('class' => 'form-label')); ?>:
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'jobtitle',
                                                                    'id' => 'jobtitle',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => $profile_summary->jobtitle_name,
                                                                    'disabled' => 'disabled'
                                                                ));
                                                                ?>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('position_id'), 'position_id', array('class' => 'form-label')); ?>:
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'position_id',
                                                                    'id' => 'position_id',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => $profile_summary->position_name,
                                                                    'disabled' => 'disabled'
                                                                ));
                                                                ?>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('employment_status'), 'employment_status_id', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'position_id',
                                                                    'id' => 'position_id',
                                                                    'class' => 'form-control',
                                                                    'placeholder' => $profile_summary->emp_status_name,
                                                                    'disabled' => 'disabled'
                                                                ));
                                                                ?>
                                                            </div>

                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('date_of_joining'), 'date_of_joining', array('class' => 'form-label')); ?>:
                                                                <span class="desc desc-red">*</span>
                                                                <div class="input-group date">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'date_of_joining',
                                                                        'id' => 'date_of_joining',
                                                                        'data-format' => 'D, dd MM yyyy',
                                                                        'class' => 'form-control datepicker',
                                                                        'value' => $profile_summary->date_of_joining,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                    <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                </div>
                                                            </div>


                                                            <div class="form-group col-sm-6">
                                                                <?php echo form_label(lang('years_exp'), 'years_exp', array('class' => 'form-label')); ?>:
                                                                <label class="form-label">Experience</label>
                                                                <span class="desc desc-red">*</span>
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'years_exp',
                                                                        'id' => 'years_exp',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $profile_summary->years_exp . ' Years',
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <!--                                                            <div class="form-group col-sm-6">
                                                                                                                            <label class="form-label">Work Telephone Number</label>
                                                                                                                            <div class="controls">
                                                                                                                                <input type="text" class="form-control" placeholder="+91 020 25530297" disabled="disabled">
                                                                                                                            </div>
                                                                                                                        </div>                                        -->

                                                        </form>

                                                    </div>

                                                    <!--Start Personal Details-->

                                                    <div class="tab-pane fade" id="personal-information">

                                                        <?php if (isset($personal_detail)) { ?>

                                                            <form>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('gender'), 'gender', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('gender', $personal_detail->genderid, $personal_detail->genderid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                                                                </div>                                      

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('marital_status'), 'marital_status', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('marital_status', $personal_detail->genderid, $personal_detail->genderid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>                                                             
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('nationality'), 'nationality', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('nationality', $personal_detail->nationalityid, $personal_detail->nationalityid, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                                                                </div>


                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('language'), 'language', array('class' => 'form-label')); ?>:
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'language',
                                                                        'id' => 'language',
                                                                        'class' => 'form-control',
                                                                        'placeholder' => $personal_detail->languageid,
                                                                        'disabled' => 'disabled'
                                                                    ));
                                                                    ?>
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('dob'), 'dob', array('class' => 'form-label')); ?>:
                                                                    <label class="form-label">Date of Birth</label>
                                                                    <div class="input-group date">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'dob',
                                                                            'id' => 'dob',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $personal_detail->dob,
                                                                            'disabled' => 'disabled'
                                                                        ));
                                                                        ?>
                                                                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('bloodgroup'), 'bloodgroup', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('bloodgroup', $personal_detail->bloodgroup, $personal_detail->bloodgroup, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>
                                                                </div>

                                                            </form>
                                                        <?php } else { ?>
                                                            <p>No Data found!</p>
                                                        <?php } ?>
                                                    </div>

                                                    <!--End Personal Details-->


                                                    <!--Start Communication Details-->

                                                    <div class="tab-pane fade" id="contact-information">

                                                        <?php if (isset($communication_detail)) { ?>

                                                            <form>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('personal_email'), 'personal_email', array('class' => 'form-label')); ?>:

                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'personalemail',
                                                                            'id' => 'personalemail',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->personalemail,
                                                                            'disabled' => 'disabled'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-sm-12">
                                                                    <?php echo form_label(lang('perm_address_title'), 'perm_address_title', array('class' => 'text-bold')); ?>:
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('street_address'), 'street_address', array('class' => 'form-label')); ?>:

                                                                    <div class="controls">    
                                                                        <?php
                                                                        echo form_textarea(array(
                                                                            'name' => 'perm_address',
                                                                            'id' => 'perm_address',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $perm_address_detail . ', ',
                                                                            'disabled' => 'disabled',
                                                                            'cols' => '5'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('country'), 'country', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('country', $perm_contry, $perm_contry, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>

                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('state'), 'state', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('state', $perm_state, $perm_state, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>

                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('city'), 'city', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('city', $perm_city, $perm_city, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>                                                                    
                                                                </div>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('perm_pincode'), 'perm_pincode', array('class' => 'form-label')); ?>:
                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'perm_pincode',
                                                                            'id' => 'perm_pincode',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->perm_pincode,
                                                                            'disabled' => 'disabled',
                                                                            'cols' => '5'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>


                                                                <div class="form-group col-sm-12">
                                                                    <label class="form-label">
                                                                        <input type="checkbox" class="iCheck" checked> <span>Check if permanent and current address are same</span>

                                                                    </label>
                                                                </div>



                                                                <div class="form-group col-sm-12">
                                                                    <?php echo form_label(lang('curr_address_title'), 'curr_address_title', array('class' => 'text-bold')); ?>:
                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('street_address'), 'street_address', array('class' => 'form-label')); ?>:

                                                                    <div class="controls">    
                                                                        <?php
                                                                        echo form_textarea(array(
                                                                            'name' => 'curr_address',
                                                                            'id' => 'curr_address',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $address_detail . ', ',
                                                                            'disabled' => 'disabled',
                                                                            'cols' => '5'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>







                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('country'), 'country', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('country', $contry, $contry, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>

                                                                </div>
                                                                <div class="clearfix"></div>
                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('state'), 'state', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('state', $state, $state, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>

                                                                </div>

                                                                <div class="form-group col-sm-6">
                                                                    <?php echo form_label(lang('city'), 'city', array('class' => 'form-label')); ?>:
                                                                    <?php echo form_dropdown('city', $city, $city, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled')); ?>                                                                    
                                                                </div>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('curr_pincode'), 'curr_pincode', array('class' => 'form-label')); ?>:
                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'curr_pincode',
                                                                            'id' => 'curr_pincode',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->current_pincode,
                                                                            'disabled' => 'disabled',
                                                                            'cols' => '5'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>


                                                                <div class="form-group col-sm-12">
                                                                    <?php echo form_label(lang('emergency_detail_title'), 'emergency_detail', array('class' => 'form-bold')); ?>:
                                                                </div>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('name'), 'name', array('class' => 'form-label')); ?>:
                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'emergency_name',
                                                                            'id' => 'emergency_name',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->emergency_name ? $communication_detail->emergency_name : '-',
                                                                            'disabled' => 'disabled'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('email'), 'email', array('class' => 'form-label')); ?>:
                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'emergency_email',
                                                                            'id' => 'emergency_email',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->emergency_email ? $communication_detail->emergency_email : '-',
                                                                            'disabled' => 'disabled'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>

                                                                <div class="form-group col-sm-6 col-sm-offset-6">
                                                                    <?php echo form_label(lang('number'), 'number', array('class' => 'form-label')); ?>:                                                                    
                                                                    <div class="controls">
                                                                        <?php
                                                                        echo form_input(array(
                                                                            'name' => 'emergency_email',
                                                                            'id' => 'emergency_email',
                                                                            'class' => 'form-control',
                                                                            'placeholder' => $communication_detail->emergency_number ? $communication_detail->emergency_number : '-',
                                                                            'disabled' => 'disabled'
                                                                        ));
                                                                        ?>
                                                                    </div>
                                                                </div>



                                                            </form>
                                                        <?php } else { ?>
                                                            <p>No Data found!</p>
                                                        <?php } ?>

                                                    </div>

                                                    <div class="tab-pane fade" id="documents">
                                                        <!-- add new document here -->
                                                        <!-- <div class="new-document-bg">
                                                            <div class="text-bold text-right new-document-text">
                                                                <div class="new-document-icon"><i class="fa fa-plus-square"></i> </div> 
                                                                New Document
                                                            </div>                                       
                                                        </div>
                                                        
                                                        <div class="new-upload-doc-bg">   
                                                            <div class="close-upload-doc bottom-margin-15">
                                                                <div class="pull-left">
                                                                    <h5 class="bottom-margin-0">Upload Document</h5></div>
                                                                <div class="pull-right">
                                                                    <button type="button" class="close">x</button>
                                                                </div>
                                                            </div>

                                                            <div class="new-document-content">
                                                                 <form id="document_upload" action="#" novalidate="novalidate">
                                                                    <div class="form-group col-sm-6">

                                                                    <label class="form-label" for="uploadfilenm">Name</label>
                                                                    <span class="desc desc-red">*</span>
                                                                    <div class="controls">
                                                                        <input type="text" class="form-control" id="uploadfilenm" name="uploadfilenm">
                                                                    </div>
                                                                </div>  
                                                                  <div class="form-group col-sm-6">
                                                                    <label for="exampleInputFile">Attacment</label>
                                                                    <input type="file" class="no-border" id="uploadattachment">      
                                                                  </div>

                                                                  <div class="form-group col-sm-12">
                                                                  <button type="submit" class="btn btn-teal">Submit</button>
                                                                  <button type="reset" class="btn btn-cancel2">Cancel</button>
                                                                </div>
                                                                </form>
                                                            </div>

                                                        </div> -->

                                                            <!-- <table id="user-pro-document" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Document Name</th>
                                                        <th>Download</th>                                                  
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>Passport</td>
                                                        <td><a href="#"><i class="fa fa-download"></i></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>Aadhar Card</td>
                                                        <td><a href="#"><i class="fa fa-download"></i></a></td>
                                                    </tr>
                                                     <tr>
                                                        <td>3</td>
                                                        <td>Voting card</td>
                                                        <td><a href="#"><i class="fa fa-download"></i></a></td>
                                                    </tr>
                                                    <tr>
                                                        <td>4</td>
                                                        <td>Pan Card</td>
                                                        <td><a href="#"><i class="fa fa-download"></i></a></td>
                                                    </tr> 
                                                                                                  
                                                </tbody>
                                            </table> -->

                                                        <div class="row">
                                                            <div class="col-md-12 col-sm-12 col-xs-12">

                                                                <div class="custom-dropzone file-upload-dropzone mydrop">
                                                                    <div>
                                                                        <div class="col-sm-8 drop-table">

                                                                            <table class="table" id="custom-droptable">
                                                                                <thead>
                                                                                    <tr>
                                                                                        <th width="10%" class="text-center">#</th>
                                                                                        <th width="40%">Name</th>
                                                                                        <th width="20%" id="test">test</th>
                                                                                        <th width="20%">Progress</th>
                                                                                        <th width="20%">Size</th>
                                                                                        <th width="10%">Type</th>
                                                                                    </tr>
                                                                                </thead>
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td colspan="5">No Files Uploaded Yet!</td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </div>
                                                                        <div class="col-sm-4 drop-area text-center">
                                                                            <div id="customDZ" class="droppable-area">
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>

                                                            </div>
                                                        </div>




                                                    </div>

                                                    <div class="tab-pane fade" id="skills">

                                                        <!-- add new document here -->
                                                        <div class="new-document-bg">
                                                            <div class="text-bold text-right new-document-text">
                                                                <div class="add-skill-icon"><i class="fa fa-plus-square"></i> </div> 
                                                                Add Skills
                                                            </div>                                       
                                                        </div>
                                                        <!-- add new document here -->

                                                        <div class="new-add-skills-bg">   
                                                            <div class="close-upload-doc bottom-margin-15">
                                                                <div class="pull-left">
                                                                    <h5 class="bottom-margin-0">Skills</h5></div>
                                                                <div class="pull-right">
                                                                    <button type="button" class="close">x</button>
                                                                </div>
                                                            </div>



                                                            <div class="new-document-content">
                                                                <form id="emp_skill" action="employee/test" method="post" novalidate="novalidate">

                                                                    <div class="form-group col-sm-6">
                                                                        <?php echo form_label(lang('skillname'), 'skillname', array('class' => 'form-label')); ?>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <?php
                                                                            echo form_input(array(
                                                                                'name' => 'skillname',
                                                                                'id' => 'skillname',
                                                                                'class' => 'form-control',
                                                                                'placeholder' => ''
                                                                            ));
                                                                            ?>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <?php echo form_label(lang('skills_experience_y'), 'skills_experience_y', array('class' => 'form-label','for'=>'skills_experience_y')); ?>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <div class="col-sm-6">
                                                                                <?php
                                                                                echo form_input(array(
                                                                                    'name' => 'skills_experience_y',
                                                                                    'id' => 'skills_experience_y',
                                                                                    'class' => 'form-control',
                                                                                    'placeholder' => 'YYYY'
                                                                                ));
                                                                                ?>
                                                                            </div> -
                                                                            <div class="col-sm-6">
                                                                                <?php
                                                                                echo form_input(array(
                                                                                    'name' => 'skills_experience_m',
                                                                                    'id' => 'skills_experience_m',
                                                                                    'class' => 'form-control',
                                                                                    'placeholder' => 'MM',
                                                                                ));
                                                                                ?>
                                                                            </div>
                                                                        </div>
                                                                    </div> 

                                                                    <div class="form-group col-sm-6">
                                                                        <?php echo form_label(lang('skilllevel'), 'skilllevel', array('class' => 'form-label','for'=>'skilllevel')); ?>
                                                                        <span class="desc desc-red">*</span>
                                                                        <?php echo form_dropdown('skilllevel', $personal_detail->genderid, $personal_detail->genderid, array('class' => 'form-control input-sm m-bot15', 'name' => 'skilllevel','id' => 'skilllevel')); ?>  
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <?php echo form_label(lang('skill_last_use_year'), 'skill_last_use_year', array('class' => 'form-label','for'=>'skill_last_use_year')); ?>

                                                                        <div class="input-group date">
                                                                            <?php
                                                                                echo form_input(array(
                                                                                    'name' => 'skill_last_use_year',
                                                                                    'id' => 'skill_last_use_year',
                                                                                    'class' => 'form-control datepicker',
                                                                                    'placeholder' => 'MM',
                                                                                    'data-format'=>'D, dd MM yyyy'
                                                                                ));
                                                                                ?>
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="clearfix"></div>

                                                                    <div class="form-group col-sm-12">
                                                                        <button type="submit" class="btn btn-teal">Confirm</button>
                                                                        <button type="reset" class="btn btn-default">Cancel</button>
                                                                    </div>


                                                                </form>
                                                            </div>

                                                        </div>

                                                        <table id="user-pro-skill" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Skill</th>
                                                                    <th>Years of Experience</th>
                                                                    <th>Competency Level</th>
                                                                    <th>Skill Last Used Year</th>
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Skill</th>
                                                                    <th>Years of Experience</th>
                                                                    <th>Competency Level</th>
                                                                    <th>Skill Last Used Year</th>
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td>HTML 5</td>
                                                                    <td>4 Year</td>
                                                                    <td>Intermediate</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>

                                                                <tr>
                                                                    <td>CSS 3</td>
                                                                    <td>4 Year</td>
                                                                    <td>Intermediate</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>
                                                                <tr>
                                                                    <td>PHP</td>
                                                                    <td>4 Year</td>
                                                                    <td>Intermediate</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>
                                                                <tr>
                                                                    <td>Javascript</td>
                                                                    <td>3.5 Year</td>
                                                                    <td>Intermediate</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>                                                
                                                                <tr>
                                                                    <td>Jquery</td>
                                                                    <td>3.5 Year</td>
                                                                    <td>Intermediate</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>

                                                            </tbody>
                                                        </table>



                                                    </div>

                                                    <div class="tab-pane fade" id="job-history">

                                                        <!-- add new document here -->
                                                        <div class="new-document-bg">
                                                            <div class="text-bold text-right new-document-text">
                                                                <div class="add-jhistory-icon"><i class="fa fa-plus-square"></i> </div> 
                                                                Add Job Details
                                                            </div>                                       
                                                        </div>
                                                        <!-- add new document here -->

                                                        <div class="add-jhistory-bg">   
                                                            <div class="close-upload-doc bottom-margin-15">
                                                                <div class="pull-left">
                                                                    <h5 class="bottom-margin-0">Job Details</h5></div>
                                                                <div class="pull-right">
                                                                    <button type="button" class="close">x</button>
                                                                </div>
                                                            </div>

                                                            <!-- body content start here -->
                                                            <div class="new-document-content">

                                                                <form id="icon_validate" action="#" novalidate="novalidate">

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhdepartment">Department</label>
                                                                        <select class="form-control input-sm m-bot15" id="jhdepartment" name="jhdepartment">
                                                                            <option>Select Department</option>
                                                                            <option value="it">IT</option> 
                                                                            <option value="hr">HR</option>              
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhjobtitle">Job Title</label>               
                                                                        <select class="form-control input-sm m-bot15" id="jhjobtitle" name="jhjobtitle">
                                                                            <option>Select Job Title</option>
                                                                            <option value="it">Manager</option> 
                                                                            <option value="hr">Designer</option> 
                                                                            <option value="hr">Developer</option>             
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhjobposition">Position</label>               
                                                                        <select class="form-control input-sm m-bot15" id="jhjobposition" name="jhjobposition">
                                                                            <option>Select Position</option>
                                                                            <option value="it">Manager</option> 
                                                                            <option value="hr">Designer</option> 
                                                                            <option value="hr">Developer</option>             
                                                                        </select>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhfromdate">From</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="jhfromdate" name="jhfromdate" data-format="D, dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhtodate">To</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="jhtodate" name="jhtodate" data-format="D, dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="jhclient">Client</label>

                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="jhclient" name="jhclient">
                                                                        </div>
                                                                    </div>       
                                                                    <div class="clearfix"></div>
                                                                    <div class="form-group col-sm-12">
                                                                        <button type="submit" class="btn btn-teal">Confirm</button>
                                                                        <button type="reset" class="btn btn-default">Cancel</button>
                                                                    </div>
                                                                </form>

                                                            </div>
                                                            <!-- body content end here -->
                                                        </div>



                                                        <table id="user-pro-jhistory" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Department</th>
                                                                    <th>Client</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Department</th>
                                                                    <th>Client</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td>Design</td>
                                                                    <td>ArtNexxt</td>
                                                                    <td>1 Aug 2016</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>

                                                                <tr>
                                                                    <td>Development</td>
                                                                    <td>ArtNexxt</td>
                                                                    <td>1 Aug 2016</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>

                                                                <tr>
                                                                    <td>HR</td>
                                                                    <td>MindWorx</td>
                                                                    <td>1 Aug 2016</td>
                                                                    <td>24 Oct 2016</td>                                                    
                                                                </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>


                                                    <div class="tab-pane fade" id="experience">

                                                        <!-- add new document here -->
                                                        <div class="new-document-bg">
                                                            <div class="text-bold text-right new-document-text">
                                                                <div class="add-experience-icon"><i class="fa fa-plus-square"></i> </div> 
                                                                Add Experience
                                                            </div>                                       
                                                        </div>
                                                        <!-- add new document here -->

                                                        <div class="add-experience-bg">   
                                                            <div class="close-upload-doc bottom-margin-15">
                                                                <div class="pull-left">
                                                                    <h5 class="bottom-margin-0">Experience</h5></div>
                                                                <div class="pull-right">
                                                                    <button type="button" class="close">x</button>
                                                                </div>
                                                            </div>

                                                            <!-- body content start here -->
                                                            <div class="new-document-content">
                                                                <?php echo form_open('employee/save_exp_data', array('class' => 'form-inline text-left', 'id' => 'profile-info')); ?>
                                                                <!--<form id="icon_validate" action="employee/save_exp_data" novalidate="novalidate" method="post">-->

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expcompanynm">Company Name</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expcompanynm" name="expcompanynm">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expcompanyurl">Company Website</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expcompanyurl" name="expcompanyurl">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expdesignation">Designation</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expdesignation" name="expdesignation">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expfromdate">From</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="expfromdate" name="expfromdate" data-format="dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="exptodate">To</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="exptodate" name="exptodate" data-format="dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expreferrernm">Referrer Name</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expreferrernm" name="expreferrernm">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expreferrercnt">Referrer Contact</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expreferrercnt" name="expreferrercnt">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="expreferrermail">Referrer Email</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="expreferrermail" name="expreferrermail">
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-sm-12">
                                                                        <label class="form-label" for="expreasonleave">Reason for Leaving</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">                         
                                                                            <textarea class="form-control" id="expreasonleave" name="expreasonleave" cols="5" style="width:100%;"></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <div class="form-group col-sm-12">
                                                                        <button type="submit" class="btn btn-teal">Confirm</button>
                                                                        <button type="reset" class="btn btn-default">Cancel</button>
                                                                    </div>
                                                                </form>

                                                            </div>
                                                            <!-- body content end here -->
                                                        </div>

                                                        <table id="user-pro-experience" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Company Name</th>
                                                                    <th>Company website</th>
                                                                    <th>Designation</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Company Name</th>
                                                                    <th>Company website</th>
                                                                    <th>Designation</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td><?php echo $company_rpfile->comp_name;?></td>
                                                                    <td>http://mindworxsoftware.com</td>
                                                                    <td>UI Designer</td>
                                                                    <td>1 Apr 2015</td>
                                                                    <td>Till Date</td>
                                                                </tr>

                                                                <tr>
                                                                    <td>MindWorx</td>
                                                                    <td>http://mindworxsoftware.com</td>
                                                                    <td>Apps</td>
                                                                    <td>1 Apr 2015</td>
                                                                    <td>Till Date</td>
                                                                </tr>



                                                            </tbody>
                                                        </table>                                                       

                                                    </div>

                                                    <div class="tab-pane fade" id="education">

                                                        <!-- add new document here -->
                                                        <div class="new-document-bg">
                                                            <div class="text-bold text-right new-document-text">
                                                                <div class="add-education-icon"><i class="fa fa-plus-square"></i> </div> 
                                                                Add Education
                                                            </div>                                       
                                                        </div>
                                                        <!-- add new document here -->

                                                        <div class="add-education-bg">   
                                                            <div class="close-upload-doc bottom-margin-15">
                                                                <div class="pull-left">
                                                                    <h5 class="bottom-margin-0">Education Details</h5></div>
                                                                <div class="pull-right">
                                                                    <button type="button" class="close">x</button>
                                                                </div>
                                                            </div>

                                                            <!-- body content start here -->
                                                            <div class="new-document-content">

                                                                <form id="icon_validate" action="#" novalidate="novalidate">

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationlevel">Education Level</label>
                                                                        <span class="desc desc-red">*</span>            
                                                                        <select class="form-control input-sm m-bot15" id="educationlevel" name="educationlevel">
                                                                            <option>Select Education Level</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationinstinm">Institution Name</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="educationinstinm" name="educationinstinm">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationcourse">Course</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="educationcourse" name="educationcourse">
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationfromdate">From</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="educationfromdate" name="educationfromdate" data-format="D, dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationtodate">To</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="input-group date">
                                                                            <input type="text" class="form-control datepicker" id="educationtodate" name="educationtodate" data-format="D, dd MM yyyy">
                                                                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                                                                        </div>
                                                                    </div>

                                                                    <div class="form-group col-sm-6">
                                                                        <label class="form-label" for="educationpercent">Percentage</label>
                                                                        <span class="desc desc-red">*</span>
                                                                        <div class="controls">
                                                                            <input type="text" class="form-control" id="educationpercent" name="educationpercent">
                                                                        </div>
                                                                    </div>

                                                                    <div class="clearfix"></div>
                                                                    <div class="form-group col-sm-12">
                                                                        <button type="submit" class="btn btn-teal">Confirm</button>
                                                                        <button type="reset" class="btn btn-default">Cancel</button>
                                                                    </div>
                                                                </form>

                                                            </div>
                                                            <!-- body content end here -->
                                                        </div>

                                                        <table id="user-pro-education" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Education</th>
                                                                    <th>Institution Name</th>
                                                                    <th>Course</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                    <th>Percentage</th>
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Education</th>
                                                                    <th>Institution Name</th>
                                                                    <th>Course</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                    <th>Percentage</th>
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td>MCA</td>
                                                                    <td>Pune University</td>
                                                                    <td>Regular</td>
                                                                    <td>May 2008</td>
                                                                    <td>June 2011</td>
                                                                    <td>80%</td>
                                                                </tr>

                                                                <tr>
                                                                    <td>BCA</td>
                                                                    <td>Pune University</td>
                                                                    <td>Regular</td>
                                                                    <td>May 2005</td>
                                                                    <td>May 2008</td>
                                                                    <td>80%</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>HSC</td>
                                                                    <td>Maharashtra Board</td>
                                                                    <td>Regular</td>
                                                                    <td>Mar 2003</td>
                                                                    <td>Feb 2005</td>
                                                                    <td>80%</td>
                                                                </tr>

                                                                <tr>
                                                                    <td>SSC</td>
                                                                    <td>Maharashtra Board</td>
                                                                    <td>Regular</td>
                                                                    <td>Jun 2002</td>
                                                                    <td>Feb 2003</td>
                                                                    <td>80%</td>
                                                                </tr>

                                                            </tbody>
                                                        </table> 

                                                    </div>

                                                    <div class="tab-pane fade" id="visa">

                                                        <table id="user-pro-visa" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Passport Number</th>
                                                                    <th>Passport Expiry Date</th>
                                                                    <th>Visa Number</th>
                                                                    <th>Visa Expiry Date</th>
                                                                    <th>Inline Status</th>
                                                                    <th>Ininetyfour Status</th>
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Passport Number</th>
                                                                    <th>Passport Expiry Date</th>
                                                                    <th>Visa Number</th>
                                                                    <th>Visa Expiry Date</th>
                                                                    <th>Inline Status</th>
                                                                    <th>Ininetyfour Status</th>
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td>PP101DA123423</td>
                                                                    <td>May 2018</td>
                                                                    <td>456789</td>
                                                                    <td>June 2019</td>
                                                                    <td>L</td>
                                                                    <td>a</td>
                                                                </tr>

                                                                <tr>
                                                                    <td>PP101DA123423</td>
                                                                    <td>May 2018</td>
                                                                    <td>456789</td>
                                                                    <td>June 2019</td>
                                                                    <td>L</td>
                                                                    <td>a</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>PP101DA123423</td>
                                                                    <td>May 2018</td>
                                                                    <td>456789</td>
                                                                    <td>June 2019</td>
                                                                    <td>L</td>
                                                                    <td>a</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>PP101DA123423</td>
                                                                    <td>May 2018</td>
                                                                    <td>456789</td>
                                                                    <td>June 2019</td>
                                                                    <td>L</td>
                                                                    <td>a</td>
                                                                </tr>


                                                            </tbody>
                                                        </table> 

                                                    </div>

                                                    <div class="tab-pane fade" id="holiday">                                            
                                                        <table id="user-pro-holiday" class="table table-striped dt-responsive display" cellspacing="0" width="100%">
                                                            <thead>
                                                                <tr>
                                                                    <th>Holiday Group</th>
                                                                    <th>Holiday</th>
                                                                    <th>Date</th>
                                                                    <th>Description</th>                            
                                                                </tr>
                                                            </thead>

                                                            <tfoot>
                                                                <tr>
                                                                    <th>Holiday Group</th>
                                                                    <th>Holiday</th>
                                                                    <th>Date</th>
                                                                    <th>Description</th> 
                                                                </tr>
                                                            </tfoot>

                                                            <tbody>
                                                                <tr>
                                                                    <td>Associate Group</td>
                                                                    <td>Public</td>
                                                                    <td>24 Oct 2016</td>
                                                                    <td>Event</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Associate Group</td>
                                                                    <td>Public</td>
                                                                    <td>24 Oct 2016</td>
                                                                    <td>Event</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Associate Group</td>
                                                                    <td>Public</td>
                                                                    <td>24 Oct 2016</td>
                                                                    <td>Event</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Associate Group</td>
                                                                    <td>Public</td>
                                                                    <td>24 Oct 2016</td>
                                                                    <td>Event</td>
                                                                </tr>
                                                            </tbody>
                                                        </table> 

                                                    </div>






                                                </div>


                                                <!-- </div>  -->


                                                <div class="clearfix progress-bar "><br></div>


                                            </div>

                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>                                                                      
                    </div>
                </div>
                <!-- second row start here -->
            </div>
            <!--column 8 left center part end here -->
        </div>
        <!-- containt page row end here -->
    </section>
</section>
<!--content section end-->




<script src="<?php echo base_url(); ?>assets/js/inline-textbox-edit/jquery.inlineedit.js"></script>
<script type="text/javascript">
// $(function(){
// 	$('.editable').inlineEdit({
// 	  buttons: '<a href="#" class="save"><i class="icon-ok-circle"></i></a> <a href="#" class="cancel"><i class="icon-remove-circle"></i></a>',
// 	  buttonsTag: 'a'
// 	});
// });
//          </script>

<script>
    $(document).ready(function () {
        var data = '';
        var upload_url = 'employee/upload_file';
        $("#customDZ").dropzone({
            url: upload_url,
            success: function (file, response) {

                return true;
            }
            return true;
        });
    });


</script>

