<div class="row">
    <!-- Left col -->
    <section class="col-lg-9 connectedSortable">

        <!-- 1st row here -->
        <div class="row">
            <div class="col-sm-12">
                <!-- Custom tabs-->
                <div class="nav-tabs-custom margin-bottom-10">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#apply-leave" data-toggle="tab">Apply Leave</a></li>
                        <li><a href="#conference-book" data-toggle="tab">Conference Room</a></li>
                        <li><a href="#post-article" data-toggle="tab">Post Forum</a></li>
                        <li><a href="#post-event" data-toggle="tab">Post Events</a></li>
                        <li><a href="#announcement" data-toggle="tab">Announcements</a></li>
                        <li><a href="#timesheet" data-toggle="tab">Timesheet</a></li>
                    </ul>
                    <div class="tab-content">
                        <!-- apply leave start -->
                        <div class="active tab-pane" id="apply-leave">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form">
                                    <div class="box-body all-padding-0">
                                        <div class="form-group margin-bottom-0">
                                            <textarea class="form-control no-border" rows="3" placeholder="Leave Details"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <div class="controls">
                                                        <input type="text" id="daterange-1" placeholder="12/27/2016" class="input-sm form-control daterange">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select class="form-control input-sm">
                                                        <option disabled="" selected="">Leave Type</option>
                                                        <option>Casual leave</option>
                                                        <option>Sick leave</option>
                                                        <option>Personal leave</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- /.post -->
                        </div>
                        <!-- apply leave start -->

                        <!-- conference-book start -->
                        <div class="tab-pane" id="conference-book">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form" id="form-leave-id" method="post" action="dashboard/leave">
                                    <div class="box-body all-padding-0">
                                        <div class="form-group margin-bottom-0">
                                            <textarea name="conference_room_description"class="form-control no-border" rows="3" placeholder="Conference Room Booking details"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <div class="controls">
                                                        <input name="daterange" type="text" id="daterange-4" class="form-control daterange input-sm" data-time-picker="true" data-time-picker-increment="5" placeholder="Enter Date &  time" data-format="YYYY/MM/DD hh:mm A">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select name="conference_room" class="form-control input-sm">
                                                        <option disabled="" selected="">Room Type</option>
                                                        <option>Shivneri</option>
                                                        <option>Sinhagad</option>
                                                        <option>Raigad</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- /.post -->
                        </div>
                        <!-- conference-book start -->

                        <!-- post article start -->
                        <div class="tab-pane" id="post-article">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form">
                                    <div class="box-body all-padding-0">

                                        <div class="form-group margin-bottom-0">
                                            <input type="text" class="form-control no-border" id="inputName" placeholder="Title">
                                        </div>

                                        <div class="form-group margin-bottom-0">
                                            <textarea class="form-control no-border" rows="3" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select class="form-control input-sm">
                                                        <option disabled="" selected="">Group</option>
                                                        <option>2015</option>
                                                        <option>2016</option>
                                                        <option>2017</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- post article start -->

                        <!-- post Event -->
                        <div class="tab-pane" id="post-event">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form">
                                    <div class="box-body all-padding-0">

                                        <div class="form-group margin-bottom-0">
                                            <input type="text" class="form-control no-border" id="inputName" placeholder="Title">
                                        </div>

                                        <div class="form-group margin-bottom-0">
                                            <textarea class="form-control no-border" rows="3" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <div class="controls">
                                                        <input type="text" id="daterange-4" class="form-control daterange input-sm" data-time-picker="true" data-time-picker-increment="5" placeholder="Eneter Date With time" data-format="YYYY/MM/DD hh:mm A">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select class="form-control input-sm">
                                                        <option disabled="" selected="">Group</option>
                                                        <option>2015</option>
                                                        <option>2010</option>
                                                        <option>2016</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- /.post -->
                        </div>
                        <!-- post Event -->

                        <!-- Announcement start-->
                        <div class="tab-pane" id="announcement">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form">
                                    <div class="box-body all-padding-0">

                                        <div class="form-group margin-bottom-0">
                                            <input type="text" class="form-control no-border" id="inputName" placeholder="Title">
                                        </div>

                                        <div class="form-group margin-bottom-0">
                                            <textarea class="form-control no-border" rows="3" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select class="form-control input-sm">
                                                        <option disabled="" selected="">Group</option>
                                                        <option>2015</option>
                                                        <option>2016</option>
                                                        <option>2017</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-9">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- Announcement start --> 

                        <!-- timesheet start-->
                        <div class="tab-pane" id="timesheet">
                            <div class="post">                  
                                <!-- /.user-block -->
                                <!-- form start -->
                                <form role="form">
                                    <div class="box-body all-padding-0">
                                        <div class="form-group margin-bottom-0">
                                            <textarea class="form-control no-border" rows="3" placeholder="Description"></textarea>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer padding-tp">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <div class="controls">
                                                        <input type="text" id="daterange-4" class="form-control daterange input-sm" data-time-picker="true" data-time-picker-increment="5" placeholder="Enter Date &  time" data-format="YYYY/MM/DD hh:mm A">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-3">
                                                <div class="form-group margin-bottom-0">
                                                    <select class="form-control input-sm">
                                                        <option disabled="" selected="">Hours</option>
                                                        <option>1</option>
                                                        <option>5</option>
                                                        <option>10</option>
                                                        <option>15</option>
                                                        <option>20</option>
                                                        <option>24</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="pull-right">
                                                    <button type="submit" class="btn btn-info btn-sm">Post</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <!-- /.post -->
                        </div>
                        <!-- timesheet start -->             




                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row here -->

        <!-- filter block here -->
        <div class="row">
            <div class="col-sm-12 ">
                <div class="filter-block pull-right margin-bottom-5">
                    <ul>
                        <li>                 
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle all-padding-0" data-toggle="dropdown"> All 
                                    <i class="fa fa-filter"></i> <span class="caret"></span></button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Action</a></li>
                                    <li><a href="#">Another action</a></li>                    
                                </ul>
                            </div>
                        </li>
                        <li> |</li>
                        <li>Self</li>
                        <li> 
                            <div class="slideOne">  
                                <input type="checkbox" value="None" id="slideOne" name="check" />
                                <label for="slideOne"></label>
                            </div>
                        </li>
                        <li>Public</li>
                    </ul>

                    <!--             <div class="box-tools pull-right">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"> All 
                                        <i class="fa fa-filter"></i> <span class="caret"></span></button>
                                      <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>                    
                                      </ul>
                                    </div>
                                  <div class="filter-check-bg"> 
                                    All
                                  </div>
                                </div> -->
                </div>


            </div>
        </div>
        <!-- filter block here -->


        <!-- 2nd row here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="white-bg all-padding-20">
                    <!-- The timeline -->
                    <ul class="timeline timeline-inverse">
                        <!-- timeline time label -->
                        <li class="time-label">
                            <span class="bg-red">
                                10 Feb. 2014
                            </span>
                        </li>
                        <!-- /.timeline-label -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-envelope bg-blue"></i>

                            <div class="timeline-item padding-bottom-10">

                                <div class="row">
                                    <div class="col-sm-3"> 
                                        <div class="media">
                                            <div class="media-left">
                                                <a href="#">
                                                    <img class="media-object img-circle" src="<?php echo base_url(); ?>frontend/dist/img/user1-128x128.jpg" width="60" height="60">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <p class="text-bold text-info">Balram Kamble</p>    
                                                <p> UI Developer</p>                             
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-9"> 
                                        <div class="timeline-body">
                                            <h6 class="all-margin border-bottom1 padding-bottom-5">
                                                <span class="text-info">National Holiday </span>
                                                <small class="text-primary">on 26th  January 2017</small></h6>

                                            <p class="padding-top-bottom-10">Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplin</p>

                                            <p><span class="time"><i class="fa fa-clock-o"></i> 12:05</span></p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </li>
                        <!-- END timeline item -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-user bg-aqua"></i>

                            <div class="timeline-item padding-bottom-10">

                                <div class="row">
                                    <div class="col-sm-3"> 
                                        <div class="media">
                                            <div class="media-left">
                                                <a href="#">
                                                    <img class="media-object img-circle" src="<?php echo base_url(); ?>frontend/dist/img/user1-128x128.jpg" width="60" height="60">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <p class="text-bold text-info">Balram Kamble</p>    
                                                <p> UI Developer</p>                             
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-9"> 
                                        <div class="timeline-body">
                                            <h6 class="all-margin border-bottom1 padding-bottom-5">
                                                <span class="text-info">National Holiday </span>
                                                <small>on 26th  January 2017</small></h6>

                                            <p class="padding-top-bottom-10">Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplin</p>

                                            <p><span class="time"><i class="fa fa-clock-o"></i> 12:05</span></p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </li>
                        <!-- END timeline item -->

                        <!-- timeline time label -->
                        <li class="time-label">
                            <span class="bg-green">
                                3 Jan. 2014
                            </span>
                        </li>
                        <!-- /.timeline-label -->
                        <!-- timeline item -->
                        <li>
                            <i class="fa fa-camera bg-purple"></i>

                            <div class="timeline-item padding-bottom-10">

                                <div class="row">
                                    <div class="col-sm-3"> 
                                        <div class="media">
                                            <div class="media-left">
                                                <a href="#">
                                                    <img class="media-object img-circle" src="<?php echo base_url(); ?>frontend/dist/img/user1-128x128.jpg" width="60" height="60">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <p class="text-bold text-info">Balram Kamble</p>    
                                                <p> UI Developer</p>                             
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-9"> 
                                        <div class="timeline-body">
                                            <h6 class="all-margin border-bottom1 padding-bottom-5">
                                                <span class="text-info">National Holiday </span>
                                                <small>on 26th  January 2017</small></h6>

                                            <p class="padding-top-bottom-10">Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplin</p>

                                            <p><span class="time"><i class="fa fa-clock-o"></i> 12:05</span></p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </li>
                        <!-- END timeline item -->
                        <li>
                            <i class="fa fa-clock-o bg-gray"></i>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- 2nd row here -->




    </section>
    <!-- /.Left col -->
    <!-- right col-->
    <section class="col-lg-3">     

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12">
                <div class="profile-bg">
                    <div class="profile-bg-img">
                        <?php if (isset($personal_detail) && $personal_detail['profile_image'] != '') { ?>
                        <img class="img-circle" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">
                            <!--<img class="media-object margin-top-0" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">-->  
                        <?php } else { ?>
                            <img class="media-object margin-top-0" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                        <?php } ?>

                       
                    </div>

                    <div class="box box-widget">
                        <div class="box-header text-center">
                            <div class="user-block padding-top-30">
                                <h4 class="margin-bottom-0 text-info"><?php echo $user_summary['userfullname']; ?></h4>
                                <small><?php echo $user_summary['position_name']; ?></small>
                            </div>
                            <!-- /.user-block -->
                            <div class="box-tools">                
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
                            </div>
                            <!-- /.box-tools -->
                        </div>

                        <div class="box-body">                                     
                            <p><i class="fa fa-phone fa-fw fa-lg"></i> &nbsp; &nbsp;<span class="editable" id="contact_id"> <?php echo $communication_detail['mobile_number']; ?></span></p>
                            <p>
                                <i class="fa fa-envelope fa-fw fa-lg"></i>
                                <a href="mailto: <?php echo $user_summary['emailaddress']; ?>" class="text-info"> &nbsp; &nbsp;<?php echo $user_summary['emailaddress']; ?></a>
                            </p>
                        </div>

                        <!-- /.box-footer -->
                        <div class="box-footer">

                            
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /.box -->


                </div>
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Associate of Month</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body ">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    </div>            
                </div>
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <!-- Custom tabs (Charts with tabs)-->
                <div class="nav-tabs-custom">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#notleave" data-toggle="tab">Leave</a></li>
                        <li><a href="#notholiday" data-toggle="tab">Holiday</a></li>
                        <li><a href="#nothistory" data-toggle="tab">History</a></li>
                    </ul>
                    <div class="tab-content no-padding">
                        <!-- Morris chart - Sales -->
                        <div class="tab-pane active" id="notleave">
                            <div class="not-leave-bg">
                                <div class="not-leave-content text-center text-primary-2"> 
                                    <p><?php echo $leaves['emp_leave_limit'] ? $leaves['emp_leave_limit'] : '0'; ?></p>
                                    <small>Total</small>
                                </div>

                                <div class="not-leave-content text-center text-info"> 
                                    <p><?php echo $leaves['used_leaves'] ? $leaves['used_leaves'] : '0'; ?></p>
                                    <small>Used</small>
                                </div>

                                <div class="not-leave-content text-center text-warning-2"> 
                                    <p><?php echo $leaves['used_leaves'] ? $leaves['emp_leave_limit'] - $leaves['used_leaves'] : '0'; ?></p>
                                    <small>Remaining</small>
                                </div>

                            </div>
                        </div>
                        <div class="tab-pane" id="notholiday">
                            <div class="chart" id="revenue-chart" style="position: relative; height: 300px;">ddfdg</div>
                        </div>

                        <div class="tab-pane" id="nothistory">

                            <div class="history-list"> 

                                <ul class="products-list product-list-in-box">
                                    <li class="item">                 
                                        <div class="product-info">
                                            <a href="javascript:void(0)" class="product-title">Sick Leave 
                                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                            <span class="product-description">
                                                Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                            </span>
                                        </div>
                                    </li>
                                    <!-- /.item -->
                                    <li class="item">

                                        <div class="product-info">
                                            <a href="javascript:void(0)" class="product-title">Personal Leave 
                                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                            <span class="product-description">
                                                Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                            </span>
                                        </div>
                                    </li>
                                    <!-- /.item -->

                                </ul>

                            </div>

                        </div>


                    </div>
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Announcement</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body ">
                        <ul class="products-list product-list-in-box">
                            <li class="item">
                                <div class="product-img">
                                    <img src="<?php echo base_url(); ?>frontend/dist/img/default-50x50.gif" alt="Product Image">
                                </div>
                                <div class="product-info">
                                    <a href="javascript:void(0)" class="product-title">Diwali 
                                        <span class="label label-warning pull-right">20 October 2016</span></a>
                                    <span class="product-description">
                                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                    </span>
                                </div>
                            </li>
                            <!-- /.item -->
                            <li class="item">
                                <div class="product-img">
                                    <img src="<?php echo base_url(); ?>frontend/dist/img/default-50x50.gif" alt="Product Image">
                                </div>
                                <div class="product-info">
                                    <a href="javascript:void(0)" class="product-title">Diwali 
                                        <span class="label label-warning pull-right">20 October 2016</span></a>
                                    <span class="product-description">
                                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                    </span>
                                </div>
                            </li>
                            <!-- /.item -->
                            <li class="item">
                                <div class="product-img">
                                    <img src="<?php echo base_url(); ?>frontend/dist/img/default-50x50.gif" alt="Product Image">
                                </div>
                                <div class="product-info">
                                    <a href="javascript:void(0)" class="product-title">Diwali 
                                        <span class="label label-warning pull-right">20 October 2016</span></a>
                                    <span class="product-description">
                                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                    </span>
                                </div>
                            </li>
                            <!-- /.item -->
                            <li class="item">
                                <div class="product-img">
                                    <img src="<?php echo base_url(); ?>frontend/dist/img/default-50x50.gif" alt="Product Image">
                                </div>
                                <div class="product-info">
                                    <a href="javascript:void(0)" class="product-title">Diwali 
                                        <span class="label label-warning pull-right">20 October 2016</span></a>
                                    <span class="product-description">
                                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                    </span>
                                </div>
                            </li>
                            <!-- /.item -->

                        </ul>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer text-center">
                        <a href="javascript:void(0)" class="uppercase">View All Products</a>
                    </div>
                    <!-- /.box-footer -->
                </div>
            </div>
        </div>
        <!-- 1st row right here -->




    </section>
    <!-- right col -->
</div>
<script>
$("#save_id").click(function () {
                alert("Handler for .click() called.");
            });

</script>