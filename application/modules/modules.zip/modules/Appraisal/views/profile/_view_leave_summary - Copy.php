<?php // var_dump($leave_summary_data[1]->user_name);die;                                                       ?>
<?php
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
?>
<link href="<?php echo base_url(); ?>assets/css/hrms-inline-input.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/moment.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/daterangepicker.js" type="text/javascript"></script> 
<link href="<?php echo base_url(); ?>assets/plugins/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" media="screen"/>

<!--start history and filter page css here-->
<link href="<?php echo base_url(); ?>assets/plugins/jplist-master/css/jplist.main-pages.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/plugins/jplist-master/css/jplist.core.min.css" rel="stylesheet" type="text/css" />		
<link href="<?php echo base_url(); ?>assets/plugins/jplist-master/css/jplist.list-grid-view.min.css" rel="stylesheet" type="text/css" />
<!--start history and filter page css here-->

<!--content section start-->
<section id="main-content" class=" sidebar_shift ">
    <section class="wrapper" >
        <!-- containt page row start here -->
        <div class="row">

            <!--column 8 left center part start here -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
                <!-- title here -->
                <!-- <div class="row">
                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                        <div class="page-title">
                            <div class="pull-left">
                                <h1 class="title">left</h1>
                            </div>
                        </div>
                    </div>
                </div> -->
                <!-- title here end-->

                <!-- second row start here -->
                <div class="row">
                    <div class="col-sm-12">
                        <section class="box">                                    
                            <div class="leave-history-bg">                            
                                <div class="row">

                                    <div class="col-sm-12">
                                        <!-- start history here-->  
                                        <div id="filter" class="box jplist">

                                            <!-- ios button: show/hide panel -->
                                            <div class="jplist-ios-button">
                                                <i class="fa fa-sort"></i>
                                                Filter
                                            </div>


                                            <!-- panel -->

                                            <div class="jplist-panel box panel-top">                        

                                                <!-- back button button -->
                                                <button 
                                                    type="button" 
                                                    data-control-type="back-button" 
                                                    data-control-name="back-button" 
                                                    data-control-action="back-button">
                                                    <i class="fa fa-arrow-left"></i> Go Back
                                                </button>

                                                <!-- reset button -->
                                                <button 
                                                    type="button" 
                                                    class="jplist-reset-btn"
                                                    data-control-type="reset" 
                                                    data-control-name="reset" 
                                                    data-control-action="reset">
                                                    Reset &nbsp;<i class="fa fa-share"></i>
                                                </button>

                                                <!-- items per page dropdown -->
                                                <div 
                                                    class="jplist-drop-down" 
                                                    data-control-type="items-per-page-drop-down" 
                                                    data-control-name="paging" 
                                                    data-control-action="paging">

                                                    <ul>
                                                        <li><span data-number="4"> 4 per page </span></li>
                                                        <li><span data-number="8"> 8 per page </span></li>
                                                        <li><span data-number="12" data-default="true"> 12 per page </span></li>
                                                        <li><span data-number="all"> View All </span></li>
                                                    </ul>
                                                </div>

                                                <!-- sort dropdown -->
                                                <div 
                                                    class="jplist-drop-down" 
                                                    data-control-type="sort-drop-down" 
                                                    data-control-name="sort" 
                                                    data-control-action="sort"
                                                    data-datetime-format="{month}/{day}/{year}"> <!-- {year}, {month}, {day}, {hour}, {min}, {sec} -->

                                                    <ul>
                                                        <li><span data-path="default">Sort by</span></li>
                                                        <li><span data-path=".title" data-order="asc" data-type="text">Title A-Z</span></li>
                                                        <li><span data-path=".title" data-order="desc" data-type="text">Title Z-A</span></li>
                                                        <li><span data-path=".id" data-order="asc" data-type="text" data-default="true">Id asc</span></li>
                                                        <li><span data-path=".id" data-order="desc" data-type="text">Id desc</span></li>
                                                    </ul>
                                                </div>

                                                <!-- filter by title -->
                                                <div class="text-filter-box">

                                                    <i class="fa fa-search  jplist-icon"></i>

                                                    <!--[if lt IE 10]>
                                                    <div class="jplist-label">Filter by Title:</div>
                                                    <![endif]-->

                                                    <input 
                                                        data-path=".title" 
                                                        type="text" 
                                                        value="" 
                                                        placeholder="Filter by Name" 
                                                        data-control-type="textbox" 
                                                        data-control-name="title-filter" 
                                                        data-control-action="filter"
                                                        />
                                                </div>

                                                <!-- filter by description -->
                                                <div class="text-filter-box">

                                                    <i class="fa fa-search  jplist-icon"></i>

                                                    <!--[if lt IE 10]>
                                                    <div class="jplist-label">Filter by Description:</div>
                                                    <![endif]-->

                                                    <input 
                                                        data-path=".id" 
                                                        type="text" 
                                                        value="" 
                                                        placeholder="Filter by ID" 
                                                        data-control-type="textbox" 
                                                        data-control-name="desc-filter" 
                                                        data-control-action="filter"
                                                        />  
                                                </div>

                                                <!-- views -->
                                                <div 
                                                    class="jplist-views" 
                                                    data-control-type="views" 
                                                    data-control-name="views" 
                                                    data-control-action="views"
                                                    data-default="jplist-grid-view">
                                                    <!--  <button type="button" class="jplist-view jplist-grid-view" data-type="jplist-grid-view"></button> -->
                                                </div>  

                                                <!-- pagination results -->
                                                <div 
                                                    class="jplist-label" 
                                                    data-type="Page {current} of {pages}" 
                                                    data-control-type="pagination-info" 
                                                    data-control-name="paging" 
                                                    data-control-action="paging">
                                                </div>

                                                <!-- pagination control -->
                                                <div 
                                                    class="jplist-pagination" 
                                                    data-control-type="pagination" 
                                                    data-control-name="paging" 
                                                    data-control-action="paging">
                                                </div>

                                            </div>               
                                            <?php //var_dump($leave_summary_data);die;?>
                                            <!-- main background list box -->
                                            <div class="list box">
                                                <!-- list item start here -->
                                                <?php foreach ($leave_summary_data as $leavereasult) { ?>
                                                    <?php // var_dump($leavereasult);die;                                                 ?>

                                                    <div class="list-item list-item2 box">                

                                                        <div class="leave-history-profile-bg">
                                                            <img src="<?php echo base_url(); ?>data/profile/user.png" class="img-circle img-profile pending-profile-border" />
                                                        </div>
                                                        <div class="leave-history-label-bg">
                                                            <p class="title"><?php echo $leavereasult->user_name ?></p>
                                                            <p class="id"><?php echo $leavereasult->employeeId ?></p>                                           
                                                        </div>
                                                        <form action="employee/summary" method="post">
                                                            <div class="leave-history-details-bg">
                                                                <div class="lhistory-label">Leave</div>
                                                                <div class="lhistory-dot"> : </div>
                                                                <div class="lhistory-data"><?php echo $leavereasult->reason ?></div>
                                                                <div class="lhistory-label">Type</div>
                                                                <div class="lhistory-dot"> : </div>
                                                                <div class="lhistory-data">Sick</div>                                
                                                                <div class="lhistory-label">Date</div>
                                                                <div class="lhistory-dot"> : </div>
                                                                <div class="lhistory-data"><?php echo $leavereasult->from_date ?> - <?php echo $leavereasult->to_date ?></div>
                                                                <div class="lhistory-label">Days</div>
                                                                <div class="lhistory-dot"> : </div>
                                                                <div class="lhistory-data"><?php echo $leavereasult->no_of_days ?>days</div>

                                                                <div class="lhistory-label">Reason</div>
                                                                <div class="lhistory-dot"> : </div>
                                                                <div class="lhistory-desc text-justify"><?php echo $leavereasult->reason ?></div>

                                                            </div>

                                                            <div class="form-group">
                                                                <label class="form-label" for="lrreason">Comment</label>
                                                                <div class="controls">
                                                                    <textarea class="form-control" cols="5" id="cardlreason" name="approval_reason"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">          
                                                                <button type="submit" class="btn btn-teal">Approve</button>
                                                                <button type="reset" class="btn btn-default">Reject</button>
                                                            </div>
                                                        </form>                            
                                                    </div> 
                                                <?php } ?>
                                                <!-- list item start here -->









                                            </div>
                                            <!-- main background list box -->  

                                            <div class="box jplist-no-results text-shadow align-center">
                                                <p>No results found</p>
                                            </div>

                                        </div>

                                        <!-- end history here -->
                                    </div>

                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <!-- second row start here -->




            </div>
            <!--column 8 left center part end here -->



        </div>
        <!-- containt page row end here -->
    </section>
</section>
<!--content section end-->     


<!--start history and filter page css here-->
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.core.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.sort-bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.textbox-filter.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.pagination-bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.history-bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.filter-toggle-bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jplist-master/js/jplist.list-grid-view.min.js"></script>
<script>
    $('document').ready(function () {

        $('#filter').jplist({
            itemsBox: '.list'
            , itemPath: '.list-item'
            , panelPath: '.jplist-panel'
        });
    });
</script>
<!--end history and filter page css here-->