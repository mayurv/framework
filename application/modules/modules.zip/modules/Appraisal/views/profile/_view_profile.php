<div class="row">
    <!-- Left col -->
    <section class="col-lg-9 connectedSortable">
        <!-- 1st row here -->
        <div class="row">
            <div class="col-sm-12">
                <!-- Custom tabs-->
                <div class="nav-tabs-custom margin-bottom-10">
                    <ul class="nav nav-tabs pull-right">
                        <!-- <li class="active"><a href="#send-message" data-toggle="tab">
                          <i class="fa fa-comment-o"></i> Message</a></li> -->
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-pencil-square-o"></i>
                                Action <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#apply-leave">Apply Leave</a>
                                </li>

                                <li>
                                    <a href="#" data-toggle="modal" data-target="#attendance-m">Attendance Management</a>
                                </li>

                                <li>
                                    <a href="#" data-toggle="modal" data-target="#conference-book">Conference Room</a>
                                </li>

                                <li>
                                    <a href="#" data-toggle="modal" data-target="#claim-reim">Claims & Reimbursement</a>
                                </li>
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#book-appoinment">Book a Appoinment</a>
                                </li> 
                                <li>
                                    <a href="#" data-toggle="modal" data-target="#request-help">Request / HelpDesk </a>
                                </li>

                                <li>
                                    <a href="#" data-toggle="modal" data-target="#timesheet">Timesheet</a>
                                </li>

                            </ul>
                        </li>


                    </ul>
                    <div class="tab-content">
                        <!-- Message start -->

                        <?php $this->load->view('blog/_post_blog'); ?>
                        <!-- Message leave start -->

                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row here -->

        <!-- filter block here -->
        <div class="row">
            <div class="col-sm-12 ">
                <div class="filter-block pull-right margin-bottom-5">
                    <ul>
                        <li>                 
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle all-padding-0" data-toggle="dropdown"> All 
                                    <i class="fa fa-filter"></i> <span class="caret"></span></button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Action</a></li>
                                    <li><a href="#">Another action</a></li>                    
                                </ul>
                            </div>
                        </li>
                        <li> |</li>
                        <li>Public</li>
                        <li> 
                            <div class="slideOne">  
                                <input type="checkbox"  id="slideOne" name="check" value="0"/>
                                <label for="slideOne"></label>
                            </div>
                        </li>
                        <li>Self</li>
                    </ul>

                    <!--             <div class="box-tools pull-right">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown"> All 
                                        <i class="fa fa-filter"></i> <span class="caret"></span></button>
                                      <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Action</a></li>
                                        <li><a href="#">Another action</a></li>                    
                                      </ul>
                                    </div>
                                  <div class="filter-check-bg"> 
                                    All
                                  </div>
                                </div> -->
                </div>


            </div>
        </div>
        <!-- filter block here -->


        <!-- 2nd row here -->
        <div class="row">
            <div class="col-sm-12 blur-bck" >
                <!--                <div class="overlay">-->
                <div class="white-bg all-padding-20">
                    <input type="hidden" value="<?php echo count($blog_data); ?>" id="post_count">
                    <!-- The timeline -->

                    <ul class="timeline timeline-inverse">


                        <?php $this->load->view('_timeline_div'); ?>


                        <li>
                            <i class="fa fa-clock-o bg-gray"></i>
                        </li>
                    </ul>
                </div>
                <!--</div>-->

                <?php // $this->load->view('_blog_timeline'); ?>
            </div>
            <div class="loader" style="display: none"></div>
        </div>
        <!-- 2nd row here -->




    </section>
    <!-- /.Left col -->



    <!-- right col-->
    <section class="col-lg-3">     

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12">
                <!--                <div class="profile-bg">
                                    <div class="profile-bg-img">
                <?php if (isset($personal_detail) && $personal_detail['profile_image'] != '') { ?>
                                                                                    <img class=" img-circle img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">
                                                                                        <img class="media-object margin-top-0" src="<?php echo base_url() . 'assets/uploads/' . $associate_slug . '/profile/' . $personal_detail['profile_image']; ?>">  
                <?php } else { ?>
                                                                                    <img class="media-object margin-top-0" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                <?php } ?>
                
                
                                    </div>
                
                                    <div class="box box-widget collapsed-box">
                                        <div class="box-header text-center">
                                            <div class="user-block padding-top-30">
                                                <h4 class="margin-bottom-0 text-info"><?php echo $user_summary['userfullname']; ?></h4>
                                                <small><?php echo $user_summary['position_name']; ?></small>
                                            </div>
                                             /.user-block 
                                            <div class="box-tools">                
                                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                                </button>
                                                 <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> 
                                            </div>
                                             /.box-tools 
                                        </div>
                
                                        <div class="box-body">                                     
                                            <p><i class="fa fa-phone fa-fw fa-lg"></i> &nbsp; &nbsp;<span  id="contact_id"> <?php echo $communication_detail['mobile_number']; ?></span></p>
                                            <p>
                                                <i class="fa fa-envelope fa-fw fa-lg"></i>
                                                <a href="mailto: <?php echo $user_summary['emailaddress']; ?>" class="text-info"> &nbsp; &nbsp;<?php echo $user_summary['emailaddress']; ?></p></a>
                                            </p>
                                        </div>
                
                                         /.box-footer 
                                        <div class="box-footer">
                
                                            <i class="fa fa-map-marker fa-fw fa-lg"></i>
                
                                        </div>
                                         /.box-footer 
                                    </div>
                                     /.box 
                
                
                                </div>-->
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header padding-top-5 padding-bottom-0">
                        <h3 class="box-title">&nbsp;</h3> 
                        <div class="box-tools pull-right">
                          <!-- <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                          </button> -->
                            <!--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>-->
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body all-padding-0">

                        <div class="associate-bg">
                            <div class="associate-img"> 

                                <img class="img-thumbnail img-responsive" src="<?php echo base_url() . 'assets/uploads/' . $hall_of_fame['salt'] . '/profile/' . $hall_of_fame['profile_image']; ?>">
                            </div>
                        </div>

                        <div class="associate-content text-center">
                            <h4>Hall of Fame</h4>
                            <h6><?php echo $hall_of_fame['userfullname'] ?> <small class="clr-999"><?php echo $hall_of_fame['employeeId'] ?></small></h6>
                        </div>

                    </div>            
                </div>
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <!-- Custom tabs (Charts with tabs)-->
                <div class="nav-tabs-custom">
                    <!-- Tabs within a box -->
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#notleave" data-toggle="tab">Leave
                                <?php foreach ($balnce_leaves as $list) { ?>
                                    <span class="label label-warning"><?php echo $list['tot'] - $list['bal'] ?></span>
                                <?php } ?>
                            </a></li>
                        <li><a href="#notholiday" data-toggle="tab">Holiday
                                <span class="label label-warning"><?php count($holiday_list) ?></span>
                            
                            </a></li>
                        <li><a href="#nothistory" data-toggle="tab">History</a></li>
                    </ul>
                    <div class="tab-content no-padding">
                        <!-- Morris chart - Sales -->
                        <div class="tab-pane active" id="notleave">
                            <div class="not-leave-bg">
                                <?php if (isset($leaves)) { ?>

                                    <?php foreach ($leaves as $list) { ?>
                                        <div class="not-leave-content text-center clr-333"> 

                                            <p class="off-leave-allot">
                                                <span class="text-light-gray" title="Used"><span class="font-size-18"><?php echo $list['used_leaves'] ?></span></span>
                                                <span class="text-default" title="Alloted"><small class="font-size-18"><?php echo $list['alloted_leaves'] ?> </small></span>
                                            </p>    
                                            <p class="off-leave-balance"><span class="badge badge-secondary" title="Balanced"><?php echo $list['alloted_leaves'] - $list['used_leaves'] ?></span></p>


                                        </div>

                                    <?php } ?>
                                <?php } ?>


                                <?php if (isset($balnce_leaves)) { ?>
                                    <?php foreach ($balnce_leaves as $list) { ?>


                                        <p class="off-leave-allot">                                            
                                            <span class="text-light-gray" title="Used"><span class="font-size-18"><?php echo $list['bal'] ?></span></span>
                                            <span class="text-default" title="Alloted"><small class="font-size-18"><?php echo $list['tot'] ?> </small></span> 
                                        </p>
                                        <p class="off-leave-balance"><span class="badge badge-secondary" title="Balanced"><?php echo $list['tot'] - $list['bal'] ?></span></p>

                                    <?php } ?>
                                <?php } ?>  




                            </div>
                        </div>

                        <div class="tab-pane" id="notholiday">
                            <div class="tab-pane" id="notholiday">
                                <div class="list-holiday"> 
                                    <ul>
                                        <?php foreach ($holiday_list as $list) { ?>
                                            <li>
                                                <div class="row">
                                                    <div class="col-sm-6"><?php echo date("j F", strtotime($list['holidaydate'])); ?> <small class="clr-999"><?php echo date("l", strtotime($list['holidaydate'])); ?></small></div>

                                                    <div class="col-sm-6"><small><?php echo $list['holidayname']; ?></small></div>
                                                </div>                      
                                            </li>
                                        <?php } ?>
                                    </ul>
                                </div> 
                            </div>
                        </div>

                        <div class="tab-pane" id="nothistory">
                            <div class="list-holiday"> 
                                <ul>
                                    <li>
                                        <div class="row">
                                            <div class="col-sm-6 text-bold">sick Leave</div>
                                            <div class="col-sm-6"><small>19 January 2017</small></div>
                                        </div>                      
                                    </li>
                                    <li>
                                        <div class="row">
                                            <div class="col-sm-6 text-bold">Sick Leave</div>
                                            <div class="col-sm-6"><small>19 January 2017</small></div>
                                        </div>                      
                                    </li> 
                                    <li>
                                        <div class="row">
                                            <div class="col-sm-6 text-bold">
                                                Sick Leave
                                            </div>
                                            <div class="col-sm-6"><small>19 January 2017</small></div>
                                        </div>                      
                                    </li> 



                                </ul>

                            </div>

                        </div>


                    </div>
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
        </div>
        <!-- 1st row right here -->

        <!-- 1st row right here -->
        <div class="row"> 
            <div class="col-sm-12"> 
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Announcement</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->

                    <div class="box-body ">
                        <!-- <ul class="products-list product-list-in-box">
                          <li class="item">
                            <div class="product-info">
                              <a href="javascript:void(0)" class="product-title">Diwali 
                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                  <span class="product-description">
                                   Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                  </span>
                            </div>
                          </li>
                        
                          <li class="item">
                            <div class="product-img">
                              <img src="dist/img/default-50x50.gif" alt="Product Image">
                            </div>
                            <div class="product-info">
                              <a href="javascript:void(0)" class="product-title">Diwali 
                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                  <span class="product-description">
                                   Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                  </span>
                            </div>
                          </li>
                   
                          <li class="item">
                            <div class="product-img">
                              <img src="dist/img/default-50x50.gif" alt="Product Image">
                            </div>
                           <div class="product-info">
                              <a href="javascript:void(0)" class="product-title">Diwali 
                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                  <span class="product-description">
                                   Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                  </span>
                            </div>
                          </li>
                     
                          <li class="item">
                            <div class="product-img">
                              <img src="dist/img/default-50x50.gif" alt="Product Image">
                            </div>
                            <div class="product-info">
                              <a href="javascript:void(0)" class="product-title">Diwali 
                                <span class="label label-warning pull-right">20 October 2016</span></a>
                                  <span class="product-description">
                                   Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,dsdsfd 
                                  </span>
                            </div>
                          </li>
                        </ul> -->

                        <div id="carousel-example-generic" class="carousel slide">

                            <div class="carousel-inner">
                                <div class="item active">
                                    <img src="http://placehold.it/900x500/39CCCC/ffffff&text=I+Love+Bootstrap" alt="First slide">

                                    <div class="carousel-caption">
                                        First Slide
                                    </div>

                                </div>
                                <div class="item">
                                    <img src="http://placehold.it/900x500/3c8dbc/ffffff&text=I+Love+Bootstrap" alt="Second slide">

                                    <div class="carousel-caption">
                                        Second Slide
                                    </div>
                                </div>
                                <div class="item">
                                    <img src="http://placehold.it/900x500/f39c12/ffffff&text=I+Love+Bootstrap" alt="Third slide">

                                    <div class="carousel-caption">
                                        Third Slide
                                    </div>
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="fa fa-angle-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="fa fa-angle-right"></span>
                            </a>
                        </div>  

                    </div>

                    <!-- /.box-body -->
                    <div class="box-footer text-right">
                        1/25
                    </div>
                    <!-- /.box-footer -->
                </div>
            </div>
        </div>
        <!-- 1st row right here -->




    </section>
    <!-- right col -->
</div>


<!-- apply leave modal -->
<div class="modal fade" id="apply-leave" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Leave Management</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">         
                    <div class="form-group">
                        <label for="d1" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="d1">
                            </div>
                        </div>
                    </div>            
                    <div class="form-group">
                        <label for="leavetype" class="col-sm-3 control-label">Leave Type</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">Casual Leave</option>
                                <option>Sick Leave</option>
                                <option>Personal Leave</option>
                            </select>
                        </div>
                    </div>
                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->
                    <div class="form-group">
                        <label for="leavereason" class="col-sm-3 control-label">Reason</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>            
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>
            <!-- modal body here --> 
            <!-- <div class="modal-footer text-left">          
              <div class="form-group">
                  <div class="col-sm-4 col-sm-offset-8">
                    <button class="btn btn-sm">Cancel</button>
                    <button class="btn btn-info btn-sm">Submit</button>                      
                  </div>
              </div>
            </div> -->       
        </div>      
    </div>
</div>
<!-- apply leave modal -->

<!-- Attendance Management modal -->
<div class="modal fade" id="attendance-m" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Attendance Management</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal"> 
                    <div class="form-group">
                        <label for="work-category" class="col-sm-3 control-label">Category</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">Client Side</option>
                                <option>Work Form Home</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="d2" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="d2">
                            </div>
                        </div>
                    </div> 

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->
                    <div class="form-group">
                        <label for="attendance-desc" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="attendance-desc" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>            
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- Attendance Management modal -->

<?php echo $this->load->view('profile/_conference_booking'); ?>

<!-- timesheet Management modal -->
<div class="modal fade" id="timesheet" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Timesheet</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">

                    <div class="form-group">
                        <label for="d3" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="d3">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="timesheet-desc" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="timesheet-desc" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="timehour" class="col-sm-3 control-label">Hours</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">1</option>
                                <option selected="selected">5</option>
                                <option selected="selected">8</option>
                                <option selected="selected">10</option>
                            </select>
                        </div>
                    </div>              

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->

                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- timesheet Management modal -->

<!-- Claims and Reimbursement modal -->
<div class="modal fade" id="claim-reim" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Claims and Reimbursement</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">

                    <div class="form-group">
                        <label for="claimfor" class="col-sm-3 control-label">Claim For</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">Demo</option>
                                <option selected="selected">Demo</option>
                                <option selected="selected">Demo</option>
                                <option selected="selected">Demo</option>
                            </select>
                        </div>
                    </div> 

                    <div class="form-group">
                        <label for="d4" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="d4">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="im-bill" class="col-sm-3 control-label">Bill</label>
                        <div class="col-sm-8">
                            <input id="exampleInputFile" type="file">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ex-amt" class="col-sm-3 control-label">Amount</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" plceholder="Enter Amount" />
                        </div>
                    </div>             

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->

                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- Claims and Reimbursement modal -->

<!-- Book Appoinment modal -->
<div class="modal fade" id="book-appoinment" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Book Appoinment</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">

                    <div class="form-group">
                        <label for="claimfor" class="col-sm-3 control-label">Person</label>

                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">Manager one</option>
                                <option selected="selected">Manager two</option>
                                <option selected="selected">Manager three</option>
                                <option selected="selected">Manager four</option>
                            </select>
                        </div>

                    </div> 

                    <div class="form-group">
                        <label for="dt2" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="dt2">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="book-appoinment" class="col-sm-3 control-label">Reason</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="book-appoinment" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>          

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->

                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- Book Appoinment modal -->

<!--Request / helpdesk modal -->
<div class="modal fade" id="request-help" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Request / Helpdesk</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal">

                    <div class="form-group">
                        <label for="requestfor" class="col-sm-3 control-label">Request For</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">one</option>
                                <option selected="selected">two</option>
                                <option selected="selected">three</option>
                                <option selected="selected">four</option>
                            </select>
                        </div>
                    </div> 

                    <div class="form-group">
                        <label for="d5" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="d5">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="request-desc" class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="request-desc" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>          

                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->

                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm ">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!--Request / helpdesk modal -->

<script>
    $("#save_id").click(function () {
        alert("Handler for .click() called.");
    });

    $("#psot_id" +<?php echo $user_summary['user_id'] ?>).click(function () {
        var user_id = <?php echo $user_summary['user_id'] ?>;
        $("#form_post_id_" + user_id).submit();
    });

</script>

<script>

    window.setInterval(function () {

        var postcnt = $('#post_count').val();
        var postdbcount = <?php echo count($blog_data); ?>;
        var currentStatus = $('#slideOne').val();
        //for post filter(self-public)

//        alert(currentStatus);


        $.ajax({
            type: "GET",
            url: '<?php echo base_url(); ?>dashboard/get_blogs',
            data: {current_status: currentStatus},
            success: function (data) {

                var parsed = $.parseJSON(data);
                //for post filter(self-public)

                var postdbcount = parsed.count;
                $('#post_count').val(postdbcount);
//                alert(postdbcount);
                //if (postdbcount > postcnt || postdbcount < postcnt) {

                $('#post_count').val(postdbcount);
//                $('#blog_detail').val('');

                $('.timeline').html('');
                $('.timeline').html(parsed.content);
                //}
            }
        });
    }, 3000000);
</script>

<!--Filter for public and private post-->
<script>
    //0 = public 99 = self
    $('#slideOne').on('change', function () {
        $('.loader').show();
        $('.white-bg').addClass('overlay');
        var currentStatus = $('#slideOne').val();

        if (currentStatus == '0') {
            $('#slideOne').val('99');
            currentStatus = 99;
        }
        else {
            $('#slideOne').val('0');
            currentStatus = 0;
        }
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/get_blogs',
            data: {current_status: currentStatus},
            success: function (data) {
                $('.white-bg').removeClass('overlay');
                $('.loader').hide();
                var parsed = $.parseJSON(data);
                //for post filter(self-public)                
                var postdbcount = parsed.count;
                $('#post_count').val(postdbcount);
//                alert(postdbcount);
                //if (postdbcount > postcnt || postdbcount < postcnt) {

                $('#post_count').val(postdbcount);
                $('#blog_detail').val('');

                $('.timeline').html('');
                $('.timeline').html(parsed.content);
                //}
            }
        });
//        alert(this.value);
    })
</script>
<style>
    .overlay {
        /*background: #e9e9e9;*/  
        display: block;        
        /*position: absolute;*/   
        /*        top: 0;                  
                right: 0;               
                bottom: 0;
                left: 0;*/
        opacity: 0.5;
    }
    .loader {    
        margin: 8% auto 0;
        border: 6px solid #f3f3f3; /* Light grey */
        border-top: 6px solid #505050; /* Blue */
        border-radius: 50%;
        width: 60px;
        height: 60px;
        animation: spin 1s linear infinite;

    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>
