<!-- Conference Booking modal -->
<div class="modal fade" id="conference-book" role="dialog">
    <div class="modal-dialog" >

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Conference Booking</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal"> 
                    <div class="form-group">
                        <label for="roomtype" class="col-sm-3 control-label">Room Name</label>
                        <div class="col-sm-8">
                            <select class="form-control select2" style="width:100%;">
                                <option selected="selected">Shivneri</option>
                                <option>Sinhagad</option>
                                <option>Sindhudurg</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dt1" class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="dt1">
                            </div>
                        </div>
                    </div> 
                    <div class="form-group">
                        <div class="col-sm-12 right-align">

                            <span class="badge badge-orange right-align" onclick="checkAvaliability()" data-toggle="modal" data-target="#show-availabilty">check availability</span>
                        </div>
                    </div>
                    <!--<div class="form-group">
                      <label class="col-sm-9 col-sm-offset-3">Pending Leave</label>
                    </div> -->
                    <div class="form-group">
                        <label for="room-book-reason" class="col-sm-3 control-label">Reason</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" id="room-book-reason" rows="3" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>            
                    <div class="form-group">
                        <div class="col-sm-10 col-sm-offset-1 text-right">
                            <button class="btn btn-sm">Cancel</button>
                            <button class="btn btn-info btn-sm">Submit</button>                      
                        </div>
                    </div>
                </form>
            </div>     
        </div>      
    </div>
</div>
<!-- Conference Booking modal -->
<!--show-availabilty modal-->
<div class="modal fade" id="show-availabilty" role="dialog">
    <div class="modal-dialog" style="width:800px !important;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header all-padding-10">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title font-16">Check Availability</h4>
            </div>
            <!-- modal body here --> 
            <div class="modal-body">          
                <form class="form-horizontal"> 
                    <div class="form-group">
                        <div class="row">
                            <!--Availability start here-->
                            <div class="col-sm-12">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <div class="col-sm-4">
                                            Available <i class="fa fa-square-o icon-lg text-green"></i>
                                        </div>
                                        <div class="col-sm-4">
                                            Your Selection   <i class="fa fa-square icon-lg-o text-green"></i>
                                        </div>
                                        <div class="col-sm-4">
                                            Unavailable  <i class="fa fa-square icon-lg text-gray"></i>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!--Availability end here-->

                            <!--Tab Start here-->
                            <div class="col-md-12">

                                <ul class="nav nav-tabs">
                                    <h5 class="text-center">Booking Dates</h5>
                                    <li class="active">
                                        <a href="#home-3" data-toggle="tab">
                                            <i class="fa fa-calendar"></i> 1 jan 17
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#profile-3" data-toggle="tab">
                                            <i class="fa fa-calendar"></i> 2 jan 17 
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#messages-3" data-toggle="tab">
                                            <i class="fa fa-calendar"></i> 3 jan 17
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#settings-3" data-toggle="tab">
                                            <i class="fa fa-calendar"></i> 4 jan 17
                                        </a>
                                    </li>
                                </ul>
                                <input id="selected_count_id" value="0" type="hidden"/>
                                <div class="tab-content">
                                    <div class="tab-pane fade in active" id="home-3">
                                        <div>
                                            <div class="row border-bottom-dash">

                                                <div class="col-sm-3">
                                                </div>

                                                <div class="col-sm-9 margin-top-5 "> 
                                                    <?php $j = 9; ?>
                                                    <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                        <b class="margin-right-18 small"><?php echo $i ?></b>   
                                                        <?php
                                                        $j = $j + 1;
                                                    }
                                                    ?>   
                                                </div>

                                            </div>

                                            <div class="row  border-bottom-dash">
                                                <div class="col-sm-3">
                                                    <label for="roomtype" class="col-sm-3 control-label">Shivneri</label>
                                                </div>
                                                <div class="col-sm-9 margin-top-10 ">  
                                                    <div class="hideShivneri">
                                                        <div class="btn-group" data-toggle="buttons">
                                                            <?php for ($i = 1; $i <= 16; $i++) { ?> 
                                                                <i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="<?php echo $i ?>" onclick="checkShivneri(<?php echo $i ?>)"><input type="checkbox" id="check-shivneri-<?php echo $i ?>" name="check-shivneri-<?php echo $i ?>[<?php echo $i ?>]" >    </i>                                
                                                            <?php } ?>   
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row border-bottom-dash">
                                                <div class="col-sm-3">
                                                    <label for="roomtype" class="col-sm-3 control-label">Sihangad</label>
                                                </div>
                                                <div class="col-sm-9 margin-top-10"> 
                                                    <div class="hideSihangad">
                                                        <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                            <i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="sih-<?php echo $i ?>" onclick="checkSihangad('sih-<?php echo $i ?>')">
                                                                <input type="checkbox" id="check-sihangad-sih-<?php echo $i ?>" name="check-sihangad-sih-<?php echo $i ?>[<?php echo $i ?>]" >    
                                                            </i>
                                                            <!--<i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="sih-<?php echo $i ?>" onclick="checkSihangad('sih-<?php echo $i ?>')"></i>-->                                
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row border-bottom-dash">
                                                <div class="col-sm-3">
                                                    <label for="roomtype" class="col-sm-3 control-label">Sindhurdurg</label>
                                                </div>
                                                <div class="col-sm-9 margin-top-10">
                                                    <div class="hideSindhurdurg">
                                                        <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                            <i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')">
                                                                <input type="checkbox" id="check-sindhurdurg-sind-<?php echo $i ?>" name="check-sindhurdurg-sind-<?php echo $i ?>[<?php echo $i ?>]" >    
                                                            </i>
                                                            <!--<i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')"></i>-->                                
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row border-bottom-dash">
                                                <div class="col-sm-3">
                                                    <label for="roomtype" class="col-sm-3 control-label">Rajgad</label>
                                                </div>
                                                <div class="col-sm-9 margin-top-10 "> 
                                                    <div class="hideRajgad">
                                                        <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                            <i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="raj-<?php echo $i ?>" onclick="checkRaigad('raj-<?php echo $i ?>')"></i>                                
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div> 
                                    <div class="tab-pane fade" id="profile-3">

                                        <div class="row border-bottom-dash">
                                            <div class="col-sm-3">
                                                <label for="roomtype" class="col-sm-3 control-label">Sindhurdurg</label>
                                            </div>
                                            <div class="col-sm-9 margin-top-10 ">
                                                <div class="hideSindhurdurg">
                                                    <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                        <i class="fa fa-square-o icon-lg text-green fa-2cx margin-right-10" id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')"></i>                                
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom-dash">
                                            <div class="col-sm-3">
                                                <label for="roomtype" class="col-sm-3 control-label">Sindhurdurg</label>
                                            </div>
                                            <div class="col-sm-9 margin-top-10 ">
                                                <div class="hideSindhurdurg">
                                                    <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                        <i class="fa fa-square-o icon-lg text-green fa-2cx " id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')"></i>                                
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom-dash">
                                            <div class="col-sm-3">
                                                <label for="roomtype" class="col-sm-3 control-label">Sindhurdurg</label>
                                            </div>
                                            <div class="col-sm-9 margin-top-10">
                                                <div class="hideSindhurdurg">
                                                    <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                        <i class="fa fa-square-o icon-lg text-green fa-2cx " id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')"></i>                                
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row border-bottom-dash">
                                            <div class="col-sm-3">
                                                <label for="roomtype" class="col-sm-3 control-label">Sindhurdurg</label>
                                            </div>
                                            <div class="col-sm-9 margin-top-10">
                                                <div class="hideSindhurdurg">
                                                    <?php for ($i = 1; $i <= 16; $i++) { ?>
                                                        <i class="fa fa-square-o icon-lg text-green fa-2cx " id="sind-<?php echo $i ?>" onclick="checkSindhurdurg('sind-<?php echo $i ?>')"></i>                                
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="tab-pane fade" id="messages-3">



                                    </div>

                                    <div class="tab-pane fade" id="settings-3">


                                    </div>
                                </div>

                            </div>



                        </div>

                    </div>    
                </form> 
                <div class="form-group">
                    <div class="col-sm-10 col-sm-offset-1 text-right">
                        <button class="btn btn-sm">Cancel</button>
                        <button class="btn btn-info btn-sm">Submit</button>                      
                    </div>
                </div>
            </div>      
        </div>
    </div>
</div>
<!--show-availabilty modal-->

<script>
    var i = 1;
    var myarray = [];
    function checkAvaliability(dId) {
        //        if()
        $("div").remove("#" + dId);
        //        $.ajax({
        //            type: "POST",
        //            url: '<?php echo base_url(); ?>employee/delete_skills',
        //            data: {'skills_id': dId},
        //            success: function (data) {
        //                alert('deleted successfully');
        //            }
        //        });
        return false;
    }

    function checkShivneri(id) {

        if ($("#check-shivneri-" + id).prop("checked") == true) {
            $("#check-shivneri-" + id).prop('checked', false);
            $("#" + id).toggleClass("fa-square");
        }
        else {
            $("#check-shivneri-" + id).prop('checked', true);
            $("#" + id).toggleClass("fa-square");
        }

    }
    function checkSihangad(id) {
        if ($("#check-sihangad-" + id).prop("checked") == true) {
            $("#check-sihangad-" + id).prop('checked', false);
            $("#" + id).toggleClass("fa-square");
        }
        else {
            $("#check-sihangad-" + id).prop('checked', true);
            $("#" + id).toggleClass("fa-square");
        }

        //        $("#1").removeClass();
        //        $(".hideShivneri").css('display', 'none');
        //        $(".hideRajgad").css('display', 'none');
        //        $(".hideSindhurdurg").css('display', 'none');
        //        $(".selected_count_id").val('0');

        //        $('.hideShivneri').click(false);
        //    $(".hideShivneri").attr('disabled','disabled');
        //        $("#" + id).toggleClass("fa-square");
    }
    function checkSindhurdurg(id) {
        if ($("#check-sindhurdurg-" + id).prop("checked") == true) {
            $("#check-sindhurdurg-" + id).prop('checked', false);
            $("#" + id).toggleClass("fa-square");
        }
        else {
            $("#check-sindhurdurg-" + id).prop('checked', true);
            $("#" + id).toggleClass("fa-square");
        }
    }
    function checkRaigad(id) {
        //        $("#1").removeClass();
        //        $(".hideSindhurdurg").css('display', 'none');
        //        $(".hideSihangad").css('display', 'none');
        //        $(".hideShivneri").css('display', 'none');
        $("#" + id).toggleClass("fa-square");
    }
</script>