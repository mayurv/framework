<?php // var_dump($profile_summary);die;                                               ?>

<link href="<?php echo base_url(); ?>assets/css/hrms-inline-input.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/moment.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/daterangepicker.js" type="text/javascript"></script> 
<link href="<?php echo base_url(); ?>assets/plugins/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" media="screen"/>
<!--content section start-->
<section id="main-content" class=" sidebar_shift ">
    <section class="wrapper">
        <!-- containt page row start here -->
        <div class="row">

            <!--column 8 left center part start here -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  


                <!-- second row start here -->
                <div class="row">
                    <div class="col-sm-12">
                        <section class="box">                                    
                            <div class="leave-main-bg">                            
                                <div class="row">

                                    <!-- apply Leave start here -->

                                    <!-- apply Leave end here -->

                                    <!-- apply Leave start here -->
                                    <div class="col-sm-4">
                                        <a class="btn btn-teal" data-toggle="modal" href="#ultraModal-1">Apply Leave</a>

                                        <!-- modal start -->
                                        <div class="modal fade" id="ultraModal-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                                            <div class="modal-dialog aply-leave-modal">
                                                <div class="modal-content">
                                                    <div class="modal-header modal-header-blue">
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                        <h4 class="modal-title">Apply Leave</h4>
                                                    </div>
                                                    <div class="modal-body">

                                                        <div class="leave-apply-frm-bg">
                                                            <?php echo form_open('employee/apply_leave'); ?>

                                                            <div class="form-group"> 
                                                                <?php echo form_label(lang('leave_day_type'), 'leave', array('class' => 'form-label')); ?>:
                                                                <?php echo form_dropdown('leave_day_type', $leave_day_type, $leave_day_type, array('class' => 'form-control input-sm m-bot15', 'id' => 'cardltype1', 'name' => 'leave_day_type')); ?>
                                                            </div>

                                                            <div class="form-group">

                                                                <?php echo form_label(lang('leave_type'), 'leave_type', array('class' => 'form-label')); ?>:
                                                                <?php echo form_dropdown('leave_type', $leave_type, $leave_type, array('class' => 'form-control input-sm m-bot15', 'id' => 'cardltype2', 'name' => 'leave_type')); ?>

                                                            </div>

                                                            <div class="form-group">
                                                                <?php echo form_label(lang('date'), 'date', array('class' => 'form-label', 'for' => 'daterange-1')); ?>:
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'leave_date',
                                                                        'id' => 'cardlfrmtodate',
                                                                        'class' => 'form-control daterange',
                                                                        'data-format' => 'DD/MM/YYYY'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <?php // echo form_label(lang('reportind_manager'), 'reportind_manager', array('class' => 'form-label','hidden')); ?>:
                                                                <div class="controls">
                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'reportind_manager',
                                                                        'id' => 'cardlrptmanager',
                                                                        'value' => $user->reporting_manager,
                                                                        'class' => 'form-control daterange',
                                                                        'type' => 'hidden'
                                                                    ));
                                                                    ?>

                                                                    <?php
                                                                    echo form_input(array(
                                                                        'name' => 'leave_status',
                                                                        'value' => 0,
                                                                        'class' => 'form-control',
                                                                        'type' => 'hidden'
                                                                    ));
                                                                    ?><?php
                                                                    echo form_input(array(
                                                                        'name' => 'no_of_days',
                                                                        'value' => '',
                                                                        'class' => 'form-control',
                                                                        'type' => 'hidden'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>   

                                                            <div class="form-group">
                                                                <?php echo form_label(lang('leave_reason'), 'leave_reason', array('class' => 'form-label', 'for' => 'lrreason')); ?>:
                                                                <div class="controls">    
                                                                    <?php
                                                                    echo form_textarea(array(
                                                                        'name' => 'leave_reason',
                                                                        'id' => 'cardlreason',
                                                                        'class' => 'form-control',
                                                                        'cols' => '5'
                                                                    ));
                                                                    ?>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">          
                                                                <button type="submit" class="btn btn-teal">Apply</button>
                                                                <button type="reset" class="btn btn-default">Cancel</button>
                                                            </div>

                                                            <?php echo form_close(); ?>
                                                        </div>


                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- modal end -->






                                    </div>
                                    <!-- apply Leave end here -->










                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <!-- second row start here -->




            </div>
            <!--column 8 left center part end here -->



        </div>
        <!-- containt page row end here -->
    </section>
</section>
<!--content section end-->        