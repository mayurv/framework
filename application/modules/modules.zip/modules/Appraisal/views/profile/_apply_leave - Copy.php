<?php // var_dump($profile_summary);die;                                                            ?>

<link href="<?php echo base_url(); ?>assets/css/hrms-inline-input.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/moment.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/js/daterangepicker.js" type="text/javascript"></script> 
<link href="<?php echo base_url(); ?>assets/plugins/daterangepicker/css/daterangepicker-bs3.css" rel="stylesheet" type="text/css" media="screen"/>
<!--content section start-->
<section id="main-content" class=" sidebar_shift ">
    <section class="wrapper">
        <!-- containt page row start here -->
        <div class="row">
            <!--column 8 left center part start here -->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
                <!-- title here -->
                <div class="row">
                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                        <div class="page-title">                                        
                            <h2 class="bottom-margin-0">Apply Leave</h2>                                        
                        </div>
                    </div>
                </div> 
                <!-- title here end-->

                <!-- second row start here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="leave-main-bg">
                            <div class="row">
                                <!-- apply Leave start here -->
                                <div class="col-sm-4">
                                    <a class="btn btn-teal" data-toggle="modal" href="#ultraModal-1">Apply Leave</a>

                                    <!-- modal start -->
                                    <div class="modal fade " id="ultraModal-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
                                        <div class="modal-dialog modal-400">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    <h4 class="modal-title">Leave Application</h4>
                                                </div>
                                                <div class="modal-body">

                                                    <!-- 
                                                                                                            <div class="leave-apply-profile-bg">    
                                                                                                               <img src="data/profile/user.png" class="img-circle img-profile" />
                                                                                                            </div> -->
                                                    <!-- 
                                                                                                            <div class="leave-apply-label-bg">
                                                                                                                <p>Balram Kamble</p>
                                                                                                                <p>MWX0001</p>                                           
                                                                                                            </div> -->

                                                    <div class="leave-apply-frm-bg">

                                                        <form  action="#">

                                                            <div class="form-group">                                            
                                                                <label class="form-label">Leave :</label>
                                                                <select class="form-control input-sm m-bot15" id="cardltype1" name="">
                                                                    <option>Half Day</option>
                                                                    <option>Full Day</option>                                             
                                                                </select>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="form-label">Leave Type</label>
                                                                <select class="form-control input-sm m-bot15" id="cardltype2" name="">
                                                                    <option>Casual Leave</option>
                                                                    <option>Sick Leave</option>
                                                                    <option>Personal Leave</option>
                                                                </select>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="form-label" for="daterange-1">Date</label>
                                                                <div class="controls">
                                                                    <input type="text" id="cardlfrmtodate" class="form-control daterange">
                                                                </div>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="form-label" for="lrreason">Reason</label>
                                                                <div class="controls">
                                                                    <textarea class="form-control" cols="5" id="cardlreason"></textarea>
                                                                </div>
                                                            </div>

                                                            <div class="form-group">          
                                                                <button type="submit" class="btn btn-blue">Apply</button>
                                                                <button type="reset" class="btn btn-default">Cancel</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <!-- modal end -->
                                </div>
                                <!-- apply Leave end here -->
                            </div>
                        </div>

                    </div>
                </div>
                <!-- second row start here -->




            </div>
            <!--column 8 left center part end here -->



        </div>
        <!-- containt page row end here -->
    </section>
</section>
<!--content section end-->      