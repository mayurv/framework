 <div class="row">
                                <!--<div class="col-sm-12 white-bg">-->
                                <div class="col-sm-12 white-bg">
                                <div class="all-padding-15">
                                    <h2> Associate Self Feedback</h2>

                                    <!--1st row here start --> 
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="box box-solid goal-box">
                                                <div class="box-header with-border">
                                                    <h3 class="box-title font-size-16 font-w-500">Feedback Questions</h3>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                    <div class="table-responsive table-condensed">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="col-md-4">Question</th>
                                                                    <th class="col-md-4">
                                                                        Response from Balram K
                                                                    </th>
                                                                    <th class="col-md-1 text-center">Rating</th>
                                                                    <th class="col-md-1 text-center">Potential</th>
                                                                    <th class="col-md-2">Rating definition</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <p class="text-justify">Did the person demonstrate the ability to analyze, investigate &amp; interpret data, issues &amp; situations?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>dfesf</p>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            1 <span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Significantly underperforms</p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <p>Did the person demonstrate the ability to provide and gather information and effectively communicate with the team?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>aedwaedawrf</p>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            2 <span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Needs improvement</p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <p>Was the person able to plan, organize and prioritize work balancing resources, skills, priorities and timescales to achieve objectives?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>aedad</p>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            5 <span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Top performer</p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <p>Was the person able to evaluate or judge the best course of action and to make decisions at the appropriate speed?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>wedwfwe</p>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            4 <span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Exceeds expectations</p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <p>Did the person respond and adapt to changing circumstances and manage to solve problems and provide solutions in a climate of ambiguity?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>wedwr</p>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            3<span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Meets expectations</p>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <p>Was the person able to work ethically according to the company values?</p>
                                                                    </td>
                                                                    <td>
                                                                        <p>wedwaewerw</p>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-success tooltip">
                                                                            3<span class="tooltiptext">Rating</span>
                                                                        </div>
                                                                    </td>
                                                                    <td class="text-center">
                                                                        <div class="badge badge-default tooltip">
                                                                            5 <span class="tooltiptext">Potential</span>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <p>Meets expectations</p>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <!-- /.box-body -->
                                            </div>
                                            <!-- /.box -->

                                            <div class="box box-solid goal-box">
                                                <div class="box-header with-border">
                                                    <h3 class="box-title font-size-16 font-w-500">Feedback Chart</h3>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                    <div class="chart-area">
                                                        <div id="score_chart" data-scores="[{&quot;score&quot;:1,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Did the person demonstrate the ability to analyze, investigate \u0026 interpret data, issues \u0026 situations?&quot;,&quot;question_number&quot;:&quot;Question 1&quot;},{&quot;score&quot;:2,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Did the person demonstrate the ability to provide and gather information and effectively communicate with the team?&quot;,&quot;question_number&quot;:&quot;Question 2&quot;},{&quot;score&quot;:5,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Was the person able to plan, organize and prioritize work balancing resources, skills, priorities and timescales to achieve objectives?&quot;,&quot;question_number&quot;:&quot;Question 3&quot;},{&quot;score&quot;:4,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Was the person able to evaluate or judge the best course of action and to make decisions at the appropriate speed?&quot;,&quot;question_number&quot;:&quot;Question 4&quot;},{&quot;score&quot;:3,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Did the person respond and adapt to changing circumstances and manage to solve problems and provide solutions in a climate of ambiguity?&quot;,&quot;question_number&quot;:&quot;Question 5&quot;},{&quot;score&quot;:3,&quot;score_potential&quot;:5,&quot;question_text&quot;:&quot;Was the person able to work ethically according to the company values?&quot;,&quot;question_number&quot;:&quot;Question 6&quot;}]" style="position: relative;"><svg height="342" version="1.1" width="1051" xmlns="http://www.w3.org/2000/svg" style="overflow: hidden; position: relative; top: -0.849976px;"><desc>Created with Raphaël 2.1.2</desc><defs></defs><text style="text-anchor: end; font: 12px sans-serif;" x="39.5" y="307" text-anchor="end" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal"><tspan dy="4">0</tspan></text><path style="" fill="none" stroke="#aaaaaa" d="M52,307H1026" stroke-width="0.5"></path><text style="text-anchor: end; font: 12px sans-serif;" x="39.5" y="236.5" text-anchor="end" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal"><tspan dy="4">1.25</tspan></text><path style="" fill="none" stroke="#aaaaaa" d="M52,236.5H1026" stroke-width="0.5"></path><text style="text-anchor: end; font: 12px sans-serif;" x="39.5" y="166" text-anchor="end" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal"><tspan dy="4">2.5</tspan></text><path style="" fill="none" stroke="#aaaaaa" d="M52,166H1026" stroke-width="0.5"></path><text style="text-anchor: end; font: 12px sans-serif;" x="39.5" y="95.5" text-anchor="end" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal"><tspan dy="4">3.75</tspan></text><path style="" fill="none" stroke="#aaaaaa" d="M52,95.5H1026" stroke-width="0.5"></path><text style="text-anchor: end; font: 12px sans-serif;" x="39.5" y="25" text-anchor="end" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal"><tspan dy="4">5</tspan></text><path style="" fill="none" stroke="#aaaaaa" d="M52,25H1026" stroke-width="0.5"></path><text style="text-anchor: middle; font: 12px sans-serif;" x="831.2" y="319.5" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4">Question 5</tspan></text><text style="text-anchor: middle; font: 12px sans-serif;" x="636.4000000000001" y="319.5" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4">Question 4</tspan></text><text style="text-anchor: middle; font: 12px sans-serif;" x="441.6" y="319.5" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4">Question 3</tspan></text><text style="text-anchor: middle; font: 12px sans-serif;" x="246.8" y="319.5" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4">Question 2</tspan></text><text style="text-anchor: middle; font: 12px sans-serif;" x="52" y="319.5" text-anchor="middle" font="10px &quot;Arial&quot;" stroke="none" fill="#888888" font-size="12px" font-family="sans-serif" font-weight="normal" transform="matrix(1,0,0,1,0,7)"><tspan dy="4">Question 1</tspan></text><path style="" fill="none" stroke="#777777" d="M52,25C100.7,25,198.10000000000002,25,246.8,25C295.5,25,392.90000000000003,25,441.6,25C490.30000000000007,25,587.7,25,636.4000000000001,25C685.1000000000001,25,782.5,25,831.2,25C879.9000000000001,25,977.3,25,1026,25" stroke-width="3"></path><path style="" fill="none" stroke="#9ad268" d="M52,250.6C100.7,236.5,198.10000000000002,222.39999999999998,246.8,194.2C295.5,166,392.90000000000003,39.099999999999994,441.6,25C490.30000000000007,10.9,587.7,67.3,636.4000000000001,81.4C685.1000000000001,95.5,782.5,130.75,831.2,137.8C879.9000000000001,144.85000000000002,977.3,137.8,1026,137.8" stroke-width="3"></path><circle cx="52" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="246.8" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="441.6" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="636.4000000000001" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="831.2" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="1026" cy="25" r="4" fill="#777777" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="52" cy="250.6" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="246.8" cy="194.2" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="441.6" cy="25" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="636.4000000000001" cy="81.4" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="831.2" cy="137.8" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle><circle cx="1026" cy="137.8" r="4" fill="#9ad268" stroke="#ffffff" style="" stroke-width="1"></circle></svg><div class="morris-hover morris-default-style" style="left: 208.3px; top: 35px; display: none;"><div class="morris-hover-row-label">Question 2</div><div class="morris-hover-point" style="color: #9AD268">
                                                                    Rating:
                                                                    2
                                                                </div><div class="morris-hover-point" style="color: #777777">
                                                                    Potential:
                                                                    5
                                                                </div></div></div>
                                                        <script>
                                                            $(function () {
                                                            });

                                                            new Morris.Line({
                                                                element: "score_chart",
                                                                data: $("#score_chart").data("scores"),
                                                                xkey: "question_number",
                                                                ykeys: ["score", "score_potential"],
                                                                parseTime: false,
                                                                ymax: 5,
                                                                labels: ["Rating", "Potential"],
                                                                lineColors: ["#9AD268", "#777777"],
                                                                hideHover: "auto"
                                                            });
                                                        </script>
                                                    </div>                                                    
                                                </div>
                                                <!-- /.box-body -->
                                            </div>
                                            <!-- /.box -->

                                            <div class="box box-solid goal-box">
                                                <div class="box-header with-border">
                                                    <h3 class="box-title font-size-16 font-w-500">Self assessment from Balram K </h3>
                                                </div>
                                                <!-- /.box-header -->
                                                <div class="box-body">
                                                    <div class="list-group">
                                                        <div class="list-group-item">
                                                            <div class="list-label">
                                                                <div class="label label-default margin-right-10">Self Assessment</div>
                                                            </div>
                                                            <div class="inline-block">juyijuyhikuko</div>
                                                        </div>
                                                        <div class="list-group-item">
                                                            <div class="list-label">
                                                                <div class="label label-default margin-right-10">Self Assessment Rating</div>
                                                            </div>
                                                            <div class="inline-block">Needs improvement</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.box-body -->
                                                <div class="box-footer"> 
                                                    <small>
                                                        <i class="fa fa-clock-o"></i>
                                                        Self assessment created on
                                                        6th April 2017
                                                    </small>

                                                </div>
                                            </div>
                                            <!-- /.box -->

                                        </div>
                                    </div>
                                    <!--1st row here end -->
                                </div>
                                </div>
                            </div>