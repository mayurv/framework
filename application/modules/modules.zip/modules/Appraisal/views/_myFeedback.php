<div class="row">
                <!--1st dashboard here start --> 
                <div class="row">
                    <div class="col-sm-3">

                        <?php foreach ($my_requested_feedback as $r => $data) { ?>
                            <div class="box box-solid <?php echo $data['feedback_status'] == 1 ? 'bg-success' : 'bg-warning' ?>">
                                <div class="box-body all-padding-20 text-center text-white">
                                    <i class="fa <?php echo $data['feedback_status'] == 1 ? 'fa-check' : 'fa-exclamation' ?> fa-4x"></i>
                                    <hr class="goal-line">
                                    <h2 class="font-w-500"><?php echo $r + 1 ?></h2>
                                    <p class="text-uppercase"><?php echo $data['feedback_status'] == 1 ? 'Feedback Complete' : 'Feedback not received' ?></p>
                                    <small>
                                        <?php echo $data['name'] ?>
                                    </small>
                                </div>
                                <!-- /.box-body -->
                            </div>
                        <?php } ?>



                    </div>
                    <!-- /.col-->

                    <div class="col-sm-9">    
                        <?php // var_dump($my_requested_feedback);die;?>
                        <?php foreach ($my_requested_feedback as $data) {
                            ?>

                            <div class="row"> 
                                <div class="col-sm-12"><hr class="margin-top-5" /></div>
                            </div>


                            <div class="box box-solid goal-box-border">
                                <div class="box-header with-border bg-gray-light">

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <h4 class="box-title font-size-16 font-w-500"><?php echo $data['name'] ?></h4>
                                        </div>
                                        <div class="col-sm-6 ">
                                     
                                            <div class="pull-right">                                                

                                                <div class="text-gray"> <?php echo date('d F Y', strtotime($data['createddate'])); ?> </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="box-body">


                                    <div class="row">
                                        <div class="col-sm-12">
                                            <?php if (isset($data['mang_status']) && $data['mang_status'] != 0) {
                                                ?>
                                                <?php
                                                $data_remark = array(1 => 'Significantly underperforms',
                                                    2 => 'Needs improvement',
                                                    3 => 'Meets expectations',
                                                    4 => 'Exceeds expectations',
                                                    5 => 'Top performer'
                                                );
                                                ?>
                                                <?php $remark = $data_remark[$data['mang_status']] ?>

                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <i class="fa fa-pencil"> </i> <b> <?php echo $data['userfullname'] ?></b>
                                                    </div>
                                                    <div class="col-sm-6 ">
                                                        <div class="text-gray pull-right">
                                                            <?php echo date('l d F Y', strtotime($data['mang_createddate'])) ?>
                                                        </div>

                                                    </div>
                                                </div>


                                                <table class="table ">

                                                    <tbody>
                                                        <tr>
                                                            <th>Remark</th>
                                                            <td><?php echo $remark ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Comment</th>
                                                            <td><?php echo $data['mang_comment'] ?></td>
                                                        </tr>

                                                    </tbody>
                                                </table>

                                            <?php } else { ?>
                                                <div class="alert alert-default"><b>Note : </b> Feedback yet to come</div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>                      
                            </div>
                        <?php } ?>

                    </div>
                    <!-- /.col -->


                </div>
                <!--1st dashboard here end -->
            </div>