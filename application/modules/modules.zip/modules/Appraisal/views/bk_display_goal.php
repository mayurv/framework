<script src="https://www.google.com/jsapi"></script>
<link href="<?php echo base_url('assets/css/pwerformance.css'); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url('assets/css/performance-theme.css'); ?>" rel="stylesheet" type="text/css"/>
<link href='https://fonts.googleapis.com/css?family=Cedarville+Cursive' rel='stylesheet' type='text/css'>
<script src="//d3n380booc75fg.cloudfront.net/assets/application-26b040b9491d13d260cf2c1a8fb0a2be.js"></script>
<div class="main-bg">
   <div class="row">
        <div class="col-lg-6">
            <div id="page-title">
                <h1 class="page-header text-overflow">Goals</h1>
            </div>
        
        </div>
        <div class="col-lg-6">
            <span class="btn-group margin-top-20 pull-right margin-right-20">
                <a class="active btn btn-active-default btn-default needs-loading" data-disable-with="Loading ..." href="/goals">
                    <i class="fa fa-user margin-right-5"></i>
                    Your goals
                </a>
                <a class="btn btn-default needs-loading" data-disable-with="Loading ..." href="/goals/all-colleagues">
                    <i class="fa fa-sitemap margin-right-5"></i>
                    All colleagues
                </a>
            </span>
            <span class="btn-group margin-top-20 pull-right margin-right-20">
                <button class="btn btn-default" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-cogs fa-fw margin-right-5"></i>
                    Goal actions
                </button>
                <button class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu pull-left">
                    <li>
                        <a class="needs-loading" data-remote="true" href="/goals/remote_new_goal_modal"><i class="fa fa-plus fa-fw"></i>
                            New individual goal
                        </a></li>
                    <li class="divider"></li>
                    <li>
                        <a class="needs-loading" data-remote="true" href="/goals/remote_new_individual_goal_modal"><i class="fa fa-plus fa-fw"></i>
                            New colleague goal
                        </a></li>
                    <li>
                        <a class="needs-loading" data-remote="true" href="/goals/remote_new_single_teamgoal_modal"><i class="fa fa-plus fa-fw"></i>
                            New team goal
                        </a></li>
                    <li>
                        <a class="needs-loading" data-remote="true" href="/goals/remote_new_single_departmentgoal_modal"><i class="fa fa-plus fa-fw"></i>
                            New department goal
                        </a></li>
                    <li class="divider"></li>
                    <li>
                        <a href="/goals?sort=name">
                            <i class="fa fa-list fa-fw margin-right-5"></i>
                            Sort by name
                        </a>
                    </li>
                    <li>
                        <a href="/goals?sort=created_at">
                            <i class="fa fa-calendar fa-fw margin-right-5"></i>
                            Sort by created
                        </a>
                    </li>
                    <li>
                        <a href="/goals?sort=target_date">
                            <i class="fa fa-clock-o fa-fw margin-right-5"></i>
                            Sort by target date
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/reports/team-goals">
                            <i class="fa fa-users fa-fw margin-right-5"></i>
                            Show all team goals
                        </a>
                    </li>
                    <li>
                        <a href="/reports/department-goals">
                            <i class="fa fa-sitemap fa-fw margin-right-5"></i>
                            Show all department goals
                        </a>
                    </li>
                    <li>
                        <a href="/goals/goals_xls.xls">
                            <i class="fa fa-file-excel-o fa-fw margin-right-5"></i>
                            Export to Excel
                        </a>
                    </li>
                    <li>
                        <a href="/goals.pdf" target="_blank">
                            <i class="fa fa-file-pdf-o fa-fw margin-right-5"></i>
                            Export goals to PDF
                        </a>
                    </li>
                </ul>
            </span>
        </div>
    </div>
    <div id="page-content">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="panel">
                    <div class="panel-heading">
                        <div class="panel-control panel-control-btn">
                            <span class="goal-progress margin-right-10">
                                <span class="progress progress-striped progress-lg margin-bottom-0 active">
                                    <div aria-valuetransitiongoal="0" class="progress-bar progress-bar-info" id="1887448progress" aria-valuenow="0" style="width: 0%;">0%</div>
                                </span>
                            </span>
                            <button class="btn btn-default blacktip" data-placement="top" data-target="#collapse1" data-title="Expand" data-toggle="collapse" data-trigger="hover" data-original-title="" title="">
                                <i class="fa fa-chevron-down"></i>
                            </button>
                        </div>
                        <h3 class="panel-title panel-title-small">
                            <span class="margin-right-10">
                                <mark class="badge-mark">Your goal</mark>
                            </span>
                            <a data-target="#collapse1" data-toggle="collapse">
                                <span>jjjjjjj</span>
                            </a>
                        </h3>
                    </div>
                    <div class="collapse in panel-collapse" id="collapse1">
                        <div class="panel-body">
                            <small class="block pull-right margin-bottom-10">
                                <i class="fa fa-clock-o"></i>
                                Due
                                14 days from now
                                |
                                <a href="/goals/887448/edit">Edit goal</a>
                                |
                                <a href="/goals/887448/duplicate">Copy goal</a>
                                |
                                <span><a data-confirm="Are you sure you wish to delete this goal? It will be permanently removed from PeopleGoal." rel="nofollow" data-method="delete" href="/goals/887448">Delete goal</a></span>
                                <span class="badge badge-default margin-left-5">
                                    <i class="fa fa-check-circle fa-xs"></i>
                                    <small>Approved</small>
                                </span>
                            </small>
                            <table class="table table-striped margin-top-20">
                                <thead>
                                    <tr>
                                        <th class="col-md-6">Attribute</th>
                                        <th class="col-md-6">
                                            <span>Description</span>
                                            <span class="margin-left-5">
                                                <small class="text-thin">
                                                    (
                                                    <i class="fa fa-pencil"></i>
                                                    Click to edit
                                                    )
                                                </small>
                                            </span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="v-align-top">
                                        <td>Goal name</td>
                                        <td class="full-width red-empty"><span class="editable editable-pre-wrapped editable-click" title="Short description" data-type="textarea" data-model="goal" data-name="short_description" data-value="jjjjjjj" data-placeholder="Short description" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">jjjjjjj</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>Goal description</td>
                                        <td class="full-width"><span class="editable editable-pre-wrapped editable-click" title="Long description" data-type="textarea" data-model="goal" data-name="long_description" data-value="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500" data-placeholder="Long description" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>What is specific about your goal?</td>
                                        <td class="full-width"><span class="editable editable-pre-wrapped editable-click" title="Specific" data-type="textarea" data-model="goal" data-name="specific" data-value="p" data-placeholder="Specific" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">p</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>How will it be measured?</td>
                                        <td class="full-width"><span class="editable editable-pre-wrapped editable-click" title="Measurable" data-type="textarea" data-model="goal" data-name="measurable" data-value="pp" data-placeholder="Measurable" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">pp</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>How will you attain/achieve your goal?</td>
                                        <td class="full-width"><span class="editable editable-pre-wrapped editable-click" title="Attainable" data-type="textarea" data-model="goal" data-name="attainable" data-value="p" data-placeholder="Attainable" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">p</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>How is your goal relevant?</td>
                                        <td class="full-width"><span class="editable editable-pre-wrapped editable-click" title="Relevant" data-type="textarea" data-model="goal" data-name="relevant" data-value="p" data-placeholder="Relevant" data-url="/goals/887448" data-emptytext="N/A" data-rows="2" data-onblur="submit" data-mode="inline" data-showbuttons="false">p</span></td>
                                    </tr>
                                    <tr class="v-align-top">
                                        <td>When is the goal due to be achieved?</td>
                                        <td>
                                            <span>29th March 2017</span>
                                            <a class="margin-left-10" href="/goals/887448/edit">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="panel-footer panel-footer-gray">
                            <p>
                            </p><div class="row">
                                <div class="col-md-2">
                                    <span class="margin-right-10 margin-bottom-5">
                                        Goal update
                                    </span>
                                </div>
                                <div class="col-md-10 goal-labels">
                                    <span class="blacktip goal-label label label-default margin-right-5 padding-xs" data-placement="top" data-title="Click to set goal status" data-trigger="hover" id="887448status4" data-original-title="" title="">
                                        Complete
                                        <script>
                                            $("#887448status4").on("click", function () {
                                                return $.ajax({
                                                    type: 'POST',
                                                    url: '/goals/update_status',
                                                    dataType: 'json',
                                                    data: {
                                                        goal: {
                                                            goal_id: 887448,
                                                            u_update: 'Complete'
                                                        }
                                                    }
                                                });
                                            });
                                            $("#887448status4").on("click", function () {
                                                $("#887448status1").removeClass("label-info").addClass("label-default");
                                                $("#887448status2").removeClass("label-warning").addClass("label-default");
                                                $("#887448status3").removeClass("label-danger").addClass("label-default");
                                                $("#887448status4").removeClass("label-default").addClass("label-success");
                                            });
                                        </script>
                                    </span>
                                    <span class="blacktip goal-label label label-default margin-right-5 padding-xs" data-placement="top" data-title="Click to set goal status" data-trigger="hover" id="887448status2" data-original-title="" title="">
                                        Cost or scope at risk
                                        <script>
                                            $("#887448status2").on("click", function () {
                                                return $.ajax({
                                                    type: 'POST',
                                                    url: '/goals/update_status',
                                                    dataType: 'json',
                                                    data: {
                                                        goal: {
                                                            goal_id: 887448,
                                                            u_update: 'Cost or scope at risk'
                                                        }
                                                    }
                                                });
                                            });
                                            $("#887448status2").on("click", function () {
                                                $("#887448status1").removeClass("label-info").addClass("label-default");
                                                $("#887448status2").removeClass("label-default").addClass("label-warning");
                                                $("#887448status3").removeClass("label-danger").addClass("label-default");
                                                $("#887448status4").removeClass("label-success").addClass("label-default");
                                            });
                                        </script>
                                    </span>
                                    <span class="blacktip goal-label label label-default margin-right-5 padding-xs" data-placement="top" data-title="Click to set goal status" data-trigger="hover" id="887448status3" data-original-title="" title="">
                                        Corrective action required
                                        <script>
                                            $("#887448status3").on("click", function () {
                                                return $.ajax({
                                                    type: 'POST',
                                                    url: '/goals/update_status',
                                                    dataType: 'json',
                                                    data: {
                                                        goal: {
                                                            goal_id: 887448,
                                                            u_update: 'Corrective action required'
                                                        }
                                                    }
                                                });
                                            });
                                            $("#887448status3").on("click", function () {
                                                $("#887448status1").removeClass("label-info").addClass("label-default");
                                                $("#887448status2").removeClass("label-warning").addClass("label-default");
                                                $("#887448status3").removeClass("label-default").addClass("label-danger");
                                                $("#887448status4").removeClass("label-success").addClass("label-default");
                                            });
                                        </script>
                                    </span>
                                    <span class="blacktip goal-label label label-info margin-right-5 padding-xs" data-placement="top" data-title="Click to set goal status" data-trigger="hover" id="887448status1" data-original-title="" title="">
                                        Performing to plan/time
                                        <script>
                                            $("#887448status1").on("click", function () {
                                                return $.ajax({
                                                    type: 'POST',
                                                    url: '/goals/update_status',
                                                    dataType: 'json',
                                                    data: {
                                                        goal: {
                                                            goal_id: 887448,
                                                            u_update: 'Performing to plan/time'
                                                        }
                                                    }
                                                });
                                            });
                                            $("#887448status1").on("click", function () {
                                                $("#887448status1").removeClass("label-default").addClass("label-info");
                                                $("#887448status2").removeClass("label-warning").addClass("label-default");
                                                $("#887448status3").removeClass("label-danger").addClass("label-default");
                                                $("#887448status4").removeClass("label-success").addClass("label-default");
                                            });
                                        </script>
                                    </span>
                                </div>
                            </div>
                            <p></p>
                            <p>
                            </p><div class="row">
                                <div class="col-md-2">
                                    <span class="margin-right-10 margin-bottom-5">
                                        Goal comments
                                    </span>
                                </div>
                                <div class="col-md-10">
                                    <em>No comments</em>
                                    <div class="row margin-top-10">
                                        <div class="col-md-2">
                                            <a class="btn btn-sm btn-default" data-toggle="collapse" href="#commentForm1">
                                                <i class="fa fa-comment fa-xs margin-right-5"></i>
                                                <span>Add a comment</span>
                                            </a>
                                        </div>
                                        <div class="col-md-10 collapse" id="commentForm1">
                                            <form class="simple_form new_goal_comment" id="new_goal_comment" enctype="multipart/form-data" action="/goal_comments" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="✓"><input type="hidden" name="authenticity_token" value="LvXq9VfNfK8HQ5a0bLGPmAeXRqOZHJS3D2darpLvQ8anJWcUk10Bk35TiGncEw/CaneuJdnsR6fiatBtkjqmNw=="><div class="input-group">
                                                    <div class="control-group string required goal_comment_content"><div class="controls"><input class="string required form-control input-sm" required="required" aria-required="true" placeholder="Comment on this goal" type="text" name="goal_comment[content]" id="goal_comment_content"></div></div>
                                                    <span class="input-group-btn">
                                                        <input type="submit" name="commit" value="Submit" class="btn btn btn-md btn-default input-btn-height" data-disable-with="Submitting ...">
                                                    </span>
                                                </div>
                                                <div class="control-group hidden goal_comment_goal_id"><div class="controls"><input value="887448" class="hidden" type="hidden" name="goal_comment[goal_id]" id="goal_comment_goal_id"></div></div>
                                                <div class="control-group hidden goal_comment_user_id"><div class="controls"><input value="12699" class="hidden" type="hidden" name="goal_comment[user_id]" id="goal_comment_user_id"></div></div>
                                                <p>
                                                </p><div class="row">
                                                    <div class="col-md-6">
                                                        <span>Add an attachment (max. file size: 2mb)</span>
                                                        <span class="margin-top-10">
                                                            <div class="control-group file optional goal_comment_attachment"><div class="controls"><input class="file optional" type="file" name="goal_comment[attachment]" id="goal_comment_attachment"></div></div>
                                                        </span>
                                                    </div>
                                                </div>
                                                <p></p>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <p></p>
                            <p>
                            </p><div class="row">
                                <div class="col-md-2">
                                    <span class="margin-right-10">
                                        Goal progress
                                    </span>
                                </div>
                                <div class="col-md-4">
                                    <div class="in-progress-slider">
                                        <div class="slider slider-horizontal" id="ex1Slider" style="width: 139px;"><div class="slider-track"><div class="slider-selection" style="left: 0%; width: 0.01%;"></div><div class="slider-handle round" style="left: 0.01%;"></div><div class="slider-handle round hide" style="left: 0%;"></div></div><div class="tooltip top hide" style="top: -34px; left: -21.9662px;"><div class="tooltip-arrow"></div><div class="tooltip-inner">0.01</div></div><input data-slider-id="ex1Slider" data-slider-max="100" data-slider-min="0" data-slider-step="1" data-slider-tooltip="hide" data-slider-value="0.01" id="1887448" type="text" style="display: none;"></div>
                                    </div>
                                    <script>
                                        $('#1887448').slider(
                                                );
                                        $("#1887448").on("slide", function (slideEvt) {
                                            $("#887448span").text(slideEvt.value);
                                            $('#1887448progress').css('width', slideEvt.value + '%');
                                            $('#1887448progress').html(slideEvt.value + '%');
                                        });
                                        $("#1887448").on("slideStop", function (slideEvt) {
                                            $.ajax({
                                                type: 'POST',
                                                url: '/goals/update_progress',
                                                dataType: 'json',
                                                data: {
                                                    goal: {
                                                        goal_id: 887448,
                                                        progress: slideEvt.value
                                                    }
                                                }
                                            });
                                        });
                                    </script>
                                </div>
                                <div class="col-md-3">
                                    <div class="margin-left-minus-5 padding-top-5">
                                        <strong class="badge badge-info margin-right-5">
                                            <span id="887448span">
                                                0
                                            </span>
                                            <span style="margin-left: -2px">
                                                %
                                            </span>
                                        </strong>
                                        <a class="btn btn-default btn-sm margin-left-10" data-disable-with="Calculating ..." href="https://mexx.peoplegoal.com/goals/887448">
                                            <i class="fa fa-refresh margin-right-5"></i>
                                            Re-calculate progress
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <p></p>
                            <p class="small block margin-bottom-minus-5 margin-top-20">
                                <span>
                                    <i class="fa fa-clock-o"></i>
                                    Last updated
                                    less than a minute ago
                                    |
                                    Created on
                                    14th March 2017
                                </span>
                               
                            </p>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

