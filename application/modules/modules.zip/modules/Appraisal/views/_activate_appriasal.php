<?php // var_dump($department_list);die;                            ?>
<!--Activate Associate-->
<div class="main-bg all-padding-15"> 
    <div class="col-sm-8">
        <h4 class="text-bold">Activate Apprisal</h4>
    </div>
    <div class="clearfix"></div>

    <div class="candidate-ls">
        <div class="col-sm-12 border-left">
            <div class="post-list" id="postList">
                <div class="activate-slim">
                    <table id="dt-activate-associate" class="table table-responsive table-hover">
                        <thead>
                            <tr>
                                <!--<th class="text-center"><i class="fa fa-slack"></i></th>-->
                                <th>Associate Name</th>
                                <th>Joining Date</th>
                                <th>Last Apprisal</th>
                                <th>Appriasal Access Status</th>
                            </tr>
                        </thead>
                        <div class="pull-right"> 

                        </div>
                        <tbody >
                            <?php foreach ($employee as $result) { ?>
                                <tr id="deleteLeaveRow_<?php echo $result->user_id ?>">

                                    <td>
                                        <i><?php if (isset($result->profileimg) && $result->profileimg != '') { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $result->profileimg; ?>">  
                                            <?php } else { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                            <?php } ?></i>                               
                                        <p><a href="<?php echo base_url()?>employee/view_user/<?php echo $result->user_id; ?>"><?php echo $result->userfullname; ?> </a> 
                                            <small class="text-light-gray"> <?php echo $result->employeeId; ?></small>
                                        </p>
                                        <p>
                                            <small >
                                                <?php echo $result->department_name ?>, 
                                                <?php echo $result->position_name ?>
                                            </small>

                                        </p>
                                    </td>                        
                                    <td>
                                        <p><?php echo date("j F, Y", strtotime($result->date_of_joining)); ?></p>

                                        <p>
                                            <small class="text-light-gray" title="Created At"><?php echo date("j F, Y h:m A", strtotime($result->createddate)) ?></small>
                                        </p>
                                    </td>


                                    <td></td>
                                    <td>
                                        <div class="switch">
                                            <label>      
                                                <?php
                                                $ch = '';
                                                $hideDiv = 'none';
                                                $function = 'activateAssociate(' . $result->user_id . ')';
                                                if ($result->app_isactive == '1') {
                                                    $ch = "'checked'=>'TRUE'";
                                                    $hideDiv = 'none';
                                                    $chval = 1;
                                                } else {
                                                    $ch = "";
                                                    $hideDiv = 'block';
                                                    $chval = 0;
                                                }
                                                ?>

                                                <?php echo form_checkbox(array('id' => 'apprisalStatus_' . $result->user_id, 'name' => 'apprisalStatus', 'value' => $chval, 'checked' => $ch, 'onclick' => $function)); ?>
                                                <span class="lever"></span>                                    
                                            </label>
                                        </div>

                                    </td>                        
                                </tr>  
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php // $this->load->view('_activate_associate_filter');?>
<script>
    $(document).ready(function () {
        $('.activate-slim').slimscroll({
            width: '100%',
            height: '440px',
            axis: 'both'
        });
    });
</script>
<script>


    function activateAssociate(associateId) {
        var isChecked = $("#apprisalStatus_" + associateId).val();
        if (isChecked == 0) {
            $("#apprisalStatus_" + associateId).val('1');
        } else {
            $("#apprisalStatus_" + associateId).val('0');
        }
        var apprisal_status = $("#apprisalStatus_" + associateId).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>appraisal/activate_appriasal',
            data: {'associate_id': associateId, 'apprisal_status': apprisal_status},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.active == '1')
                    showSuccess("Associate Apprisal Activated Successfully");
                else
                    showSuccess("Associate Apprisal Deactivated Successfully");
            }
        });
    }

</script>
