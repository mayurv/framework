<!-- appraisal block here -->
<div class="row">
    <div class="col-sm-12 ">
        <div class="appraisal-bg">
            <!-- approach to work -->
            <div class="first-div">                    
                <div class="approach-bg">
                    <h3 class="page-header"> Approach to Work</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Fallows Instruction</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Proactive Approach</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Planning & Organizing</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Accepts Constructive Criticism</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q5. Flexible & Adaptable</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw13"></div>
                                    <p class="your-choice-was13 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice13"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw14"></div>
                                    <p class="your-choice-was14 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice14"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw15"></div>
                                    <p class="your-choice-was15 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice15"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div>                      
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
            </div>
            <!-- approach to work -->

            <!-- Technical Skill start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Technical Skills</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1.  Job Knowledge</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Application of Skill</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Analyzing of Skill</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Follow Procedures & Stadards</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q5.  Learning New Skill</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw13"></div>
                                    <p class="your-choice-was13 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice13"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw14"></div>
                                    <p class="your-choice-was14 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice14"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw15"></div>
                                    <p class="your-choice-was15 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice15"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div>

                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>

            </div>
            <!-- Technical Skill end here -->

            <!-- Quality of work start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Quality of Work</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Accuracy</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Presentation</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Reliability</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Follow-through and Follow-up</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div>  
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Quality of work end here -->

            <!-- Handling targets start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header">Handling Targets and Dead Lines</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Completion of Work on-time</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Ability to Work Under Pressure</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Priority Setting</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Handling targets end here -->

            <!-- interpersonal skill start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Interpersonal Skill</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Reletionship With Colleagues</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Co-operation & Co-ordination</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Team Work</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Problem Solving</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q5. Decision Making</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw13"></div>
                                    <p class="your-choice-was13 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice13"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw14"></div>
                                    <p class="your-choice-was14 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice14"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw15"></div>
                                    <p class="your-choice-was15 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice15"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- interpersonal skill end here -->

            <!-- Willingness start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Willingness to Learn and Develop Skill</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Seeks Training and Development</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Open to Ideas</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Willingness end here -->

            <!-- Communication start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Communication Skills</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Oral & Written Expressions</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Speaking in English</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3.  Shares Information/Knowledge willin</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Reporting</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->                           
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Communication end here -->

            <!-- Personality start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Personality</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Enthusiastic, Fair and Mature</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Trustworthy</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Volunteer in Infronic's Activity</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div>  
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Personality end here -->

            <!-- Code of conduct start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Code of Conduct</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Work Place Etiquette</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Attendance</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3. Punctuality</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Email & Mobile Phone Etiquette</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q5. Dress Code</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw13"></div>
                                    <p class="your-choice-was13 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice13"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw14"></div>
                                    <p class="your-choice-was14 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice14"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw15"></div>
                                    <p class="your-choice-was15 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice15"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!-- Code of conduct end here -->


            <!-- Leadership Skills start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <h3 class="page-header"> Leadership Skills</h3>
                    <div class="exam-content">
                        <!-- form start here -->
                        <form role="form">
                            <!-- heading here -->
                            <div class="row margin-top-bottom-5"> 
                                <div class="col-md-3 col-sm-3">&nbsp;</div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Associate</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">Manager</small></div>
                                <div class="col-md-2 col-sm-3"><small class="clr-999">HR</small></div>
                            </div>
                            <!-- heading here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q1. Coach and Develop Other</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw1"></div>
                                    <p class="your-choice-was1 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice1"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw2"></div>
                                    <p class="your-choice-was2 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice2"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw3"></div>
                                    <p class="your-choice-was3 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice3"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q2. Team Building</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw4"></div>
                                    <p class="your-choice-was4 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice4"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw5"></div>
                                    <p class="your-choice-was5 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice5"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw6"></div>
                                    <p class="your-choice-was6 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice6"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q3.  News Strategy and Direction</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw7"></div>
                                    <p class="your-choice-was7 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice7"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw8"></div>
                                    <p class="your-choice-was8 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice8"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw9"></div>
                                    <p class="your-choice-was9 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice9"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q4. Client Interation & Co-Ordination</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw10"></div>
                                    <p class="your-choice-was10 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice10"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw11"></div>
                                    <p class="your-choice-was11 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice11"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw12"></div>
                                    <p class="your-choice-was12 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice12"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->

                            <!-- row start here -->
                            <div class="row margin-bottom-10">
                                <!-- 1st question column start here -->
                                <div class="col-md-3 col-sm-3 padding-top-bottom-5"> 
                                    <p>Q5. Client Replies</p>
                                    <p><small class="clr-999">User 3/5 | Manager 2/5 | HR 3/5</small></p>
                                </div>
                                <!-- 1st question column end here -->
                                <!-- 2nd  user rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw13"></div>
                                    <p class="your-choice-was13 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice13"></span></small>
                                    </p>                              
                                </div>
                                <!-- 2nd  user rating column end here -->
                                <!-- 3rd  manager rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw14"></div>
                                    <p class="your-choice-was14 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice14"></span></small>
                                    </p>                              
                                </div>
                                <!-- 3rd  user rating column end here -->
                                <!-- 4th  HR rating column start here -->
                                <div class="col-md-2 col-sm-3 padding-top-bottom-5">
                                    <div class="starrr" id="aw15"></div>
                                    <p class="your-choice-was15 text-italic" style="display: none;">
                                        <small class="clr-999">Your rating was 
                                            <span class="choice15"></span></small>
                                    </p>                              
                                </div>
                                <!-- 4th  HR rating column end here -->
                            </div>
                            <!-- row end here -->
                            <div class="row margin-top-bottom-10">
                                <div class="col-sm-12">                           
                                    <textarea class="form-control" rows="2" placeholder="Enter Comment"></textarea>
                                </div>
                            </div>

                        </form>
                        <!-- form end here -->
                    </div>                    
                </div> 
                <button class="next btn btn-info pull-right margin-left-5 btn-next-right-margin">Next</button>
                <button class="back btn btn-default pull-right">Back</button>
            </div>
            <!--Leadership Skills end here -->

            <!-- Result start here -->
            <div class="next-div" style="display:none;">
                <div class="approach-bg">
                    <!-- <h3 class="page-header">Result</h3> -->
                    <div class="exam-content all-padding-6p text-center">
                        <h2>Thank You !</h2>
                        <p>You have Given</p>
                        <h3>30/50</h3>
                        <p class="margin-top-bottom-10">Points to Yourself</p>
                        <button class="btn btn-danger margin-top-bottom-30">Submit</button>
                    </div>                   
                </div> 
            </div>
            <!--result  end here -->


        </div>
    </div>
</div> 
<!-- appraisal block here -->

<script type="text/javascript">
    jQuery(document).ready(function () {
        $('.next').click(function () {
            $(this).parent().hide().next().show();//hide parent and show next
        });

        $('.back').click(function () {
            $(this).parent().hide().prev().show();//hide parent and show previous
        });


    });
</script>
<script>
    $(function () {
        $('#aw1').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was1').show();
                    $('.choice1').text(value);
                } else {
                    $('.your-choice-was1').hide();
                }
            }
        });

        $('#aw2').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was2').show();
                    $('.choice2').text(value);
                } else {
                    $('.your-choice-was2').hide();
                }
            }
        });

        $('#aw3').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was3').show();
                    $('.choice3').text(value);
                } else {
                    $('.your-choice-was3').hide();
                }
            }
        });

        $('#aw4').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was4').show();
                    $('.choice4').text(value);
                } else {
                    $('.your-choice-was4').hide();
                }
            }
        });

        $('#aw5').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was5').show();
                    $('.choice5').text(value);
                } else {
                    $('.your-choice-was5').hide();
                }
            }
        });

        $('#aw6').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was6').show();
                    $('.choice6').text(value);
                } else {
                    $('.your-choice-was6').hide();
                }
            }
        });

        $('#aw7').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was7').show();
                    $('.choice7').text(value);
                } else {
                    $('.your-choice-was7').hide();
                }
            }
        });

        $('#aw8').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was8').show();
                    $('.choice8').text(value);
                } else {
                    $('.your-choice-was8').hide();
                }
            }
        });

        $('#aw9').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was9').show();
                    $('.choice9').text(value);
                } else {
                    $('.your-choice-was9').hide();
                }
            }
        });

        $('#aw10').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was10').show();
                    $('.choice10').text(value);
                } else {
                    $('.your-choice-was10').hide();
                }
            }
        });

        $('#aw11').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was11').show();
                    $('.choice11').text(value);
                } else {
                    $('.your-choice-was11').hide();
                }
            }
        });

        $('#aw12').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was12').show();
                    $('.choice12').text(value);
                } else {
                    $('.your-choice-was12').hide();
                }
            }
        });

        $('#aw13').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was13').show();
                    $('.choice13').text(value);
                } else {
                    $('.your-choice-was13').hide();
                }
            }
        });

        $('#aw14').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was14').show();
                    $('.choice14').text(value);
                } else {
                    $('.your-choice-was14').hide();
                }
            }
        });

        $('#aw15').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was15').show();
                    $('.choice15').text(value);
                } else {
                    $('.your-choice-was15').hide();
                }
            }
        });




        $('#alldiv').starrr({
            change: function (e, value) {
                if (value) {
                    $('.your-choice-was-alldiv').show();
                    $('.choice-alldiv').text(value);
                } else {
                    $('.your-choice-was-alldiv').hide();
                }
            }
        });
    });
</script>




