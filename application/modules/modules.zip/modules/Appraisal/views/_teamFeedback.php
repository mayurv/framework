<?php // var_dump($user_summary['manager_id']);  ?>
<table id="app_feedback" class="table table-bordered ">
    <thead>
        <tr>
            <th>Name</th>
            <th>Feedback Detail</th>
        </tr>
    </thead>
    <tbody>
        <?php //var_dump($my_teamrequested_feedback); ?>
        <?php foreach ($my_teamrequested_feedback as $row) { ?>

            <tr>
                <td>
                    <div class="margin-top-40"></div>
                    <i><?php if (isset($row['profileimg']) && $row['profileimg'] != '') { ?>
                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $row['profileimg']; ?>">  
                        <?php } else { ?>
                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                        <?php } ?></i> 
                    <?php echo $row['userfullname']; ?>
                    <p>
                        <?php echo $row['department_name'] ?>, 
                        <?php echo $row['position_name'] ?>
                    </p>
                </td>

                <td>
                    <table class="table ">
                        <thead>
                            <tr>
                                <th>Goal Name</th>
                                <th>Goal Submitted Date</th>
                                <th>Feedback Given Date</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <?php foreach ($row['user_feedback'] as $data) { ?>
                            <?php // var_dump($row['user_feedback']); ?>
                            <tr>
                                <td>
                                    <?php echo $data['name'] ?>

                                </td>
                                <td>                                    
                                    <p><?php echo date('d F Y', strtotime($data['createddate'])) ?></p>
                                </td>
                                <td>                                    
                                    <p><?php if(isset($data['mang_createddate']) && $data['mang_createddate'] != '0000-00-00 00:00:00') echo date('d F Y', strtotime($data['mang_createddate'])) ?></p>
                                </td>
                                <td>
                                    <?php if ($user_summary['emprole'] == '3' || $user_summary['emprole'] == '1' || $user_summary['emprole'] == '4') { ?>
                                        <?php if ($data['feedback_status'] != 1) { ?>
                                            <div class="">
                                                <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#feedback-provide<?php echo $data['id'] ?>">
                                                    <i class="fa fa-pencil fa-xs"></i>
                                                    Feedback
                                                </button>
                                            </div>
                                        <?php } else { ?>
                                            <div class="">
                                                <button class="btn btn-success btn-xs" data-toggle="modal" data-target="#feedback-provide<?php echo $data['id'] ?>">
<!--                                                    <i class="fa fa-pencil fa-xs"></i>-->
                                                    Already Given
                                                </button>
                                            </div>
                                        <?php } ?>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>

                    </table>
                </td>


            </tr>

        <?php } ?>
    </tbody>
</table>
<?php $this->load->view('modal/_feedback') ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#app_feedback').DataTable({
            "pageLength": 100,
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
    });
</script>