  <?php if (isset($my_goals) && !empty($my_goals)) { ?>
                        <!--1st dashboard here start --> 
                        <div class="row">
                            <hr>
                            <div class="col-sm-3">
                                <?php foreach ($my_goals as $r => $data) { ?>
                                    <div class="box box-solid <?php echo $data['user_status'] == 1 ? 'bg-success' : 'bg-warning' ?>">
                                        <div class="box-body all-padding-20 text-center text-white">
                                            <i class="fa <?php echo $data['user_status'] == 1 ? 'fa-check' : 'fa-exclamation' ?> fa-4x"></i>
                                            <hr class="goal-line">
                                            <h2 class="font-w-500"><?php echo $r + 1 ?></h2>
                                            <p class="text-uppercase"><?php echo $data['user_status'] == 1 ? 'Goal Complete' : 'Goal Inprogress' ?></p>
                                            <small>
                                                <?php echo $data['name'] ?>
                                            </small>
                                        </div>
                                        <!-- /.box-body -->
                                    </div>
                                <?php } ?>
                            </div>
                            <!-- /.col-->

                            <div class="col-sm-9">                                    

                                <div class="row"> 
                                    <div class="col-sm-2"><h4 class="font-w-500 ">Average goals</h4></div>
                                    <div class="col-sm-10"> 

                                        <?php
                                        $per = 0;
                                        $cnt = count($my_goals);
                                        foreach ($my_goals as $data) {
                                            $per += $data['user_progress'];
                                        }
                                        $per_value = round($per / $cnt);
                                        ?>
                                        <div class="progress progress-goals progress-goals-avg">
                                            <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar" aria-valuenow="<?php echo $per_value ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $per_value ?>%; height: 100%">
                                                <span><?php echo $per_value ?>%</span>
                                            </div>
                                        </div>
                                        <!--<small class="text-info"><?php echo $per_value ?> %</small>-->
                                    </div>
                                </div>
                                <?php $flag = '0';
                                $colclass = '';
                                ?>
                                <?php foreach ($my_goals as $data) { ?>
        <?php echo $flag == '1' ? $colclass = "collapsed-box" : $colclass = ""; ?>

                                    <div class="row"> 
                                        <div class="col-sm-12"><hr class="margin-top-5" /></div>
                                    </div>

                                    <div class="box box-solid goal-box-border">
                                        <div class="box-header with-border bg-gray-light">

                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <h4 class="box-title font-size-16 font-w-500"><?php echo $data['name'] ?></h4>
                                                </div>
                                                <div class="col-sm-6">

                                                    <div class="row"> 
                                                        <div class="col-sm-7">                                                             
                                                            <div class="progress margin-top-10">
                                                                <div class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar" aria-valuenow="<?php echo $data['user_progress'] ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $data['user_progress'] ?>%">
                                                                    <span><?php echo $data['user_progress'] ?>%</span>
                                                                </div>

                                                            </div>
                                                            <small class="text-light-gray"><?php echo $data['user_progress'] ?> %</small>
                                                        </div>

                                                        <div class="col-sm-5">
                                                            <div class="box-tools pull-right">
                                                                <!--                                                        <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                                                                                                            <i class="fa fa-folder-open fa-lg"></i> Show Goal   <span class="tooltiptext">Open in new window</span>                                                          
                                                                                                                        </button>  -->

                                                                <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                                                    <i class="fa fa-angle-down fa-lg"></i> <span class="tooltiptext">Expand</span>
                                                                </button>  
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="box-body">
                                            <!--<div class="row">-->
                                            <div class="col-sm-12 margin-bottom-10">
                                                <div class="pull-right">
        <?php // if ($data['user_status'] == 0) {   ?>

                                                    <i class=""></i> <?php echo date('l d M Y', strtotime($data['createddate'])); ?> |

                                             <!--<a data-remote="true" data-toggle="modal" data-target="#edit_goal_<?php echo $data['id'] ?>">Edit goal</a> |-->


        <?php // }   ?>
                                                    <div class="btn btn-xs btn-default margin-left-5">
                                                        <i class="fa  <?php echo $data['user_status'] == 1 ? 'text-success fa-check-circle fa-xs' : 'fa-minus-circle fa-xs' ?>"></i>
        <?php echo $data['user_status'] == 1 ? 'Complete' : 'Inprogress' ?>
                                                    </div>
                                                </div>

                                            </div>
                                            <!--</div>-->

                                            <!--<div class="row">-->
                                            <div class="col-sm-12">
                                                <form name="goalProgressForm" method="post" id="goalProgressForm" action="<?php echo base_url() ?>appraisal/update_progress">
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th width="25%">Attribute</th>
                                                                <th>
                                                                    <span>Description</span>
                                                                </th>
                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            <tr>
                                                                <td>Goal name</td>
                                                                <td><?php echo $data['name'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Goal description</td>
                                                                <td><?php echo $data['description'] ?></td>
                                                            </tr>

                                                            <tr>
                                                                <td>When is the goal due to be achieved?</td>
                                                                <td>
                                                                    <span><?php echo date('d M Y', strtotime($data['completion_date'])); ?></span>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Goal progress</td>
                                                                <td>
                                                                    <div name="goal_progress" id="unranged-value<?php echo $data['id'] ?>" style="width: 250px; margin: 0px"></div> 
                                                                    <input hidden id="amountDisp<?php echo $data['id'] ?>" style="color: #ff0000" name="goal_progress" value="<?php echo $data['user_progress'] ?>">
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>Remark</td>
                                                                <td>
                                                                    <textarea name="remark" placeholder="Give Remarks" value="<?php echo $data['remark'] ?>"><?php echo isset($data['remark']) ? $data['remark'] : '' ?></textarea>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td></td>
                                                                <td>
                                                                    <input id="goal_id" name="goal_id" value="<?php echo $data['id'] ?>" hidden>
                                                                    <?php if ($data['user_status'] == 0) { ?>
                                                                        <button class="pull-right btn btn-sm btn-warning">Submit</button>
                                                                    <?php } else { ?>
                                                                        <label class="pull-right btn btn-sm btn-success">Already Submitted</label>
        <?php } ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>

                                                    </table>
                                                </form>
                                            </div>
                                            <!--</div>-->
                                        </div>                      
                                    </div>
                                    <?php
                                    $flag = '1';
                                }
                                ?>
                            </div>
                            <!-- /.col -->


                        </div>
                        <!--1st dashboard here end -->

<?php } ?>