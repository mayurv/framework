    <?php // echo $assessment_status;die;?>
<div class="row">
    <div class="col-sm-12 appraisal-bg">
        <div class="all-padding-15 margin-bottom-35">
            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#assosciate" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-user "></i> Self Assesment
                    </a>
                </li>
                <?php if ($user_summary['emprole'] == '3' || $user_summary['emprole'] == '1' || $user_summary['emprole'] == '4') { ?>
                    <li class="">
                        <a href="#team" data-toggle="tab" aria-expanded="false">
                            <i class="fa fa-users"></i> Team Assesment
                        </a>
                    </li>
                <?php } ?>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="assosciate">
                    <div class="id_warning">
                        
                    </div>
                    <?php $this->load->view('_self_assesment') ?>
                </div>
                <div class="tab-pane fade " id="team">
                    <?php $this->load->view('_team_assesment') ?>
                </div>
            </div>
        </div>
    </div>
</div> 

<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });</script>
<script src="<?php echo base_url() ?>plugins/Easy-Five-Star-Rating/dist/starrr.js"></script>




<!-- Page script -->


<script>
    /*to hide comment*/
    function hide_comment(id) {
        $('.' + id).toggle("slow");
    }

</script>

<script type="text/javascript">
    var associate_total = 0;
    var manager_total = 0;
    var hr_total = 0;
    $(document).ready(function () {

<?php foreach ($pa_category as $category) { ?>

            $('.first-div-<?php echo $category['id'] ?> .next').click(function () {

            <?php if ($assessment_status != 'ass_completed') { ?>
                <?php foreach ($pa_subcategory as $subcategory) { ?>
                    <?php if ($category['id'] == $subcategory['cat_id']) { ?>
                                    val = parseInt($('.choice1<?php echo $subcategory['id'] ?>').text());

                                    if (isNaN(val)) {
                                        warning_html = '<div class="alert alert-danger alert-dismissible col-sm-8"> <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="icon fa fa-times text-white"></i></button> <i class="icon fa fa-ban text-white"></i> <b>Warning : </b>Please Give Rating to All Sub-points</div>';
                                                $('.id_warning').html(warning_html);
                                                
                                        return false;
                                    }else{
                                        $('.id_warning').html('');
                                    }
                    <?php } ?>
                    <?php } ?>
                    <?php } ?>
                var divVal = <?php echo $category['id'] ?>;
                if (divVal == 10) {
    <?php foreach ($pa_subcategory as $subcategory) { ?>
                        val = parseInt($('.choice1<?php echo $subcategory['id'] ?>').text());

                        if (isNaN(val)) {
                            alert('please give rating');
                            return false;
                        }
                        val = parseInt($('.choice1<?php echo $subcategory['id'] ?>').text());
                        if (!isNaN(val))
                            associate_total += val;

                        $('#rating').text(associate_total);
                        $('#outof').text('205');
                        avrg = parseFloat((associate_total / 205) * 100);
                        avrg = avrg.toFixed(2);

    <?php } ?>
                    if (avrg >= 0 && avrg <= 20) {
                        $('#total_average').addClass('btn btn-lg btn-danger');
                        $('#total_average').text('Level 1 |  ' + avrg);
                    } else if (avrg >= 21 && avrg <= 40) {
                        $('#total_average').addClass('btn btn-lg btn-warning');
                        $('#total_average').text('Level 2 |  ' + avrg);

                    } else if (avrg >= 41 && avrg <= 60) {
                        $('#total_average').addClass('btn btn-lg btn-info');
                        $('#total_average').text('Level 3 |  ' + avrg);

                    } else if (avrg >= 61 && avrg <= 90) {
                        $('#total_average').addClass('btn btn-lg btn-primary');
                        $('#total_average').text('Level 4 |  ' + avrg);

                    } else if (avrg >= 91 && avrg <= 100) {
                        $('#total_average').addClass('btn btn-lg btn-success');
                        $('#total_average').text('Level 5 |  ' + avrg);
                    }
                    $('.first-div-10').hide().next().show(); //hide parent and show next

                } else
                    $('.first-div-<?php echo $category['id'] ?>').hide().next().show(); //hide parent and show next
            });
            $('.first-div-<?php echo $category['id'] ?> .back').click(function () {
                var divVal = <?php echo $category['id'] ?>;
                if (divVal == 1) {
                    $(this).removeClass('btn-default');
                    $(this).addClass('btn-disabled');
                    return false;
                }
                else {
                    $(this).removeClass('btn-disabled');
                    $(this).addClass('btn-default');
                }
                $('.first-div-<?php echo $category['id'] ?>').hide().prev().show(); //hide parent and show next
            });
<?php } ?>

    });</script>

<script src="plugins/Easy-Five-Star-Rating/dist/starrr.js"></script>
<script>
<?php foreach ($pa_subcategory as $subcategory) { ?>
        //associate

        $('#aw1<?php echo $subcategory['id'] ?>').starrr({
            change: function (e, value) {
                if (value) {

                    $('#associate_rate<?php echo $subcategory['id'] ?>').val(value);
                    $('.your-choice-was1<?php echo $subcategory['id'] ?>').show();
                    $('.choice1<?php echo $subcategory['id'] ?>').text(value);
                } else {
                    $('.your-choice-was1<?php echo $subcategory['id'] ?>').hide();
                }
            },
        });
        //Manager
    <?php if ($user_summary['emprole'] == '3' || $user_summary['emprole'] == '4' || $user_summary['emprole'] == '1') { ?>
            $('#aw2<?php echo $subcategory['id'] ?>').starrr({
                change: function (e, value) {
                    if (value) {

                        $('#mng_rate<?php echo $subcategory['id'] ?>').val(value);
                        $('.your-choice-was2<?php echo $subcategory['id'] ?>').show();
                        $('.choice2<?php echo $subcategory['id'] ?>').text(value);
                    } else {

                        $('.your-choice-was2<?php echo $subcategory['id'] ?>').hide();
                    }
                }
            });
    <?php } ?>
        //Hr
    <?php if ($user_summary['emprole'] == '4' || $user_summary['emprole'] == '1') { ?>
            $('#aw3<?php echo $subcategory['id'] ?>').starrr({
                change: function (e, value) {
                    if (value) {
                        $('#hr_rate<?php echo $subcategory['id'] ?>').val(value);
                        $('.your-choice-was3<?php echo $subcategory['id'] ?>').show();
                        $('.choice3<?php echo $subcategory['id'] ?>').text(value);
                    } else {

                        $('.your-choice-was3<?php echo $subcategory['id'] ?>').hide();
                    }
                }
            });
    <?php } ?>
<?php } ?>



    $('#alldiv').starrr({
        change: function (e, value) {
            if (value) {
                $('.your-choice-was-alldiv').show();
                $('.choice-alldiv').text(value);
            } else {
                $('.your-choice-was-alldiv').hide();
            }
        }
    });</script>
<script>
    $("[data-widget='collapse']").click(function () {
        //Find the box parent        
        var box = $(this).parents(".box").first();
        //Find the body and the footer
        var bf = box.find(".box-body, .box-footer");
        if (!box.hasClass("collapsed-box")) {
            box.addClass("collapsed-box");
            bf.slideUp('slow');
        } else {
            box.removeClass("collapsed-box");
            bf.slideDown('slow');
        }
    });
</script>