<div class="row">
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">
            <h2> Feedback</h2>

            <!--1st dashboard here start --> 
            <div class="row">
                <div class="col-sm-6">            
                    <div class="info-box">

                        <div class='panel'>
                            <div id='demo-step-wz'>
                                <div class='wz-heading wz-w-label bg-grey'>
                                    <div class='progress progress-xs progress-wizard'>
                                        <div class='progress-bar progress-bar-dark active' style='width: 0%; margin: 0px 12.5%;'></div>
                                    </div>
                                    <ul class='wz-steps wz-icon-bw wz-nav-off text-lg'>
                                        <li class='col-xs-4 active'>
                                            <a aria-expanded='true' data-toggle='tab' href='#demo-step-tab1_feedback'>
                                                <span class='icon-wrap icon-wrap-xs icon-circle bg-dark'>
                                                    <span class='wz-icon icon-txt text-bold'>1</span>
                                                    <i class='wz-icon-done fa fa-check'></i>
                                                </span>
                                                <small class='wz-desc box-block margin-top-5'>Request feedback</small>
                                            </a>
                                        </li>
                                        <li class='col-xs-4'>
                                            <a data-toggle='tab' href='#demo-step-tab2_feedback'>
                                                <span class='icon-wrap icon-wrap-xs icon-circle bg-dark'>
                                                    <span class='wz-icon icon-txt text-bold'>2</span>
                                                    <i class='wz-icon-done fa fa-check'></i>
                                                </span>
                                                <small class='wz-desc box-block margin-top-5'>Receive feedback</small>
                                            </a>
                                        </li>
                                        <li class='col-xs-4'>
                                            <a data-toggle='tab' href='#demo-step-tab3_feedback'>
                                                <span class='icon-wrap icon-wrap-xs icon-circle bg-dark'>
                                                    <span class='wz-icon icon-txt text-bold'>3</span>
                                                    <i class='wz-icon-done fa fa-check'></i>
                                                </span>
                                                <small class='wz-desc box-block margin-top-5'>Analyze feedback</small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <form class='form-horizontal'>
                                    <div class='panel-body'>
                                        <div class='tab-content'>
                                            <div class='tab-pane active in' id='demo-step-tab1_feedback'>
                                                <h4>Requesting feedback</h4>
                                                <div class='margin-bottom-10'>
                                                    You can request feedback on your performance from anyone. Feedback works best when you raise new requests on regular intervals.
                                                </div>
                                                <div class='margin-bottom-15 margin-top-15'>
                                                    <ul class='margin-left-20'>
                                                        <li>Feedback can be related to a specific goal which has been set</li>
                                                        <li>You can also provide a message to the feedback provider which will be included in the email sent to them</li>
                                                    </ul>
                                                </div>
                                                <div class='margin-top-15'>
                                                    <a class="btn btn-info" data-remote="true" data-toggle="modal" data-target="#internal-feedback">
                                                        <i class='fa fa-comments fa-lg margin-right-5'></i>
                                                        Request internal feedback
                                                    </a>
                                                  </div>

                                            </div>
                                            <div class='tab-pane fade' id='demo-step-tab2_feedback'>
                                                <h4>Feedback providers are given a unique form to provide feedback</h4>
                                                <div class='margin-bottom-10'>
                                                    Feedback providers will receive an automatic email notification explaining that you have requested feedback. The email will contain a link to a unique form to provide feedback.
                                                </div>
                                                <div class='margin-bottom-15 margin-top-15'>
                                                    <ul class='margin-left-20'>
                                                        <li>The provider will be asked to assess you on certain feedback questions. These are set by your business.</li>
                                                        <li>He/she will be able to give you a 'rating' out of 5 for each question.</li>
                                                        <li>They will also be asked to provide a 'stretch' rating. This is an indication of how far you were 'stretched' on the current question.</li>
                                                        <li>They are asked to provide an answer to two questions: "Where did the individual perform well?" and "What are the areas for growth for the individual?"</li>
                                                        <li>A final overall rating is also provided on the feedback form.</li>
                                                    </ul>
                                                </div>
                                                <table class='table table-striped'>
                                                    <thead>
                                                        <tr>
                                                            <th class='col-sm-1'>Rating</th>
                                                            <th class='col-sm-1'>Symbol</th>
                                                            <th class='col-sm-10'>Rating Definition</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <img class="award-icon-table" src="//d3n380booc75fg.cloudfront.net/assets/1_square-8ad099b06e06dff9de09c8d852218012.png" alt="1 square" />
                                                            </td>
                                                            <td>Significantly underperforms</td>
                                                        </tr>
                                                        <tr>
                                                            <td>2</td>
                                                            <td>
                                                                <img class="award-icon-table" src="//d3n380booc75fg.cloudfront.net/assets/1_square-8ad099b06e06dff9de09c8d852218012.png" alt="1 square" />
                                                            </td>
                                                            <td>Needs improvement</td>
                                                        </tr>
                                                        <tr>
                                                            <td>3</td>
                                                            <td>
                                                                <img class="award-icon-table" src="//d3n380booc75fg.cloudfront.net/assets/3_square-bfc7c4a0646a5db7168e2dd6ad3a23bc.png" alt="3 square" />
                                                            </td>
                                                            <td>Meets expectations</td>
                                                        </tr>
                                                        <tr>
                                                            <td>4</td>
                                                            <td>
                                                                <img class="award-icon-table" src="//d3n380booc75fg.cloudfront.net/assets/4_square-2df0ae7b021595433e7b08d55e57dd39.png" alt="4 square" />
                                                            </td>
                                                            <td>Exceeds expectations</td>
                                                        </tr>
                                                        <tr>
                                                            <td>5</td>
                                                            <td>
                                                                <img class="award-icon-table" src="//d3n380booc75fg.cloudfront.net/assets/5_square-f69dbb0f31a7dfb04ad8859d0f9dc85d.png" alt="5 square" />
                                                            </td>
                                                            <td>Top performer</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class='tab-pane mar-btm' id='demo-step-tab3_feedback'>
                                                <h4>Analyze your feedback and return the favor!</h4>
                                                <div class='margin-bottom-10'>
                                                    You will be notified when someone has provided feedback for you. You can then view your feedback here and expand each feedback request to see the full details. You should analyze your areas for growth to improve your performance.
                                                </div>
                                                <div class='margin-bottom-10'>
                                                    You should return the favor by providing 360 degree feedback for your manager, line of sight or other colleagues.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class='panel-footer text-right'>
                                        <div class='box-inline'>
                                            <button class='previous btn btn-info btn-theme disabled' type='button'>Previous</button>
                                            <button class='next btn btn-info btn-theme' type='button'>Next</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                    <!-- /.col -->
                </div>
                <!--1st dashboard here end --> 
            </div>
        </div>
    </div>
</div>

<!--step wizard css-->
<script src="<?php echo base_url('frontend/plugins/goal-step/js/application-main.js') ?>"></script>
<script src="<?php echo base_url('frontend/plugins/goal-step/js/v2.js') ?>"></script>
<!--step wizard css-->
<?php $this->load->view('modal/_request_feedback');?>