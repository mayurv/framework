<?php foreach ($my_teamrequested_feedback as $row) {
    ?>
    <?php foreach ($row['user_feedback'] as $data) { ?>
        <!-- Modal -->
        <div class="modal fade" id="feedback-provide<?php echo $data['id'] ?>">" role="dialog">
            <div class="modal-dialog modal-lg">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Feedback for : <?php echo $data['name'] ?></h4>
                    </div>
                    <form name="formSubFeedbackValidate" method="post" id="formSubFeedbackValidate" action="<?php echo base_url() ?>appraisal/add_feedback">
                        <div class="modal-body all-padding-20  user-modal-slim">

                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th width="25%">Attribute</th>
                                        <th>
                                            <span>Description</span>

                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td>Goal name</td>
                                        <td><?php echo $data['name'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>Goal description</td>
                                        <td><?php echo $data['description'] ?></td>
                                    </tr>

                                    <tr>
                                        <td>When is the goal due to be achieved?</td>
                                        <td>
                                            <span><?php echo date('d F Y', strtotime($data['completion_date'])); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Goal progress</td>
                                        <td>
                                            <div name="goal_progress" id="unranged-value<?php echo $data['goal_id'] ?>" style="width: 250px; margin: 0px"></div> 
                                            <input hidden id="amountDisp" style="color: #ff0000" name="goal_progress" value="<?php echo $data['user_progress'] ?>">
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Remark</td>
                                        <td>
                                            <?php echo $data['remark'] ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Self-assessment</td>
                                        <td>
                                            <?php //var_dump($row['user_feedback']);  ?>
                                            <?php
                                            $data_remark = array(1 => 'Significantly underperforms',
                                                2 => 'Needs improvement',
                                                3 => 'Meets expectations',
                                                4 => 'Exceeds expectations',
                                                5 => 'Top performer'
                                            );
                                            ?>
                                            <?php $remark1 = $data_remark[$data['self_assesment']] ?>
                                            <span class="btn btn-xs btn-default"><?php echo $remark1 ?></span>
                                        </td>
                                    </tr>



                                    <tr>
                                        <td>Additional Comments</td>
                                        <td>
                                            <?php echo $data['self_comment'] ?>
                                        </td>
                                    </tr>


                                    <tr>
                                        <td>
                                            Manager Remark
                                        </td>

                                        <td>
                                            <?php if ($data['feedback_status'] != 1) { ?>

                                                <select class="browser-default margin-bottom-20" id="mang_status" name="mang_status" data-error=".errorTxt-g3">
                                                    <option value="">Select Your Option</option>
                                                    <option value="1">1 - Significantly underperforms</option>
                                                    <option value="2">2 - Needs improvement</option>
                                                    <option value="3">3 - Meets expectations</option>
                                                    <option value="3">4 - Exceeds expectations</option>
                                                    <option value="3">5 - Top performer</option>                                              
                                                </select>
                                                <div class="input-field">
                                                    <div class="errorTxt-g3"></div>
                                                </div>

                                            <?php } else { ?>

                                                <?php
                                                $data_remark = array(1 => 'Significantly underperforms',
                                                    2 => 'Needs improvement',
                                                    3 => 'Meets expectations',
                                                    4 => 'Exceeds expectations',
                                                    5 => 'Top performer'
                                                );
                                                ?>
                                                <?php $remark = $data_remark[$data['mang_status']] ?>
                                                <p><?php echo $remark ?></p>
                                            <?php } ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Manager Comments</td>
                                        <td>

                                            <?php if ($data['feedback_status'] != 1) { ?>
                                                <textarea name="mang_comment" data-error=".errorTxt-g9"></textarea>
                                                <div class="input-field">
                                                    <div class="errorTxt-g9"></div>
                                                </div>
                                            <?php } else { ?>
                                                <p><?php echo $data['mang_comment'] ?></p>
                                            <?php } ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td></td>
                                        <td>
                                            <div class="text-right"> 
                                                <input id="goal_id" name="goal_id" value="<?php echo $data['goal_id'] ?>" hidden>
                                                 <?php if ($data['feedback_status'] != 1) { ?>
                                                <button class="btn btn-warning2 btn-sm" type="submit">Submit</button>  
                                               <?php } else { ?>
                                                <button class="btn btn-success btn-sm" >Feedback Submitted</button>  
                                            <?php } ?>
                                                 <!--<button class="btn btn-info"><i class="fa fa-comments margin-right-5"></i>Submit your feedback</button>-->                      
                                            </div>
                                        </td>
                                    </tr>

                                </tbody>

                            </table>


                        </div>
                    </form>


                </div>

            </div>    
        </div>

    <?php } ?>
<?php } ?>

<?php foreach ($my_teamrequested_feedback as $row) { ?>
    <?php foreach ($row['user_feedback'] as $data) { ?>

        <script>
            var s2 = $("#unranged-value<?php echo $data['id'] ?>").freshslider({
                step: 1,
                value: <?php echo $data['user_progress'] ?>,
                onchange: function (low, high) {
                    $('#amountDisp').val(low);
                },
                enabled: false,
            });

        </script>

    <?php } ?>
<?php } ?>