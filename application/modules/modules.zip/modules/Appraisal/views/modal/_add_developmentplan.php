       <!-- Modal -->
        <div class="modal fade" id="developement-plan" role="dialog">
            <div class="modal-dialog modal-lg">
                <form class="formValidate" id="formValidate" method="get" action="#">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Development Plan Details</h4>
                        </div>
                        <div class="modal-body all-padding-20">
                            <div class="goal-modal-bg">
                                <!--body inner row start here-->
                                <div class="row">
                                    <!--left side start here-->
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 margin-bottom-20">
                                            <p class="text-bold">Balram Kamble</p>          
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-12">
                                            <label for="teamselect">Manager Name</label>
                                            <select class="browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                <option value="" disabled selected>Select Your Manager</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                            <div class="input-field">
                                                <div class="errorTxt-g3"></div>
                                            </div>
                                        </div>                    
                                        <div class="clearfix"></div>

                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <label for="goalachieved">Plan start date</label>                
                                                <input id="goalachieved" name="goalachieved" class="datepicker" type="text" placeholder="Date" data-error=".errorTxt-g8">
                                                <div class="errorTxt-g8"></div>
                                            </div> 
                                        </div>
                                        <div class="clearfix"></div>

                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <label for="goalachieved">Plan end date</label>                
                                                <input id="goalachieved" name="goalachieved" class="datepicker" type="text" placeholder="Date" data-error=".errorTxt-g8">
                                                <div class="errorTxt-g8"></div>
                                            </div> 
                                        </div>
                                        <div class="clearfix"></div>
                                        
                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <label for="goaldesc">Development Plan Name</label>
                                                <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Development Plan Name" data-error=".errorTxt-g2">
                                                </textarea>
                                                <div class="errorTxt-g2"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                        
                                        <div class="col-sm-12">
                                            <div class="input-field">
                                                <label for="goaldesc">Summary of responsibilities</label>
                                                <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Summary of responsibilities" data-error=".errorTxt-g2">
                                                </textarea>
                                                <div class="errorTxt-g2"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <!--right side end here-->
                                </div>
                                <!--body inner row end here-->  
                            </div>
                        </div>
                        <div class="modal-footer">
                            <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                            <div class="form-group">
                                <div class="text-right">
                                    <button class="btn btn-default">Cancel</button>
                                    <button class="btn btn-info">Submit</button>                      
                                </div>
                            </div>          
                        </div>
                    </div>
                </form>
            </div>    
        </div>