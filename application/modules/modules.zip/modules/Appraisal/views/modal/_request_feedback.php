<!-- Modal -->
<div class="modal fade" id="internal-feedback" role="dialog">
    <div class="modal-dialog modal-lg">
        <form class="formRequestValidate" id="formRequestValidate" method="post" action="<?php echo base_url() ?>appraisal/create_feedback">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Feedback request</h4>
                </div>
                <div class="modal-body all-padding-20  user-modal-slim">
                    <div class="goal-modal-bg">
                        <!--body inner row start here-->
                        <div class="row">
                            <!--left side start here-->
                            <div class="col-sm-6">
                                <div class="col-sm-12 margin-bottom-20">
                                    <p class="text-bold">Feedback details</p>
                                    <p>Please provide some basic details regarding the feedback request</p>                                        
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <label for="teamselect">Request feedback for Goal</label>
                                    <?php
                                    echo form_dropdown(array('id' => 'goal_id',
                                        'name' => 'goal_id',
                                        'class' => ' browser-default margin-bottom-20 ',
                                        'data-error' => '.errorTxt-g3',
                                            ), $goal_dropdown);
                                    ?>

                                    <div class="input-field">
                                        <div class="errorTxt-g3"></div>
                                    </div>
                                </div>  
                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager', 'data-error' => 'reporting_manager')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'mang_id',
                                        'class' => 'browser-default ',
                                        'data-error' => '.errorTxtOff10',
                                        'name' => 'mang_id'), $rep_manager_list);
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtOff10"></div>
                                    </div>
                                    <?php echo form_error('reporting_manager'); ?>
                                </div>                    
                                <div class="clearfix"></div>


                            </div>
                            <!--left side end here-->
                            <!--right side start here-->
                            <div class="col-sm-6">
                                <div class="col-sm-12 margin-bottom-20">
                                    <p class="text-bold">Additional details</p>
                                    <p>Please provide the following additional details</p>
                                </div>
                                <div class="clearfix"></div>


                                <div class="col-sm-12">
                                    <label for="teamselect">Self-assessment</label>
                                    <select class="browser-default margin-bottom-20" id="teamselect" name="self_assesment" data-error=".errorTxt-g13">
                                        <option value="" disabled selected>Select self-assessment rating</option>
                                        <option value="1">Significantly underperforms</option>
                                        <option value="2">Needs improvement</option>
                                        <option value="3">Meets expectations</option>
                                        <option value="4">Exceeds expectations</option>
                                        <option value="5">Top performer</option>
                                    </select>
                                    <div class="input-field">
                                        <div class="errorTxt-g13"></div>
                                    </div>
                                </div>  
                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <label for="goaldesc">Some comments (optional) for the feedback provider to read</label>
                                        <textarea id="goaldesc" name="self_comment" class="materialize-textarea validate" placeholder="Enter some comments for the feedback provider to read" data-error=".errorTxt-g2"></textarea>
                                        <div class="errorTxt-g2"></div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>   



                            </div>
                            <!--right side end here-->
                        </div>
                        <div class="row">
                            <div class="col-sm-12 "> 
                                <div class="form-group">
                                    <div class="text-right">

                                        <button class="btn btn-warning2 btn-sm" type="submit">Submit</button>                      
                                    </div>
                                </div>          
                            </div>
                        </div>
                        <!--body inner row end here-->  
                    </div>
                </div>


            </div>
        </form>
    </div>    
</div>
<!--Modal-->
