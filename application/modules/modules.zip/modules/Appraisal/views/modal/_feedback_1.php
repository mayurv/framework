<?php foreach ($my_requested_feedback as $data) { ?>
    <!-- Modal -->
    <div class="modal fade" id="feedback-provide<?php echo $data['id'] ?>">" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Feedback for : <?php echo $data['name'] ?></h4>
                </div>
                <form name="formSubFeedbackValidate" method="post" id="formSubFeedbackValidate" action="<?php echo base_url() ?>appraisal/add_feedback">
                    <div class="modal-body all-padding-20  user-modal-slim">

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th width="25%">Attribute</th>
                                    <th>
                                        <span>Description</span>

                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td>Goal name</td>
                                    <td><?php echo $data['name'] ?></td>
                                </tr>
                                <tr>
                                    <td>Goal description</td>
                                    <td><?php echo $data['description'] ?></td>
                                </tr>

                                <tr>
                                    <td>When is the goal due to be achieved?</td>
                                    <td>
                                        <span><?php echo date('d M Y', strtotime($data['completion_date'])); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Goal progress</td>
                                    <td>
                                        <div name="goal_progress" id="unranged-value<?php echo $data['goal_id'] ?>" style="width: 250px; margin: 0px"></div> 
                                        <input hidden id="amountDisp" style="color: #ff0000" name="goal_progress" value="<?php echo $data['user_progress'] ?>">
                                    </td>
                                </tr>

                                <tr>
                                    <td>Remark</td>
                                    <td>
                                        <?php echo $data['remark'] ?>
                                    </td>
                                </tr>

                                <tr>
                                    <td>Self-assessment</td>
                                    <td>
                                        <?php echo $data['remark'] ?>
                                    </td>
                                </tr>

                                <tr>
                                    <td>Additional Comments</td>
                                    <td>
                                        <?php echo $data['remark'] ?>
                                    </td>
                                </tr>


                                <tr>
                                    <td>
                                        Status
                                    </td>

                                    <td>


                                        <select class="browser-default margin-bottom-20" id="mang_status" name="mang_status" data-error=".errorTxt-g3">
                                            <option value="">Select Your Option</option>
                                            <option value="1">1 - Significantly underperforms</option>
                                            <option value="2">2 - Needs improvement</option>
                                            <option value="3">3 - Meets expectations</option>
                                            <option value="3">4 - Exceeds expectations</option>
                                            <option value="3">5 - Top performer</option>                                              
                                        </select>
                                        <div class="input-field">
                                            <div class="errorTxt-g3"></div>
                                        </div>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Additional Comments</td>
                                    <td>
                                        <textarea name="mang_comment" data-error=".errorTxt-g9"></textarea>
                                        <div class="input-field">
                                            <div class="errorTxt-g9"></div>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td></td>
                                    <td>
                                        <div class="text-right"> 
                                            <input id="goal_id" name="goal_id" value="<?php echo $data['id'] ?>" hidden>
                                            <button class="btn btn-warning2 btn-sm" type="submit">Submit</button>  
                                            <!--<button class="btn btn-info"><i class="fa fa-comments margin-right-5"></i>Submit your feedback</button>-->                      
                                        </div>
                                    </td>
                                </tr>

                            </tbody>

                        </table>


                    </div>
                </form>


            </div>

        </div>    
    </div>

<?php } ?>

<?php foreach ($my_requested_feedback as $r => $data) { ?>
    <script>
        var s2 = $("#unranged-value<?php echo $data['id'] ?>").freshslider({
            step: 1,
            value: <?php echo $data['user_progress'] ?>,
            onchange: function (low, high) {
                $('#amountDisp').val(low);
            },
            enabled: false,
        });

    </script>

<?php } ?>