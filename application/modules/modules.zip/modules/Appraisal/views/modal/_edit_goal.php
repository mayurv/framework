<?php foreach ($my_goals as $data) { ?>
    <!-- Modal -->
    <div class="modal fade" id="edit_goal_<?php echo $data['id'] ?>" role="dialog">
        <div class="modal-dialog modal-lg">
            <form class="formValidate" id="formValidate" method="post" action="<?php echo base_url() . 'appraisal/create_goal/' . $data['id'] ?>">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Edit goal : <?php echo $data['name'] ?></h4>
                    </div>
                    <div class="modal-body all-padding-20">
                        <div class="goal-modal-bg">
                            <!--body inner row start here-->
                            <div class="row">
                                <!--left side start here-->
                                <div class="col-sm-6">
                                    <div class="col-sm-12 margin-bottom-20">
                                        <p class="text-bold">Your new goal details</p>
                                        <p>Please provide a name and short description for your new goal.</p>                                        
                                    </div>
                                    <div class="clearfix"></div>

                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('goal_name'), 'goal_name', array('for' => 'goal_name', 'data-error' => 'select role')); ?>            
                                            <?php
                                            echo form_input(array(
                                                'id' => 'goal_name',
                                                'name' => 'goalname',
                                                'placeholder' => 'Goal Name',
                                                'class' => 'browser-default ',
                                                'data-error' => '.errorTxtProj1',
                                                'value' => $data['name']
                                            ));
                                            ?> 
                                            <div class="errorTxt-g1"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">

                                            <?php echo form_label(lang('goaldesc'), 'goaldesc', array('for' => 'goaldesc', 'data-error' => 'select role')); ?>            
                                            <?php
                                            echo form_textarea(array(
                                                'id' => 'goaldesc',
                                                'name' => 'goaldesc',
                                                'class' => 'browser-default materialize-textarea ',
                                                'placeholder' => 'Goal Description',
                                                'data-error' => '.errorTxtProj1',
                                                'value' => $data['description']
                                            ));
                                            ?> 


                                            <div class="errorTxt-g2"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager', 'data-error' => 'reporting_manager')); ?>
                                        <?php
                                        echo form_dropdown(array('id' => 'mang_id',
                                            'class' => 'browser-default ',
                                            'data-error' => '.errorTxtOff10',
                                            'name' => 'mang_id'), $rep_manager_list, set_value('mang_id', $listData['mang_id']));
                                        ?>
                                        <div class="input-field">
                                            <div class="errorTxtOff10"></div>
                                        </div>
                                        <?php echo form_error('reporting_manager'); ?>
                                    </div>                    
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">


                                        <div class="input-field">
                                            <?php echo form_label(lang('goal_date'), 'goal_date', array('for' => 'goal_date')); ?>
                                            <?php
                                            echo form_input(array(
                                                'id' => 'goal_date',
                                                'name' => 'goal_date',
                                                'placeholder' => 'Select Date',
                                                'data-format' => 'yyyy-mm-dd',
                                                'class' => 'goal_date',
                                                'data-error' => '.addOpening4',
                                                'value' => $data['completion_date']
                                            ));
                                            ?>   
                                            <div class="addOpening4"></div>                                
                                            <?php echo form_error('interview_date'); ?> 
                                        </div> 
                                    </div>

                                </div>
                                <!--left side end here-->
                                <!--right side start here-->
                                <div class="col-sm-6">
                                    <div class="col-sm-12 margin-bottom-20">
                                        <p class="text-bold">Your new goal attributes</p>
                                        <p>This is a series of questions designed to ensure that your goals are SMART (Specific, Measurable, Attainable, Relevant and Time-bound)</p>                    

                                    </div>
                                    <div class="clearfix"></div>

                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <label for="goalname">Goal Name</label>                

                                            <div class="errorTxt-g1"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <label for="goalabt">What is specific about your goal?</label>                

                                            <div class="errorTxt-g4"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <label for="goalmeasure">How will it be measured?</label>                

                                            <div class="errorTxt-g5"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <label for="goalachieve">How will you attain/achieve your goal?</label>                

                                            <div class="errorTxt-g6"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <label for="goalrelevant">How is your goal relevant?</label>                

                                            <div class="errorTxt-g7"></div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>

                                    <div class="clearfix"></div>




                                </div>
                                <!--right side end here-->
                            </div>
                            <!--body inner row end here-->  
                        </div>
                    </div>
                    <div class="modal-footer">
                        <!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
                        <div class="form-group">
                            <div class="text-right">
                                <button class="btn btn-default">Cancel</button>
                                <button class="btn btn-info">Submit</button>                      
                            </div>
                        </div>          
                    </div>
                </div>
            </form>
        </div>    
    </div>
    <!--End Modal-->

    <script type="text/javascript">
        /* Date picker validation Fucntions */
        $(document).ready(function () {
            $(".goal_date").click(function () {
                $('.goal_date').pickadate({
                    selectYears: true,
                    selectMonths: true,
                    min: new Date(),
                });
            });
        });
    </script>

    <script>
        $("[data-widget='collapse']").click(function () {
            //Find the box parent        
            var box = $(this).parents(".box").first();
            //Find the body and the footer
            var bf = box.find(".box-body, .box-footer");
            if (!box.hasClass("collapsed-box")) {
                box.addClass("collapsed-box");
                bf.slideUp('slow');
            } else {
                box.removeClass("collapsed-box");
                bf.slideDown('slow');
            }
        });
    </script>

<?php } ?>