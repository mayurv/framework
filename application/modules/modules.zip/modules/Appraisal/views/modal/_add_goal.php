<!-- Modal -->
<div class="modal fade" id="new-goal" role="dialog">
    <div class="modal-dialog modal-lg">
        <form class="formGoalValidate" id="formGoalValidate" method="post" action="<?php echo base_url() ?>appraisal/create_goal">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">New individual goal</h4>
                </div>
                <div class="modal-body all-padding-20 user-modal-slim">
                    <div class="goal-modal-bg">
                        <!--body inner row start here-->
                        <div class="row">
                            <!--left side start here-->
                            <div class="col-sm-6">
                                <div class="col-sm-12 margin-bottom-20">
                                    <p class="text-bold">Your new goal details</p>
                                    <p>Please provide a name and short description for your new goal.</p>                                        
                                </div>
                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('goal_name'), 'goal_name', array('for' => 'goal_name', 'data-error' => 'select role')); ?>            
                                        <?php
                                        echo form_input(array(
                                            'id' => 'goal_name',
                                            'name' => 'goalname',
                                            'placeholder' => 'Goal Name',
                                            'class' => 'browser-default ',
                                            'data-error' => '.errorTxtGoal1'
                                        ));
                                        ?> 
                                        <div class="input-field">
                                            <div class="errorTxtGoal1"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <label for="goaldesc">Goal Description</label>
                                        <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Goal Description" data-error=".errorTxt-g2"></textarea>
                                        <div class="errorTxt-g2"></div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager', 'data-error' => 'reporting_manager')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'mang_id',
                                        'class' => 'browser-default ',
                                        'data-error' => '.errorTxtGoal2',
                                        'name' => 'mang_id'), $rep_manager_list);
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtGoal2"></div>
                                    </div>
                                    <?php echo form_error('reporting_manager'); ?>
                                </div>                    
                                <div class="clearfix"></div>
                                <div class="col-sm-12">


                                    <div class="input-field">
                                        <?php echo form_label(lang('goal_date'), 'goal_date', array('for' => 'goal_date')); ?>
                                        <?php
                                        echo form_input(array(
                                            'id' => 'goal_date',
                                            'name' => 'goal_date',
                                            'placeholder' => 'Select Date',
                                            'data-format' => 'yyyy-mm-dd',
                                            'class' => 'goal_date',
                                            'data-error' => '.errorTxtGoal3'
                                        ));
                                        ?>   
                                        <div class="errorTxtGoal3"></div>                                
                                        <?php echo form_error('interview_date'); ?> 
                                    </div> 
                                </div>

                            </div>
                            <!--left side end here-->
                            <!--right side start here-->
                            <div class="col-sm-6">
                                <div class="col-sm-12 margin-bottom-20">
                                    <p class="text-bold">Your new goal attributes</p>
                                    <p>This is a series of questions designed to ensure that your goals are SMART (Specific, Measurable, Attainable, Relevant and Time-bound)</p>                    

                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-8">
                                    <h4>Does Your goal meets following things ? ....</h4>
                                    <div class="margin-top-20"></div>
                                    <ul id="disc-ul">
                                        <li class="margin-top-10">What is specific about your goal?</li>
                                        <li class="margin-top-10">How will it be measured?</li>
                                        <li class="margin-top-10">How will you attain/achieve your goal?</li>
                                        <li class="margin-top-10">How is your goal relevant?</li>
                                    </ul>
                                </div>

                                <div class="col-sm-4 "> 
                                    <img src="<?php base_url() ?>/assets/images/man.png" width="100px" height="160px">
                                </div>

                            </div>


                        </div>
                        <div class="row">
                            <div class="col-sm-12 "> 
                                <div class="form-group">
                                    <div class="text-right">

                                        <button class="btn btn-warning2 btn-sm" type="submit">Submit</button>                      
                                    </div>
                                </div>          
                            </div>
                        </div>
                        <!--right side end here-->
                    </div>
                    <!--body inner row end here-->  
                </div>
            </div>
            
        </form>
    </div>    
</div>
<!--End Modal-->
<style>
    ul:not(.browser-default) li{
        list-style-type:disc !important;
    }

</style>
<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
        $(".goal_date").click(function () {
            $('.goal_date').pickadate({
                selectYears: true,
                selectMonths: true,
                min: new Date(),
            });
        });
    });
</script>

<script>
    $("[data-widget='collapse']").click(function () {
        //Find the box parent        
        var box = $(this).parents(".box").first();
        //Find the body and the footer
        var bf = box.find(".box-body, .box-footer");
        if (!box.hasClass("collapsed-box")) {
            box.addClass("collapsed-box");
            bf.slideUp('slow');
        } else {
            box.removeClass("collapsed-box");
            bf.slideDown('slow');
        }
    });
</script>