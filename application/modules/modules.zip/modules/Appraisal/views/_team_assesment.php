<div class="row">
    <div class="col-sm-12">
        <table>
            <thead>
                <tr>
                    <th>Associate Name</th>
                    <th>Submitted Date</th>
                    <th>#</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($my_team_assesment as $teamData) { ?>
                <tr>
                    <td>
                        <p><?php echo $teamData['userfullname']?></p>
                        <p><?php echo $teamData['department_name']?>, <?php echo $teamData['position_name']?></p>
                        
                    </td>
                    <td><?php echo $teamData['userfullname']?></td>
                    <td><button class="btn btn-xs btn-default"><i class="fa fa-line-chart"></i>  Give Rating </button></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>