<table id="app_feedback" class="table table-bordered ">
    <thead>
        <tr>
            <th>Name</th>
            <th>Goals Detail</th>
        </tr>
    </thead>
    <tbody>
        <?php //var_dump($my_teamGoals); ?>
        <?php foreach ($my_teamGoals as $row) { ?>

            <tr>
                <td>
                    <div class="margin-top-40"></div>
                    <i><?php if (isset($row['profileimg']) && $row['profileimg'] != '') { ?>
                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $row['profileimg']; ?>">  
                        <?php } else { ?>
                            <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                        <?php } ?></i> 
                    <?php echo $row['userfullname']; ?>
                    <p>
                        <?php echo $row['department_name'] ?>, 
                        <?php echo $row['position_name'] ?>
                    </p>
                </td>

                <td>
                    <table class="table ">
                        <thead>
                            <tr>
                                <th>Goal Name</th>
                                <th>Duration</th>
                                <th>Status</th>
                                <th>Progress</th>
                            </tr>
                        </thead>
                        <?php foreach ($row['user_goals'] as $data) { ?>
                            <?php //var_dump($row['user_goals']); ?>
                            <tr>
                                <td>
                                    
                                    <?php echo $data['name'] ?>

                                </td>
                                <td>
                                    <p><?php echo date('d F Y', strtotime($data['createddate'])) ?></p>
                                    <p><?php echo date('d F Y', strtotime($data['completion_date'])) ?></p>
                                </td>
                                <td>

                                    <?php //echo $data['user_status'];?>
                                    <button class="btn btn-xs <?php echo $data['user_status'] == '0' ? 'btn-warning' : 'btn-success'; ?>"><?php echo $data['user_status'] == '0' ? 'In Progress' : 'Completed'; ?></button>
                                </td>
                                <td>
                                    <button class="btn btn-xs btn-primary "><?php echo $data['user_progress'] ?>%</button>
                                </td>
                            </tr>
                        <?php } ?>

                    </table>
                </td>


            </tr>

        <?php } ?>
    </tbody>
</table>

<script type="text/javascript">
    $(document).ready(function () {
        $('#app_feedback').DataTable({
            "pageLength": 100,
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
    });
</script>