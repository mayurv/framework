<div class="row">
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">


            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Appriasal Reports</h4> 
                    </div>              
                </div>
            </div>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#assosciate" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> Associate
                    </a>
                </li>


                <li class="">
                    <a href="#hr" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> HR
                    </a>
                </li>

                <li class="">
                    <a href="#manager" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> Manager
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="assosciate">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Associate Ratings </h5>

                                </div>
                                <div class="ibox-content">
                                    <div id="morris-one-line-chart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade " id="hr">


                </div>

                <div class="tab-pane fade " id="manager">
                    <?php //$this->load->view('report/dept_leaveSummary') ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php //$this->load->view('modal/_add_developmentplan') ?>



<link href="<?php echo base_url('plugins/morris_new/morris-0.4.3.min.css'); ?>" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url('plugins/morris_new/morris.js') ?>"></script>
<script src="<?php echo base_url('plugins/morris_new/raphael-2.1.0.min.js') ?>"></script>
<?php
$arr_name = '';
foreach ($ass_report as $k => $opData) {
    $arr_name .= "{cat_id: '" . $opData['cat_id'] . "', value: " .$opData['self_avg_rating'] ."},";  
}
?>

<script>
    $(function () {  
        

         var names = <?php echo '[' . $arr_name . ']' ?>;   
         //alert(names);
        Morris.Line({
            element: 'morris-one-line-chart',
            //data: names,
            data: names,
            xkey: 'cat_id',
            ykeys: ['value'],
            resize: true,
            lineWidth: 4,
            labels: ['Value'],
            lineColors: ['#1ab394'],
            pointSize: 5,
            parseTime:false
        });



    });
</script>