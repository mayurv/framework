
<div class="row">
                                <div class="col-sm-12 white-bg">
                                <div class="all-padding-15">
                                    <h2> Reviews</h2>

                                    <!--1st dashboard here start --> 
                                    <div class="row">
                                        <div class="col-sm-6">            
                                            <div class="info-box">

                                                <div class="panel">
<div id="demo-step-wz">
<div class="wz-heading wz-w-label bg-grey">
<div class="progress progress-xs progress-wizard">
<div class="progress-bar progress-bar-dark active" style="width: 0%; margin: 0px 16.6667%;"></div>
</div>
<ul class="wz-steps wz-icon-bw wz-nav-off text-lg">
<li class="col-xs-4 active">
<a aria-expanded="true" data-toggle="tab" href="#demo-step-tab1_reviews">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">1</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Self assessment</small>
</a>
</li>
<li class="col-xs-4">
<a data-toggle="tab" href="#demo-step-tab2_reviews" aria-expanded="false">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">2</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Manager review</small>
</a>
</li>
<li class="col-xs-4">
<a data-toggle="tab" href="#demo-step-tab3_reviews" aria-expanded="false">
<span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
<span class="wz-icon icon-txt text-bold">3</span>
<i class="wz-icon-done fa fa-check"></i>
</span>
<small class="wz-desc box-block margin-top-5">Sign-off</small>
</a>
</li>
</ul>
</div>
<form class="form-horizontal">
<div class="panel-body">
<div class="tab-content">
<div class="tab-pane active in" id="demo-step-tab1_reviews">
<h4>Complete your self assessment</h4>
<div class="margin-bottom-10">
The process starts with the employee (you) completing your own self assessment. This is a simple form where the employee assesses their own performance against criteria set by your business. When complete, this form is sent to the employee's manager for their assessment.
</div>
<div class="margin-bottom-15 margin-top-15">
<table class="table table-striped col-md-6">
<thead>
<tr>
<th class="col-md-10">Question</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<small class="text-muted">In which areas did you perform well?</small>
</td>
</tr>
<tr>
<td>
<small class="text-muted">In which areas could you have performed better?</small>
</td>
</tr>
</tbody>
</table>
</div>
<div class="pull-left">
<a class="btn btn-info btn-theme btn-md" href="<?php echo base_url()?>appraisal/assesment" target="_blank">
<i class="fa fa-plus-circle fa-lg margin-right-5"></i>
Start your self assessment now 
</a>
</div>
</div>
<div class="tab-pane fade" id="demo-step-tab2_reviews">
<h4>Your manager provides their review</h4>
<div class="margin-bottom-15 margin-top-15">
<table class="table table-striped col-md-6">
<thead>
<tr>
<th class="col-md-10">Question</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<small class="text-muted">In which areas did you perform well?</small>
</td>
</tr>
<tr>
<td>
<small class="text-muted">In which areas could you have performed better?</small>
</td>
</tr>
</tbody>
</table>
</div>
<div class="margin-bottom-10">
The manager meets with employees to discuss their self-assessment. Following the performance discussion the manager provides his/her assessment against exactly the same criteria as the employee. Once complete, this form is sent back to the employee for review and signature.
</div>
<div class="signature margin-left-20 margin-top-20">
<i class="fa fa-pencil margin-right-5"></i>
<span class="text-success">Manager signature here</span>
</div>
</div>
<div class="tab-pane mar-btm" id="demo-step-tab3_reviews">
<h4>Both parties sign off your review</h4>
<div class="margin-bottom-10">
The last step in the process if for the employee to sign and acknowledge their review. The process is then complete!
</div>
<div class="signature margin-left-20 margin-top-20">
<i class="fa fa-pencil margin-right-5"></i>
<span class="text-success">Your signature here</span>
</div>
</div>
</div>
</div>
<div class="panel-footer text-right">
<div class="box-inline">
<button class="previous btn btn-info btn-theme disabled" type="button">Previous</button>
<button class="next btn btn-info btn-theme" type="button" style="display: inline-block;">Next</button>
</div>
</div>
</form>
</div>
</div>

                                            </div>
                                            <!-- /.col -->
                                        </div>
                                        <!--1st dashboard here end --> 
                                    </div>
                                </div>
                                </div>
                                </div>

<!--step wizard css-->
<script src="<?php echo base_url('frontend/plugins/goal-step/js/application-main.js') ?>"></script>
<script src="<?php echo base_url('frontend/plugins/goal-step/js/v2.js') ?>"></script>
<!--step wizard css-->