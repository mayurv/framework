<?php // var_dump($user_summary);  ?>
<div class="row">
    <!--<div class="col-sm-12 white-bg">-->
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">
            <div class="row">
                <div class="col-sm-8">
                    <h4><a href="<?php echo base_url() ?>appraisal">Appraisal </a> | Associate Feedback Overview</h4>
                </div>
                <div class="col-sm-4">
                    <div class="pull-right">
                        <a class="btn btn-default btn-sm btn-radius-3" data-remote="true" data-toggle="modal" data-target="#internal-feedback">
                            <i class='fa fa-comments fa-lg margin-right-5'></i>
                            Request feedback
                        </a>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#assosciate" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> My Feedback
                    </a>
       
                </li>
                <?php if ($user_summary['emprole'] == '3' || $user_summary['emprole'] == '1' || $user_summary['emprole'] == '4') { ?>
                    <li class="">
                        <a href="#team" data-toggle="tab" aria-expanded="false">
                            <i class="fa fa-check-circle"></i> Team Feedback
                        </a>
                    </li>
                <?php } ?>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="assosciate">
                    <?php $this->load->view('_myFeedback') ?>
                </div>
                <div class="tab-pane fade " id="team">
                    <?php $this->load->view('_teamFeedback') ?>
                </div>
            </div>


        </div>
    </div>
</div>

<?php $this->load->view('modal/_request_feedback') ?>
<?php $this->load->view('modal/_feedback') ?>


<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>



