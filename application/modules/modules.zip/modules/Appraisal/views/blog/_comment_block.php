<!--Start Comment block-->
<?php if (isset($timeline_comment)) { ?>
<div class="reply-comment-public">
    <div class="box-comment">
        <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
        <div class="comment-text">
            <span class="username"> Mayur Vachchewar
                <small style="padding:0px 10px;" class="clr-999">
                    <i class="fa fa-clock-o"></i> 8:03 PM </small>
            </span>

            <p>It is a long established fact that a reader will be distracted
                by the readable content of a page when looking at its layout.</p>
        </div>
    </div>
</div>
<?php } ?>
<!--End Comment block-->