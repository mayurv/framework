<!-- timeline item -->
<?php
$i = 0;
$current_date = ''
?>
<?php if (isset($blog_data)) { ?>
    <?php foreach ($blog_data as $data) { ?>

        <?php if ($current_date != $data['blog_date']) { ?>
            <li class="time-label">
                <span class="timline-btn-sm">
                    <?php echo $data['blog_date']; ?>
                </span>
            </li>
        <?php } ?>    
        <?php if ($data['user_id'] == $user_summary['user_id'] && $data['publish_group_id'] == '99') { ?>

            <li id="post_<?php echo $data['id'] ?>">                
                <div class="timeline-image">     
                    <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                </div>

                <!-- timeline item start here-->
                <div class="timeline-item">                         
                    <div class="timeline-header">
                        <!-- <span class="text-info">Smita Walvekar </span> -->

                        <div class="timelineheader-content1">
                            <span class="text-info "><?php echo $data['userfullname'] ?></span>
                        </div>
                        <div class="timelineheader-content1">
                            <span class="text-primary"><?php echo $data['title']; ?></span>
                        </div>

                        <!--<small class="text-primary">on <?php // echo $data['blog_date']; ?></small>-->
                        <small class="time"><i class="fa fa-clock-o"></i> <?php echo date('t A',  strtotime($data['blog_time'])); ?></small>


                        <div class="box-tools pull-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-angle-down text-bold"></i></button>
                                <ul class="dropdown-menu pull-right" role="menu">
                                    <li><a href="#" onclick="edit_post(<?php echo $data['id'] ?>)" >Edit</a></li>
                                    <li class="divider"></li>
                                    <li><a  onclick="delete_post(<?php echo $data['id'] ?>)">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="timeline-body">
                        <?php echo $data['description']; ?>
                    </div>

                    <!--hidden blog data-->
                    <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->

                    <!-- reply-comment-main-bg-here -->

                    <div class="reply-comment-main-bg">
                        <!-- box-here -->  
                        <div class="box no-shadow-box">
                            <!-- box-header -->                             
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <?php if (isset($data['comment'])) { ?>
                                        <button type="button" class="btn btn-box-tool ">
                                            <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                                        </button>   
                                    <?php } ?>                               
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!--box-body -->
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <!-- reply comment here -->
                                        <div class="comment_div_id_<?php echo $data['id'] ?> view-comment-1">
                                            <?php if (isset($data['comment'])) { ?>
                                                <?php $cnt = count($data['comment']); ?>
                                                <?php foreach ($data['comment'] as $commentResult) { ?>
                                                    <?php // var_dump($commentResult);?>
                                                    <div class="reply-comment-public">
                                                        <div class="box-comment">
                                                            <i class="fa fa-remove-square-o text-danger"></i>
                                                            <img class="img-circle img-sm" src="<?php echo base_url() . 'assets/uploads/' . $commentResult['profileimg']; ?>">
                                                            <div class="comment-text">
                                                                <span class="username"><?php echo $commentResult['userfullname'] ?>
                                                                    <small style="padding:0px 10px;" >
                                                                        <i class="fa fa-clock-o"></i> <small class="clr-999"><?php echo $commentResult['comment_time'] ?> </small> </small>
                                                                </span>
                                                                <p><?php echo $commentResult['comment'] ?> </p>
                                                            </div>
                                                        </div>
                                                    </div>       
                                                <?php } ?>

                                            <?php } ?>
                                        </div>
                                        <!-- reply comment here -->
                                        <!-- comment icon here -->
                                        <div class="share-info-bg">
                                            <ul class="list-inline">                               
                                                <li>
                                                    <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                                                        <?php if (isset($data['comment'])) { ?>
                                                            (<?php echo $data['comment'] ? count($data['comment']) : '0' ?>)
                                                            <?php
                                                        } else {
                                                            echo "(0)";
                                                        }
                                                        ?>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <!-- comment icon here -->
                                        <!-- comment box here -->
                                        <div class="reply-comment-box">
                                            <div class="input-group">
                                                <input name="comment_box_<?php echo $data['id'] ?>" id="comment_box_<?php echo $data['id'] ?>" class="form-control input-sm" placeholder="Type message..." >
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-info btn-sm" onclick="comment_post(<?php echo $data['id'] ?>)">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- comment box here -->
                                    </div>
                                </div>
                            </div>
                            <!-- ./box-body -->                              
                        </div>
                        <!-- box-here -->  
                    </div>

                    <!-- reply-comment-main-bg-here -->   

                </div>
                <!-- timeline item end here-->
            </li>

        <?php } if ($data['publish_group_id'] != '99') { ?>

            <li id="<?php echo $data['id'] ?>">
                <div class="timeline-image">     
                    <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                </div>

                <!-- timeline item start here-->
                <div class="timeline-item">                         
                    <div class="timeline-header">
                        <!-- <span class="text-info">Smita Walvekar </span> -->

                        <div class="timelineheader-content1">
                            <span class="text-info "><?php echo $data['userfullname'] ?></span>
                        </div>
                        <div class="timelineheader-content1">
                            <span class="text-primary"><?php echo $data['title']; ?></span>
                        </div>

                        <!--<small class="text-primary">on <?php echo $data['blog_date']; ?></small>-->
                        <small class="time"><i class="fa fa-clock-o "></i> <?php echo $data['blog_time']; ?></small>


                        <div class="box-tools pull-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-angle-down text-bold"></i></button>
                                <ul class="dropdown-menu pull-right" role="menu">
                                    <li><a href="#" onclick="edit_post(<?php echo $data['id'] ?>)" >Edit</a></li>
                                    <li class="divider"></li>
                                    <li><a onclick="delete_post(<?php echo $data['id'] ?>)">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="timeline-body">
                        <?php echo $data['description']; ?>
                    </div>

                    <!--hidden blog data-->
                    <!--<input name="post_blog_id_<?php echo $data['id'] ?>" value="<?php echo $data['publish_group_id'] ?>">-->

                    <!-- reply-comment-main-bg-here -->

                    <div class="reply-comment-main-bg">
                        <!-- box-here -->  
                        <div class="box no-shadow-box">
                            <!-- box-header -->                             
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <?php if (isset($data['comment'])) { ?>
                                        <button type="button" class="btn btn-box-tool ">
                                            <i class="fa fa-plus" onclick="hide_comment('comment_div_id_<?php echo $data['id'] ?>')"></i>
                                        </button>   
                                    <?php } ?>
                                </div>
                            </div>
                            <!-- /.box-header -->

                            <!--box-body -->
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <!-- reply comment here -->
                                        <div class="comment_div_id_<?php echo $data['id'] ?> view-comment-1">
                                            <?php if (isset($data['comment'])) { ?>
                                                <?php $cnt = count($data['comment']); ?>
                                                <?php foreach ($data['comment'] as $commentResult) { ?>
                                                    <?php // var_dump($commentResult);  ?>
                                                    <div class="reply-comment-public">
                                                        <i class="fa fa-remove-square-o text-danger"></i>
                                                        <div class="box-comment">
                                                            <img class="img-circle img-sm" src="<?php echo base_url() . 'assets/uploads/' . $commentResult['profileimg']; ?>">
                                                            <div class="comment-text">
                                                                <span class="username"><?php echo $commentResult['userfullname'] ?>
                                                                    <small style="padding:0px 10px;" >
                                                                        <i class="fa fa-clock-o"></i> <small class="clr-999"><?php echo $commentResult['comment_time'] ?> </small> </small>
                                                                </span>
                                                                <p><?php echo $commentResult['comment'] ?> </p>
                                                            </div>
                                                        </div>
                                                    </div>       
                                                <?php } ?>

                                            <?php } ?>
                                        </div>
                                        <!-- reply comment here -->

                                        <!-- comment icon here -->
                                        <div class="share-info-bg">
                                            <ul class="list-inline">                               
                                                <li>
                                                    <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                                                        <?php if (isset($data['comment'])) { ?>
                                                            (<?php echo $data['comment'] ? count($data['comment']) : '0' ?>)
                                                            <?php
                                                        } else {
                                                            echo "(0)";
                                                        }
                                                        ?>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <!-- comment icon here -->
                                        <!-- comment box here -->
                                        <div class="reply-comment-box">
                                            <div class="input-group">
                                                <input name="comment_box_<?php echo $data['id'] ?>" id="comment_box_<?php echo $data['id'] ?>" class="form-control input-sm" placeholder="Type message..." >
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-info btn-sm" onclick="comment_post(<?php echo $data['id'] ?>)">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- comment box here -->
                                    </div>
                                </div>
                            </div>
                            <!-- ./box-body -->                              
                        </div>
                        <!-- box-here -->  
                    </div>

                    <!-- reply-comment-main-bg-here -->   

                </div>
                <!-- timeline item end here-->
            </li>
        <?php } ?>
        <?php $current_date = $data['blog_date']; ?>
    <?php } ?>
<?php } ?>
<!-- timeline item -->
<script>
    /*to edit post*/
    function edit_post(delete_post_id) {
        $('#post_' + delete_post_id).html('');
        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
        $('#post_' + delete_post_id).html(deleteNotify);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
            data: {delete_post_id: delete_post_id},
            success: function (data) {

            }
        });
    }
    /*to delete post*/
    function delete_post(delete_post_id) {
//    alert(delete_post_id); return false;
        $('#post_' + delete_post_id).html('');
        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px; margin-left:15%" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
        $('#post_' + delete_post_id).html(deleteNotify);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
            data: {delete_post_id: delete_post_id},
            success: function (data) {

            }
        });
    }

    /*to comment on  post*/
    function comment_post(blog_id) {
        $('.white-bg').addClass('overlay');
        var comment_value = $('#comment_box_' + blog_id).val();
        var currentStatus = $('#slideOne').val();
        var associate_id = <?php echo $user_summary['user_id'] ?>;
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/add_comment',
            data: {blog_id: blog_id, comment: comment_value, associate_id: associate_id, current_status: currentStatus},
            success: function (data) {
                $('#comment_box_' + blog_id).val('');
                $('.white-bg').removeClass('overlay');
                $('.loader').hide();
                $('#blog_detail').val('');
                $('#post_count').val();
                var parsed = $.parseJSON(data);
                $('.timeline').html('');
                $('.timeline').html(parsed.content);

            }
        });


//        $('#post_' + delete_post_id).html('');
//        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
//        $('#post_' + delete_post_id).html(deleteNotify);
//        $.ajax({
//            type: "POST",
//            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
//            data: {delete_post_id: delete_post_id},
//            success: function (data) {
//
//            }
//        });
    }
</script>

<script>
    /*to hide comment*/
    function hide_comment(id) {
        $('.' + id).toggle("slow");
    }

</script>

<style>
    .overlay {
        /*background: #e9e9e9;*/  
        display: block;        
        /*position: absolute;*/   
        /*        top: 0;                  
                right: 0;               
                bottom: 0;
                left: 0;*/
        opacity: 0.5;
    }
    .loader {    
        margin: 8% auto 0;
        border: 6px solid #f3f3f3; /* Light grey */
        border-top: 6px solid #505050; /* Blue */
        border-radius: 50%;
        width: 60px;
        height: 60px;
        animation: spin 1s linear infinite;

    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>