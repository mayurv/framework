<!-- Message start -->
<div class="active tab-pane" id="send-message">
    <div class="post">                  
        <!-- /.user-block -->
        <!-- form start -->
        <form role="form" id="form_post_id_<?php echo $user_summary['user_id'] ?>">
            <?php ?>
            <!--<input value="" id="slideOnePost" name="slideOnePost">-->
            <div class="box-body all-padding-0">
                <div class="form-group margin-bottom-0">
                    <textarea name="blog_detail"  id="blog_detail" class="form-control no-border" rows="3" placeholder="Enter Message"></textarea>
                </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer padding-tp">

                <div class="row"> 
                    <div class="col-sm-12 "></div>
                </div>

                <div class="row">
                    <div class="col-sm-7">

                        <div class="demo-droppable">
                            <i class="fa fa-paperclip fa-lg text-ccc" title="Attach File"></i>
                        </div>

                        <div class="demo-droppable1">
                            <i class="fa fa-camera fa-lg text-ccc" title="Attach Image"></i>
                        </div>

                        <!-- <div class="demo-droppable2">
                          <i class="fa fa-video-camera fa-lg"></i>
                        </div>-->
                        <!-- <div class="form-group margin-bottom-0">
                          <div class="controls">
                            <input type="text" id="daterange-1" placeholder="12/27/2016" class="input-sm form-control daterange">
                          </div>
                        </div> -->                             


                    </div>

                    <div class="col-sm-3 col-sm-offset-1">
                        <div class="form-group margin-bottom-0">
                            <?php
                            echo form_dropdown(array('id' => 'publish_group_id', 'name' => 'publish_group_id', 'class' => 'form-control  input-sm'), $publish_group);
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div class="col-sm-12">
            <div class="pull-right align-post">
                <?php $postFunction = 'postBlogFunction(' . $user_summary['user_id'] . ')'; ?>
                <button type="submit" class="btn btn-info btn-sm" id="post_id_<?php echo $user_summary['user_id'] ?>" onclick="<?php echo $postFunction ?>">Post</button>
            </div>
        </div>
    </div>
    <!-- /.post -->
</div>
<!-- Message leave start -->
<script>
    function postBlogFunction() {
//        $form = form_post_id_
//        $("#form_post_id_<?php echo $user_summary['user_id'] ?>").submit();
        $('.loader').show();
        $('.white-bg').addClass('overlay');
        var formData = $("#form_post_id_<?php echo $user_summary['user_id'] ?>").serializeArray();
        var myData = $('#upload_post_file_id')[0].files;
        //var myData = new FormData($("#form_post_id_<?php echo $user_summary['user_id'] ?>")[0]);
//        $('#slideOnePost').val($('#slideOne').val())
        var files = $("#form_post_id_<?php echo $user_summary['user_id'] ?>").prop('files');

        //$('#upload_post_file_id')[0].files[0]
//        $( ".timeline" ).prepend( "" );
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/post_blog',
            data: formData,
            success: function (data) {
                $('.white-bg').removeClass('overlay');
                $('.loader').hide();
                $('#blog_detail').val('');
                $('#post_count').val();
                var parsed = $.parseJSON(data);
                $('.timeline').html('');
                $('.timeline').html(parsed.content);
            }
        });
        return false;
    }


</script>