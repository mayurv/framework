<!-- timeline item -->
<?php
$i = 0;
$current_date = ''
?>
<?php if (isset($blog_data)) { ?>
    <?php foreach ($blog_data as $data) { ?>

        <?php if ($current_date != $data['blog_date']) { ?>
            <li class="time-label">
                <span class="bg-red">
                    <?php echo $data['blog_date']; ?>
                </span>
            </li>
        <?php } ?>    
        <?php if ($data['user_id'] == $user_summary['user_id'] && $data['publish_group_id'] == '99') { ?>
            <li>
                <div class="timeline-image">     
                    <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                </div>

                <!-- timeline item start here-->
                <div class="timeline-item">                         
                    <div class="timeline-header">
                        <!-- <span class="text-info">Smita Walvekar </span> -->

                        <div class="timelineheader-content1">
                            <span class="text-info text-bold"><?php echo $data['userfullname'] ?></span>
                        </div>
                        <div class="timelineheader-content1">
                            <span class="text-primary"><?php echo $data['title']; ?></span>
                        </div>

                        <small class="text-primary">on <?php echo $data['blog_date']; ?></small>
                        <small class="time"><i class="fa fa-clock-o"></i> <?php echo $data['blog_time']; ?></small>


                        <div class="box-tools pull-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-angle-down text-bold"></i></button>
                                <ul class="dropdown-menu pull-right" role="menu">
                                    <li><a href="#" >Add</a></li>
                                    <li><a href="#">Edit</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#" onclick="delete_post(<?php echo $data['id'] ?>)">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="timeline-body">
                        <?php echo $data['description']; ?>
                    </div>


                    <!-- reply-comment-main-bg-here -->  
                    <div class="reply-comment-main-bg">
                        <!-- box-here -->  
                        <div class="box no-shadow-box">
                            <!-- box-header -->                             
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool view-comment-1">
                                        <i class="fa fa-plus"></i>
                                    </button>                                  
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!--box-body -->
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <!-- reply comment here -->
                                        <div class="reply-comment-public">
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Mayur Vachchewar
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>

                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Balram Kamble
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>
                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>

                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Mayur Vachchewar
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>

                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Balram Kamble
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>
                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>

                                        </div>
                                        <!-- reply comment here -->
                                        <!-- comment icon here -->
                                        <div class="share-info-bg">
                                            <ul class="list-inline">                               
                                                <li>
                                                    <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                                                        (2)</a></li>
                                            </ul>
                                        </div>
                                        <!-- comment icon here -->
                                        <!-- comment box here -->
                                        <div class="reply-comment-box">
                                            <div class="input-group">
                                                <input class="form-control input-sm" placeholder="Type message...">
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-info btn-sm">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- comment box here -->
                                    </div>
                                </div>
                            </div>
                            <!-- ./box-body -->                              
                        </div>
                        <!-- box-here -->  
                    </div>
                    <!-- reply-comment-main-bg-here -->   

                </div>
                <!-- timeline item end here-->
            </li>

            <li>
                <i class="fa fa-envelope bg-blue"></i>

                <div class="timeline-item padding-bottom-10">

                    <div class="row">
                        <div class="col-sm-3"> 
                            <div class="media">
                                <div class="media-left">
                                    <a href="#">
                                        <!--frontend/dist/img/profile-->
                                        <?php // echo base_url().'assets/uploads/'.$associate_slug.'/profile/'.$personal_detail['profile_image']; ?>
                                        <?php // echo base_url(); ?><?php // echo $data['profileimg']; ?>
                                        <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>" width="60" height="60">
                                    </a>
                                </div>

                                <div class="media-body">
                                    <p class="text-bold text-info"><?php echo $data['userfullname'] ?></p>    
                                    <p> <?php echo $data['position_name']; ?></p>                             
                                </div>
                            </div>
                        </div>


                        <div class="col-sm-9"> 
                            <div id="post_<?php echo $data['id'] ?>">
                                <div class="timeline-body">
                                    <div class="dropdown pull-right">
                                        <i type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true" class="dropdown-toggle fa fa-angle-down" id="dropdownMenu1" data-toggle="dropdown"></i>
                                        <ul class="dropdown-menu action-dropdown" role="menu" aria-labelledby="dropdownMenu1">
                                            <!--<i class="fa fa-minus text-info animated fadeIn "></i>-->
                                            <!--<i class="fa fa-remove text-danger animated fadeIn ">-->
                                            <!--<li role="presentation"><a role="menuitem" tabindex="-1" data-toggle="modal" href="#certification-det-Modal-2-v-<?php echo $data['id'] ?>">edit</a></li>-->
                                            <li role="presentation"><a role="menuitem" tabindex="-1" onclick="delete_post(<?php echo $data['id'] ?>)"><i class="fa fa-remove text-danger"></i></a></li>
                                        </ul>
                                    </div>
                                    <h6 class="all-margin border-bottom1 padding-bottom-5">
                                        <span class="text-info"><?php echo $data['title']; ?> </span>
                                        <small class="text-primary">on <?php echo $data['blog_date']; ?> <span class="time"><i class="fa fa-clock-o"></i> <?php echo $data['blog_time']; ?></span></small></h6>

                                    <p class="padding-top-bottom-10"><?php echo $data['description']; ?></p>

                                                                        <!--<p><span class="time"><i class="fa fa-clock-o"></i> <?php echo $data['blog_time']; ?></span></p>-->
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </li>
        <?php } if ($data['publish_group_id'] != '99') { ?>
            <li>
                <div class="timeline-image">     
                    <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>">
                </div>

                <!-- timeline item start here-->
                <div class="timeline-item">                         
                    <div class="timeline-header">
                        <!-- <span class="text-info">Smita Walvekar </span> -->

                        <div class="timelineheader-content1">
                            <span class="text-info text-bold"><?php echo $data['userfullname'] ?></span>
                        </div>
                        <div class="timelineheader-content1">
                            <span class="text-primary"><?php echo $data['title']; ?></span>
                        </div>

                        <small class="text-primary">on <?php echo $data['blog_date']; ?></small>
                        <small class="time"><i class="fa fa-clock-o"></i> <?php echo $data['blog_time']; ?></small>


                        <div class="box-tools pull-right">
                            <div class="btn-group">
                                <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-angle-down text-bold"></i></button>
                                <ul class="dropdown-menu pull-right" role="menu">
                                    <li><a href="#" >Add</a></li>
                                    <li><a href="#">Edit</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#" onclick="delete_post(<?php echo $data['id'] ?>)">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="timeline-body">
                        <?php echo $data['description']; ?>
                    </div>


                    <!-- reply-comment-main-bg-here -->  
                    <div class="reply-comment-main-bg">
                        <!-- box-here -->  
                        <div class="box no-shadow-box">
                            <!-- box-header -->                             
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool view-comment-1">
                                        <i class="fa fa-plus"></i>
                                    </button>                                  
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!--box-body -->
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <!-- reply comment here -->
                                        <div class="reply-comment-public">
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">Mayur Vachchewar
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>

                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Balram Kamble
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>
                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>

                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Mayur Vachchewar
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>

                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>
                                            <div class="box-comment">
                                                <img class="img-circle img-sm" src="dist/img/user1-128x128.jpg">
                                                <div class="comment-text">
                                                    <span class="username">
                                                        Balram Kamble
                                                        <small style="padding:0px 10px;" class="text-muted">
                                                            <i class="fa fa-clock-o"></i> 8:03 PM </small>
                                                    </span>
                                                    <p>It is a long established fact that a reader will be distracted
                                                        by the readable content of a page when looking at its layout.</p>
                                                </div>
                                            </div>

                                        </div>
                                        <!-- reply comment here -->
                                        <!-- comment icon here -->
                                        <div class="share-info-bg">
                                            <ul class="list-inline">                               
                                                <li>
                                                    <a href="#" class="link-black text-sm"><i class="fa fa-comments-o margin-r-5"></i> Comments
                                                        (2)</a></li>
                                            </ul>
                                        </div>
                                        <!-- comment icon here -->
                                        <!-- comment box here -->
                                        <div class="reply-comment-box">
                                            <div class="input-group">
                                                <input class="form-control input-sm" placeholder="Type message...">
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-info btn-sm">Send</button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- comment box here -->
                                    </div>
                                </div>
                            </div>
                            <!-- ./box-body -->                              
                        </div>
                        <!-- box-here -->  
                    </div>
                    <!-- reply-comment-main-bg-here -->   

                </div>
                <!-- timeline item end here-->
            </li>
            <li>
                <i class="fa fa-envelope bg-blue"></i>

                <div class="timeline-item padding-bottom-10">

                    <div class="row">
                        <div class="col-sm-3"> 
                            <div class="media">
                                <div class="media-left">
                                    <a href="#">
                                        <!--frontend/dist/img/profile-->
                                        <?php // echo base_url().'assets/uploads/'.$associate_slug.'/profile/'.$personal_detail['profile_image']; ?>
                                        <?php // echo base_url(); ?><?php // echo $data['profileimg']; ?>
                                        <img class="media-object img-circle" src="<?php echo base_url() . 'assets/uploads/' . $data['profileimg']; ?>" width="60" height="60">
                                    </a>
                                </div>

                                <div class="media-body">
                                    <p class="text-bold text-info"><?php echo $data['userfullname'] ?></p>    
                                    <p> <?php echo $data['position_name']; ?></p>                             
                                </div>
                            </div>
                        </div>


                        <div class="col-sm-9"> 
                            <div id="post_<?php echo $data['id'] ?>">
                                <div class="timeline-body">
                                    <div class="dropdown pull-right">
                                        <i type="button" id="dropdownMenu1" data-toggle="dropdown" aria-expanded="true" class="dropdown-toggle fa fa-angle-down" id="dropdownMenu1" data-toggle="dropdown"></i>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                            <!--<i class="fa fa-minus text-info animated fadeIn "></i>-->
                                            <!--<i class="fa fa-remove text-danger animated fadeIn ">-->
                                            <!--<li role="presentation"><a role="menuitem" tabindex="-1" data-toggle="modal" href="#certification-det-Modal-2-v-<?php echo $data['id'] ?>">edit</a></li>-->
                                            <li role="presentation"><a role="menuitem" tabindex="-1" onclick="edit_post(<?php echo $data['id'] ?>)"><i class="fa fa-pencil-square  text-default"></i>Edit Post</a></li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" onclick="delete_post(<?php echo $data['id'] ?>)"><i class="fa fa-times-rectangle text-default"></i>Delete Post</a></li>
                                        </ul>
                                    </div>
                                    <h6 class="all-margin border-bottom1 padding-bottom-5">
                                        <span class="text-info"><?php echo $data['title']; ?> </span>
                                        <small class="text-primary">on <?php echo $data['blog_date']; ?> <span class="time"><i class="fa fa-clock-o"></i> <?php echo $data['blog_time']; ?></span></small></h6>

                                    <p class="padding-top-bottom-10"><?php echo $data['description']; ?></p>

                                                                        <!--<p></p>-->
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </li>
        <?php } ?>
        <?php $current_date = $data['blog_date']; ?>
    <?php } ?>
<?php } ?>
<!-- timeline item -->
<script>
    /*to edit post*/
    function edit_post(delete_post_id) {
        $('#post_' + delete_post_id).html('');
        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
        $('#post_' + delete_post_id).html(deleteNotify);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
            data: {delete_post_id: delete_post_id},
            success: function (data) {

            }
        });
    }
    /*to delete post*/
    function delete_post(delete_post_id) {
        $('#post_' + delete_post_id).html('');
        var deleteNotify = '<div class="alert alert-default alert-dismissible fade in" style="border-radius:5px;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button><strong class="text-danger">removed,</strong> your post removed successfully.</div>';
        $('#post_' + delete_post_id).html(deleteNotify);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>dashboard/delete_post_blog',
            data: {delete_post_id: delete_post_id},
            success: function (data) {

            }
        });
    }
</script>



