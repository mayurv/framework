<div class="white-bg all-padding-20">
    <!-- The timeline -->
    <ul class="timeline timeline-inverse">
        <!-- timeline time label -->
        <li class="time-label">
            <span class="bg-red">
                10 Feb. 2014
            </span>
        </li>
        <!-- /.timeline-label -->
        
        
        
        <!-- timeline item -->
        <li>
            <i class="fa fa-user bg-aqua"></i>

            <div class="timeline-item padding-bottom-10">

                <div class="row">
                    <div class="col-sm-3"> 
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object img-circle" src="<?php echo base_url(); ?>frontend/dist/img/user1-128x128.jpg" width="60" height="60">
                                </a>
                            </div>
                            <div class="media-body">
                                <p class="text-bold text-info">Balram Kamble</p>    
                                <p> UI Developer</p>                             
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-9"> 
                        <div class="timeline-body">
                            <h6 class="all-margin border-bottom1 padding-bottom-5">
                                <span class="text-info">National Holiday </span>
                                <small>on 26th  January 2017</small></h6>

                            <p class="padding-top-bottom-10">Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplin</p>

                            <p><span class="time"><i class="fa fa-clock-o"></i> 12:05</span></p>
                        </div>
                    </div>

                </div>

            </div>
        </li>
        <!-- END timeline item -->

        <!-- timeline time label -->
        <li class="time-label">
            <span class="bg-green">
                3 Jan. 2014
            </span>
        </li>
        <!-- /.timeline-label -->
        <!-- timeline item -->
        <li>
            <i class="fa fa-camera bg-purple"></i>

            <div class="timeline-item padding-bottom-10">

                <div class="row">
                    <div class="col-sm-3"> 
                        <div class="media">
                            <div class="media-left">
                                <a href="#">
                                    <img class="media-object img-circle" src="<?php echo base_url(); ?>frontend/dist/img/user1-128x128.jpg" width="60" height="60">
                                </a>
                            </div>
                            <div class="media-body">
                                <p class="text-bold text-info">Balram Kamble</p>    
                                <p> UI Developer</p>                             
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-9"> 
                        <div class="timeline-body">
                            <h6 class="all-margin border-bottom1 padding-bottom-5">
                                <span class="text-info">National Holiday </span>
                                <small>on 26th  January 2017</small></h6>

                            <p class="padding-top-bottom-10">Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplin Etsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplinEtsy doostang zoodles disqus groupon greplin</p>

                            <p><span class="time"><i class="fa fa-clock-o"></i> 12:05</span></p>
                        </div>
                    </div>

                </div>

            </div>
        </li>
        <!-- END timeline item -->
        <li>
            <i class="fa fa-clock-o bg-gray"></i>
        </li>
    </ul>
</div>