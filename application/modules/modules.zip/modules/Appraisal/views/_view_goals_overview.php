<div class="row">
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">
            <div class="row">
                <div class="col-sm-8">
                    <h4> <a href="<?php echo base_url() ?>appraisal">Appraisal </a> | Associate Goal Overview </h4>
                </div>
                <div class="col-sm-4">
                    <div class="pull-right">
                        <a class="btn btn-default btn-sm btn-radius-3" data-remote="true" data-toggle="modal" data-target="#new-goal">
                            <i class="fa fa-plus-circle fa-lg margin-right-5"></i> Create goal                
                        </a>
                    </div>
                </div>
            </div>
              <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#assosciate" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> My Goals
                    </a>
                </li>
                <?php if($user_summary['emprole']=='3' || $user_summary['emprole']=='1' || $user_summary['emprole']=='4'){?>
                <li class="">
                    <a href="#team" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> Team Goals
                    </a>
                </li>
                <?php }?>
            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="assosciate">
                    <?php $this->load->view('_myGoals') ?>
                </div>
                <div class="tab-pane fade " id="team">
                    <?php $this->load->view('_teamGoals') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('modal/_add_goal'); ?>
<?php $this->load->view('modal/_edit_goal'); ?>

<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>
<?php foreach ($my_goals as $r => $data) { ?>
    <script>
        var s2 = $("#unranged-value<?php echo $data['id'] ?>").freshslider({
            step: 1,
            value: <?php echo $data['user_progress'] ?>,
            onchange: function (low, high) {
                $('#amountDisp<?php echo $data['id'] ?>').val(low);
            },
    <?php if ($data['user_status'] != 0) { ?>
                enabled: false,
    <?php } ?>
        });

    </script>

<?php } ?>