<div class="row">
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">
        <h2> Set Goals</h2>

        <!--1st dashboard here start --> 
        <div class="row">
            <div class="col-sm-6">            
                <div class="info-box">
                    <div class="panel">
                        <div id="demo-step-wz">
                            <div class="wz-heading wz-w-label bg-grey">
                                <div class="progress progress-xs progress-wizard">
                                    <div class="progress-bar progress-bar-dark active" style="width: 0%; margin: 0px 12.5%;"></div>
                                </div>
                                <ul class="wz-steps wz-icon-bw wz-nav-off text-lg">
                                    <li class="col-xs-4 active">
                                        <a aria-expanded="true" data-toggle="tab" href="#demo-step-tab1_goals">
                                            <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                <span class="wz-icon icon-txt text-bold">1</span>
                                                <i class="wz-icon-done fa fa-check"></i>
                                            </span>
                                            <small class="wz-desc box-block margin-top-5">Set goals</small>
                                        </a>
                                    </li>
                                    <li class="col-xs-4">
                                        <a data-toggle="tab" href="#demo-step-tab2_goals">
                                            <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                <span class="wz-icon icon-txt text-bold">2</span>
                                                <i class="wz-icon-done fa fa-check"></i>
                                            </span>
                                            <small class="wz-desc box-block margin-top-5">Approve goals</small>
                                        </a>
                                    </li>
                                    <li class="col-xs-4">
                                        <a data-toggle="tab" href="#demo-step-tab3_goals">
                                            <span class="icon-wrap icon-wrap-xs icon-circle bg-dark">
                                                <span class="wz-icon icon-txt text-bold">3</span>
                                                <i class="wz-icon-done fa fa-check"></i>
                                            </span>
                                            <small class="wz-desc box-block margin-top-5">Update goals</small>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <form class="form-horizontal">
                                <div class="panel-body">
                                    <div class="tab-content no-border">
                                        <div class="tab-pane active in" id="demo-step-tab1_goals">
                                            <h4>You set your own individual goals</h4>
                                            <div class="margin-bottom-10">
                                                You start by setting your own individual goals for the period. PeopleGoal helps you to set SMART goals:
                                            </div>
                                            <div class="margin-bottom-15 margin-top-15">
                                                <table class="table table-striped col-md-6">
                                                    <thead>
                                                        <tr>
                                                            <th>SMART Attribute</th>
                                                            <th>PeopleGoal asks you:</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>Specific</td>
                                                            <td>What is specific about the goal?</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Measurable</td>
                                                            <td>How should the goal be measured?</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Attainable</td>
                                                            <td>How will the goal be achieved?</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Relevant</td>
                                                            <td>Why is the goal relevant?</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Time-bound</td>
                                                            <td>When is the goal due to be achieved?</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div></div>
                                                If you are a manager or an admin you can also create goals for your team members or whole departments.
                                            </div>
                                            <div class="pull-left">
                                                <a class="needs-loading btn btn-info btn-theme btn-md btn-radius-3" data-remote="true" data-toggle="modal" data-target="#new-goal">
                                                    <i class="fa fa-plus-circle fa-lg margin-right-5"></i>
                                                    Create your first individual goal                   
                                                </a></div>
                                        </div>
                                        <div class="tab-pane fade" id="demo-step-tab2_goals">
                                            <h4>Your manager reviews your goal</h4>
                                            <div class="margin-bottom-10">
                                                Your manager will be sent an email asking him/her to review and approve your goal. This is done to ensure that you and your manager are in alignment with what you need to achieve in this performance period.
                                            </div>
                                            <div class="margin-bottom-20 margin-top-20">
                                                <button class="btn btn-success btn-md tooltip btn-radius-3">
                                                    <i class="fa fa-check-circle margin-right-5"></i>
                                                    Approve <span class="tooltiptext">Your manager can <br> approve the goal</span>
                                                </button>
                                                <button class="btn btn-warning btn-md margin-left-10 tooltip btn-radius-3">
                                                    <i class="fa fa-times-circle margin-right-5"></i>
                                                    Reject <span class="tooltiptext">Or your manager can <br>reject the goal</span>
                                                </button>
                                            </div>
                                            <div class="margin-bottom-10">
                                                Your manager will also be promted to provide comments to allow you to improve the quality of the goal (especially helpful when your goal has been rejected!). You can then make updates and re-submit it to your manager.
                                            </div>
                                        </div>
                                        <div class="tab-pane mar-btm" id="demo-step-tab3_goals">
                                            <h4>Update your goal progress</h4>
                                            <div class="margin-bottom-10">
                                                You can provide regular updates on your goal progress by clicking on "goals" in the sidebar. You can provide a written update and/or a progress update (percentage complete). It"s important to keep your goal progress up-to-date!
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-footer text-right">
                                    <div class="box-inline">
                                        <button class="previous btn btn-info btn-theme btn-theme disabled btn-radius-3" type="button">Previous</button>
                                        <button class="next btn btn-info btn-theme btn-theme btn-radius-3" type="button">Next</button>
                                        <a class="needs-loading btn btn-info btn-theme finish btn-md btn-radius-3" data-remote="true" data-toggle="modal" data-target="#new-goal">
                                            <i class="fa fa-plus-circle fa-lg margin-right-5"></i>
                                            Create your first individual goal
                                        </a></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
            </div>
            <!--1st dashboard here end --> 
        </div>
    </div>
    </div>        
</div>
<?php $this->load->view('modal/_add_goal'); ?>

<!--step wizard css-->
<script src="<?php echo base_url('frontend/plugins/goal-step/js/application-main.js') ?>"></script>
<script src="<?php echo base_url('frontend/plugins/goal-step/js/v2.js') ?>"></script>
<!--step wizard css-->