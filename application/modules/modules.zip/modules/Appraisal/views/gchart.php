<div class="row">
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">


            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-left">
                        <h4>Appriasal Reports</h4> 
                    </div>              
                </div>
            </div>

            <ul class="nav nav-tabs">
                <li class="active">
                    <a href="#assosciate" data-toggle="tab" aria-expanded="true">
                        <i class="fa fa-clock-o "></i> Associate
                    </a>
                </li>


                <li class="">
                    <a href="#hr" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> HR
                    </a>
                </li>

                <li class="">
                    <a href="#manager" data-toggle="tab" aria-expanded="false">
                        <i class="fa fa-check-circle"></i> Manager
                    </a>
                </li>

            </ul>

            <div class="tab-content">
                <div class="tab-pane fade active in" id="assosciate">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Associate Ratings </h5>

                                </div>
                                <div class="ibox-content">
                                    <div id="morris-one-line-chart"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade " id="hr">


                </div>

                <div class="tab-pane fade " id="manager">
                    <?php //$this->load->view('report/dept_leaveSummary') ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php //$this->load->view('modal/_add_developmentplan') ?>



<link href="<?php echo base_url('plugins/morris_new/morris-0.4.3.min.css'); ?>" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url('plugins/morris_new/morris.js') ?>"></script>
<script src="<?php echo base_url('plugins/morris_new/raphael-2.1.0.min.js') ?>"></script>
<?php

$responce->cols[] = array( 
            "id" => "", 
            "label" => "Topping", 
            "pattern" => "", 
            "type" => "string" 
        ); 
        $responce->cols[] = array( 
            "id" => "", 
            "label" => "Total", 
            "pattern" => "", 
            "type" => "number" 
        ); 
        
         foreach($ass_report as $cd) 
            { 
            $responce->rows[]["c"] = array( 
                array( 
                    "v" => $cd['self_avg_rating'], 
                    "f" => null 
                ) , 
                array( 
                    "v" => $cd['id'], 
                    "f" => null 
                ) 
            ); 
            } 
 //var_dump($responce);
         json_encode($responce); 


$arr_name = '';
foreach ($ass_report as $k => $opData) {
    $arr_name .= "{cat_id: '" . $opData['cat_id'] . "', value: " .$opData['self_avg_rating'] ."},";  
    $arr_name = json_encode($arr_name);
}
?>



<title>Google Chart and Codeigniter with MySQL</title> 
    <!--Load the AJAX API--> 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script> 
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 
    <script type="text/javascript"> 
     
    // Load the Visualization API and the piechart package. 
    google.charts.load('current', {'packages':['corechart']}); 
       
    // Set a callback to run when the Google Visualization API is loaded. 
    google.charts.setOnLoadCallback(drawChart); 
       
    function drawChart() { 
      var jsonData = $.ajax({ 
          url: "<?php echo base_url() ?>/appraisal/getdata", 
          dataType: "json", 
          async: false 
          }).responseText; 
           
      // Create our data table out of JSON data loaded from server. 
      var data = new google.visualization.DataTable(jsonData); 
 
      // Instantiate and draw our chart, passing in some options. 
      var chart = new google.visualization.PieChart(document.getElementById('chart_div')); 
      chart.draw(data, {width: 900, height: 500}); 
    } 
 
    </script> 
<style> 
h1 { 
    text-align: center; 
} 
</style> 
  </head> 
 
  <body> 
    <!--Div that will hold the pie chart--> 
    <h1>Quantity of fruits we have in our store - Displayed by Google Chart and Codeigniter with MySQL</h1> 
    <div id="chart_div"></div> 
  </body> 
</html> 