<?php $currentDate = date('Y-m-d 00:00:00'); ?>
<div class="main-bg all-padding-15">
    <div class="row">
        <div class="col-sm-12">
            <h4 class="text-bold">Approve Opening</h4>
        </div>


        <?php // var_dump($openings); die;    ?>
        <div class="col-sm-12">
            <table id="dt-approve-opening" class="table">
                <thead>
                    <tr>
<!--                        <th>#</th>-->
                        <th >Name</th>
                        <th>Close Date</th>
                        <th>Status</th>
                        <th >Positions</th>
                        <th >Skills</th>
                        <th >Qualification</th>                      
                        <th >Project</th>                      
                        <th ></th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($openings as $result) { //var_dump($openings);die;   ?>
                        <tr>
                            <?php $currentDate = date('Y-m-d'); ?>
                            <?php // if ($result['opening_status'] == 3) { ?>
                                <!--<td><i class="fa fa-check-circle text-success"></i></td>-->
                            <?php // } else if ($currentDate > $result['close_date']) { ?>
                                <!--<td><i class="fa fa-check-circle text-danger"></i></td>-->
                            <?php // } else { ?>
                                <!--<td><i class="fa fa-check-circle text-warning "></i></td>-->
                            <?php // } ?>

                            <td >
                                <p><?php echo $result['jobtitlename'] . ' <small>(' . $result['deptname'] . ')</small>'; ?></p>
                                <p> <i class="fa fa-briefcase margin-right-5"> </i> <?php echo $result['req_exp_years_from'] ?>-<?php echo $result['req_exp_years_to'] ?> years</p>
                            </td>
                            <td>
                                <p><?php echo date('d F Y', strtotime($result['close_date'])); ?></p>
                                <?php $currentDate = date('Y-m-d'); ?>
                                <?php if ($currentDate > $result['close_date']) { ?>
                                    <p><small><i class=" text-orange">Closing Date exceed</i></small></p>
                                <?php } ?>
                            </td>
                            <td>
                                <p><?php
                                    if ($result['opening_status'] == 3)
                                        echo date('d F Y', strtotime($result['actual_close_date']));
                                    ?></p>

                                <?php $currentDate = date('Y-m-d'); ?>
                                <?php if ($currentDate > $result['close_date'] && $result['opening_status'] != 3) { ?>
                                    <p class="text-orange"><span class="btn btn-danger btn-xs" title="Closing Date Exceed">On Going</span></p>
                                <?php } elseif ($result['opening_status'] == 3) {
                                    ?>
                                    <p class=" text-success"><span class="btn btn-success btn-xs" title="Opening Closed">Closed</span>
                                        <?php
                                        $fromDate = (date('Y-m-d', strtotime($result['close_date'])));
                                        $toDate = (date('Y-m-d'));
                                        $diff = date_diff(date_create($fromDate), date_create($toDate));
                                        ?>
                                        <?php if ($fromDate >= $toDate) { ?>
                                            <small class="text-success" title="Closed Before Closing Date"> <?php echo '(' . ($diff->days) . ' days)'; ?></small>
                                        <?php } else { ?>
                                            <small class="text-danger" title="Excced From Closed Date"> <?php echo '(' . ($diff->days) . ' days)'; ?></small>
                                        <?php } ?>
                                    </p>
                                <?php } else { ?>
                                    <p ><span class="btn btn-warning btn-xs" title="Ongoing">On Going</span></p>
                                <?php } ?>
                            </td>
                            <td>
                                <?php
                                $val = (100 / $result['req_no_positions']) * $result['selected'];
                                ?>
                                <div class="progress">
                                    <?php //echo $val ?>
                                    <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="<?php echo $result['selected'] ?>" aria-valuemin="0" aria-valuemax="<?php echo $result['req_no_positions'] ?>" style="width: <?php echo $val ?>%; height: 100%; background-color: rgba(31, 181, 172, 1);"></div>

                                </div> 
                                <p class="text-ccc">(
                                    <span title="Filled Position" style="cursor:pointer">  <?php echo $result['selected'] ?></span>
                                    /
                                    <span title="Required Position" style="cursor:pointer"><?php echo $result['req_no_positions'] ?></span>
                                )</p>

                            </td>
                            <td width="10%"><?php echo $result['req_skills'] ?></td>
                            <td><?php echo $result['req_qualification'] ?></td> 
                            <td><p><?php echo $result['project_name'] ?></p> 
                                <p class="text-ccc"><?php echo $result['client_name'] ?>
                                </p></td> 

                            <td width="5%">
                                <div class="switch">
                                    <label>      
                                        <?php
                                        $ch = '';
                                        $hideDiv = 'none';
                                        $function = 'activateJobOpenings(' . $result['id'] . ')';
                                        if ($result['isactive'] == '1') {
                                            $ch = "'checked'=>'TRUE'";
                                            $hideDiv = 'none';
                                            $chval = 1;
                                        } else {
                                            $ch = "";
                                            $hideDiv = 'block';
                                            $chval = 0;
                                        }
                                        ?>

                                        <?php echo form_checkbox(array('id' => 'openingStatus_' . $result['id'], 'name' => 'portalStatus', 'value' => $chval, 'checked' => $ch, 'onclick' => $function)); ?>
                                        <span class="lever"></span>                                    
                                    </label>
                                </div>

                            </td>  


                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
<script>

    function activateJobOpenings(openingId) {


        var isChecked = $("#openingStatus_" + openingId).val();
        if (isChecked == 0) {
            $("#openingStatus_" + openingId).val('1');
        } else {
            $("#openingStatus_" + openingId).val('0')
        }
        var statusOp = $("#openingStatus_" + openingId).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>admin/approve_openings',
            data: {'opening_id': openingId, 'status': statusOp},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.active == '1')
                    showSuccess("Active - Opening approved successfully");
                else
                    showSuccess("Inactive - Opening deactivated successfully");
            }
        });
    }

</script>
<script>

    function aprroveClosingDate(temp_req_id, req_id) {
        var close_date = $('#close_date_' + temp_req_id).val();
        var req_close_date = $('#req_close_date_' + temp_req_id).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>admin/approve_closingdate',
            data: {'temp_req_id': temp_req_id, 'req_id': req_id, 'close_date': close_date, 'req_close_date': req_close_date},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.aprroved == '1') {
                    $('#req-ic-' + temp_req_id).addClass('text-success');
                    showSuccess("Approved - Position closing date request approved");
                    window.location.reload();
                } else {
                    showSuccess("Inactive - Position closing date request unapproved");
                }
            }
        });
    }

</script>

<!--Leave chart-->
<!--<script src="<?php echo base_url('frontend/plugins/chartjs/Chart.min.js'); ?>"></script>-->
<?php // var_dump($leaves);die;      ?>
<script>
//    $(function () {
//
//        // Get context with jQuery - using jQuery's .get() method.
//        var pieChartCanvas = $("#opningsStatus").get(0).getContext("2d");
//        var pieChart = new Chart(pieChartCanvas);
//        var PieData = [
//<?php foreach ($openings as $opData) { ?>
        //
        //                {
        //                    value: <?php echo $opData['req_no_positions'] ?>,
        //                    color: "#ccc",
        //                    highlight: "Data",
        //                    label: "<?php echo $opData['jobtitlename'] ?>",
        //                    title: "<?php echo $opData['jobtitlename'] ?>",
        //                },
        //<?php } ?>
//
//        ];
//        var pieOptions = {
//            //Boolean - Whether we should show a stroke on each segment
//            segmentShowStroke: true,
//            //String - The colour of each segment stroke
//            segmentStrokeColor: "#fff",
//            //Number - The width of each segment stroke
//            segmentStrokeWidth: 1,
//            //Number - The percentage of the chart that we cut out of the middle
//            percentageInnerCutout: 5, // This is 0 for Pie charts
//            //Number - Amount of animation steps
//            animationSteps: 100,
//            //String - Animation easing effect
//            animationEasing: "easeOutBounce",
//            //Boolean - Whether we animate the rotation of the Doughnut
//            animateRotate: true,
//            //Boolean - Whether we animate scaling the Doughnut from the centre
//            animateScale: false,
//            //Boolean - whether to make the chart responsive to window resizing
//            responsive: true,
//            // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
//            maintainAspectRatio: true,
//            //String - A legend template
//            legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
//        };
//        //Create pie or douhnut chart
//        // You can switch between pie and douhnut using the method below.
//        pieChart.Doughnut(PieData, pieOptions);
//        barChartOptions.datasetFill = false;
//        barChart.Bar(barChartData, barChartOptions);
//    });</script>



