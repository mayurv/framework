<style>
    .user-bg1{
            float: left;
    width: 100%;
    height: auto;
    padding: 10px;
    margin: 10px 0px 10px 0px;
    box-shadow: 0 3px 7px 0 #a8a8a8 !important;
    border: 1px solid rgba(118, 118, 118, 0.15) !important;
    }
</style>
<?php foreach ($employee as $result) {  ?>
    <!-- col-sm-4 here -->
    <div class="col-sm-6" > 
        <!-- user bg -->
        <div class="user-bg1" title="">
            <div class="media">
                <div class="margin-right-10 text-center">   
                    <?php if (isset($result['profileimg']) && $result['profileimg'] != '') { ?>
                        <img class="img-responsive img-circle center-img media-object margin-top-0" src="<?php echo base_url() . 'assets/uploads/' . $result['profileimg']; ?>">  
                    <?php } else { ?>
                        <img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                    <?php } ?>
                </div>
                <div class="">
                    <h5 class="text-bold text-primary-main text-center">
                        <a href="<?php echo base_url() ?>employee/view_user/<?php echo $result['user_id']; ?>" >
                            <?php if (strlen($result['firstname']) > 10 || strlen($result['lastname']) > 12) { ?>
                                <?php echo $result['firstname'] . ' ' . substr($result['lastname'], 0, 1); ?>
                            <?php } else { ?>
                                <?php echo $result['userfullname']; ?>
                            <?php } ?>
                        </a>

                    </h5>
                     
                    <p class="text-center line-hgt" > <?php echo $result['employeeId']; ?></p>
                    <p class="text-center line-hgt" > <span title="Designation"> <?php echo $result['position_name']; ?></span>, <span title="Department"> <?php echo $result['department_name']; ?></span></p>                                                                                               
                    <?php
                    if ($result['isactive'] == '1')
                        $color = 'progress-bar-success';
                    else if ($result['isactive'] < '1')
                        $color = 'progress-bar-warning';
                    else
                        $color = 'progress-bar-danger';
                    ?>
                    <div class="progress">
                        <div class="progress-bar <?php echo $color ?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $result['profile_completion']; ?>%" title="Profile Completion : <?php echo $result['profile_completion']; ?>%">
                            <span class="text-white"></span>
                        </div>
                    </div>
                  
                   <div class="comment-box" style='dispaly:block'>
                       <textarea id="textarea1" class="materialize-textarea" placeholder="Add comment in detail"></textarea>
                        <button>submit</button>
                    </div>
                   
                </div>
            </div>              
        </div>                                                  
    </div>
<?php } ?>


