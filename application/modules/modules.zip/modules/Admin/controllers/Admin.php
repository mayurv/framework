<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// NOTE: this controller inherits from MY_Controller instead of Admin_Controller,
// since no authentication is required
class Admin extends MY_Controller {

    /**
     * Login page and submission
     */
    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language')); //employeesholiday
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails', 'years', 'months', 'holidaydates', 'workstation'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language', 'proficiency', 'employeelanguage', 'emergencycontact', 'emphobbies', 'empchilddetails', 'numbers'));
        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa', 'passport', 'leavetypesAllocation'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'gender', 'requisition', 'requisition_temp'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        } elseif (!$this->ion_auth->in_group('admin')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        $this->load->library('form_builder');
        $form = $this->form_builder->create_form();

        if ($form->validate()) {
            // passed validation
            $identity = $this->input->post('username');
            $password = $this->input->post('password');
            $remember = ($this->input->post('remember') == 'on');

            if ($this->ion_auth->login($identity, $password, $remember)) {
                // login succeed
                $messages = $this->ion_auth->messages();
                $this->system_message->set_success($messages);
                redirect($this->mModule);
            } else {
                // login failed
                $errors = $this->ion_auth->errors();
                $this->system_message->set_error($errors);
                refresh();
            }
        }


        // display form when no POST data, or validation failed
        $this->mViewData['form'] = $form;
        $this->mBodyClass = 'login-page';
        $this->render('about', 'empty');
    }

    public function approve_openings() {

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        /* if approved openong post method */
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//            var_dump($_POST);die;
            $opening_id = $this->input->post('opening_id');
            $status = $this->input->post('status');
            if ($status == 1) {
                $ispublished = '1';
                $active = '1';
            } else {
                $active = '0';
                $ispublished = '0';
            }
            //ispublished = 1 :Un approved 0: approve
            //isactive 0 = notactive 1: active
            $data = array('isactive' => $active, 'ispublished' => $ispublished);

            $this->requisition->update($opening_id, $data);
            echo json_encode(array('active' => $active));
            die;
        }


//        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        $data['openings'] = $this->requisition->get_all_openingsforAdmin();
        foreach ($data['openings'] as $id => $list) {
            if (isset($list['req_temp_id']) && $list['req_temp_id'] != null)
                $data['openings'][$id]['req_opening'] = $this->requisition_temp->get_by_id($list['id']);
        }
//        var_dump($data['openings']);die;
        //to get all data
        //to get main menu, sub menu
        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');

//        var_dump($data);die;
        $user_id = $this->session->userdata('user_id');

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['employee'] = $this->employeesummary->get_all();
        $dataMenu['candidates'] = $this->employeesummary->get_candidate_list();

        //$this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', '_job_opening', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function approve_closingdate() {
//        var_dump($_POST);
//        die;
        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $req_close_date = $this->input->post('req_close_date');
            $temp_req_id = $this->input->post('temp_req_id');
            $req_id = $this->input->post('req_id');
            $tempreqData = array(
                'isactive' => '1',
                'ispublished' => '1',
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s'),
            );
            $this->requisition_temp->update($temp_req_id, $tempreqData);

            $reqiData = array(
                'ispublished' => '1',
                'close_date' => $req_close_date,
//                'modifieddate' => date('Y-m-d H:i:s'),
            );

            $this->requisition->update($req_id, $reqiData);

            echo json_encode(array('aprroved' => '1'));
            die;
        }
    }

}
