<?php  
   if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Home_Model extends MY_Model {
        	 
     public function __construct() 
     {
           parent::__construct(); 
           $this->load->database();
     }

	function get_last_ten_entries(){
        $this->db->select('*');
        $this->db->from('system_users');
        $query = $this->db->get();
        return $query->result();
    }
      }
?>