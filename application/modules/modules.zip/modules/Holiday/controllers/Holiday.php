<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hr
 *
 *  *
 * @category   User Module
 * @package    HR
 * @author     Mayur Vachchewar <mayur.v@mindworx.in>
 * @author     Another Author <another@example.com>
 * @copyright  2016 The PHP Group
 * @since      File available since Release 1
 * @deprecated File deprecated in Release 2.1
 */
class Holiday extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('employees'));
        $this->load->model(array('user_model', 'holidaydates', 'years', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language('master');
        $this->load->language('holiday_lang');

        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        elseif (!$this->ion_auth->in_group('hr')) {
//            $this->session->set_flashdata('message', $this->ion_auth->errors());
//            redirect('/', 'refresh');
//        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

//        var_dump($this->session->userdata());die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //variables
        $k = 1;
        $cnt = 1;
        $menuobj = new ArrayObject();
        $i = 1;


        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', 'hrdashboard', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function add_holiday() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $holiday_count = $this->input->post('total_count');
            if (isset($holiday_count)) {
                for ($i = 1; $i <= $holiday_count; $i++) {
                    $dataHoliday[$i]['holidayname'] = $this->input->post('holidayName-' . $i);
                    $dataHoliday[$i]['holidaydate'] = date('Y-m-d H:m:s', strtotime(str_replace(',', '', $this->input->post('holidayDate-' . $i))));
                    $dataHoliday[$i]['description'] = $this->input->post('holidayDes-' . $i);
                    $dataHoliday[$i]['holidayyear'] = $this->input->post('holidayYear');
                    $dataHoliday[$i]['isactive'] = 1;
                    $dataHoliday[$i]['createdby'] = $user_id;
                    $dataHoliday[$i]['createddate'] = date('Y-m-d H:m:s');
                }
            }

            if (isset($dataHoliday))
                foreach ($dataHoliday as $dataResult) {
                    $this->holidaydates->insert($dataResult);
                }
            $this->session->set_flashdata('msg', 'Record addedd successfully');
        }
        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $data['publish_year'] = $this->holidaydates->get_AllYearsList();

        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_allholidayList();
//        var_dump($data['holiday_list'] );die;
        $data['holiday_list_all'] = $this->holidaydates->get_holidayList();

        //$data['holiday_list_by_year'] = $this->holidaydates->get_holidayList(2);

        $data['holidayYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_holiday', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function delete_holiday() {

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $this->input->post('delete_id');
            $this->holidaydates->delete($id);
        }
    }

    public function publish_holiday($id) {
        $dataPublish = array(
            'isactive' => 0
        );

        $this->holidaydates->update_holiday($id, $dataPublish);

        redirect('holiday/add_holiday');
    }

    public function edit_holiday($id) {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        echo $id;
        // var_dump($_POST);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dataHoliday = array(
                'holidayname' => $this->input->post('holiday_name'),
                'holidaydate' => date('Y-m-d H:m:s', strtotime(str_replace(',', '', $this->input->post('holiday_date')))),
                'description' => $this->input->post('holiday_des'),
            );
            $this->holidaydates->update($id, $dataHoliday);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }


        $data['publish_year'] = $this->holidaydates->get_AllYearsList();

        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_allholidayList();
//        var_dump($data['holiday_list'] );die;
        $data['holiday_list_all'] = $this->holidaydates->get_holidayList();

        //$data['holiday_list_by_year'] = $this->holidaydates->get_holidayList(2);

        $data['holidayYear_list'] = (array('' => 'Select Year') + $this->years->dropdown('year_id'));
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        
        /* Header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_holiday', '', TRUE);
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();

//        redirect('holiday/add_holiday');
    }

}
