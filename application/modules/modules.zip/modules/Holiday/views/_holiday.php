<div class="main-bg all-padding-15">
    <!-- top button bar here -->                                
    <div class="add-candidate-bg"> 
        <div class="pull-left">
            <button class="btn btn-warning btn-sm" data-toggle="modal" href="#addholiday-1"><i class="fa fa-plus-circle"></i> Add Holidays</button>
        </div>
    </div>                          
    <!-- top button bar here -->
    <?php // var_dump($publish_year)?>
    <div class="row">
        <div class="col-sm-3">
            <ul class="nav nav-tabs" role="tablist">
                <?php foreach ($publish_year as $list) { ?> 
                    <?php if ($list['isactive'] == 1) { ?>
                        <li role="presentation"  >
                            <a href="#<?php echo $list['year_id']; ?>" aria-controls="Year <?php echo $list['year_id']; ?>" role="tab" data-toggle="tab"><?php echo $list['year_id']; ?></a>
                        </li>
                    <?php } else { ?>
                        <li role="presentation" class="active">
                            <a href="#<?php echo $list['year_id']; ?>" aria-controls="Year <?php echo $list['year_id']; ?>" role="tab" data-toggle="tab"><?php echo $list['year_id']; ?></a>
                        </li>
                    <?php } ?>
                <?php } ?>

            </ul>
        </div>

        <div class="col-sm-9">            
            <div class="tab-content">
                <?php // var_dump($holiday_list); ?>
                <?php foreach ($publish_year as $list) { ?> 

                    <?php $list['isactive'] == 1 ? $tabActive = "" : $tabActive = "active" ?>

                    <div role="tabpanel" class="tab-pane <?php echo $tabActive ?>" id="<?php echo $list['year_id']; ?>">
                        <div class="heading">List of National and Regional Public Holidays | <b>Year <?php echo $list['year_id']; ?></b>
                            <div class="pull-right">
                                <?php if ($list['year_id'] >= date("Y")) { ?>
                                    <?php if ($list['isactive'] == 1) { ?>
                                        <a data-toggle="modal" href="<?php echo base_url(); ?>holiday/publish_holiday/<?php echo $list['holidayyear'] ?>">  
                                            <span class="text-white" title="Click here to Published"><i class="fa fa-remove"></i> </span>

                                        </a>
                                    <?php } else {
                                        ?>
                                        <a data-toggle="modal" href="<?php echo base_url(); ?>holiday/publish_holiday/<?php echo $list['holidayyear'] ?>">
                                            <span class="text-white" title="Published"><i class="fa fa-check"></i> </span>
                                        </a>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="tab-data user-back-slim ">

                            <p class="text-left">
                            <table class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th>Occasion</th>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <div class="pull-right"> 

                                </div>
                                <tbody>
                                    <?php // var_dump($resList); ?>
                                    <?php // var_dump($holiday_list); ?>

                                    <?php foreach ($holiday_list as $listData) { ?>
                                        <?php if ($list['year_id'] == $listData['year_id']) { ?>
                                            <tr id="deleteLeaveRow_<?php echo $listData['id'] ?>">
                                                <td><?php echo $listData['holidayname']; ?></td>
                                                <td><?php echo date("j F, Y", strtotime($listData['holidaydate'])); ?></td>
                                                <td><?php echo date("l", strtotime($listData['holidaydate'])); ?></td>
                                                <td>

                                                    <i title="delete" class="fa fa-trash text-ccc " onclick="deleteHolidayDiv(<?php echo $listData['id'] ?>);"></i>
                                                </td>
                                                <td>

                                                    <a data-toggle="modal" href="#edit-holiday-Modal-<?php echo $listData['id'] ?>">  
                                                        <i class="fa fa-pencil text-ccc "></i>
                                                    </a>
                                                </td>
                                            </tr>  
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            </p>
                        </div>
                    </div>
                    <?php
                }
                ?>


            </div>

        </div>
    </div>

</div>  
<?php $this->load->view('holiday/_holiday_modal'); ?>
<?php $this->load->view('holiday/_holiday_modal_edit'); ?>
<script>
    $(window).load(function () {
        /*for success message*/
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>
<script>
    function deleteHolidayDiv(dId) {

        if (confirm('Are you sure, you want to delete this?')) {
            $('#deleteLeaveRow_' + dId).remove();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>holiday/delete_holiday',
                data: {'delete_id': dId},
                success: function (data) {
                    showSuccess("Record deleted successfully");
                }
            });
            return false;
        }

    }
</script>
