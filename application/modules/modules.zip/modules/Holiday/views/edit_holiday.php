
<?php foreach ($holiday_list as $list) { ?>
    <div class="modal fade" id="edit-holiday-Modal-<?php echo $list['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Edit Holiday</h4>
                </div>
                <div class="modal-body">
                    <div class="office-info-1">
                        <?php echo form_open('holiday/edit_holiday/'.$list['id'], array('id' => 'form_addHoliday_id', 'class' => 'form_addHoliday_id')); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row">
                                    <input type="hidden" name="total_count" id="total_count" value="">
                                    <div class="col-sm-3">   

                                        <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>
                                        <?php
                                        echo form_input(array(
                                            'id' => 'holiday_name',
                                            'name' => 'holiday_name',
                                            'placeholder' => 'Day',
                                            'data-error' => '.errorTxtexp4',
                                            'value' => set_value('dob', $list['holidayname']),
                                        ));
                                        ?>


                                        <div class="errorTxtCom20"></div>
                                    </div>

                                    <div class="col-sm-3">
                                        <?php echo form_label(lang('holiday_date'), 'holiday_date', array('for' => 'holiday_date')); ?>
                                        <?php
                                        echo form_input(array(
                                            'id' => 'holiday_date',
                                            'name' => 'holiday_date',
                                            'class' => 'datepicker validate',
                                            'placeholder' => 'Date',
                                            'data-error' => '.errorTxtexp4',
                                            'value' => set_value('holidaydate', date("j F, Y", strtotime($list['holidaydate']))),
                                        ));
                                        ?>
                                        <div class="errorTxtCom21"></div>
                                    </div>

                                    <div class="col-sm-3">   

                                        <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>


                                        <?php
                                        $timestamp = strtotime($list['holidaydate']);
                                        $day = date('l', $timestamp);
                                        

                                        echo form_input(array(
                                            'id' => 'holiday_day',
                                            'name' => 'holiday_day',
                                            'placeholder' => 'Day',
                                            'data-error' => '.errorTxtexp4',
                                            'value' => set_value('day',$day),
                                        ));
                                        ?>


                                        <div class="errorTxtCom20"></div>
                                    </div>

                                    <div class="col-sm-3">
    <?php echo form_label(lang('holiday_des'), 'holiday_des', array('for' => 'holiday_des')); ?>

                                        <?php
                                        echo form_input(array(
                                            'id' => 'holiday_des',
                                            'name' => 'holiday_des',
                                            'placeholder' => 'Day',
                                            'data-error' => '.errorTxtexp4',
                                            'value' => set_value('dob', $list['description']),
                                        ));
                                        ?>

                                        <div class="errorTxtCom22"></div>
                                    </div>


                                </div>

                            </div>

                            <div class="col-sm-12 padding-top-10">
                                <input type="submit" class="btn btn-warning2 btn-sm" />
                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                            </div>
                        </div>
    <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
