<h1>Publish holiday</h1>
<table>
    <?php foreach ($publish_year as $list) { ?>

        <tr><td>
                <?php echo $list['year_id'] . '<br>'; ?>
            </td>
            <td>

                <?php echo ($list['total_cnt']); ?>
            </td>
            <td>
                <?php if ($list['isactive'] == 1) { ?>
                    <a data-toggle="modal" href="<?php echo base_url(); ?>holiday/publish_holiday/<?php echo $list['holidayyear'] ?>">  
                        <i class="fa fa-pencil-square-o text-info font-size-18"></i>
                    </a>
                <?php } else {
                    ?>
                    <a data-toggle="modal" href="<?php echo base_url(); ?>holiday/publish_holiday/<?php echo $list['holidayyear'] ?>">  
                    </a>
                </td>
            </tr>
        <?php } ?>
    <?php } ?>
</table>

<h1>Display holiday</h1>
<table>
    <?php foreach ($holiday_list as $list) { ?>
        <tr><td>
                <?php echo $list['holidayname'] . '<br>'; ?>
            </td>
            <td>

                <?php echo date("j F, Y", strtotime($list['holidaydate'])); ?>
            </td>
            <td>
                <?php
                $timestamp = strtotime($list['holidaydate']);
                $day = date('l', $timestamp);
                echo $day;
                ?>
            </td>
            <td>


                <a href="<?php echo base_url() ?>holiday/delete_holiday/<?php echo $list['id'] ?>"><i class="fa fa-remove text-danger font-size-18"></i></a>
            </td>
            <td>
                <!--<a href="<?php echo base_url() ?>hr/edit_holiday/<?php echo $list['id'] ?>">edit</a>-->

                <a data-toggle="modal" href="#edit-holiday-Modal-<?php echo $list['id'] ?>">  
                    <i class="fa fa-pencil-square-o text-info font-size-18"></i>
                </a>
            </td>

        </tr>


    <?php } ?>
</table>
<h1>Add holiday</h1>

<div class="office-info-1"> 
    <?php echo form_open('holiday/add_holiday', array('id' => 'form_addHoliday_id', 'class' => 'form_addHoliday_id')); ?>
    <div class="row">

        <div class="col-sm-6">
            <?php echo form_label(lang('holidayYear'), 'holidayYear', array('for' => 'holidayYear')); ?>
            <?php
            echo form_dropdown(array('id' => 'holidayYear', 'name' => 'holidayYear'), $holidayYear_list, array('class' => 'browser-default', 'data-error' => '.errorTxtOff2'));
            ?>
            <div class="input-field">
                <div class="errorTxtOff2"></div>
            </div> 
            <?php echo form_error('prefix_id'); ?>
        </div>

        <div class="col-sm-12">
            <div class="row">
                <input type="hidden" name="total_count" id="total_count" value="">
                <div class="col-sm-3">   

                    <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>
                    <input type="text" id="holiday_name" name="holiday_name" placeholder="Name">
                    <div class="errorTxtCom20"></div>
                </div>

                <div class="col-sm-3">
                    <?php echo form_label(lang('holiday_date'), 'holiday_date', array('for' => 'holiday_date')); ?>
                    <?php
                    echo form_input(array(
                        'id' => 'holiday_date',
                        'name' => 'holiday_date',
                        'class' => 'holiday_date',
                        'placeholder' => 'Date',
                        'data-error' => '.errorTxtexp4'
                    ));
                    ?>
                    <div class="errorTxtCom21"></div>
                </div>

                <div class="col-sm-3">   

                    <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>
                    <input type="text" id="holiday_day" name="holiday_day" placeholder="Day">
                    <div class="errorTxtCom20"></div>
                </div>

                <div class="col-sm-3">
                    <?php echo form_label(lang('holiday_des'), 'holiday_des', array('for' => 'holiday_des')); ?>
                    <input type="text" id="holiday_des" name="holiday_des" placeholder="Description" data-error="errorTxtCom22" />
                    <div class="errorTxtCom22"></div>
                </div>

                <div class="col-sm-3">
                    <p><label>Action</label></p>
                    <i class="fa fa-plus add-row"></i>
                    <i class="fa fa-minus delete-row"></i>

                </div>
            </div>

        </div>
        <div class="col-sm-12">
            <table class="table-responsive">
                <div class="row">
                    <thead>
                        <tr>
                    <div class="col-sm-2"><th>Select</th></div>
                    <div class="col-sm-3"><th>Title</th></div>
                    <div class="col-sm-3"><th>Date</th></div>
                    <div class="col-sm-3"><th>Day</th></div>
                    <div class="col-sm-4"><th>Description</th></div>
                    </tr>
                    </thead>

                    <div class="clearfix"></div>
                    <tbody>
                    </tbody>
                </div>
            </table>
        </div>
        <div class="col-sm-12 padding-top-10">
            <input type="submit" class="btn btn-warning2 btn-sm" />
            <button type="reset" class="btn btn-default btn-sm">Cancel</button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>
<?php $this->load->view('edit_holiday'); ?> 
<script type="text/javascript">

    function formatDate(date) {
        var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }
    $('input[name="holiday_date"]').change(function () {
        var cur_date = $(this).val();

        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var d = new Date(formatDate(cur_date));
        var dayName = days[d.getDay()];

        $('#holiday_day').val(dayName);

    });



    $(document).ready(function () {

        $(".holiday_date").on('click', function () {
            $('.holiday_date').pickadate({
                selectYears: true,
                selectMonths: true,
                //max: new Date()
            });

        });

        var i = 0;
        $(".add-row").on('click', function () {
            i++;

            $('#form_addHoliday_id').validate();
            if ($("#holiday_name").val() == '' && $("#holiday_date").val() == '' && $("#holiday_name").val() == '') {
                alert('Holiday fields can not be null!');
                return false;
            }
            var name = $("#holiday_name").val();
            var date = $("#holiday_date").val();
            var day = $("#holiday_day").val();
            var des = $("#holiday_des").val();
            $("#total_count").val(i);
            var markup = "<tr ><td><input type='checkbox' name='record'></td>\n\n\
                            <td><input type='hidden' name='holidayName-" + i + "' value='" + name + "'>" + name + "</td>\n\
                            <td><input type='hidden' name='holidayDate-" + i + "' value='" + date + "'>" + date + "</td>\n\n\
                            <td>" + day + "</td>\n\
                            <td><input type='hidden' name='holidayDes-" + i + "' value='" + des + "'>" + des + "</td></tr>";
            $("table tbody").append(markup);
            $("#holiday_name").val('');
            $("#holiday_date").val('');
            $("#holiday_day").val('');
            $("#holiday_des").val('');
        });
        // Find and remove selected table rows
        $(".delete-row").click(function () {
            if (i > 0)
                i--;
            $("table tbody").find('input[name="record"]').each(function () {
                if ($(this).is(":checked")) {
                    $("#total_count").val(i);
                    $(this).parents("tr").remove();
                }
            });
        });
    });
</script>
<!--<script src="http://code.jquery.com/jquery-migrate-1.4.1.js" type="text/javascript"></script>-->-->

<tr >
    <td>
        <input type='checkbox' name='record'>
    </td>
    <td><input type='hidden' name='holidayName-" + i + "' value='" + name + "'>" + name + "</td>\n\
    <td><input type='hidden' name='holidayDate-" + i + "' value='" + date + "'>" + date + "</td>\n\n\
    <td>" + day + "</td>\n\
    <td><input type='hidden' name='holidayDes-" + i + "' value='" + des + "'>" + des + "</td></tr>


