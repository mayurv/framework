<!-- modal start -->
<div class="modal fade" id="addholiday-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content ">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add Holiday</h4>
            </div>
            <div class="modal-body ">
                <div class="user-modal-slim">

                    <?php echo form_open('holiday/add_holiday', array('id' => 'form_addHoliday_id', 'class' => 'form_addHoliday_id')); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <?php echo form_label(lang('holidayYear'), 'holidayYear', array('for' => 'holidayYear')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'holidayYear', 'name' => 'holidayYear', 'class' => 'browser-default', 'data-error' => '.errorTxtOff2'), $holidayYear_list);
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff2"></div>
                            </div> 
                            <?php echo form_error('prefix_id'); ?>
                        </div>

                        <div class="clearfix"> </div>

                        <div class="col-sm-3">
                            <div class="input-field">
                                <input type="hidden" name="total_count" id="total_count" value="">
                                <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>
                                <input type="text" id="holiday_name" name="holiday_name" placeholder="Name">
                                <div class="errorTxtCom20"></div>
                                <label for="adholidaynm">Name*</label>

                                <div class="errorTxt111"></div>
                            </div>                                        
                        </div>
                        <div class="col-sm-3">
                            <div class="input-field">
                                <?php echo form_label(lang('holiday_date'), 'holiday_date', array('for' => 'holiday_date')); ?>
                                <?php
                                echo form_input(array(
                                    'id' => 'holiday_date',
                                    'name' => 'holiday_date',
                                    'class' => 'holiday_date',
                                    'placeholder' => 'Date',
                                    'data-error' => '.errorTxtexp4'
                                ));
                                ?>
                                <div class="errorTxtCom21"></div>
                            </div>                                       
                        </div>
                        <div class="col-sm-2">
                            <div class="input-field">
                                <?php echo form_label(lang('holiday_name'), 'holiday_name', array('for' => 'holiday_name')); ?>
                                <input type="text" id="holiday_day" name="holiday_day" placeholder="Day">
                                <div class="errorTxt114"></div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="input-field">
                                <?php echo form_label(lang('holiday_des'), 'holiday_des', array('for' => 'holiday_des')); ?>
                                <input type="text" id="holiday_des" name="holiday_des" placeholder="Description" data-error="errorTxtCom22" />
                                <div class="errorTxtCom22"></div>
                            </div>
                        </div>

                        <div class="col-sm-1 margin-top-20">

                            <i class="fa fa-plus add-row font-size-11"></i>
                        </div>
                        <div class="clearfix"></div>


                        <div class="col-sm-12">
                            <!-- bind data start here -->
                            <div class="holiday-dbind-bg">
                                <div class="row border-bottom margin-bottom-10 padding-bottom-10"> 

                                    <div class="col-sm-3"><p class="text-bold">Occasion</p></div>
                                    <div class="col-sm-3"><p class="text-bold">Date</p></div>
                                    <div class="col-sm-4"><p class="text-bold">Description</p></div>
                                    <div class="col-sm-2"><p class="text-bold"></p></div>
                                </div>
                                <div class="holidayList">

                                </div>


                            </div>
                            <!-- bind data end here -->
                        </div>

                        <div class="clearfix"></div>
                        <div class="col-sm-12 text-right padding-top-10">
                            <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                            <button type="submit" class="btn btn-warning2 btn-sm" id="subId" disabled="disabled">Submit</button>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>                                                    
        </div>
    </div>
</div>
<!-- modal end -->

<script type="text/javascript">
    var i = 0;

    function formatDate(date) {
        var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }
    $('input[name="holiday_date"]').change(function () {
        var cur_date = $(this).val();

        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var d = new Date(formatDate(cur_date));
        var dayName = days[d.getDay()];

        $('#holiday_day').val(dayName);

    });



    $(document).ready(function () {

        $(".holiday_date").on('click', function () {
            $('.holiday_date').pickadate({
                selectYears: true,
                selectMonths: true,
                //max: new Date()
            });

        });


        $(".add-row").on('click', function () {
            i++;

            $('#form_addHoliday_id').validate();
            if ($("#holiday_name").val() == '' && $("#holiday_date").val() == '' && $("#holiday_name").val() == '') {
                alert('Holiday fields can not be null!');
                return false;
            }
            var name = $("#holiday_name").val();
            var date = $("#holiday_date").val();
            var day = $("#holiday_day").val();
            var des = $("#holiday_des").val();
            $("#total_count").val(i);
            var markup = "<div class='margin-bottom-5 deleteHoliday_" + i + "'><div class='row'><div class='col-sm-3'><p><input type='hidden' name='holidayName-" + i + "' value='" + name + "'>" + name + "</p></div>\n\
                          <div class='col-sm-3'><p><input type='hidden' name='holidayDate-" + i + "' value='" + date + "'>" + date + "</p></div>\n\
                          <div class='col-sm-4'><p><input type='hidden' name='holidayDes-" + i + "' value='" + des + "'>" + des + "</p></div>\n\
                          <div class='col-sm-2' ><i class='fa fa-trash text-ccc' onclick=\"deleteHoliday('" + i + "');\"></i></div></div></div>";
            $(".holidayList").append(markup);
            $("#holiday_name").val('');
            $("#holiday_date").val('');
            $("#holiday_day").val('');
            $("#holiday_des").val('');
            $("#subId").prop('disabled', false);

        });
        // Find and remove selected table rows
        //deleteHoliday_


    });
</script>
<script>
    function deleteHoliday(dId) {
        alert(dId);
        if (i > 0)
            i--;
        $("div").remove(".deleteHoliday_" + dId);
    }
</script>