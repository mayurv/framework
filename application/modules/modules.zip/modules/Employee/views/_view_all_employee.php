<?php // var_dump($department_list);die;                 ?>
<style>
    .toggle-hide{  float: left;
                   position: absolute;
                   top: 10px;
                   margin-left: 0px;}
    </style>
    <div class="">
        <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
        <?php $i = 1; ?>
</div>
<div id="loader-bg" style="display: none">
    <div class="loader-txt margin-bottom-10"><h3 class="text-white">We Make IT simple</h3></div>
    <div class="loader-animation" style="display: block">&#9632;&#9632;&#9632;&#9632;&#9632;</div>
</div>

<!-- left side col-sm-9 here -->
<div class="row">


    <div class="col-sm-12">
        <div class="main-bg all-padding-15">

            <!-- add button -->
            <div class="row">
                <div class="col-sm-2">
                    <div class="input-field all-margin">
                        <input class="no-border" type="text" style="float: left" id="search_emp_val" name="search_emp_val" placeholder="Search">
                        <div class="search-i-bg-emp"> 
                            <i class="fa fa-search text-primary"></i>
                        </div>
                        

                    </div>

                </div>
                
               
                <div class="col-sm-8">  
                    
                    <table class="table table-dept-bg text-center">
                        <tr>
                            <td>
                                <div>
                                    <i class="fa fa-filter toggle-hide" title="Click for Filters"> </i>
                                </div>
                            </td>
                            <td class="hideFilter " style="display: none" >
                                <span class="btn btn-xs btn-default handle text-bold" title="All" onclick="return filterbyDept('all')">All
                                    | <span class="text-light-gray">
                                        <?php echo count($employee); ?>
                                    </span>
                                </span>
                            </td>
                            <?php foreach ($department_list as $deptData) { ?>
                                <?php $count = 0; ?>
                                <td class="hideFilter" style="display: none">
                                    <span class="btn btn-xs btn-default handle " title="Click to Filter | <?php echo $deptData ?>" onclick="return filterbyDept('<?php echo $deptData ?>')">
                                        <?php echo $deptData ?>
                                        <?php foreach ($employee as $result) { ?>                                            
                                            <?php if ($result->department_name == $deptData) { ?>
                                                <?php $count = $count + 1; ?>
                                            <?php } ?>     
                                        <?php } ?> 
                                        | <span class="text-light-gray">
                                            <?php echo $count; ?>
                                        </span>
                                    </span>
                                </td>
                            <?php } ?>                        
                        </tr>
                    </table>
                </div>
                <div class="col-sm-2 pull-right">
                    <div class="pull-right">
                        <button class="btn btn-default btn-sm" data-toggle="modal" href="#addModal-1"><i class="fa fa-plus-circle"></i> Add Associate</button>
                       
                    </div>
                </div>

            </div>
            <!-- add button -->
            <?php $count = 0; ?>
            <!-- search button -->
            <div class="row"> 


            </div>
            <!-- search button -->

            <?php // var_dump($personal_detail);die;?>
            <!-- card display -->

            <div class="row">
                <?php $this->load->view('employee/_view_card_display'); ?>


                <div class="clearfix"> </div>

            </div>
            <!-- card display -->


        </div>          
    </div>
    <!-- left side col-sm-9 here -->

    <!-- right side col-sm-3 here -->
    <!--    <div class="col-sm-3">
            <div class="main-bg margin-bottom-15">
                 <div class="event-heading">Event</div> 
                <div class="r3_notification db_box"> 
                    <h3 class="text-primary">Event</h3>                                  
                    <ul class="notification-widget">
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>  
    
            <div class="main-bg">
                 <div class="article-heading">Article</div> 
                <div class="r3_notification db_box">      
                    <h3 class="text-primary">Article</h3>   
                    <ul class="notification-widget">
    
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>                                                                                
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>                                            
                    </ul>
                </div>
            </div>  
    
        </div>-->
    <!-- right side col-sm-3 here -->
</div>

<!-- modal start -->
<div class="modal fade" id="addModal-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">User Registration</h4>
            </div>
            <div class="modal-body">
                <?php echo form_open('employee/addofficial/', array('id' => 'form_communication_id')); ?>
                <input name="form_action" type="hidden"  value="1"/>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="p-title margin-bottom-20">Mode of Employment</div>
                    </div>
                    <input type="hidden" id="directid" name="direct"  value="1"/>
                    <div class="col-sm-6">
                        <input name="group1" type="radio" id="test1" value="1" checked=""/>

                        <label for="test1">Direct</label>
                    </div> 
                    <div class="col-sm-6">
                        <input name="group1" type="radio" id="test2" value="0"/>
                        <label for="test2">Interview</label>
                    </div>                                                       

                    <div class="clearfix"> </div>
                    <div id="dropId" style="display: none;">
                        <?php // var_dump($candidates);die;   ?>
                        <div class="col-sm-12">
                            <?php echo form_label(lang('candidate_id'), 'candidate_id', array('for' => 'candidate_id')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'candidate_id', 'name' => 'candidate_id', 'class' => 'browser-default', 'data-error' => '.errorTxt12', 'required' => 'required'), $candidates);
                            ?>
                            <div class="input-field">
                                <div class="errorTxt12"></div>
                            </div>
                            <?php echo form_error('skills_id'); ?>  
                        </div>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-sm-12 padding-top-10 text-right">
                        <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                        <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>

        </div>
    </div>
</div>
<!-- modal end -->

<script>
    $(document).ready(function () {
        $("#directid").val('direct');
        $("#test2").click(function () {
            $("#directid").val('0');
            $("#test1").val('0');
            $("#test2").val('1');
            $("#dropId").show();
        });
        $("#test1").click(function () {

            $("#directid").val('direct');
            $("#test1").val('1');
            $("#test2").val('0');
            $("#dropId").hide();
        });

        $("#check_status").click(function () {

            var isChecked = $("#check_status").val();
            if (isChecked == 0) {
                $(".curr_add_id").hide();
                $("#check_status").val('1');
            } else {
                $(".curr_add_id").show();
                $("#check_status").val('0')
            }

        });
    });
</script>
<style>
    .main-bg-blur{z-index:1;opacity:0.4;filter: alpha(opacity = 50);}
</style>
<script>
    $(document).ready(function () {
        $(".toggle-hide").click(function () {
            $('.hideFilter').toggle();

        });


    });

</script>

<script>
    (function () {

        var emp_url = '<?php echo base_url(); ?>search/searchEmployee';

        $("#search_emp_val").keypress(function (event) {

            var emp_search = $('#search_emp_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('#loader-bg').show();
                $('.loader-animation').show();
                search_employee(emp_search, emp_url);
            }
        });
        $(".search-i-bg-emp").click(function () {

            $('#loader-bg').show();
            $('.loader-animation').show();
//            $('.loader').show();
            var emp_search = $('#search_emp_val').val();
//            $('.card_display').addClass('overlay');
            search_employee(emp_search, emp_url);
        });



        $(".id-filer").click(function () {
            $('.filter-cl').toggle();

        });



        function search_employee(search_key, url) {
            $.ajax({
                type: "POST",
                url: url,
                data: {'search_key': search_key},
                success: function (data) {
                    $('#loader-bg').hide();
                    $('.loader-animation').hide();
//                    $('.loader').hide();
//                    $('.card_display').removeClass('overlay');
                    var parsed = $.parseJSON(data);
                    $('.card_display').html('');
                    if (parsed.search_list == null) {
                        $('.card_display').html('<div class="middle-box text-center animated fadeInDown"><h1>404 no data available</h1><i class="text-orange fa fa-exclamation-triangle fa-5x"></i>   <h3 class="font-bold">Sorry, but we couldnt find the content you were looking for.</h3><div class="error-desc"></div></div>');
                    } else {
                        $('.card_display').html(parsed.search_list);
                    }
                }
            });
        }
    }
    )();
    var emp_url = '<?php echo base_url(); ?>search/searchEmployee';
    function filterbyDept(filter) {
        search_employee(filter, emp_url);
    }
    function search_employee(search_key, url) {
        $('#loader-bg').show();
        $('.loader-animation').show();
        $.ajax({
            type: "POST",
            url: url,
            data: {'search_key': search_key,'search_type':'search_type'},
            success: function (data) {
                $('#loader-bg').hide();
                $('.loader-animation').hide();
//                $('.loader').hide();
//                $('.card_display').removeClass('overlay');
                var parsed = $.parseJSON(data);
                $('.card_display').html('');
                if (parsed.search_list == null) {
                    $('.card_display').html('<div class="middle-box text-center animated fadeInDown"><h1>404 no data available</h1><i class="text-orange fa fa-exclamation-triangle fa-5x"></i>   <h3 class="font-bold">Sorry, but we couldnt find the content you were looking for.</h3>    <div class="error-desc">     </div></div>');
                } else {
                    $('.card_display').html(parsed.search_list);
                }
            }
        });
    }
</script>

