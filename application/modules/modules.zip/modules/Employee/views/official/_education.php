<!-- Education modal start -->
<div class="modal fade" id="education-det-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Education</h4>
            </div>
            <div class="loader" style="display: none"></div>
            <div class="modal-body">
                <div class="user-normal-slim">                                                             
                    <?php echo form_open_multipart('employee/education/add/' . $user_summary['user_id'], array('id' => 'form_validate_education_id', 'class' => 'form_validate_education_id'));
                    ?>
                    <!-- 1st row start here -->
                    <div class="row">
                        <div class="col-sm-6">
                            <?php echo form_label(lang('education_level'), 'education_level', array('for' => 'education_level')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'education_level', 'name' => 'education_level', 'class' => 'browser-default', 'data-error' => '.errorTxtedu1'), $education_level);
                            ?>	
                            <div class="input-field">
                                <div class="errorTxtedu1"></div>
                            </div> 
                            <?php echo form_error('education_level'); ?>
                        </div> 

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('institution_name'), 'institute_name', array('for' => 'institute_name')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'institute_name',
                                    'name' => 'institute_name',
                                    'placeholder' => 'Board/ University',
                                    'data-error' => '.errorTxtedu2'
                                ));
                                ?>
                                <div class="errorTxtedu2"></div>
                                <?php echo form_error('institute_name'); ?>
                            </div> 
                        </div>

                        <div class="clearfix"></div> 

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('course_name'), 'course_name', array('for' => 'course_name')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'course_name',
                                    'name' => 'course_name',
                                    'placeholder' => 'Course Title',
                                    'data-error' => '.errorTxtedu3'
                                ));
                                ?>
                                <div class="errorTxtedu3"></div>
                                <?php echo form_error('course_name'); ?>
                            </div>
                        </div>  

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('grade'), 'grade', array('for' => 'grade')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'grade',
                                    'name' => 'grade',
                                    'placeholder' => 'Grade',
                                    'data-error' => '.errorTxtedu4'
                                ));
                                ?>
                                <div class="errorTxtedu4"></div>
                                <?php echo form_error('grade'); ?>
                            </div> 
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('from_date'), 'from_date', array('for' => 'from_date')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'from_date_ed',
                                    'name' => 'from_date',
                                    'class' => 'from_date_ed',
                                    'placeholder' => 'From Date',
                                    'data-error' => '.errorTxtedu5'
                                ));
                                ?>
                                <div class="errorTxtedu5"></div>
                                <?php echo form_error('from_date'); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('to_date'), 'to_date', array('for' => 'to_date')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'to_date_ed',
                                    'name' => 'to_date',
                                    'class' => 'to_date_ed',
                                    'placeholder' => 'To Date',
                                    'data-error' => '.errorTxtedu6'
                                ));
                                ?>
                                <div class="errorTxtedu6"></div>
                                <?php echo form_error('to_date'); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('percentage'), 'percentage', array('for' => 'percentage')); ?> 
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'percentage',
                                    'name' => 'percentage',
                                    'placeholder' => 'Percentage',
                                    'data-error' => '.errorTxtedu7'
                                ));
                                ?>
                                <div class="errorTxtedu7"></div>
                                <?php echo form_error('percentage'); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('remark'), 'remark', array('for' => 'remark')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'remark',
                                    'name' => 'remark',
                                    'placeholder' => 'Remark',
                                    'data-error' => '.errorTxtedu8'
                                ));
                                ?>
                                <div class="errorTxtedu8"></div>
                                <?php echo form_error('remark'); ?>

                            </div> 
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <div class="file-field input-field">
                                <div class="btn btn-default btn-sm margin-top-10">Browse
                                    <?php
                                    echo form_input(array(
                                        'type' => 'file',
                                        'id' => 'education_doc',
                                        'name' => 'education_doc',
                                        'class' => 'form-control',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                        'data-error' => '.errorTxtedu9',
                                        'placeholder' => 'type (jpeg, jpg, png)',
                                    ));
                                    ?>
                                </div>


                                <div class="file-path-wrapper">
                                    <?php
                                    echo form_input(array(
                                        'id' => 'education_doc',
                                        'name' => 'education_doc',
                                        'class' => 'file-path',
                                        'placeholder' => '( pdf, doc, jpeg, jpg)',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                    ));
                                    ?>
                                </div>
                                <div class="errorTxtedu9"></div>
                            </div>      
                        </div>

                        <div class="clearfix"></div>
                        <input type="hidden" value="" id="ajaxPostId" name="ajaxPostId">
                        <div class="col-sm-12 padding-top-10 text-right">
                            <!--<button type="submit" class="btn btn-warning2 btn-sm">Submit</button>-->
                            <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                            <button type="button" class="btn btn-warning2 btn-sm" id="submit_edu">Submit & Add new</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>
                    <!-- 1st row end here -->
                    <?php echo form_close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Education modal end -->

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {
        $('.from_date_ed').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });

        $(".to_date_ed").click(function () {

            var date = new Date($('#from_date_ed').val());

//            $(".from_date_md").removeClass('datepicker');
            var fromDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();

            $('.to_date_ed').pickadate({
                min: new Date(fromDate),
                selectYears: true,
                selectMonths: true,
                max: new Date()
            });
        });

    });
</script>

<!--Submit & Add new-->

<!--Upload Education Submit & Add new-->
<script>
    $(document).ready(function () {
        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>employee/education/add/' +<?php echo $user_summary['user_id'] ?>, // override for form's 'action' attribute
            type: 'post', // 'get' or 'post', override for form's 'method' attribute 
            clearForm: true,
            // clear all form fields after successful submit 
//            resetForm: true, // reset the form after successful submit 

        };

        $('#submit_edu').click(function () {

            var validateReuslt = $("#form_validate_education_id").valid();
            $("#ajaxPostId").val('ajaxPost');

            if ($("#form_validate_education_id").valid())
                $("#form_validate_education_id").ajaxSubmit(options);
            else
                return false;

        });
        // pre-submit callback 
        function showRequest(formData, jqForm, options) {

            $('.modal-body').addClass('overlay');
            $('.loader').show();
            //response
            return true;
        }
        // post-submit callback 
        function showResponse(responseText, statusText, xhr, $form) {

            $('.loader').hide();
            $('.modal-body').removeClass('overlay');

            //response  
            $("div").removeClass('error');
            $("#education_level").val($("#education_level option:first").val());

            var parsed = $.parseJSON(responseText);
            $('.education_display').html(parsed.education_cards);

            showSuccess("Record Addedd successfully");
            return true;
        }





    });
</script>

<script>

    $(document).ready(function () {
        $(".close").on('click', function () {
//            $("#form_validate_education_id")[0].reset();
//            $("#form").trigger('reset');
        });




    });
</script>