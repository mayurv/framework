<!--wizard javascript end here --> 
<div class="col-sm-12">
    <div class="main-bg padding-lt-rt-top">

        <!-- Smart Wizard -->
        <div id="wizard" class="swMain">
            <!--<span class="connecting-line"></span>-->
            <!--<span class="connecting-line-slim"></span>-->
            <input type="hidden" id="last_id" name="last_id" value="">
            <ul>
                <li>
                    <a href="#step-1">
                        &nbsp;                                                

                        <div class="sw-lbl-bottom">Official </div>
                    </a>
                </li>
                <li>
                    <a href="#step-2">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Personal </div>
                    </a>
                </li> 
                <li>
                    <a href="#step-5">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Experience </div>
                    </a>
                </li>
                <li>
                    <a href="#step-9">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Skills </div>
                    </a>
                </li>
                <li>
                    <a href="#step-6">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Education </div>
                    </a>
                </li>
                <li>
                    <a href="#step-7">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Certification </div>
                    </a>
                </li>
                <li>
                    <a href="#step-8">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Visa</div>
                    </a>
                </li>  
                <li>
                    <a href="#step-3">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Documents </div>
                    </a>
                </li>
                <li>
                    <a href="#step-4">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Job History </div>
                    </a>
                </li>
            </ul>

            <!-- official information -->
           
            <div id="step-1"> 
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Official Information</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#office-info-Modal-2" title="Edit">  
                                            <i class="fa fa-pencil text-ccc "></i>
                                        </a>
                                       
                                    </div>
                                </div>
                                <div class="panel-body all-padding-0">

                                    <?php $this->load->view('official/_view_official'); ?>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- official information -->

            <div id="step-2">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">
                            <!--  panel start here -->
                            <div class="panel panel-default">

                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Personal & Contact Information</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#personal-info-Modal-2" title="Add"> 
                                            <?php if ($personal_detail == NULL) { ?>
                                                <i class="fa fa-plus text-ccc" title="Add"></i>
                                            <?php } else { ?>
                                                <i class="fa fa-pencil text-ccc" title="Edit"></i>

                                            <?php } ?>
                                        </a>

                                   
                                    </div>
                                </div>

                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">  
                                        <?php if ($personal_detail == NULL) { ?>
                                            <?php $this->load->view('official/_no_data_found'); ?>
                                        <?php } else { ?>
                                            <?php $this->load->view('official/_view_communication'); ?> 
                                        <?php } ?>

                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>

                </div>

            </div>     



            <?php if (isset($jobhistroy_details)) { ?>
                <div id="step-4">
                    <div class="row"> 
                        <div class="col-sm-12">
                            <div class="w-panel-bg">

                                <!--panel start here--> 
                                <div class="panel panel-default">
                                    <div class="panel-heading all-padding-10">
                                        <div class="p-title">Job History</div>
                                    </div>
                                    <div class="panel-body all-padding-0">
                                        <div class="user-back-slim">

                                            <!-- search button -->
                                            <div class="row"> 
                                                <div class="col-sm-12 margin-bottom-10">
                                                    <form>

                                                        <div class="input-field all-margin">
                                                            <input type="text" class="search-input no-border" id="search_id" name="search_id" placeholder="Search">
                                                            <div class="search-i-bg" id="id_search"> 
                                                                <i class="fa fa-search text-gray"></i>
                                                            </div>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div>
                                            <!-- search button -->

                                            <!-- card document display -->
                                            <div class="row">
                                                <?php $this->load->view('_view_jobhistory'); ?>
                                            </div>
                                            <!-- card document display -->
                                        </div>
                                    </div>
                                </div>
                                <!--panel end here--> 
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>

            <div id="step-5">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Work Experience</div>
                                    </div>
                                    <div class="pull-right"> 


                                        <a data-toggle="modal"  href="#work-exp-Modal-2" title="Add"> 
                                            <i class="fa fa-plus text-ccc"></i>                                         
                                        </a>
                                        
                                    </div>
                                </div>                                                            



                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">

                                        <!-- search button -->
                                        <div class="row"> 
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_exp_val" name="search_exp_val" placeholder="Search">
                                                    <div class="search-i-bg-exp"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- search button -->

                                        <!-- card document display -->
                                        <div class="row">
                                            <?php $this->load->view('_view_experience'); ?>

                                        </div>
                                        <!-- card document display -->
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->

                        </div>
                    </div>
                </div>   

            </div>

            <div id="step-9">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">
                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Skills</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal"  href="#skill-exp-Modal-2" title="Add"> 
                                            <i class="fa fa-plus text-ccc"></i>                                         
                                        </a>
                                    </div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">  
                                        <!-- search button -->
                                        <div class="row">
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_skills_val" name="search_skills_val" placeholder="Search">
                                                    <div class="search-i-bg-skills"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- search button -->
                                        <div class="col-sm-12">
                                            <div class="row">
                                                <?php $this->load->view('_view_skills'); ?>
                                            </div>
                                        </div>
                                        <!-- card document display -->
                                    </div>                                                                
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>                                               
            </div>  

            <div id="step-6">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">                      
                                    <div class="pull-left"> 
                                        <div class="p-title">Education</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#education-det-Modal-2" title="Add">
                                            <i class="fa fa-plus text-ccc"></i>                                         
                                        </a>
                                     
                                    </div>
                                </div>

                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">

                                        <!-- search button -->
                                        <div class="row">
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_edu_val" name="search_edu_val" placeholder="Search">
                                                    <div class="search-i-bg-edu"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- search button -->

                                        <!-- card education display -->
                                        <div class="row">
                                            <?php $this->load->view('_view_education'); ?>
                                        </div>
                                        <!-- card education display -->
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>

            </div>

            <div id="step-7">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Certification</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#certification-det-Modal-2" title="Add"> 
                                            <i class="fa fa-plus text-ccc"></i>                                         
                                        </a>
                                      
                                    </div>
                                </div>

                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">

                                        <!-- search button -->
                                        <div class="row"> 
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_cert_val" name="search_cert_val" placeholder="Search">
                                                    <div class="search-i-bg-cert"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- search button -->

                                        <!-- card _view_certification display -->
                                        <div class="row">
                                            <?php $this->load->view('_view_certification'); ?>
                                        </div>
                                        <!-- card _view_certification display -->
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>                                                                                                                
            </div>

            <div id="step-8">

                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">                      
                                    <div class="pull-left"> 
                                        <div class="p-title">Visa</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#passport-visa-Modal-2" title="Add"> 
                                            <i class="fa fa-plus text-ccc"></i>                                         
                                        </a>                                     
                                    </div>

                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">

                                        <!-- search button -->
                                        <div class="row"> 
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_visa_val" name="search_visa_val" placeholder="Search">
                                                    <div class="search-i-bg-visa"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- search button -->

                                        <!-- card _view_visa display -->
                                        <div class="row">
                                            <?php $this->load->view('_view_visa'); ?>
                                        </div>
                                        <!-- card _view_visa display -->
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>                                                                    
            </div>

            <div id="step-3">

                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">

                                <div class="panel-heading all-padding-10">
                                    <div class="pull-left"> 
                                        <div class="p-title">Document</div>
                                    </div>
                                    <div class="pull-right"> 
                                        <a data-toggle="modal" href="#document-Modal-2" title="Add"> 
                                            <i class="fa fa-plus text-default"></i>                                         
                                        </a>
                                     
                                    </div>
                                </div>

                                <div class="panel-body all-padding-0">
                                    <div class="user-back-slim">

                                        <!-- search button -->
<!--                                        <div class="row"> 
                                            <div class="col-sm-8 margin-bottom-10">
                                                <div class="input-field all-margin">
                                                    <input type="text" class="search-input search_data no-border" id="search_doc_val" name="search_doc_val" placeholder="Search">
                                                    <div class="search-i-bg-doc"> 
                                                        <i class="fa fa-search text-gray"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>-->
                                        

                                        <!-- card document display -->

                                        <div class="col-sm-12">
                                            <div class="row">
                                                <?php $this->load->view('_view_document') ?>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- card document display -->



                                </div>
                            </div>
                        </div>
                        <!--  panel end here -->
                    </div>
                </div>
            </div>


        </div>


    </div>
    <!-- End SmartWizard Content -->    
</div>          

<!--All Modal here-->
<?php $this->load->view('_official_modal'); ?>  
<?php $this->load->view('_document'); ?>  
<?php $this->load->view('_communication'); ?>   
<?php $this->load->view('_experience'); ?>  
<?php $this->load->view('_skills'); ?>  
<?php $this->load->view('_certification'); ?>  
<?php $this->load->view('_education'); ?>  
<?php $this->load->view('_visa'); ?>  
<!--All Modal here-->
<!--View Edit Modal-->
<?php // $this->load->view('_view_document_modal'); ?>
<?php $this->load->view('_view_experience_modal'); ?>
<?php $this->load->view('_view_skills_modal'); ?>
<?php $this->load->view('_view_education_modal'); ?>
<?php $this->load->view('_view_skills_modal'); ?>
<?php $this->load->view('_view_certification_modal'); ?>
<?php $this->load->view('_view_visa_modal'); ?>

<!--Project Allocation-->
<?php $this->load->view('_projectallocation_modal') ?>
<?php $this->load->view('_editprojectallocation_modal') ?>



<script type="text/javascript" src="<?php echo base_url(); ?>plugins/jquery-donut-chart/js/jquery.circliful.min.js"></script>
<script type="text/javascript">
//    var total_leave = <?php // echo $leaves['emp_leave_limit'] ? $leaves['emp_leave_limit']: '';                                        ?>;
//    var used_leaves = <?php // echo $leaves['used_leaves'] ? $leaves['used_leaves'] : '';                                        ?>;
//    var percentage = (used_leaves / total_leave) * 100;
//    if (used_leaves == 0)
    percentage = 100;
    $("#chartdonut").circliful({
        animation: 1,
        animationStep: 5,
        foregroundBorderWidth: 15,
        backgroundBorderWidth: 15,
        percent: percentage,
        textSize: 28,
        textStyle: 'font-size: 12px;',
        textColor: '#666',
        multiPercentage: 1,
        percentages: [10, 20, 30]
    });</script>

<script>
    $('#wizard ul li a').click(function () {



        var last_selected = $('#last_id').val();
        //        $('ul.anchor li a').removeClass('disabled').addClass('active-gray');
//        $('ul.anchor li a').attr("isDone", 1);
        if ($(this).attr('href') != '#step-4') {
            $("a[href$='" + last_selected + "']").removeClass('selected').addClass('done');
            var id = " " + last_selected + " ";
        }
        if (last_selected == $(this).attr('href') && $(this).attr('href') != '#step-4') {
            //            alert("if"+last_selected);
            $("a[href$='" + last_selected + "']").removeClass('done');
            $("a[href$='" + last_selected + "']").addClass('selected');
        }
        if (last_selected != $(this).attr('href') && $(this).attr('href') != '#step-4') {
            //            alert("else"+last_selected);
            $(id).hide();
        }
        if ($(this).attr('href') != '#step-4')
            $('#last_id').val($(this).attr('href'));

        if ($(this).attr('href') == '#step-4') {
            $("a[href$='#step-4']").addClass('disabled');
            $('ul.anchor li a[href$="#step-4"]').attr("isDone", 0);
            $('ul.anchor li a[href$="#step-4"]').attr("rel", 1);
        }



    });
    $(window).load(function () {

        $("div").remove(".actionBar");
        $('.anniversary').pickadate({
            max: new Date()
        });
        /*for success message*/
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>

        $('ul.anchor li a').removeClass('disabled').addClass('active-gray');
        $('ul.anchor li a').attr("isDone", 1);
        var url = window.location.href;
        tabIdUrl = "step-1";
        var urlParam = url.split("/")[4];
        //        alert(urlParam);
        if (url.split("/")[4]) {
            tabNameUrl = url.split("/")[4];
            $("a[href$='step-1']").removeClass('selected');
            $("a[href$='step-1']").addClass('done');
            if (tabNameUrl == "contact")
                tabIdUrl = "step-2";
            if (tabNameUrl == "document")
                tabIdUrl = "step-3";
            if (tabNameUrl == "holidays")
                tabIdUrl = "step-4";
            if (tabNameUrl == "experience")
                tabIdUrl = "step-5";
            if (tabNameUrl == "education")
                tabIdUrl = "step-6";
            if (tabNameUrl == "certification")
                tabIdUrl = "step-7";
            if (tabNameUrl == "visa")
                tabIdUrl = "step-8";
            if (tabNameUrl == "skills")
                tabIdUrl = "step-9";
            $('#last_id').val("#" + tabIdUrl);
            $('#' + tabIdUrl).show();
<?php if (isset($tabId)) { ?>
    <?php foreach ($tabId as $res => $val) { ?>

                    //                    $('ul.anchor li a').removeClass('disabled').addClass('active-gray');
                    //                    $('ul.anchor li a').attr("isDone", 1);
                    $("a[href$='<?php echo $val; ?>']").removeClass('disabled').addClass('active-gray');
                    $("a[href$='<?php echo $val; ?>']").removeClass('selected');
                    $('ul.anchor li a').attr("isDone", 1);
                    $("a[href$='<?php echo $val; ?>']").attr("isDone", 1);
                    $("a[href$='<?php echo $val; ?>']").addClass('done');
    <?php } ?>
<?php } ?>

            $("a[href$='" + tabIdUrl + "']").attr("isDone", 1);
            $("a[href$='" + tabIdUrl + "']").removeClass('done');
            $("a[href$='" + tabIdUrl + "']").addClass('active-gray selected');
            $("a[href$='step-4']").addClass('disabled');
//            $("a[href$='step-4']").attr("disabled", TRUE);
        }
        else {

            $('ul.anchor li a').removeClass('disabled').addClass('done');
            $('ul.anchor li a').attr("isDone", 1);
            $("a[href$='step-1']").addClass('selected');
        }
    });
    function activeTab() {

    }
</script>
<!--Search Feature on Employee Module-->
<script type="text/javascript">
    (function () {

        //Global Variable Declaration
        var associate_id = '<?php echo $user_summary['user_id'] ?>';
        var skill_url = '<?php echo base_url(); ?>search/searchSkills';
        var doc_url = '<?php echo base_url(); ?>search/searchDoc';
        var exp_url = '<?php echo base_url(); ?>search/searchExperiance';
        var edu_url = '<?php echo base_url(); ?>search/searchEducation';
        var cert_url = '<?php echo base_url(); ?>search/searchCertification';
        var visa_url = '<?php echo base_url(); ?>search/searchVisa';

        // Search Experiance 
        $("#search_exp_val").keypress(function (event) {
            var exp_search = $('#search_exp_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.exp_display').addClass('overlay');
                search_experiance(exp_search, associate_id, exp_url);
            }
        });
        $(".search-i-bg-exp").click(function () {
            var exp_search = $('#search_exp_val').val();
            $('.exp_display').addClass('overlay');
            search_experiance(exp_search, associate_id, exp_url);
        });

        // Search Skills    
        $("#search_skills_val").keypress(function (event) {
            var skill_search = $('#search_skills_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.skill_display').addClass('overlay');
                search_skill(skill_search, associate_id, skill_url);
            }
        });
        $(".search-i-bg-skills").click(function () {
            var skill_search = $('#search_skills_val').val();
            $('.skill_display').addClass('overlay');
            search_skill(skill_search, associate_id, skill_url);
        });
        // End Search Skills


        // Search Education 
        $("#search_edu_val").keypress(function (event) {
            var edu_search = $('#search_edu_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.education_display').addClass('overlay');
                search_education(edu_search, associate_id, edu_url);
            }
        });
        $(".search-i-bg-edu").click(function () {
            var edu_search = $('#search_edu_val').val();
            $('.education_display').addClass('overlay');
            search_education(edu_search, associate_id, edu_url);
        });

        // Search Certification 
        $("#search_cert_val").keypress(function (event) {
            var cert_search = $('#search_cert_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.certification_display').addClass('overlay');
                search_certification(cert_search, associate_id, cert_url);
            }
        });
        $(".search-i-bg-cert").click(function () {
            var cert_search = $('#search_cert_val').val();
            $('.certification_display').addClass('overlay');
            search_certification(cert_search, associate_id, cert_url);
        });

        // Search Visa 
        $("#search_visa_val").keypress(function (event) {
            var visa_search = $('#search_visa_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.visa_display').addClass('overlay');
                search_visa(visa_search, associate_id, visa_url);
            }
        });
        $(".search-i-bg-visa").click(function () {
            var visa_search = $('#search_visa_val').val();
            $('.visa_display').addClass('overlay');
            search_visa(visa_search, associate_id, visa_url);
        });


        // Search Document     
        $("#search_doc_val").keypress(function (event) {
            var doc_search = $('#search_doc_val').val();
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if (keycode == '13') {
                $('.doc_display').addClass('overlay');
                search_doc(doc_search, associate_id, doc_url);
            }
        });
        $(".search-i-bg-doc").click(function () {
            var doc_search = $('#search_doc_val').val();
            $('.doc_display').addClass('overlay');
            search_doc(doc_search, associate_id, doc_url);
        });
        // End Search Document
    }
    )();
</script>
<!--End Search Feature on Employee Module-->

<script src="<?php echo base_url('assets/js/search.js'); ?>" type="text/javascript"></script> 


