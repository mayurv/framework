<!-- Experience Details -->
<?php if (isset($certification_details)) { ?>
    <?php foreach ($certification_details as $result) { ?>
        <div class="modal fade" id="certification-det-Modal-2-v-<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Certification</h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-modal-slim">
                            <?php
                            echo form_open_multipart('employee/certification/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_validate_certification_id_' . $result['id'], 'class' => 'form_validate_certification_id_' . $result['id']));
                            ?>                           
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <!-- 1st row start here -->
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('course_name'), 'course_name', array('for' => 'course_name')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'course_name',
                                            'name' => 'course_name',
                                            'class' => 'validate',
                                            'placeholder' => 'Course Name',
                                            'data-error' => '.errorTxtcert1',
                                            'value' => set_value('course_name', $result['course_name']),
                                        ));
                                        ?>
                                        <div class="errorTxtcert1"></div>
                                        <?php echo form_error('course_name'); ?>
                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('description'), 'description', array('for' => 'description')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'description',
                                            'name' => 'description',
                                            'class' => 'validate',
                                            'value' => set_value('description', $result['description']),
                                            'placeholder' => 'Description',
                                            'data-error' => '.errorTxtcert2'
                                        ));
                                        ?>
                                        <div class="errorTxtcert2"></div>
                                        <?php echo form_error('description'); ?>
                                    </div> 
                                </div>

                                <div class="clearfix"></div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('course_level'), 'course_level', array('for' => 'course_level')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'course_level',
                                            'name' => 'course_level',
                                            'value' => set_value('course_level', $result['course_level']),
                                            'class' => 'validate',
                                            'placeholder' => 'Level',
                                            'data-error' => '.errorTxtcert3'
                                        ));
                                        ?>
                                        <div class="errorTxtcert3"></div>
                                        <?php echo form_error('course_level'); ?>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('course_offered_by'), 'course_offered_by', array('for' => 'course_offered_by')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'course_off_by',
                                            'name' => 'course_off_by',
                                            'value' => set_value('course_offered_by', $result['course_offered_by']),
                                            'class' => 'validate',
                                            'placeholder' => 'Offer by',
                                            'data-error' => '.errorTxtcert4'
                                        ));
                                        ?>
                                        <div class="errorTxtcert4"></div>
                                        <?php echo form_error('course_off_by'); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('certification_name'), 'certification_name', array('for' => 'certification_name')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'certification_name',
                                            'name' => 'certification_name',
                                            'value' => set_value('certification_name', $result['certification_name']),
                                            'class' => 'validate',
                                            'placeholder' => 'Certificate Name',
                                            'data-error' => '.errorTxtcert5'
                                        ));
                                        ?>
                                        <div class="errorTxtcert5"></div>
                                        <?php echo form_error('certification_name'); ?>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('issue_date'), 'issue_date', array('for' => 'issue_date')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'issue_date',
                                            'name' => 'issue_date',
                                            'value' => set_value('issued_date', date('d F, Y', strtotime($result['issued_date']))),
                                            'class' => 'issue_date',
                                            'placeholder' => 'Date',
                                            'data-error' => '.errorTxtcert6'
                                        ));
                                        ?>
                                        <div class="errorTxtcert6"></div>
                                        <?php echo form_error('issue_date'); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('remark'), 'remark', array('for' => 'remark')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'remark',
                                            'name' => 'remark',
                                            'value' => set_value('remark', $result['remark']),
                                            'class' => 'validate',
                                            'placeholder' => 'Remark',
                                            'data-error' => '.errorTxtcert7'
                                        ));
                                        ?>
                                        <div class="errorTxtcert7"></div>
                                        <?php echo form_error('remark'); ?>
                                    </div> 
                                </div>

                                <!--                        <div class="col-sm-6">
                                                            <div class="file-field input-field">
                                                                <div class="btn btn-primary btn-sm margin-top-10">Browse
                                                                    <input name="cert_doc" type="file" multiple>
                                                                </div>
                                                                <div class="file-path-wrapper">
                                                                    <input class="file-path" multiple type="text" placeholder="Upload one or more files">
                                                                </div>
                                                            </div>
                                                        </div>-->

                                <div class="col-sm-6">
                                    <div class="file-field input-field">
                                        <div class="btn btn-default btn-sm margin-top-10">Browse
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'id' => 'cert_doc',
                                                'name' => 'cert_doc',
                                                'class' => 'form-control',
                                                'value' => set_value('cert_doc', $result['cert_doc']),
                                                'data-error' => '.errorTxtcert8'
                                            ));
                                            ?>
                                        </div>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $result['document_id']),
                                        ));
                                        ?>


                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'id' => 'cert_doc',
                                                'name' => 'cert_doc',
                                                'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                                'placeholder' => '( pdf, jpeg, jpg)',
                                                'value' => set_value('cert_doc', $result['cert_doc']),
                                            ));
                                            ?>
                                        </div>
                                        <div class="errorTxtcert8"></div>
                                    </div>      
                                </div>
                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button type="submit" class="btn btn-warning2 btn-sm " onclick="return validate_certification_form(<?php echo $result['id'] ?>)">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->
                            <!-- 1st row end here -->                             
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- work experience modal end -->

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {
        $('.issue_date').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });        
    });
</script>