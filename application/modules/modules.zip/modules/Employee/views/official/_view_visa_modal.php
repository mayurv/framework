<!-- Experience Details -->
<?php if (isset($visa_details)) { ?>
    <?php foreach ($visa_details as $result) { ?>
        <div class="modal fade" id="passport-visa-Modal-v-<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Passprot & Visa</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <?php
                            echo form_open_multipart('employee/visa/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_validate_visa_id_' . $result['id']));
                            ?>
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <div class="row">      

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('country_id'), 'country_id', array('for' => 'country_id')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'country_id', 'name' => 'country_id', 'class' => 'browser-default', 'data-error' => '.errorTxtpass8'), $country_list, set_value('country_id', $result['country_id']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtpass8"></div>
                                    </div> 
                                    <?php echo form_error('country_id'); ?> 
                                </div> 


                                <div class="clearfix"></div>


                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('visa_type'), 'visa_type', array('for' => 'visa_type')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'visa_type',
                                            'id' => 'visa_type',
                                            'value' => set_value('visa_type', $result['visa_type']),
                                            'placeholder' => 'Visa Type',
                                            'data-error' => '.errorTxtpass5'
//                                            'class' => 'validate'
                                        ));
                                        ?>
                                        <div class="errorTxtpass5"></div>
                                        <?php echo form_error('visa_type'); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('visa_issue_date'), 'visa_issue_date', array('for' => 'visa_issue_date')); ?>
                                        <?php
                                        echo form_input(array(
//                                            'type' => 'text',
                                            'name' => 'visa_issue_date',
                                            'id' => 'visa_issue_date_m',
                                            'value' => set_value('visa_issue_date', date('d M Y', strtotime($result['visa_issue_date']))),
                                            'class' => 'visa_issue_date_m',
                                            'placeholder' => 'Visa Issue Date',
                                            'data-error' => '.errorTxtpass6'
                                        ));
                                        ?>
                                        <div class="errorTxtpass6"></div>
                                        <?php echo form_error('visa_issue_date'); ?>
                                    </div>
                                </div>



                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('visa_expiry_date'), 'visa_expiry_date', array('for' => 'visa_expiry_date')); ?>
                                        <?php
                                        echo form_input(array(
//                                            'type' => 'text',
                                            'name' => 'visa_expiry_date',
                                            'id' => 'visa_expiry_date_m',
                                            'value' => set_value('visa_expiry_date', date('d M Y', strtotime($result['visa_expiry_date']))),
                                            'class' => 'visa_expiry_date_m',
                                            'placeholder' => 'Visa Expiry Date',
                                            'data-error' => '.errorTxtpass7'
                                        ));
                                        ?>
                                        <div class="errorTxtpass7"></div>
                                        <?php echo form_error('visa_expiry_date'); ?>
                                    </div>

                                </div>



                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <div class="p-title">Visa Document</div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <div class="file-field input-field">
                                        <div class="btn btn-default btn-sm margin-top-5">Browse
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'name' => 'visa_document',
                                                'id' => 'visa_document',
                                                'class' => 'form-control',
                                                'value' => set_value('visa_document', $result['visa_document']),
                                                'data-error' => '.errorTxtpass9'
                                            ));
                                            ?>
                                        </div>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $result['document_id']),
                                        ));
                                        ?>

                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'id' => 'visa_document',
                                                'name' => 'visa_document',
                                                'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                                'placeholder' => '( pdf,jpeg, jpg, png)',
                                                'value' => set_value('visa_document', $result['visa_document']),
                                            ));
                                            ?>
                                        </div>
        <!--                                        <input value="" name="visa_document[name]" id="filename">
                                        <input value="" name="visa_document[type]" id="filetype">
                                        <input value="" name="visa_document[tmp_name]" id="filetemp">
                                        <input value="" name="visa_document[size]" id="filesize">-->
                                        <div class="errorTxtpass9"></div>
                                    </div>                                
                                </div>

                                <div class="col-sm-6">
                                    <div class="file-field input-field">
                                        <?php
                                        if ($result['multi_entry'] == 1)
                                            $isCheck = "'checked'=>'TRUE'";
                                        else
                                            $isCheck = '';
                                        ?>
                                        <?php echo form_checkbox(array('id' => 'multi_entry_m', 'name' => 'multi_entry_m', 'value' => $result['multi_entry'], 'style' => 'left: 0 !important; opacity: 0 !important;', 'checked' => $isCheck)); ?>
                                        <?php echo form_label(lang('multi_entry_m'), 'multi_entry_m', array('for' => 'multi_entry_m', 'style' => 'font-size:12px !important; top: 0 !important ')); ?>
                                        <?php echo form_error('multi_entry'); ?> 
                                    </div>
                                </div>



                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                             
                            <?php echo form_close(); ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- work experience modal end -->





<script>
    $(document).ready(function () {
        /* Multientry */
        $("#multi_entry_m").click(function () {

            var isChecked = $("#multi_entry_m").val();
            if (isChecked == 0) {
                $("#multi_entry_m").val("1");
            } else {
                $("#multi_entry_m").val("0")
            }

        });
    });
</script>

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {


        //Visa

        $('.visa_issue_date_m').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date()
        });
        $(".visa_expiry_date_m").click(function () {
            $('.datepicker').pickadate();
            var date = new Date($('#visa_issue_date_m').val());
            $(".visa_expiry_date_m").removeClass('datepicker');
            var expiryDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            $('.visa_expiry_date_m').pickadate({
                min: new Date(expiryDate),
                selectYears: true,
                selectMonths: true,
            });
        });
    });
</script>