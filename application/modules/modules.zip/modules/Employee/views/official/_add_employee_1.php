<div class="container">
    <div class="row">
        <div class="col-md-12"> 
            
            <?php echo form_dropdown(array('id' => 'id', 'name' => 'id','value' => set_value('id'), 'style' => 'display:none', 'class' => 'form-control'));                ?>	
            <?php echo form_label(lang('id'), 'id'); ?>
        </div>
        <div class="col-md-12"> 
            goal_id
        </div>
        <div class="col-md-12"> 
            category
        </div>
        <div class="col-md-12"> 
            asso_description
        </div>
        <div class="col-md-12"> 
            
        </div>
        <div class="col-md-12"> 
            
        </div>
        <div class="col-md-12"> 
            
        </div>
        <div class="col-md-12"> 
            
        </div>
        
            
            
            
            
            
            
            
            
            asso_completion_status
            
            manager_description
            
            manager_completion_status
                                  
            isactive
       
    </div>
</div>