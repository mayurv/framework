<!-- second row here -->
<div class="row"> 
    <div class="col-sm-4">
        <div class="row">
        <div class="col-sm-12 ">
            <div class="per-contact-info list-group-item"> 
                <p class="text-bold margin-bottom-5">Personal Information</p>
                
                <!--Date of birth-->
                <div class="emp-icon-left-personal" title="Date of Birth">
                    <i class="fa fa-birthday-cake"></i>
                </div> 
                <div class="emp-content-right-personal">                    
                    <?php echo date('d M Y', strtotime($personal_detail['dob'])); ?>
                    <small class="text-light-gray" title="Age">(<?php echo(date('Y') - date('Y m', strtotime($personal_detail['dob']))) ?> years)</small>
                </div>
                <!--Date of birth-->

                <!--Gender-->
                <div class="emp-icon-left-personal" title="Gender">
                    <?php if ($personal_detail['gender_id'] == 1) { ?>
                        <i class="fa fa-male"></i>
                    <?php } else { ?>
                        <i class="fa fa-female"></i>
                    <?php } ?>
                </div> 
                <div class="emp-content-right-personal">
                    <?php echo $personal_detail['gender_id'] ? trim($gender[$personal_detail['gender_id']]) : '' ?>
                </div>
                <!--Gender-->

                <!--Nationality-->
                <div class="emp-icon-left-personal" title="Nationality">
                    <i class="fa fa-flag"></i>
                </div> 
                <div class="emp-content-right-personal" >
                    <?php echo $personal_detail['nationality_id'] ? $nationality_list[$personal_detail['nationality_id']] : '' ?>
                </div>
                <!--Nationality-->

                <!--Marital Status-->
                <div class="emp-icon-left-personal" title="Marital Status">
                    <i class="fa fa-slideshare"></i>
                </div> 
                <div class="emp-content-right-personal">
                    <?php echo $personal_detail['marital_status_id'] ? $marital_list[$personal_detail['marital_status_id']] : '' ?>
                    <?php if ($personal_detail['marital_status_id'] == 2) { ?>
                        | <small class="text-light-gray" title="Anniversary Date"><?php echo date('d M', strtotime($personal_detail['anniversary_date'])); ?> </small>
                    <?php } ?>
                </div>
                <!--Marital Status-->   

                <!--Email-->
                <div class="emp-icon-left-personal" title="Email">
                    <i class="fa fa-envelope margin-right-20"></i>
                </div> 
                <div class="emp-content-right-personal">
                    <a title="<?php echo $communication_detail['personalemail'] ?>" href="mailto: <?php echo $communication_detail['personalemail'] ?>">
                        <?php echo substr($communication_detail['personalemail'], 0, 25) ?><?php echo strlen($communication_detail['personalemail'])>25 ? '..' : ''?></a>
                </div>
                <!--Email-->              
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="col-sm-12">

            <div class="per-address-info list-group-item no-border-hr padding-xs-hr"> 
                <p class="text-bold margin-bottom-5">Current Address
                    <span class="badge badge-info" title="Primary">P</span>
                </p>
                <p><?php echo $communication_detail['current_streetaddress'] ? $communication_detail['current_streetaddress'] : $communication_detail['perm_streetaddress'] ?> , <?php echo $communication_detail['current_city'] ? $city_list[$communication_detail['current_city']] : '' ?></p>
                <p>
                    <?php echo $communication_detail['current_country'] ? $country_list[$communication_detail['current_country']] : $country_list[$communication_detail['perm_country']] ?> | 
                    <?php echo $communication_detail['current_state'] ? $state_list[$communication_detail['current_state']] : $state_list[$communication_detail['perm_state']] ?> |
                    <?php echo $communication_detail['current_city'] ? $city_list[$communication_detail['current_city']] : $city_list[$communication_detail['perm_city']] ?> 
                    - <?php echo $communication_detail['current_pincode'] ? $communication_detail['current_pincode'] : $communication_detail['perm_pincode'] ?>
                    <i class="fa fa-map-marker text-ccc" data-toggle="modal" href="#address_id" title="Map" id="map-address"> </i>               
                </p>
            </div>

            <div class="per-address-info list-group-item no-border-hr padding-xs-hr"> 
                <p class="text-bold margin-bottom-5">Permanent Address</p>
                <p><?php echo $communication_detail['perm_streetaddress'] ?> , <?php echo $communication_detail['perm_city'] ? $city_list[$communication_detail['perm_city']] : '' ?></p>
                <p>
                    <?php echo $country_list[$communication_detail['perm_country']] ?> | 
                    <?php echo $state_list[$communication_detail['perm_state']] ?> |
                    <?php echo $city_list[$communication_detail['perm_city']] ?> - <?php echo $communication_detail['perm_pincode'] ?>
<!--                    <i class="fa fa-map-marker text-ccc" title="Permanent Addres Map" ></i>-->
                    
                    <i class="fa fa-map-marker text-ccc" data-toggle="modal" href="#p_address_id" title="Map" id="map-address"> </i>
                </p>
            </div>


        </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="row">
            <?php if (isset($emergency_contact_details)) { ?>
                <div class="col-sm-12 ">

                    <div class="per-address-info list-group-item no-border-hr padding-xs-hr"> 
                        <p class="text-bold">Emergency Contact <a href="#emergency-info-Modal-2" data-toggle="modal"> <!--<i class="fa fa-pencil text-gray pull-right"></i>--></a></p>
                        <div class="col-sm-1 ">

                        </div>

                        <div class="col-sm-3 ">
                            <span class="text-light-head">Name</span>
                            <!--<i class="fa fa-user text-default text-center"></i>-->
                        </div>
                        <div class="col-sm-4 ">
                            <span class="text-light-head">Number</span>
                            <!--<i class="fa fa-mobile text-default text-center"></i>-->
                        </div>
                        <div class="col-sm-4">
                            <span class="text-light-head">Email</span>
                            <!--<i class="fa fa-envelope text-default text-center"></i>-->
                        </div>

                        <div class="clearfix"></div>
                        <?php foreach ($emergency_contact_details as $emeData) { ?>

                            <div class="col-sm-1 ">

                                <?php if ($emeData['preference'] == 1) { ?>
                                    <i class="fa fa-phone-square text-info" title="Primary"></i>
                                <?php } else { ?>
                                    <i class="fa fa-phone text-gray" title="Secondary"></i>
                                <?php } ?>

                            </div>
                            <div class="col-sm-3 ">
                                <?php echo $emeData['emergency_name']; ?>
                            </div>
                            <div class="col-sm-4 ">  
                                <?php echo $emeData['emergency_number']; ?>
                            </div>
                            <div class="col-sm-4 ">
                                <?php echo $emeData['emergency_email']; ?>
                            </div>
                        <?php } ?>
                    </div>   
                    <?php // var_dump(array_merge($language_details,$language_list))?>

                </div>
            <?php } ?>
        </div>

        <div class="row">
            <div class="col-sm-6 ">
                <div class="per-language-info list-group-item"> 
                    <p class="text-bold margin-bottom-5">Language Known</p>
                    <?php if (isset($language_details)) { ?>
                    <div class="row">
                        <div class="col-sm-6 text-light-head" >Languages</div>
                        <div class="col-sm-2 text-light-head">R</div>
                        <div class="col-sm-2 text-light-head">W</div>
                        <div class="col-sm-2 text-light-head">S</div>
                    </div>
                        <?php foreach ($language_details as $key => $langd) { ?>
                            <div class="row">
                                <div class="col-sm-6"><span class="margin-right-20"><?php echo $language_list[$langd['language_id']]; ?></span></td></div>
                                <div class="col-sm-2 fa <?php echo ($langd['read'] == '1') ? 'fa-check text-success' : 'fa-remove text-danger'; ?>"></div>
                                <div class="col-sm-2 fa <?php echo ($langd['write'] == '1') ? 'fa-check text-success' : 'fa-remove text-danger'; ?>"></div>
                                <div class="col-sm-2 fa <?php echo ($langd['speak'] == '1') ? 'fa-check text-success' : 'fa-remove text-danger'; ?>"></div>
                            </div>

                            <!--<div class="margin-bottom-10 "></div>-->
                            <div class="clearfix"></div>
                        <?php } ?>
                    <?php } ?>
                </div>  
            </div>

            <div class="col-sm-6 ">
                <div class="per-language-info list-group-item"> 
                    <p class="text-bold margin-bottom-5">Hobbies</p>
                    <?php if (isset($hobbies_detail)) { ?>
                        <?php foreach ($hobbies_detail as $key => $hbdata) { ?>
                            <?php if ($hbdata != '') { ?>
                                <span class="tag label label-secondary"><?php echo $hobbies[$hbdata] ?></span>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                </div>  
            </div>
        </div>
    </div>

</div>




<!-- modal start -->
<div class="modal fade" id="address_id" role="dialog" style="top:7%;">
    <div class="modal-dialog">

        <div class="modal-content">   
            <div class="modal-header no-border">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
            
            <div class="modal-body">
                <iframe class="fade in" frameborder="0" width='555' height='350'  src='https://maps.google.com/maps?z=12&amp;q=<?php echo $communication_detail['current_streetaddress'] ?> , <?php echo $communication_detail['perm_city'] ? $city_list[$communication_detail['perm_city']] : '' ?>" ) +"&amp;output=embed'></iframe>
            </div>

        </div>
    </div>
</div>
<!-- modal end -->


<!-- modal start -->
<div class="modal fade" id="p_address_id" role="dialog" style="top:7%;">
    <div class="modal-dialog">

        <div class="modal-content">   
            <div class="modal-header no-border">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
            
            <div class="modal-body">
                <iframe class="fadeInUp" frameborder="0" width='555' height='350'  src='https://maps.google.com/maps?z=12&amp;q=<?php echo $communication_detail['perm_streetaddress'] ?> , <?php echo $communication_detail['perm_city'] ? $city_list[$communication_detail['perm_city']] : '' ?>" ) +"&amp;output=embed'></iframe>
            </div>

        </div>
    </div>
</div>
<!-- modal end -->


<!-- second row here -->
<!--<<script>
    $(document).ready(function () {

        $("#map-address").click(function () {
            $(".modal-backdrop").css("position", "relative !important");
        });
    });
</script>-->

<script> 

</script>

<style>
    
   .modal-backdrop {
    display: none;  
    
}

.modal {
    background-color: rgba(14,16,19,0.5);
}
</style>
    



