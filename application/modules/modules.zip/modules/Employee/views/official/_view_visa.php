<!-- 1st document here -->
<?php // var_dump($visa_details);die;?>
<div class="visa_display">
    <?php $i = 1; ?>
    <?php if (isset($visa_details)) { ?>
        <!-- 1st document here -->
        <?php
        foreach ($visa_details as $result) {

            /* Calculate diff months */
            $date1 = date(strtotime('+6 months'));
            $date2 = date(strtotime($result['visa_expiry_date']));

            $year1 = date('Y', $date1);
            $year2 = date('Y', $date2);

            $month1 = date('m', $date1);
            $month2 = date('m', $date2);

            $diff = (($year2 - $year1) * 12) + ($month2 - $month1);
//             echo $diff;
            if ($diff >= 1) {
                $textClr = 'text-success';
                $validity = "Valid till";
            } else if ($diff >= -6 && $diff <= -1) {
                $textClr = 'text-warning';
                $validity = "Expired at";
            } else {
                $textClr = 'text-orange';
                $validity = "Expiry at";
            }
//            echo date("d",  strtotime(date()));
//            echo date('-6 months',$result['visa_expiry_date']);
            ?>

            <div id="<?php echo $result['id']; ?>">
                <div class="col-sm-3"> 

                    <div class="visa-det-bg" style="<?php // echo $border   ?>">
                        <div class="close-right margin-top-5">
                            <i class="fa fa-trash text-ccc" onclick="delete_visa(<?php echo $result['id']; ?>)" title="delete"></i>
                        </div>
                        <!-- title start here -->
                        <div class="education-det-title">                        

                            <div class="pull-left">
                                <p class="">

                                    <a title="Visa Type | Country" data-toggle="modal"  href="#passport-visa-Modal-v-<?php echo $result['id'] ?>">  <i class="fa fa-pencil"></i> <?php echo $result['visa_type']; ?> | <?php echo $country_list[$result['country_id']] ?></a>
                                    <!--<i class="fa fa-cc-visa <?php echo $textClr; ?> pull-right"> </i>-->
                                </p>
                            </div>
                        </div>
                        <!-- title end here -->

                        <div class="education-det-description margin-bottom-10">
                            <?php echo $user_summary['userfullname']; ?>
                            <div class="border-bottom margin-top-5 margin-bottom-5"></div>
                            <p title="Expiry" > <small class="text-light-gray"> <?php echo $validity . ' ' . date('d M Y', strtotime($result['visa_expiry_date'])); ?></small>  
                            </p> 
                        </div>
                        <?php if (isset($result['visa_document'])) { ?>
                            <span class="pull-right view-file-right pull-right"> 
                                <?php $parts = explode('.', $result['visa_document'])?>
                                <?php if($parts[1]=='pdf'){?>
                                <a target="_blank" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/visa/<?php  echo $result['visa_document']  ?>" ><i class="fa fa-eye text-ccc" title="View"></i> </a>
                                <?php }else {?>
                                <a class="preview" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/visa/<?php echo $result['visa_document'] ?>" rel="prettyPhoto"><i class="fa fa-eye text-ccc" title="View"></i></a>
                                <?php } ?>
                                
                            </span>
                        <?php } ?>


                    </div>
                </div>
            </div>
            <!-- 1st document here -->
            <?php if ($i == 4) { ?>
                <div class="clearfix"></div>
            <?php } ?>
            <?php
            $i++;
        }
        ?>
    <?php } else { ?>
        <?php $this->load->view('official/_no_data_found'); ?>    
    <?php } ?>
</div>
<!-- 1st document here -->

<script>
    function delete_visa(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
//        if()
            /*if visa isset*/
<?php if (isset($result['document_id'])) { ?>
                var document_id = <?php echo $result['document_id'] ? $result['document_id'] : NULL ?>;
<?php } ?>
            $("div").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_visa',
                data: {'visa_id': dId, 'document_id': document_id},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>