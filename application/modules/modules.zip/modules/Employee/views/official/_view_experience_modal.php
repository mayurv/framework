<!-- Experience Details -->
<?php if (isset($experience_details)) { ?>
    <?php foreach ($experience_details as $result) { ?>
        <div class="modal fade" id="work-exp-Modal-v-<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Work Experience</h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-normal-slim">
                            <?php
                            echo form_open_multipart('employee/experience/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_validate_experience_id_' . $result['id'], 'class' => 'form_validate_experience_id_' . $result['id']));
                            ?>
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <div class="row">   
                                <div class="col-sm-6">
                                    <div class="input-field">
                                        
                                        <?php
                                        echo form_input(array(
                                            'id' => 'company_name',
                                            'name' => 'company_name',
                                            'placeholder' => 'Company',
                                            'data-error' => '.errorTxtexp1',
                                            'value' => set_value('comp_name', $result['comp_name']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('company_name'), 'company_name'); ?>
                                        <div class="errorTxtexp1"></div>
                                        <?php echo form_error('company_name'); ?>
                                    </div> 
                                </div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'id' => 'website_url',
                                            'name' => 'website_url',
                                            'placeholder' => 'URL',
                                            'data-error' => '.errorTxtexp2',
                                            'value' => set_value('comp_website', $result['comp_website']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('website'), 'website_url', array('for' => 'website_url')); ?>
                                        <div class="errorTxtexp2"></div>
                                        <?php echo form_error('website'); ?>        
                                    </div> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        
                                        <?php
                                        echo form_input(array(
                                            'name' => 'designation',
                                            'placeholder' => 'Designation',
                                            'value' => set_value('designation', $result['designation']),
                                        ));
                                        ?>    
                                        <?php echo form_label(lang('designation'), 'designation'); ?>
                                        <?php echo form_error('designation'); ?>
                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'id' => 'from_date_cl',
                                            'name' => 'from_date',
                                            'class' => 'from_date_cl',
                                            'placeholder' => 'Date',
                                            'value' => set_value('from_date', date('Y M d', strtotime($result['from_date']))),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('from_date'), 'from_date'); ?>
                                        <?php echo form_error('from_date'); ?>

                                    </div> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'id' => 'to_date',
                                            'name' => 'to_date',
                                            'class' => 'to_date_cl',
                                            'placeholder' => 'Date',
                                            'value' => set_value('to_date', date('Y M d', strtotime($result['to_date']))),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('to_date'), 'to_date'); ?>
                                        <?php echo form_error('to_date'); ?>

                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('reference_name'), 'reference_name'); ?>
                                        <?php
                                        echo form_input(array(
                                            'name' => 'reference_name',
                                            'placeholder' => 'Reference Name',
                                            'value' => set_value('reference_name', $result['reference_name']),
                                        ));
                                        ?>

                                        <?php echo form_error('reference_name'); ?>
                                    </div> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'name' => 'reference_contact',
                                            'placeholder' => 'Reference Contact',
                                            'value' => set_value('reference_contact', $result['reference_contact']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('reference_contact'), 'reference_contact'); ?> 
                                        <?php echo form_error('reference_contact'); ?>
                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('reference_email'), 'reference_email', array('for' => 'reference_email')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'email',
                                            'id' => 'reference_email',
                                            'name' => 'reference_email',
                                            'placeholder' => 'Reference Email',
                                            'data-error' => '.errorTxtexp8',
                                            'value' => set_value('reference_email', $result['reference_email']),
                                        ));
                                        ?>
                                        <div class="errorTxtexp8"></div>
                                        <?php echo form_error('reference_email'); ?>
                                    </div>

                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'reason_leaving',
                                            'placeholder' => 'Reason',
                                            'value' => set_value('reason_for_leaving', $result['reason_for_leaving']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('reason_leaving'), 'reason_leaving'); ?>
                                        <?php echo form_error('reason_leaving'); ?>

                                    </div> 
                                </div> 
                                <div class="clearfix"></div>
                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'company_location_md',
                                            'name' => 'company_location',
                                            'placeholder' => 'Location',
                                            'value' => set_value('company_location', $result['company_location']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('company_location'), 'company_location'); ?>
                                        <?php echo form_error('company_location'); ?>

                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'remark',
                                            'placeholder' => 'Remark',
                                            'value' => set_value('remark', $result['remark']),
                                        ));
                                        ?>
                                        <?php echo form_label(lang('remark'), 'remark'); ?>
                                        <?php echo form_error('remark'); ?>

                                    </div> 
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-sm-6">
                                    <?php echo form_label(lang('tag'), 'tag'); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'tag', 'name' => 'tag', 'class' => 'browser-default', 'data-error' => '.errorTxt12'), $tag_type, set_value('tag_id', $result['tag_id']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxt12"></div>
                                    </div> 
                                    <?php echo form_error('tag'); ?>                                             
                                </div>

                                <div class="col-sm-6">
                                    <div class="file-field input-field">
                                        <div class="btn btn-default btn-sm margin-top-10">Browse
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'name' => 'document',
                                                'id' => 'document',
                                                'class' => 'form-control',
                                                'value' => set_value('document', $result['document']),
                                                'data-error' => '.errorTxtexp30'
                                            ));
                                            ?>
                                        </div>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $result['document_id']),
                                        ));
                                        ?>
                                        
                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'name' => 'document',
                                                'id' => 'document',
                                                'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                                'placeholder' => 'type ( pdf, doc, docx)',
                                                'value' => set_value('document', $result['document']),
                                            ));
                                            ?>
                                        </div>
                                        <div class="errorTxtexp30"></div>
                                    </div>                                
                                </div>

                                <div class="clearfix"></div>
                                <!--<input name="tag_name" value="" id="tag_name">-->

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button type="submit" class="btn btn-warning2 btn-sm" onclick="return validate_experience_form(<?php echo $result['id'] ?>)">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                             
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- work experience modal end -->
<script>
    $(document).ready(function () {
        $('.from_date_cl').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });

        $(".to_date_cl").click(function () {

            var date = new Date($('#from_date_cl').val());
            $(".to_date_cl").removeClass('datepicker');
            console.log(date);
            var fromDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();

            $('.to_date_cl').pickadate({
                min: new Date(fromDate),
                selectYears: true,
                selectMonths: true,
                max: new Date()
            });
        });
    });
</script>

<script type="text/javascript">
    $(function () {

        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }
        $("#company_location_md").autocomplete({
            source: function (request, response) {

                $.getJSON("<?php echo base_url(); ?>/employee/getAutocompleteLocation", {//Url of controller
                    term: extractLast(request.term)
                }, response);

            },
        });
    });

</script>
<style>
    .ui-autocomplete{ z-index: 99999 !important;}
</style> 