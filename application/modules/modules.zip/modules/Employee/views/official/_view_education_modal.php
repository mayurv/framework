<!-- Experience Details -->
<?php if (isset($education_details)) { ?>
    <?php foreach ($education_details as $result) { ?>
        <div class="modal fade" id="education-det-Modal-2-v-<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Education</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <?php
                            echo form_open_multipart('employee/education/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_validate_education_id_' . $result['id'], 'class' => 'form_validate_education_id_' . $result['id']));
                            ?>
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <?php echo form_label(lang('education_level'), 'education_level'); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'education_level', 'name' => 'education_level', 'class' => 'browser-default', 'data-error' => '.errorTxtedu1'), $education_level, set_value('educationlevel', $result['educationlevel']));
                                    ?>	

                                    <?php echo form_error('education_level'); ?>
                                    <div class="input-field">
                                        <div class="errorTxtedu1"></div>
                                    </div> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('institute_name'), 'institute_name'); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'institute_name',
                                            'name' => 'institute_name',
                                            'class' => 'validate',
                                            'placeholder' => 'Board/ University',
                                            'value' => set_value('institution_name', $result['institution_name']),
                                            'data-error' => '.errorTxtedu2'
                                        ));
                                        ?>
                                        <div class="errorTxtedu2"></div>
                                        <?php echo form_error('institute_name'); ?>
                                    </div> 
                                </div>

                                <div class="clearfix"></div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('course_name'), 'course_name', array('for' => 'course_name')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'course_name',
                                            'name' => 'course_name',
//                                        'class' => 'validate',
                                            'value' => set_value('course', $result['course']),
                                            'placeholder' => 'Course Title',
                                            'data-error' => '.errorTxtedu3'
                                        ));
                                        ?>
                                        <div class="errorTxtedu3"></div>
                                        <?php echo form_error('course_name'); ?>
                                    </div>
                                </div>  



                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('grade'), 'grade', array('for' => 'grade')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'grade',
                                            'name' => 'grade',
                                            'value' => set_value('grade', $result['grade']),
//                                        'class' => 'validate',
                                            'placeholder' => 'Grade',
                                            'data-error' => '.errorTxtedu4'
                                        ));
                                        ?>
                                        <div class="errorTxtedu4"></div>
                                        <?php echo form_error('grade'); ?>
                                    </div> 
                                </div>



                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('from_date'), 'from_date', array('for' => 'from_date')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'from_date_md',
                                            'name' => 'from_date',
                                            'class' => 'from_date_md',
                                            'placeholder' => 'From Date',                                            
                                            'value' => set_value('from_date', date('d F, Y', strtotime($result['from_date']))),
                                            'data-error' => '.errorTxtedu5'
                                        ));
                                        ?>
                                        <div class="errorTxtedu5"></div>
                                        <?php echo form_error('from_date'); ?>
                                    </div>
                                </div>


                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('to_date'), 'to_date', array('for' => 'to_date')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'to_date_md',
                                            'name' => 'to_date',
                                            'class' => 'to_date_md',
                                            'placeholder' => 'To Date',                                            
                                            'value' => set_value('to_date', date('d F, Y', strtotime($result['to_date']))),
                                            'data-error' => '.errorTxtedu6'
                                        ));
                                        ?>
                                        <div class="errorTxtedu6"></div>
                                        <?php echo form_error('to_date'); ?>
                                    </div>
                                </div>



                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('percentage'), 'percentage', array('for' => 'percentage')); ?> 
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'percentage',
                                            'name' => 'percentage',
//                                        'class' => 'validate',
                                            'placeholder' => 'Percentage',
                                            'value' => set_value('percentage', $result['percentage']),
                                            'data-error' => '.errorTxtedu7'
                                        ));
                                        ?>
                                        <div class="errorTxtedu7"></div>
                                        <?php echo form_error('percentage'); ?>
                                    </div>
                                </div>


                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('remark'), 'remark', array('for' => 'remark')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'remark',
                                            'name' => 'remark',
//                                        'class' => 'validate',
                                            'placeholder' => 'Remark',
                                            'value' => set_value('remark', $result['remark']),
                                            'data-error' => '.errorTxtedu8'
                                        ));
                                        ?>
                                        <div class="errorTxtedu8"></div>
                                        <?php echo form_error('remark'); ?>

                                    </div> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="file-field input-field">
                                        <div class="btn btn-default btn-sm margin-top-10">Browse
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'name' => 'education_doc',
                                                'id' => 'education_doc',
                                                'class' => 'form-control',
                                                'value' => set_value('education_doc', $result['education_doc']),
                                                'data-error' => '.errorTxtedu9'
                                            ));
                                            ?>
                                        </div>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $result['document_id']),
                                        ));
                                        ?>
                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'name' => 'education_doc',
                                                'id' => 'education_doc',
                                                'class' => 'file-path',
                                                'placeholder' => 'type ( pdf, doc, jpeg, jpg)',
//                                                'placeholder' => 'Upload one or more files',
                                                'value' => set_value('education_doc', $result['education_doc']),
                                                'data-error' => '.errorTxtedu9'
                                            ));
                                            ?>
                                        </div>
                                        <div class="errorTxtedu9"></div>
                                    </div>      
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10">
                                    <button type="submit" class="btn btn-warning2 btn-sm pull-right" onclick="return validate_education_form(<?php echo $result['id'] ?>)">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                         
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- work experience modal end -->

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {
        $('.from_date_md').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });

        $(".to_date_md").click(function () {
            
            var date = new Date($('#from_date_md').val());
            
//            $(".from_date_md").removeClass('datepicker');
            var fromDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();

            $('.to_date_md').pickadate({
                min: new Date(fromDate),
                selectYears: true,
                selectMonths: true,
                max: new Date()
            });
        });
    });
</script>