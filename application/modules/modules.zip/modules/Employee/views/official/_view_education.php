<!-- 1st document here -->
<div class="education_display">
    <?php $i = 1; ?>
    <?php if (isset($education_details)) { ?>
        <?php foreach ($education_details as $result) { ?>
            <!-- 1st document here -->
            <div id="<?php echo $result['id']; ?>">
                <div class="col-sm-3"> 
                    <div class="education-det-bg">                    
                        <div class="close-right margin-top-5">
                            <i class="fa fa-trash text-ccc" onclick="deleteEduCard(<?php echo $result['id'] ?>)"  title="Delete"></i>
                        </div>
                        <!-- title start here -->
                        <div class="education-det-title">
                            <a  data-toggle="modal" href="#education-det-Modal-2-v-<?php echo $result['id'] ?>">  <i class="fa fa-pencil"></i>  <?php echo $result['educationlevel'] ? $education_level[$result['educationlevel']] : '' ?></a>
                        </div>                    
                        <!-- title end here -->

                        <div class="education-det-description margin-bottom-10" >
                            <p title="Course | Board/University"><span title="<?php echo $result['course'] ?>">                                
                                    <?php echo substr($result['course'], 0, 10) ?><?php echo strlen($result['course'])>10 ? '..' : ''?>
                                </span> | 
                                <span title="<?php echo $result['institution_name'] ?>">
                                    <?php echo substr($result['institution_name'], 0, 11) ?><?php echo strlen($result['institution_name'])>11 ? '..' : ''?>
                            <p title="From | To"><?php echo date('M Y', strtotime($result['from_date'])); ?> to <?php echo date('M Y', strtotime($result['to_date'])); ?> </p>
                            <p title="Percentage | Grade"><?php echo $result['percentage']; ?>% | <span class="text-primary"><?php echo $result['grade']; ?></span></p>

                        </div>
                        <?php if (isset($result['education_doc'])) { ?>
                            <span class="pull-right view-file-right pull-right"> 
                                <a class="preview" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/education/<?php echo $result['education_doc'] ?>" rel="prettyPhoto"><i class="fa fa-eye text-ccc" title="View"></i></a>
                                <!--<a target="_blank" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/education/<?php echo $result['education_doc'] ?>" ><i class="fa fa-paperclip text-ccc" title="View"></i> </a>-->
                            </span>
                        <?php } ?>
                    </div>
                </div> 
            </div>
            <?php if ($i == 4) { ?>
                <div class="clearfix"></div>
            <?php } ?>
            <?php
            $i++;
        }
        ?>
    <?php } else { ?>
        <?php $this->load->view('official/_no_data_found'); ?>    
    <?php } ?>
</div>
<!-- 1st document here -->

<script>
    function deleteEduCard(dId) {
//        if()
        if (confirm('Are you sure, you want to delete this?')) {
            $("div").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_education',
                data: {'education_id': dId},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>
