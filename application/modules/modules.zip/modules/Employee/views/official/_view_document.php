<?php //var_dump($document_details)     ?>
<div class="doc_display">
    <div class="col-sm-12">
        <table id="dt-view-document1" class="table table-responsive">
            <thead>
                <tr>

                    <th style="width: 30%;">Document Name</th>
                    <th style="width: 16%;">Document Type</th>
                    <th style="width: 22%;">Uploaded On</th>
                    <th style="width: 22%;">Uploaded by</th>

                </tr>
            </thead>
            <tbody>
                <?php foreach ($document_details as $r => $docdata) { ?>
                    <tr>

                        <td>
                            <p>
                                <span class="margin-right-5">
                                    <?php if ($docdata['type'] == 'pdf') { ?>
                                        <i class="fa fa-file-pdf-o  text-light-gray"></i> 
                                    <?php } elseif ($docdata['type'] == 'jpeg' || $docdata['type'] == 'png') { ?>
                                        <i class="fa fa-file-image-o  text-light-gray"></i>                     
                                    <?php } elseif ($docdata['type'] == 'doc' || $docdata['type'] == 'docx') { ?>
                                        <i class="fa fa-file-word-o text-light-gray"></i> 
                                    <?php } else { ?>
                                        <i class="fa fa-file-code-o text-light-gray"></i> 
                                    <?php } ?>
                                </span>
                                <a target="_blank" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents<?php echo $docdata['attachments'] ?>" > <?php echo $docdata['name'] ?></a>
                            </p>
                            <p>
                                <i class="margin-left-20"><small class="text-light-gray">Tags : <?php echo substr(strtolower($docdata['tag']), 0, 4); ?></small></i>
                            </p>
                        </td>
                        <td><p><?php echo $docdata['title'] ?></p></td>
                        <td><p><?php echo date('d M Y', strtotime($docdata['createddate'])) ?></p></td>
                        <td><p><?php echo $docdata['userfullname'] ?></p></td>
                        
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

