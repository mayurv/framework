<!--Official Information modal start -->
<div class="modal fade" id="office-info-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Official Information</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <?php
                    echo form_open_multipart('employee/edit/' . $user_summary['user_id'], array('id' => 'form_official_modal_id', 'class' => 'form_official_modal_id'));
                    ?>
                    <?php echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => 'edit')) ?>
                    <!-- 1st row start here -->
                    <?php // form_input('')   ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('employeeid'), 'employeeid', array('for' => 'employeeid')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'employeeid',
                                    'id' => 'employeeid',
                                    'value' => set_value('employeeId', $user_summary['employeeId']),
//                                    'data-error' => '.errorTxtOff1',
                                    'placeholder' => 'MWX-000',
                                    'readonly' => 'readonly'
                                ));
                                ?>
                                <!--<div class="errorTxtOff1"></div>-->
                                <?php echo form_error('employeeid'); ?>

                            </div> 
                        </div> 
                        <div class="col-sm-6">
                            <?php echo form_label(lang('prefix_id'), 'prefix_id', array('for' => 'prefix')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'prefix_id', 'name' => 'prefix_id'), $prefix, set_value('prefix_id', $user_summary['prefix_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff2'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff2"></div>
                            </div> 
                            <?php echo form_error('prefix_id'); ?>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('firstname'), 'firstname', array('data-error' => 'firstname is required', 'for' => 'firstname')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'name' => 'firstname',
                                    'placeholder' => 'First Name',
                                    'value' => set_value('firstname', $user_summary['firstname']),
                                    'data-error' => '.errorTxtOff3'
                                ));
                                ?>
                                <div class="errorTxtOff3"></div>
                                <?php echo form_error('firstname'); ?>
                            </div> 
                        </div> 



                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('lastname'), 'lastname', array('for' => 'lastname', 'data-error' => 'please enter valid email')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'name' => 'lastname',
                                    'placeholder' => 'Last Name',
                                    'value' => set_value('lastname', $user_summary['lastname']),
//                                    'data-error' => '.errorTxtOff4'
                                ));
                                ?>
                                <div class="errorTxtOff4"></div>
                                <?php echo form_error('lastname'); ?>
                                <!--<span style="background-color: red; margin-top: 10px;"><?php // echo validation_errors();                                                       ?></span>-->
                            </div> 
                        </div>
                        <div class="clearfix"></div>


                        <div class="col-sm-6">
                            <?php echo form_label(lang('modeofemp'), 'modeofemp', array('for' => 'modeofemp', 'data-error' => 'select mode', 'disabled' => 'disabled')); ?>
                            <?php
                            if (isset($candidate_details)) {
                                echo form_dropdown(array('id' => 'modeofemp_id', 'name' => 'modeofemp_id', 'disabled' => 'disabled'), $empmode_list, 2, array('class' => 'browser-default ', 'data-error' => '.errorTxtOff5', 'readonly'));
                                ?><input type="hidden" id="modeofemp_id" value="2" /><?php
                            } else {
                                echo form_dropdown(array('id' => 'modeofemp_id', 'name' => 'modeofemp_id', 'disabled' => 'disabled'), $empmode_list, 1, array('class' => 'browser-default ', 'data-error' => '.errorTxtOff5', 'readonly'));
                                ?><input type="hidden" id="modeofemp_id" value="1" /><?php
                            }
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff5"></div>
                            </div> 
                            <?php echo form_error('firstname'); ?>

                        </div>


                        <div class="col-sm-6">
                            <?php echo form_label(lang('emprole'), 'emprole', array('for' => 'emprole', 'data-error' => 'select role')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'emprole_id', 'name' => 'emprole_id'), $emprole_list, set_value('emprole', $user_summary['emprole']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff6'));
                            ?>

                            <div class="input-field">
                                <div class="errorTxtOff6"></div>
                            </div> 
                            <?php echo form_error('emprole'); ?>

                        </div>  

                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('work_station'),'work_station', array('for' => 'work_station')); ?>

                            <?php
//                                                                        var_dump($user_summary);die;
                            echo form_dropdown(array('id' => 'work_status', 'name' => 'work_status', 'disabled' => 'disabled'), $work_station_all, set_value('work_station', $user_summary['work_station']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff7'));
                            ?>
                            <div class="input-field">   
                                <div class="errorTxtOff7"></div>
                            </div>
                            <?php echo form_error('work_station'); ?>
                        </div> 

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('email'), 'email', array('for' => 'email', 'data-error' => 'please enter valid email')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'email',
                                    'name' => 'email',
                                    'placeholder' => 'Email',
                                    'value' => set_value('emailaddress', $user_summary['emailaddress']),
                                    'data-error' => '.errorTxtOff8',
                                    'readonly' => 'readonly'
                                ));
                                ?>

                                <div class="errorTxtOff8"></div>
                                <?php echo form_error('email'); ?>
                            </div> 
                        </div>


                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('department_id'), 'department_id', array('for' => 'email', 'data-error' => 'please select department')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'department_id', 'name' => 'department_id'), $department_list, set_value('department_id', $user_summary['department_id']), array('class' => 'browser-default ', 'data-error' => '.errorTxtOff9'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff9"></div>
                            </div>
                            <?php echo form_error('department_id'); ?>

                        </div> 

                        <div class="col-sm-6">
                            <?php echo form_label(lang('reporting_manager'), 'reporting_manager', array('for' => 'reporting_manager', 'data-error' => 'reporting_manager')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'reporting_manager', 'name' => 'reporting_manager'), $rep_manager_list, set_value('reporting_manager', $user_summary['reporting_manager']), array('class' => 'browser-default ', 'data-error' => '.errorTxtOff10'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff10"></div>
                            </div>
                            <?php echo form_error('reporting_manager'); ?>

                        </div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('reporting_manager_two'), 'reporting_manager_two', array('for' => 'reporting_manager_two', 'data-error' => 'reporting_manager_two')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'reporting_manager_two', 'name' => 'reporting_manager_two', 'disabled' => 'disabled'), $rep_manager_list, set_value('reporting_manager', $user_summary['reporting_manager_twoup']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff11'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff11"></div>
                            </div>
                            <?php echo form_error('reporting_manager_two'); ?>

                        </div>



                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('jobtitle'), 'jobtitle', array('for' => 'jobtitle', 'data-error' => 'jobtitle')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'jobtitle_id', 'name' => 'jobtitle_id'), $jobtitle_list, set_value('jobtitle_id', $user_summary['jobtitle_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff12'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff12"></div>
                            </div>
                            <?php echo form_error('jobtitle'); ?>

                        </div> 

                        <div class="col-sm-6">
                            <?php echo form_label(lang('position_id'), 'position_id', array('for' => 'position_id', 'data-error' => 'position_id')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'position_id', 'name' => 'position_id'), $position_list, set_value('position_id', $user_summary['position_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff13'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff13"></div>
                            </div>
                            <?php echo form_error('position_id'); ?>

                        </div> 

                        <div class="col-sm-6">
                            <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('for' => 'emp_status_id', 'data-error' => 'emp_status_id')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $emp_status_list, set_value('emp_status_id', $user_summary['emp_status_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff14'));
                            ?>
                            <div class="input-field">  
                                <div class="errorTxtOff14"></div>
                            </div>
                            <?php echo form_error('emp_status_id'); ?>
                        </div>

                        <!--<div class="clearfix"></div>-->
                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('date_of_joining'), 'date_of_joining', array('for' => 'date_of_joining')); ?>

                                <?php
                                echo form_input(array(
//                                    'name' => 'date_of_joining',
                                    'id' => 'date_of_joining',
                                    'data-format' => 'yyyy-mm-dd',
                                    'class' => 'datepicker',
                                    'placeholder' => 'Date of Joining',
                                    'value' => set_value('date_of_joining', date('d F, Y', strtotime($user_summary['date_of_joining']))),
                                    'data-error' => '.errorTxtOff15',
                                    'disabled' => 'disabled'
                                ));
                                ?>
                                <input id="date_of_joining" name="date_of_joining" type="hidden" value="<?php echo $user_summary['date_of_joining'] ?>" >
                                <div class="errorTxtOff15"></div>
                                <?php echo form_error('date_of_joining'); ?>
                            </div>  
                        </div>


                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('date_of_leaving'), 'date_of_leaving', array('for' => 'date_of_leaving')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'date_of_leaving',
                                    'id' => 'date_of_leaving',
                                    'data-format' => 'yyyy-mm-dd',
                                    'placeholder' => 'Date of Leaving',
                                    'class' => 'date_of_leaving',
                                    'value' => $user_summary['date_of_leaving'] ? set_value('date_of_leaving', date('d F, Y', strtotime($user_summary['date_of_leaving']))) : '',
                                    'data-error' => '.errorTxt11'
                                ));
                                ?>
                                <div class="errorTxt11"></div>
                                <?php echo form_error('date'); ?>
                            </div> 
                        </div>


                        <div class="clearfix"></div>
                        <div class="col-sm-8">
                            <div class="p-title margin-bottom-10">Experience</div>
                        </div>


                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('yearsofexp'), 'yearsofexp', array('for' => 'yearsofexp')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'yearsofexp', 'name' => 'yearsofexp'), $yearsexp, set_value('years_exp', $user_summary['years_exp']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff16'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff16"></div>
                            </div> 
                            <?php echo form_error('yearsofexp'); ?>
                        </div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('monthsofexp'), 'monthsofexp', array('for' => 'monthsofexp')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'monthsofexp', 'name' => 'monthsofexp'), $monthsexp, set_value('months_exp', $user_summary['months_exp']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff17'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtOff17"></div>
                            </div> 
                            <?php echo form_error('monthsofexp'); ?>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-12">
                            <div class="p-title margin-bottom-10">Contact Number</div>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('contactnumber'), 'contactnumber', array('class' => 'form-label'), array('for' => 'contactnumber')); ?>
                                <?php
                                echo form_input(array(
                                    'name' => 'contactnumber',
                                    'id' => 'contactnumber',
                                    'class' => 'form-control',
//                                    'data-mask' => 'phone',
                                    'placeholder' => 'Contact Number',
                                    'value' => set_value('contactnumber', $user_summary['contactnumber']),
                                    'data-error' => '.errorTxtOff18'
                                ));
                                ?>
                                <div class="errorTxtOff18"></div>
                                <?php echo form_error('contactnumber'); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <?php echo form_label(lang('isactive'), 'isactive', array('for' => 'isactive')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'isactive', 'name' => 'isactive'), $status, set_value('isactive', $user_summary['isactive']), array('class' => 'browser-default', 'data-error' => '.errorTxtOff19'));
                            ?>

                            <div class="input-field">
                                <div class="errorTxtOff19"></div>
                            </div>
                            <?php echo form_error('isactive'); ?>

                        </div>  

                        <div class="clearfix"></div>
                        <div class="col-sm-12">
                            <div class="p-title ">Resume Upload</div>
                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-6">

                            <div class="file-field input-field">

                                <div class="btn btn-default btn-sm margin-top-5">Browse
                                    <?php
                                    echo form_input(array(
                                        'type' => 'file',
                                        'name' => 'cv_doc',
                                        'id' => 'cv_doc',
//                                        'class' => 'form-control',
                                        'value' => set_value('user_cv', $user_summary['user_cv']),
                                        'data-error' => '.errorTxtOff20'
                                    ));
                                    ?>

                                </div>
                                <?php
                                echo form_input(array(
                                    'type' => 'hidden',
                                    'name' => 'document_id',
                                    'class' => 'form-control',
                                    'value' => set_value('document_id', $user_summary['document_id']),
                                ));
                                ?>



                                <div class="file-path-wrapper">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'cv_doc',
                                        'id' => 'cv_doc',
                                        'class' => 'file-path',
//                                        'placeholder' => 'Upload one or more files',
                                        'placeholder' => '( pdf, doc, docx, jpg)',
                                        'value' => set_value('user_cv', $user_summary['user_cv']),
//                                        'data-error' => '.errorTxtOff20'
                                    ));
                                    ?>
                                </div>
                                <div class="errorTxtOff20"></div>
                            </div>
                        </div>

                        <!--                        <div class="col-sm-12">
                                                    <div class="p-title">CV</div>
                                                </div>-->

                        <div class="clearfix"></div>


                        <div class="col-sm-12">
                            <div class="p-title">Passport Details <i id="passHS" class="text-ccc fa fa-plus-circle font-size-18"></i></div>
                        </div>
                        <div class="clearfix"></div>

                        <div class="passHideShow" style="display: none">
                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('passport_number'), 'passport_number', array('for' => 'passport_number')); ?>
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'id' => 'passport_number',
                                        'name' => 'passport_number',
                                        'placeholder' => 'Passport Number',
                                        'value' => set_value('passport_number', $passport_details['passport_number']),
                                        'data-error' => '.errorTxtOff22'
                                    ));
                                    ?>
                                    <div class="errorTxtOff22"></div>
                                    <?php echo form_error('passport_number'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('passport_issue_date'), 'passport_issue_date', array('for' => 'passport_issue_date')); ?>
                                    <?php
                                    echo form_input(array(
//                                            'type' => 'text',
                                        'name' => 'passport_issue_date',
                                        'id' => 'passport_issue_date',
                                        'class' => 'passport_issue_date',
                                        'placeholder' => 'Passport Issue Date',
                                        'value' => set_value('passport_issue_date', $passport_details['passport_issue_date'] ? date('d F, Y', strtotime($passport_details['passport_issue_date'])) :''),
                                        'data-error' => '.errorTxtOff23'
                                    ));
                                    ?>
                                    <div class="errorTxtOff23"></div>
                                    <?php echo form_error('passport_issue_date'); ?>
                                </div> 
                            </div>
                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('passport_expiry_date'), 'passport_expiry_date', array('for' => 'passport_expiry_date')); ?>
                                    <?php
                                    echo form_input(array(
//                                            'type' => 'text',
                                        'name' => 'passport_expiry_date',
                                        'id' => 'passport_expiry_date',
                                        'class' => 'passport_expiry_date_cl',
                                        'placeholder' => 'Passport Expiry Date',
                                        'data-error' => '.errorTxtOff24',
                                        'value' => set_value('passport_expiry_date',$passport_details['passport_expiry_date'] ?  date('d F, Y', strtotime($passport_details['passport_expiry_date'])): ''),
                                    ));
                                    ?>
                                    <div class="errorTxtOff24"></div>
                                    <?php echo form_error('passport_expiry_date'); ?>
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php echo form_label(lang('issue_location'), 'issue_location', array('class' => 'form-label'), array('for' => 'issue_location')); ?>
                                    <?php
                                    echo form_input(array(
                                        'name' => 'issue_location',
                                        'id' => 'issue_location',
                                        'class' => 'form-control',
                                        'placeholder' => 'Location',
                                        'value' => set_value('issue_location', $passport_details['issue_location']),
                                        'data-error' => '.errorTxtOff25'
                                    ));
                                    ?>
                                    <div class="errorTxtOff25"></div>
                                    <?php echo form_error('issue_location'); ?>
                                </div>
                            </div>


                            <div class="col-sm-6">
                                <div class="file-field input-field">
                                    <div class="btn btn-default btn-sm margin-top-5">Attach Passport
                                        <?php
                                        echo form_input(array(
                                            'type' => 'file',
                                            'name' => 'passport_doc',
                                            'id' => 'passport_doc',
                                            'class' => 'form-control',
                                            'data-error' => '.errorTxtOff26'
                                        ));
                                        ?>
                                    </div>                                      

                                    <div class="file-path-wrapper">
                                        <?php
                                        echo form_input(array(
                                            'name' => 'passport_doc',
                                            'id' => 'passport_doc',
                                            'class' => 'file-path',
                                            'value' => set_value('passport_doc', $passport_details['passport_doc']),
//                                                'placeholder' => 'Upload one or more files',
                                            'placeholder' => '(jpg, jpeg, png, pdf)',
                                        ));
                                        ?>
                                    </div>
                                    <div class="errorTxtOff26"></div>
                                </div>
                            </div>
                        </div>




                        <div class="clearfix"></div>

                        <div class="col-sm-12 padding-top-10 text-right">
                            <!--<input >-->
                            <button type="submit" class="btn btn-warning2 btn-sm" >Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>

                    </div>

                    <input type="hidden" name="form_tag" id="form_tag" value="official">
                    <input type="hidden" name="reporting_manager_name" id="reporting_manager_name" value="<?php if (isset($user_summary['reporting_manager_name'])) echo $user_summary['reporting_manager_name']; ?>">
                    <input type="hidden" name="reporting_manager_twoup_name" id="reporting_manager_twoup_name" value="<?php if (isset($user_summary['reporting_manager_twoup_name'])) echo $user_summary['reporting_manager_twoup_name']; ?>">
                    <input type="hidden" name="department_name" id="department_name" value="<?php if (isset($user_summary['department_name'])) echo $user_summary['department_name']; ?>">
                    <input type="hidden" name="jobtitle_name" id="jobtitle_name" value="<?php if (isset($user_summary['jobtitle_name'])) echo $user_summary['jobtitle_name']; ?>">
                    <input type="hidden" name="position_name" id="position_name" value="<?php if (isset($user_summary['position_name'])) echo $user_summary['position_name']; ?>">
                    <input type="hidden" name="emp_status_name" id="emp_status_name" value="<?php if (isset($user_summary['emp_status_name'])) echo $user_summary['emp_status_name']; ?>">
                    <input type="hidden" name="holiday_group_name" id="holiday_group_name" value="<?php if (isset($user_summary['holiday_group_name'])) echo $user_summary['holiday_group_name']; ?>">
                    <input type="hidden" name="prefix_name" id="prefix_name" value="<?php if (isset($user_summary['prefix_name'])) echo $user_summary['prefix_name']; ?>">
                    <input type="hidden" name="emprole_name" id="emprole_name" value="<?php if (isset($user_summary['emprole_name'])) echo $user_summary['emprole_name']; ?>">
                    <!-- 1st row end here -->                             
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!--Official Information modal end -->
<script>

    $(document).ready(function () {
        /*set validation for date*/
        $('.date_of_leaving').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });

        $('.datepicker').val();
        $('.datepicker').pickadate({
        });

        var emprole = '';
        //to set reporting manager name
//        $("#reporting_manager").change(function () {
//            $('#reporting_manager_name').val();
//            if ($("#reporting_manager option:selected").text() != "") {
//                $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
//            }
//        });

        $("#position_id").change(function () {
            $('#position_name').val();
            if ($("#position_id option:selected").val() != 0) {
                $('#position_name').val($("#position_id option:selected").text());
            }
        });
        $("#emp_status_id").change(function () {
            //            alert('hi');
            $('#emp_status_name').val();
            if ($("#emp_status_id option:selected").text() != "") {
                $('#emp_status_name').val($("#emp_status_id option:selected").text());
            }
        });
        $("#holiday_group_id").change(function () {
            $('#holiday_group_name').val();
            if ($("#holiday_group_id option:selected").text() != "") {
                $('#holiday_group_name').val($("#holiday_group_id option:selected").text());
            }
        });
        $("#prefix_id").change(function () {
            $('#prefix_name').val();
            if ($("#prefix_id option:selected").text() != "") {
                $('#prefix_name').val($("#prefix_id option:selected").text());
            }
        });
        $("#emprole_id").change(function () {
            $('#emprole_name').val();
            if ($("#emprole_id option:selected").text() != "") {
                $('#emprole_name').val($("#emprole_id option:selected").text());
            }
        });
        //to get reporting manager 
        $("#department_id").change(function () {


            if ($("#department_id option:selected").text() != "") {
                $('#department_name').val($("#department_id option:selected").text());
            }

            //if manager
            if ($("#emprole_id option:selected").val()) {
                emprole = $("#emprole_id option:selected").val();
            }


            $('#reporting_manager_name').val('');
            if ($("#reporting_manager option:selected").text() != "") {
                $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
            }
            var department_id = $("select#department_id option:selected").val();
            ajaxCallToGetAllManager(department_id, emprole);
        });
        $("#reporting_manager_two").change(function () {
            $('#reporting_manager_twoup_name').val('');
            if ($("#reporting_manager_two option:selected").text() != "") {
                $('#reporting_manager_twoup_name').val($("#reporting_manager_two option:selected").text());
            }
        });
        //to get reporting manager two up 
        $("#reporting_manager").change(function () {

            if ($("#department_id option:selected").text() != "") {
                $('#department_name').val($("#department_id option:selected").text());
            }

            //if manager
            if ($("#emprole_id option:selected").val()) {
                emprole = $("#emprole_id option:selected").val();
            }


            $('#reporting_manager_name').val('');
            if ($("#reporting_manager option:selected").text() != "") {
                $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
            }
            var department_id = $("select#department_id option:selected").val();
            $('#reporting_manager_twoup_name').val('');
            var reporting_manager_id = $("select#reporting_manager option:selected").val();
            ajaxCallToGetAllManagerTwoUp(department_id, emprole, reporting_manager_id);
        });
        //to get position
        $("#jobtitle_id").change(function () {

            if ($("#jobtitle_id option:selected").text() != "") {
                $('#jobtitle_name').val($("#jobtitle_id option:selected").text());
            }

            var jobtitle_id = $("select#jobtitle_id option:selected").val();
            ajaxCallToGetAllPosition(jobtitle_id);
        });
        //to get manager by role
        $("#emprole_id").change(function () {

            if ($("#department_id option:selected").text() != "" && $("#department_id option:selected").val() != 0) {
                $('#department_name').val($("#department_id option:selected").text());
                var department_id = $("select#department_id option:selected").val();
                emprole = $("#emprole_id option:selected").val();
                ajaxCallToGetAllManager(department_id, emprole);
            }

        });
        /*for ajax call*/
        function ajaxCallToGetAllPosition(jobtitle_id)
        {
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getPositionName',
                data: {'jobtitle_id': jobtitle_id},
                success: function (data) {
                    if (data) {
//                        $('#position_id').val(0);
                        $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                        $("#position_id").val($("#position_id option:first").val());
                        $('#position_id').material_select();
                    }
                }
            });
        }
        function ajaxCallToGetAllManager(department_id, emprole)
        {
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getReportingManager',
                data: {'department_id': department_id, 'emprole': emprole,'new':''},
                success: function (data) {
                    //                    $('select[name="reporting_manager"]').show();
                    $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $("#reporting_manager").val($("#reporting_manager option:first").val());
                    $('#reporting_manager').material_select();
                }
            });
        }

        function ajaxCallToGetAllManagerTwoUp(department_id, emprole, reporting_manager_id)
        {
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getReportingManager',
                data: {'department_id': department_id, 'emprole': emprole, 'reporting_manager_id': reporting_manager_id},
                success: function (data) {

                    if (data.content.length > 50) {
                        $('select[name="reporting_manager_two"]').prop("disabled", false);
                        $('select[name="reporting_manager_two"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                        $("#reporting_manager_two").val($("#reporting_manager_two option:first").val());
                        
                        $('#reporting_manager_two').material_select();
                    } else {
                        $('select[name="reporting_manager_two"]').prop("disabled", true);
                    }

                }
            });
        }

        //        On role change get manager name
        //to get position



    });

</script>
<!--<a href="https://github.com/firstopinion/formatter.js" target="_blank"></a>-->
<script>
    $(document).ready(function () {
//        $('#contactnumber').formatter({
//            'pattern': '{{*}}-{{999}}-{{999}}-{{999}}',
//            'persistent': true
//        });
    });
</script>

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {

        //Passport  passport_issue_date
        $('.passport_issue_date').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date()
        });

        $(".passport_expiry_date_cl").click(function () {
            $(".passport_expiry_date_cl").removeClass('datepicker');
//            $('.datepicker').pickadate();

            var date = new Date($('#passport_issue_date').val());
//            alert(date);
//            $(".passport_expiry_date").removeClass('datepicker');
            var expiryDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            $('.passport_expiry_date_cl').pickadate({
                min: new Date(expiryDate),
                selectYears: true,
                selectMonths: true,
            });
        });

        $("#passHS").click(function () {
            $("#passHS").toggleClass('fa-minus-circle');
            $(".passHideShow").toggle('show');

        });




    });
</script>