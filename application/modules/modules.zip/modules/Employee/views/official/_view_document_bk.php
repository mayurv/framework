<?php //var_dump($document_details)    ?>

<div class="doc_display">
    <div class="col-sm-12">
        <table class="table data-table table-hover table-responsive">
            <thead>
                <tr>

                    <th style="width: 30%;">Document</th>
                    <th style="width: 22%;">Uploaded On</th>
                    <th style="width: 22%;">Uploaded by</th>
                    <th style="width: 16%;">Download</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($document_details as $r => $docdata) { ?>
                    <tr>

                        <td>
                            <p>
                                <span class="margin-right-5">
                                    <?php if ($docdata['type'] == 'pdf') { ?>
                                        <i class="fa fa-file-pdf-o fa-2x text-secondary"></i> 
                                    <?php } elseif ($docdata['type'] == 'jpeg' || $docdata['type'] == 'png') { ?>
                                        <i class="fa fa-file-image-o fa-2x text-secondary"></i>                     
                                    <?php } elseif ($docdata['type'] == 'doc' || $docdata['type'] == 'docx') { ?>
                                        <i class="fa fa-file-word-o fa-2x text-secondary"></i> 
                                    <?php } else { ?>
                                        <i class="fa fa-file-code-o fa-2x text-secondary"></i> 
                                    <?php } ?>
                                </span>
                                <a target="_blank" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents<?php echo $docdata['attachments'] ?>" > <?php echo $docdata['name'] ?></a>
                            </p>
                            <p>
                                <i><small class="text-light-gray">Tags : <?php echo substr(strtolower($docdata['tag']), 0, 4); ?></small></i>
                            </p>
                        </td>
                        <td><p><?php echo date('d M Y', strtotime($docdata['createddate'])) ?></p></td>
                        <td><p><?php echo $docdata['userfullname'] ?></p></td>
                        <td><a href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents<?php echo $docdata['attachments'] ?>" download><small class="fa fa-download text-ccc" ></small> </a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

