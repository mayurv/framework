<!--Personal & Contact information modal start -->
<div class="modal fade" id="emergency-info-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog" >
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Emergency Contacts</h4>
            </div>

            <div class="modal-body">
                <div class="col-sm-12">
                    <div class="p-title margin-top-10">Emergency Contact</div>
                </div>
                <div class="clearfix"></div>
                <div class="col-sm-12 margin-top-10">

                    <div class="row">
                        <div class="col-sm-12">
                            <input type="hidden" name="emergency_contact_count" id="emergency_contact_count" value="">
                            <div class="col-sm-3">   
                                <div class="input-field">
                                    <?php echo form_label(lang('emergency_number'), 'emergency_number', array('for' => 'emergency_number')); ?>
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'id' => 'emergency_number',
                                        'name' => 'emergency_number',
                                        'data-error' => '.errorTxtSkill5',
                                        'placeholder' => 'Contact Number',
                                        'data-error' => '.errorTxtCom20',
                                    ));
                                    ?>
                                    <div class="errorTxtCom20"></div>
                                    <?php echo form_error('emer_number'); ?>
                                </div>


                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('emergency_name'), 'emergency_name', array('for' => 'emergency_name')); ?>
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'id' => 'emergency_name',
                                        'name' => 'emergency_name',
                                        'data-error' => '.errorTxtSkill5',
                                        'placeholder' => 'Last Use',
                                        'data-error' => '.errorTxtCom21',
                                    ));
                                    ?>
                                    <div class="errorTxtCom21"></div>
                                    <?php echo form_error('emer_number'); ?>
                                </div>
                            </div>

                            <div class="col-sm-3">
                                <div class="input-field">
                                    <?php echo form_label(lang('emergency_email'), 'emergency_email', array('for' => 'emergency_email')); ?>
                                    <?php
                                    echo form_input(array(
                                        'type' => 'email',
                                        'id' => 'emergency_email',
                                        'name' => 'emergency_email',
                                        'data-error' => '.errorTxtSkill5',
                                        'placeholder' => 'Last Use',
                                        'data-error' => '.errorTxtCom22',
                                    ));
                                    ?>
                                    <div class="errorTxtCom22"></div>
                                    <?php echo form_error('emer_number'); ?>
                                </div>

                            </div>
                            <div class="col-sm-2 ">
                                <label class="margin-top-5">Preference</label>
                                <?php echo form_checkbox(array('id' => 'preference_id', 'name' => 'preference_id', 'placeholder' => 'Preference', 'style' => 'margin-left:25px !important; top: 25px;')); ?>
                                <div class="input-field">
                                    <?php // echo form_label(lang('preference'), 'preference', array('for' => 'preference')); ?>

                                    <!--<div class="errorTxtCom22"></div>-->
                                    <?php echo form_error('preference'); ?>
                                </div>                                        
                            </div>
                            <div class="col-sm-1">
                                <!--<p><label>Action</label></p>-->
                                <i class="fa fa-plus text-info add-row margin-top-20" > </i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12">
                    <!--                            <div class="row show_detail" >
                                                    
                                                    <div class="col-sm-3">
                                                        <p class=""><label>Number</label></p>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <p class=""><label>Name</label></p>
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <p class=""><label>Email</label></p>
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <p class=""><label>Select</label></p>
                                                    </div>
                                                </div>-->



                    <div class="clearfix"></div>

                    <?php if (isset($emergency_contact_details)) { ?>
                        <div class="emergencyu">
                            <?php foreach ($emergency_contact_details as $eme_result) {
                                ?>
                                <div class="<?php echo $eme_result['id']; ?>">


                                    <div class="col-sm-3">
                                        <?php // echo $eme_result['emergency_number'];    ?>
                                        <div class="input-field margin-top-0">
                                            <input data-error="" type='text' name='emergency_number-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_number'] ?>'>
                                            <div class=""></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-field margin-top-0">
                                            <?php // echo $eme_result['emergency_name'];    ?>
                                            <input data-error="errorTxtCom102" type='text' name='emergency_name-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_name'] ?>'>
                                            <div class="errorTxtCom102"></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <?php // echo $eme_result['emergency_email'];    ?>
                                        <div class="input-field margin-top-0">
                                            <input data-error="" type='email' name='emergency_email-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_email'] ?>'>
                                            <!--<input-->

                                            <div class=""></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-1">
                                        <?php
                                        $pre = '';
                                        $data = "preferenceChecked('preference-u-" . $eme_result['id'] . "')";
                                        if ($eme_result['preference'] == '1')
                                            $pre = "'checked' => 'TRUE'";
                                        ?>
                                        <?php
                                        echo form_checkbox(array('id' => 'preference-u-' . $eme_result['id'],
                                            'name' => 'preference-u-' . $eme_result['id'],
                                            'class' => 'margin-left-25',
                                            'checked' => $pre,
                                            'value' => $eme_result['preference'],
                                            'onclick' => $data
                                        ));
                                        ?>
                                    </div>
                                    <div class="col-sm-2">
                                        <i class="fa fa-remove text-danger" onclick="deleteEmDiv(<?php echo $eme_result['id'] ?>)"></i>
                                    </div>

                                </div>
                                <div class="clearfix"></div>
                            <?php }
                            ?>
                        </div>
                    <?php } ?>  
                    <div class="emergency"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--Personal & Contact information modal end -->
<script>
    $("form").submit(function () {
        return this.some_flag_variable;
    });</script>

<script>
    $(document).ready(function () {


        $("#mySubmit").click(function () {
            alert('submit');
            return false;
        });
        $("#check_status").click(function () {

            var isChecked = $("#check_status").val();
            if (isChecked == 0) {
                $(".curr_add_id").hide();
                $("#check_status").val('1');
            } else {
                $(".curr_add_id").show();
                $("#check_status").val('0')
            }

        });
    });</script>

<script type="text/javascript">
    $(document).ready(function () {
        var i = <?php echo $emergency_contact_details ? count($emergency_contact_details) : 0 ?>;
        $("#emergency_contact_count").val(i);
        $(".add-row").click(function () {

            var preference = 0;
            var checked = '';
            /*to check preference*/
            if ($("#preference_id").is(":checked")) {
                alert('is check');
                preference = 1;
                checked = 'checked';
            }

            i = $("#emergency_contact_count").val();
            if (i == 5) {
                alert('Notice : Only upto 10 emergency contact can be add ');
                return false;
            }

            i++;

            var number = $("#emergency_number").val();
            var name = $("#emergency_name").val();
            var email = $("#emergency_email").val();
            $('#form_communication_id').validate();

            if (number == '' || name == '' || email == '') {
                alert('Emergencey contact fields can not be null!');
                return false;
            }

            //            show_detail
            $(".show_detail").show();
            var number = $("#emergency_number").val();
            var name = $("#emergency_name").val();
            var email = $("#emergency_email").val();
            $("#emergency_contact_count").val(i);
//                    functionName = 'preferenceChecked('+ "id" +i+')';
            functionName = "preferenceChecked(" + i + ")";
            var markup = "<div class='" + i + "'>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_number-" + i + "' value='" + number + "'>" + number + "</div>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_name-" + i + "' value='" + name + "'>" + name + "</div>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_email-" + i + "' value='" + email + "'>" + email + "</div>\n\
                            <div class='col-sm-1'><input type='hidden' name='preference-" + i + "' id='pre" + i + "' value='" + preference + "'><input type='checkbox' class='margin-left-25' id='" + i + "'   value='" + preference + "' " + checked + " onclick='" + functionName + "'  ></div>\n\
                            <div class='col-sm-2'><i class='fa fa-remove text-danger' onclick='deleteEmDiv(" + i + ")'></i></div></div>";
            $(".emergency").append(markup);
            $("#emergency_number").val('');
            $("#emergency_name").val('');
            $("#emergency_email").val('');
        });



        // Find and remove selected table rows
        $(".delete-row").click(function () {
            i = $("#emergency_contact_count").val();
            if (i > 0)
                i--;

            $("table tbody").find('input[name="record"]').each(function () {
                if ($(this).is(":checked")) {
                    $("#emergency_contact_count").val(i);
                    $(this).parents("tr").remove();
                }
            });
        });


    });



</script>

<script>

    var $ctra = 1;
    var $ctrachild = 1;
    var i = 0;
    var cur_sele = <?php echo $language_details ? 0 : 1 ?>;
    $('#not_in_id').val(cur_sele);

    var cur_child_sele = <?php echo $child_details ? count($child_details) : 0 ?>;
//            alert(cur_child_sele);
    $('#child_count').val(cur_child_sele);
    //    function add() {
    //
    //
    //
    //
    //
    //    }

    function removeDiv(dId) {
        //        if()
        cur_sele--;
        $('#not_in_id').val(cur_sele);
        var ni = document.getElementById('myDiv');
        ni.removeChild(document.getElementById(dId));
        return false;
    }

    /* Delete language */
    function deleteDiv(dId) {
        //        if()

        $("div").remove("#remove" + dId);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/delete_emp_language',
            data: {'emp_lang_id': dId},
            success: function (data) {
            }
        });
        return false;
    }


    function deleteEmDiv(dId) {
        //        if()
        i = $("#emergency_contact_count").val();
        i--;

        $("#emergency_contact_count").val(i);
        $("div").remove("." + dId);
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/delete_emergency_contact',
            data: {'emergency_id': dId},
            success: function (data) {
            }
        });
        return false;
    }

    /* Add Language Details */
    function add()
    {
        var i = <?php echo $language_details ? count($language_details) : 0 ?>;
        //to get total language count
        cur_sele++;
        //        cur_sele =  $('#not_in_id').val(cur_sele);

        var ni = document.getElementById('myDiv');
        var numi = document.getElementById('theValue');
        var num = (document.getElementById('theValue').value - 1) + 2;
        numi.value = num;
        var newdiv = document.createElement('div');
        var divIdName = 'my' + num + 'Div';
        newdiv.setAttribute('id', divIdName);
        //var cur_sele = $('#language_id').val();
        //if (cur_sele) {


        //}

        //        var not_in_langiage_id = $('#not_in_id').val();
        $('#not_in_id').val(cur_sele);
        $.ajax({
            type: "POST",
            //            data: {not_in_langiage_id: not_in_langiage_id},
            url: '<?php echo base_url(); ?>employee/getAllLanguage',
            success: function (data) {
                newdiv.innerHTML = "<div class='row margin-bottom-10' ><div " + "class=col-sm-3 " + "> \n\
                        <select id='language_id-" + cur_sele + "' name='language_id-" + cur_sele + "' " + " class=browser-default " + "> " + data.language_list + " </select> </div> \n\
                        <div " + "class=col-sm-3 " + "> <select id='proficiency_id-" + cur_sele + "'  name='proficiency_id-" + cur_sele + "' " + " class=browser-default " + "> " + data.proficiency_list + " </select> </div>"
                        + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[1]' size=20 > </div>" + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[2]' size=20 > </div>" + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[3]' size=20 > </div>" +
                        "<div " + "class=col-sm-2 " + "><i class='fa fa-remove text-danger' onclick=\"removeDiv('" + divIdName + "');\"></i></div></div>";
                if ($ctra < 100) {
                    ni.appendChild(newdiv);
                    $ctra++;
                }
                $total = $ctra;
                ;
            }
        });
    }
    /*Add childer details*/
    function addChild()
    {
        if (cur_child_sele > 4)
            return false;

        var i = <?php echo $child_details ? count($child_details) : 0 ?>;
        //to get total language count
        cur_child_sele = $('#child_count').val();
        cur_child_sele++;
        //        cur_sele =  
        //        cur_sele =  


        var ni = document.getElementById('myDivChild');
        var numi = $('#theValueChild').val();//document.getElementById('');
        var num = (document.getElementById('theValueChild').value - 1) + 2;
        numi.value = num;
        var newdiv = document.createElement('div');
        var divIdName = 'my' + num + 'DivChild';
        newdiv.setAttribute('id', divIdName);

        $('#child_count').val(cur_child_sele);

        newdiv.innerHTML = "<div id='ch-" + cur_child_sele + "'><div class='row' >\n\
                                    <div class='col-sm-5'><input placeholder='Child Name' id='child_name-" + cur_child_sele + "' name='child_name-" + cur_child_sele + "'></div>\n\
                                    <div class='col-sm-5'><input type='date' id='child_dob-" + cur_child_sele + "' name='child_dob-" + cur_child_sele + "' placeholder='Date of Birth'></div>\n\
                                    <div class='col-sm-2'><i class='fa fa-remove text-danger' onclick=\"removeChDiv('" + cur_child_sele + "');\"></i></div>\n\
                                    </div></div>";

        if ($ctrachild < 100) {
            ni.appendChild(newdiv);
//                    $("#child_dob-1").addClass("datepicker");
            $ctrachild++;
        }
        $total = $ctrachild;

    }

    function removeChDiv(dId) {
        //        if()
//                alert(dId);
        cur_child_sele = $('#child_count').val();
        cur_child_sele--;
        $('#child_count').val(cur_child_sele);
        $('#ch-' + dId).remove();
//                var ni = document.getElementById('myDivChild');
//                ni.removeChild(document.getElementById(dId));
        return false;
    }

    function deleteChDIv(dId) {
        //        if()
        i = $("#child_count").val();
        i--;
        var child_id = dId;
        $("#child_count").val(i);
        $('#ch-u-' + dId).remove();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/delete_child',
            data: {'child_id': dId},
            success: function (data) {
            }
        });
        return false;
    }
    /*Checkbox cheked*/
    function preferenceChecked(prefId) {
//                alert(prefId);
        if ($('#' + prefId).is(":checked")) {
            $('#pre' + prefId).val(1);
            pre
            $('#' + prefId).val(1);
        }
        else {
            $('#' + prefId).val(0);
            $('#pre' + prefId).val(0);
        }
    }

</script>

<!--City country State-->
<script>

    $('select[name="country_id"]').change(function () {
        var country_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getStateList',
            data: {'country_id': country_id},
            success: function (data) {
                if (data) {
                    $('select[name="state_id"]').html(data.content).trigger('liszt:updated').val(country_id);
                    $('#state_id').material_select();
                }
            }
        });
    });

    $('select[name="state_id"]').change(function () {
        var state_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getCityList',
            data: {'state_id': state_id},
            success: function (data) {
                if (data) {
                    $('select[name="city_id"]').html(data.content).trigger('liszt:updated').val(state_id);
                    $('#city_id').material_select();
                }
            }
        });
    });

    $('select[name="c_country_id"]').change(function () {
        var country_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getStateList',
            data: {'country_id': country_id},
            success: function (data) {
                if (data) {
                    $('select[name="c_state_id"]').html(data.content).trigger('liszt:updated').val(country_id);
                    $('#c_state_id').material_select();
                }
            }
        });
    });
    $('select[name="c_state_id"]').change(function () {
        var state_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getCityList',
            data: {'state_id': state_id},
            success: function (data) {
                if (data) {
                    $('select[name="c_city_id"]').html(data.content).trigger('liszt:updated').val(state_id);
                    $('#c_city_id').material_select();
                }
            }
        });
    });

</script>
<!--End of country city state-->

<script>
    $('select[name="marital_status"]').change(function () {
        var ms_name = $('#marital_status option:selected').text();//$(this).val();
        //        alert(country_id);
        if (ms_name == 'Married') {
            $('#anniversary_id').show();
            $('#child_id').show();
        } else {
            $('#anniversary_id').hide();
            $('#child_id').hide();
        }
        return false;
    });
</script>