<!-- 1st document here -->
<?php $i = 1; ?>
<?php if (isset($document_details)) { ?>
    <?php foreach ($document_details as $result) { ?>
        <div class="col-sm-4"> 
            <div class="document-bg text-center">

                <div class="pull-right">
        <!--                    <a data-toggle="modal" href="#document-Modal-2-v-<?php echo $result['id'] ?>">  
                        <i class="fa fa-pencil-square-o text-info font-size-18"></i>
                    </a>-->
                </div>


                                <!--<p class="margin-bottom-10 badge badge-secondary"><?php echo $result['tag']; ?></p>-->

                <p><small class="text-bold"><?php echo substr($result['name'], 8); ?></small></p>
                <p> <small class="">on: <?php echo date('Y M d', strtotime($result['createddate'])); ?></small></p>

                <p> <small class=" border-bottom ">by: <?php echo $this->employeesummary->get_user_fullname($result['createdby'] ? $result['createdby'] : $result['modifiedby']); ?></small></p>
                <a class="preview" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents<?php echo $result['attachments']; ?>" rel="prettyPhoto">
                    <small class="fa fa-download text-secondary"></small> | 
                    <?php if ($result['type'] == 'pdf') { ?>
                        <i class="fa fa-file-pdf-o fa-2x text-secondary"></i> 
                    <?php } elseif ($result['type'] == 'jpeg' || $result['type'] == 'png') { ?>
                        <i class="fa fa-file-image-o fa-2x text-secondary"></i>                     
                    <?php } elseif ($result['type'] == 'doc' || $result['type'] == 'docx') { ?>
                        <i class="fa fa-file-word-o fa-2x text-secondary"></i> 
                    <?php } else { ?>
                        <i class="fa fa-file-code-o fa-2x text-secondary"></i> 
                    <?php } ?>



                </a>

                | <small class=""><label class="label label-secondary "><?php echo substr(strtolower($result['tag']), 0, 4); ?></label></small> 
                <!--                <div class="padding-top-10">
                                    
                                    <a href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents<?php echo $result['attachments']; ?>" download>  
                                        <i class="fa fa-download text-warning-2 font-size-18"></i>
                                        
                                    </a> 
                                    
                                </div>-->
            </div>
        </div>
        <!-- 1st document here -->


        <!-- card document display -->
        <?php if ($i == 3) { ?>
            <div class="clearfix"></div>
        <?php } ?>
        <?php
        $i++;
    }
    ?>
<?php } else { ?>
    <?php $this->load->view('official/_no_data_found'); ?>    
<?php } ?>
<!-- 1st document here -->