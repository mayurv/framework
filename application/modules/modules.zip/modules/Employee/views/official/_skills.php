<!-- skill experience modal start -->
<div class="modal fade" id="skill-exp-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">                
                <button type="button" class="close cls" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Skill</h4>
            </div>
            <div class="loader" style="display: none"></div>
            <div class="modal-body">

                <div class="user-normal-slim">

                    <div class="">               
                        <?php echo form_open('employee/skills/add/' . $user_summary['user_id'], array('id' => 'form_validate_skills_id', 'class' => 'form_validate_skills_id')); ?>
                        <!-- 1st row start here -->
                        <div class="row">

                            <div class="col-sm-12">
                                <?php echo form_label(lang('skills_id'), 'skills_id', array('for' => 'skills_id')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'skills_id', 'name' => 'skills_id', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill1'), $skills_list);
                                ?>
                                
                                <div class="input-field">
                                    <div class="errorTxtSkill1"></div>
                                </div>
                                <?php echo form_error('skills_id'); ?>                                             
                            </div>
                            <div class="clearfix"></div> 

                            <div class="col-sm-6">
                                <?php echo form_label(lang('years_exp'), 'years_exp', array('for' => 'years_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'years_exp', 'name' => 'years_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill2'), $yearsexp);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtSkill2"></div>
                                </div> 
                                
                                <?php echo form_error('yearsofexp'); ?>
                            </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('months_exp'), 'months_exp', array('for' => 'months_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'months_exp', 'name' => 'months_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill3'), $monthsexp);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtSkill3"></div>
                                </div> 
                                <?php echo form_error('months_exp'); ?>
                            </div>
                            <div class="clearfix"></div> 





                            <div class="col-sm-12">
                                <?php echo form_label(lang('competency_level'), 'competency_level', array('for' => 'competency_level')); ?>

                                <?php
                                echo form_dropdown(array('id' => 'competency_level', 'name' => 'competency_level', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill4'), $compentency_level);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtSkill4"></div>
                                </div>
                                <?php echo form_error('competency_level'); ?>

                            </div>


                            <div class="clearfix"></div> 

                            <div class="col-sm-6">
                                <?php echo form_label(lang('last_years_exp'), 'last_years_exp', array('for' => 'last_years_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'last_years_exp', 'name' => 'last_years_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill6'), $years_list);
                                ?>
                                <div class="input-field">
                                    <div class="last_years_exp"></div>
                                </div> 
                                <div class="input-field">
                                <div class="errorTxtSkill6"></div>
                                </div>
                                <?php echo form_error('last_years_exp'); ?>
                            </div>

                            <div class="col-sm-6">
                                <?php echo form_label(lang('last_months_exp'), 'last_months_exp', array('for' => 'last_months_exp')); ?>
                                <?php
                                echo form_dropdown(array('id' => 'last_months_exp', 'name' => 'last_months_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill7'), $months_list);
                                ?>
                                <div class="input-field">
                                    <div class="errorTxtSkill6"></div>
                                </div> 
                                <?php echo form_error('last_months_exp'); ?>
                            </div>

                            <div class="clearfix"></div>
                            
                            <input type="hidden" value="" id="ajaxPostId" name="ajaxPostId">

                            <div class="col-sm-12 padding-top-10 text-right">
                                <button type="submit" class="btn btn-warning2 btn-sm ">Submit</button>
                                <button type="button" class="btn btn-warning2 btn-sm " id="submit_skill">Submit & Add new</button>
                                <button type="reset" class="btn btn-default btn-sm">Reset</button>
                            </div>
                        </div>
                        <!-- 1st row end here -->
                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- skill experience modal end -->

<script>
    $(document).ready(function () {
        $('.year_last_use').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });
    });
</script>

<!--Upload Skills Submit & Add new-->
<script>
    $(document).ready(function () {
        /*For ajax upload */
        var options = {
            beforeSubmit: showRequest, // pre-submit callback 
            success: showResponse, // post-submit callback 

            url: '<?php echo base_url(); ?>employee/skills/add/' +<?php echo $user_summary['user_id'] ?>, // override for form's 'action' attribute
            type: 'post', // 'get' or 'post', override for form's 'method' attribute 
            clearForm: true, // clear all form fields after successful submit 
//            resetForm: true, // reset the form after successful submit 

        };

        $('#submit_skill').click(function () {

            var validateReuslt = $("#form_validate_skills_id").valid();
            $("#ajaxPostId").val('ajaxPost');

            if ($("#form_validate_skills_id").valid())
                $("#form_validate_skills_id").ajaxSubmit(options);
            else
                return false;

        });
     
        
        function showResponse(responseText, statusText, xhr, $form) {
            $('.loader').hide();
            $('.modal-body').removeClass('overlay');

            //response  
            //     last_months_exp
            $("#skills_id").val($("#skills_id option:first").val());
            $("#years_exp").val($("#years_exp option:first").val());
            $("#months_exp").val($("#months_exp option:first").val());
            $("#competency_level").val($("#competency_level option:first").val());
            $("#last_years_exp").val($("#last_years_exp option:first").val());
            $("#last_months_exp").val($("#last_months_exp option:first").val());

            var parsed = $.parseJSON(responseText);
            $('.skill_display').html(parsed.skill_cards);

            $("div").removeClass('error');
            showSuccess("Record Addedd successfully");
            return true;
        }
        // pre-submit callback 
        function showRequest(formData, jqForm, options) {
            //response
            $('.modal-body').addClass('overlay');
            $('.loader').show();

            return true;
        }


    });
</script>
<script>

    $(document).ready(function () {
        $(".close").on('click', function () {
            
            $('.input-field .error').html('');
            $('select').removeClass('error');
            $('input').removeClass('error');
            $("div").removeClass("error");
            $("#skills_id-error").removeClass("error");
        });
       




    });
</script>
