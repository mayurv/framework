<!-- Certification modal start -->
<div class="modal fade" id="passport-visa-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Certification</h4>
            </div>
            <div class="modal-body">
                <div>                                                             
                    <form>
                        <!-- 1st row start here -->
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="p-title margin-bottom-20">Passport Details</div>
                            </div>

                            <div class="col-sm-6">

                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'passport_number',
                                        'class' => 'validate',
                                        'placeholder' => 'Passport Number'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('passport_number'), 'passport_number'); ?>
                                    <?php echo form_error('passport_number'); ?>
                                </div> 
                            </div>

                            <div class="col-sm-6 ">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'passport_issue_date',
                                        'class' => 'datepicker validate',
                                        'placeholder' => 'Passport Number'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('passport_issue_date'), 'passport_issue_date'); ?>
                                    <?php echo form_error('passport_issue_date'); ?>
                                </div>
                            </div>

                            <div class="clearfix"></div> 

                            <div class="col-sm-6 ">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'ExpiryDate',
                                        'class' => 'datepicker validate',
                                        'placeholder' => 'Passport Expiry'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('passport_expiry_date'), 'passport_expiry_date'); ?>
                                    <?php echo form_error('passport_expiry_date'); ?>                                    
                                </div>
                            </div>

                            <div class="col-sm-12">
                                <div class="p-title margin-bottom-20">Visa Details</div>
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'visa_number',
                                        'class' => 'validate',
                                        'placeholder' => 'Passport Expiry'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('visa_number'), 'visa_number'); ?>
                                    <?php echo form_error('visa_number'); ?>
                                </div>  
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'name' => 'visa_type',
                                        'class' => 'validate',
                                        'placeholder' => 'Visa Type'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('visa_type'), 'visa_type'); ?>
                                    <?php echo form_error('visa_type'); ?>

                                </div>  
                            </div>

                            <div class="col-sm-6 ">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'visa_issue_date',
                                        'class' => 'datepicker validate',
                                        'placeholder' => 'Issue Date'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('visa_issue_date'), 'visa_issue_date'); ?>
                                    <?php echo form_error('visa_issue_date'); ?>
                                    
                                </div>
                            </div>

                            <div class="col-sm-6 ">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'visa_issue_date',
                                        'class' => 'datepicker validate',
                                        'placeholder' => 'Issue Date'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('visa_issue_date'), 'visa_issue_date'); ?>
                                    <?php echo form_error('visa_issue_date'); ?>
                                    
                                </div>
                            </div>

                            <div class="col-sm-6 ">
                                <div class="input-field">
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'visa_expiry_date',
                                        'class' => 'datepicker validate',
                                        'placeholder' => 'Expiry Date'
                                    ));
                                    ?>
                                    <?php echo form_label(lang('visa_expiry_date'), 'visa_expiry_date'); ?> 
                                    <?php echo form_error('visa_expiry_date'); ?>
                                    
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="input-field">
                                    <?php
                                    echo form_dropdown(array('id' => 'c_country_id', 'name' => 'c_country_id'), $country_list);
                                    ?>
                                    <?php echo form_label(lang('country_id'), 'country_id'); ?>
                                    <?php echo form_error('country_id'); ?> 

                                </div> 
                            </div> 

                            <div class="clearfix"></div>

                            <div class="col-sm-12 padding-top-10">
                                <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                            </div>
                        </div>
                        <!-- 1st row end here -->
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Education modal end -->  