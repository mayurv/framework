<!-- Document Details -->
<?php if (isset($education_details)) { ?>
    <?php foreach ($education_details as $result) { ?>
        <div class="modal fade" id="document-Modal-2-v-" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Document</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <?php
                            echo form_open_multipart('employee/document/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_validate_document_id_' . $result['id'], 'class' => 'form_validate_document_id_' . $result['id']));
                            ?>
                            <!-- 1st row start here -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('document_title'), 'institute_name'); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'document_title',
                                            'name' => 'document_title',
                                            'placeholder' => 'Document Title',
                                            'value' => set_value('document_title', $result['document_title']),
                                            'data-error' => '.errorTxtDoc1'
                                        ));
                                        ?>
                                        <div class="errorTxtDoc1"></div>
                                        <?php echo form_error('institute_name'); ?>
                                    </div> 
                                </div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('document_type'), 'document_type', array('for' => 'document_type')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'document_type', 'name' => 'document_type', 'class' => 'browser-default', 'data-error' => '.errorTxtDoc2'), $document_type);
                                    ?>	
                                    <div class="input-field">
                                        <div class="errorTxtDoc2"></div>
                                    </div> 
                                    <?php echo form_error('document_type'); ?>
                                </div> 



                                <div class="clearfix"></div>


                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <div class="file-field input-field">
                                        <div class="btn btn-primary btn-sm margin-top-10">Browse
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'id' => 'common_doc',
                                                'name' => 'common_doc',
                                                'class' => 'form-control',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                                'data-error' => '.errorTxtDoc3'
                                            ));
                                            ?>
                                        </div>

                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $result['document_id']),
                                        ));
                                        ?>

                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'id' => 'common_doc',
                                                'name' => 'common_doc',
                                                'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                                'placeholder' => 'type ( pdf, doc, docx,  jpeg, jpg)',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                            ));
                                            ?>
                                        </div>
                                        <div class="errorTxtDoc3"></div>
                                    </div>      
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10">
                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                            

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- document modal end -->