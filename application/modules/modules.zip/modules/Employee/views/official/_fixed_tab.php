<div class="content-body" style="height: 500px !important;">
    <div class="row">
            <table class="table">
                <thead>
                    <!--hr/employee/addofficial/-->
                        <?php // echo $c_emp_summary->user_id ?>
                    <tr><th scope="row" ><a href="<?php echo base_url(); ?>employee/addofficial" disabled="disabled">Official</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/contactinfo/">Personal / Contact</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/document/">Document</a></th>

<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/holidays">Holiday</a></th>-->
<!--<th scope="row"><a href="<?php echo base_url(); ?>hr/leaves">Leaves</a></th>-->

                        <th scope="row"><a href="<?php echo base_url(); ?>employee/skills/">Skills</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/jobhistory/">Job History</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/experience/">Experience</a>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/education/">Education</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/certificate/">Certificate</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/visa/">Visa</a></th></tr>
                </thead>
            </table>
    </div>
</div>