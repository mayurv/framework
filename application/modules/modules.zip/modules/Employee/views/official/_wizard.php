<!--wizard javascript end here --> 
<div class="col-sm-12">
    <div class="main-bg padding-lt-rt-top">

        <!-- Smart Wizard -->
        <div id="wizard" class="swMain">
            <ul>
                <li>
                    <a href="#step-1">
                        &nbsp;                                                

                        <div class="sw-lbl-bottom">Official </div>
                    </a>
                </li>
                <li>
                    <a href="#step-2">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Personal </div>
                    </a>
                </li>
                <li>
                    <a href="#step-3">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Documents </div>
                    </a>
                </li>
                <li>
                    <a href="#step-4">
                        &nbsp; 

                        <div class="sw-lbl-bottom-2">Job History </div>
                    </a>
                </li>
                <li>
                    <a href="#step-5">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Experience </div>
                    </a>
                </li>
                <li>
                    <a href="#step-9">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Skills </div>
                    </a>
                </li>
                <li>
                    <a href="#step-6">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Education </div>
                    </a>
                </li>
                <li>
                    <a href="#step-7">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Certification </div>
                    </a>
                </li>
                <li>
                    <a href="#step-8">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Visa</div>
                    </a>
                </li>                                                
            </ul>

            <!-- official information -->
            <div id="step-1"> 
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Official information</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <?php form_open_multipart('employee/addofficial'); ?>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'name' => 'employeeid',
                                                            'id' => 'employeeid',
                                                            'placeholder' => 'MWX' . $empId,
                                                            'value' => 'MWX-' . $empId,
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('employeeid'), 'employeeid'); ?>

                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();

                                                        foreach ($prefix as $category)
                                                            $options[$category['id']] = $category['prefix'];
                                                        echo form_dropdown(array('id' => 'prefix_id', 'name' => 'prefix_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('prefix_id'), 'prefix_id'); ?>
                                                    </div> 
                                                </div>

                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'type' => 'text',
                                                            'name' => 'firstname',
                                                            'placeholder' => 'First Name'
                                                        ));
                                                        ?>

                                                        <?php echo form_label(lang('firstname'), 'firstname', array('class' => 'form-label')); ?>

                                                    </div> 
                                                </div> 

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'type' => 'text',
                                                            'name' => 'lastname',
                                                            'placeholder' => 'Last Name'
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('lastname'), 'lastname', array('class' => 'form-label')); ?>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();
                                                        foreach ($empmode as $category)
                                                            $options[$category['id']] = $category['mode'];
                                                        echo form_dropdown(array('id' => 'modeofemp_id', 'name' => 'modeofemp_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('modeofemp'), 'modeofemp'); ?>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();
                                                        foreach ($emprole as $category)
                                                            $options[$category['id']] = $category['rolename'];

                                                        echo form_dropdown(array('id' => 'emprole_id', 'name' => 'emprole_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('emprole'), 'emprole'); ?>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>

                                                            <option value="1">WS-001</option>
                                                            <option value="1">WS-002</option>
                                                            <option value="2">WS-003</option>               
                                                            <option value="4">WS-004</option>               
                                                            <option value="5">WS-005</option>               
                                                        </select>
                                                        <?php echo form_label(lang('work_station')); ?>
                                                        <label>Work Station</label>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'type' => 'text',
                                                            'name' => 'email',
                                                            'placeholder' => 'Email'
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('email'), 'email', array('for' => 'email', 'data-error' => 'wrong', 'data-success' => 'right')); ?>                                                        
                                                    </div> 
                                                </div>

                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">

                                                        <?php
                                                        $options = array();
                                                        foreach ($department as $category)
                                                            $options[$category['id']] = $category['deptname'];
                                                        echo form_dropdown(array('id' => 'department_id', 'name' => 'department_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('department_id'), 'department_id'); ?>

                                                    </div>
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php echo form_dropdown(array('id' => 'reporting_manager', 'name' => 'reporting_manager')); ?>
                                                        <?php echo form_label(lang('reportind_manager'), 'reportind_manager'); ?>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();
                                                        foreach ($jobtitle as $category)
                                                            $options[$category['id']] = $category['jobtitlename'];

                                                        echo form_dropdown(array('id' => 'jobtitle_id', 'name' => 'jobtitle_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('jobtitle'), 'jobtitle'); ?>

                                                    </div>
                                                </div> 

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php echo form_dropdown(array('id' => 'position_id', 'name' => 'position_id')); ?>
                                                        <?php echo form_label(lang('position_id'), 'position_id'); ?>
                                                    </div>
                                                </div> 

                                                <div class="col-sm-6">
                                                    <div class="input-field">                                                        
                                                        <?php
                                                        $options = array();
                                                        foreach ($emp_status as $category)
                                                            $options[$category['id']] = $category['emp_status'];
                                                        echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('emp_status_id'), 'emp_status_id'); ?>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">

                                                        <?php
                                                        echo form_input(array(
                                                            'name' => 'date_of_joining',
                                                            'id' => 'date_of_joining',
                                                            'data-format' => 'yyyy-mm-dd',
                                                            'class' => 'datepicker',
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('date'), 'date_of_joining'); ?>:
                                                    </div>  
                                                </div> 

                                                <!--                                                <div class="col-sm-6">
                                                                                                    <div class="input-field">
                                                                                                        <input type="text" placeholder="Date" class="datepicker"> 
                                                                                                        <label>Date of Release</label>           
                                                                                                    </div> 
                                                                                                </div>-->

                                                <div class="clearfix"></div>
                                                <div class="col-sm-4">
                                                    <div class="input-field">

                                                        <?php echo form_dropdown(array('id' => 'isactive', 'name' => 'isactive'), array('In-Active', 'Active'));
                                                        ?>
                                                        <?php echo form_label(lang('isactive'), 'isactive'); ?>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-4">
                                                    <div class="input-field">

                                                        <?php
                                                        $options = array();
                                                        foreach ($yearsexp as $category)
                                                            $options[$category['id']] = $category;
                                                        echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('yearsofexp'), 'yearsofexp'); ?>

                                                    </div> 
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();
                                                        foreach ($monthsexp as $category)
                                                            $options[$category['id']] = $category;
                                                        echo form_dropdown(array('id' => 'monthsofexp', 'name' => 'monthsofexp'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('monthsofexp'), 'monthsofexp'); ?>

                                                    </div> 
                                                </div>

                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="p-title margin-bottom-20">Leave</div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-4">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'name' => 'emp_leave_limit',
                                                            'id' => 'emp_leave_limit',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'leaves'
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('leave_limit'), 'emp_leave_limit'); ?>
                                                    </div> 
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-field">
                                                        <?php
                                                        echo form_input(array(
                                                            'name' => 'emp_leave_year',
                                                            'id' => 'emp_leave_year',
                                                            'class' => 'form-control',
                                                            'placeholder' => 'leaves'
                                                        ));
                                                        ?>
                                                        <?php echo form_label(lang('alloted_year'), 'alloted_year'); ?>
                                                    </div> 
                                                </div>
                                                <div class="col-sm-4">
                                                    <div class="input-field">
                                                        <input disabled value="10" id="disabled" type="text">
                                                        <label>Used Leave</label>
                                                    </div> 
                                                </div>

                                                <div class="clearfix"></div>



                                                <div class="col-sm-12">
                                                    <div class="p-title margin-bottom-20">Holiday</div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <?php
                                                        $options = array();
                                                        foreach ($holiday_group as $category)
                                                            $options[$category['id']] = $category['groupname'];
                                                        echo form_dropdown(array('id' => 'holiday_group_id', 'name' => 'holiday_group_id'), $options);
                                                        ?>
                                                        <?php echo form_label(lang('holiday_group_id'), 'holiday_group_id', array('class' => 'form-label')); ?>:
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="file" name="profileimage" size="20" />
                                                        <?php echo form_label(lang('profileimage'), 'profileimage', array('class' => 'form-label')); ?>:
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12 padding-top-10">
                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                </div>

                                            </div>
                                            <!-- 1st row end here -->                             
                                        <?php form_close();?>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>

            </div>
            <!-- official information -->

            <div id="step-2">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">
                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Personal & Contact information</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Male</option>
                                                            <option value="2">Female</option>
                                                        </select>
                                                        <label>Gender</label>
                                                    </div>
                                                </div>  
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>                                  
                                                            <option value="1">Single</option>
                                                            <option value="2">Married</option>
                                                        </select>
                                                        <label>Marital Status</label>
                                                    </div>  
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="" disabled selected>Choose your option</option>
                                                            <option value="1">India</option>

                                                        </select>
                                                        <label>Nationality</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="" disabled selected>Choose your option</option>
                                                            <option value="1">English</option>
                                                            <option value="2">Hindi</option>
                                                            <option value="2">Marathi</option>
                                                        </select>
                                                        <label>Language</label>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="" disabled selected>Choose your option</option>
                                                            <option value="1">Active</option>
                                                            <option value="2">Inactive</option>
                                                        </select>
                                                        <label>Status</label>
                                                    </div>  
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker"> 
                                                        <label>Date of Birth</label>           
                                                    </div>  
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6 ">
                                                    <div class="input-field">
                                                        <input type="email" placeholder="Email">
                                                        <label>Personal Email</label>
                                                    </div>
                                                </div>  
                                                <div class="col-sm-6 ">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Mobile">
                                                        <label>Personal Mobile</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="p-title margin-bottom-20">Permanent Address</div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Permanent address">
                                                        <label>Street Address</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">India</option>
                                                        </select>
                                                        <label>Country</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Maharashtra</option>
                                                            <option value="2">Gujrat</option>
                                                            <option value="2">Karnataka</option>
                                                        </select>
                                                        <label>State</label>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Pune</option>
                                                        </select>
                                                        <label>City</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Pin Code">
                                                        <label>Pin Code</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <input type="checkbox" id="test5" />
                                                    <label for="test5">Current Address Same Click</label>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="p-title margin-bottom-20">Current Address</div>
                                                </div>
                                                <div class="clearfix"></div>


                                                <div class="col-sm-12">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Permanent address">
                                                        <label>Street Address</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">India</option>
                                                        </select>
                                                        <label>Country</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Maharashtra</option>
                                                            <option value="2">Gujrat</option>
                                                            <option value="2">Karnataka</option>
                                                        </select>
                                                        <label>State</label>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Pune</option>
                                                        </select>
                                                        <label>City</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Pin Code">
                                                        <label>Pin Code</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="p-title margin-bottom-20">Emergency Contact</div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Number">
                                                        <label>Number</label>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Name">
                                                        <label>Name</label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="email" placeholder="Email">
                                                        <label>Email</label>
                                                    </div>
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Active</option>
                                                            <option value="2">Iactive</option>
                                                        </select>
                                                        <label>Status</label>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                            </div>
                                            <!-- 1st row end here -->
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>

                </div>                                                
            </div>     

            <div id="step-3">

                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Document</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <!-- label here -->
                                                <div class="col-sm-4">

                                                    <div class="row">
                                                        <!-- <div class="col-sm-12">
                                                    <button type="button" class="btn btn-warning2 btn-sm">Add</button></div> -->

                                                        <form action="#" class="dropzone" id="dropzoneForm">
                                                            <div class="col-sm-12">
                                                                <div class="file-field input-field">
                                                                    <div class="btn btn-primary btn-sm margin-top-10">Browse
                                                                        <input name="file" type="file" multiple>
                                                                    </div>
                                                                    <div class="file-path-wrapper">
                                                                        <input class="file-path" multiple type="text" placeholder="Upload one or more files">
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="clearfix"> </div>
                                                            <div class="col-sm-12">
                                                                <div class="input-field">
                                                                    <select>
                                                                        <option value="1">pdf</option>
                                                                        <option value="2">text</option>
                                                                    </select>
                                                                    <label>Asign Tag</label>
                                                                </div> 
                                                            </div>

                                                            <div class="clearfix"> </div>
                                                            <div class="col-sm-12">
                                                                <button class="btn btn-warning2 btn-xs">Upload</button>
                                                            </div>
                                                        </form>


                                                        <div class="col-sm-12 margin-top-30"> 
                                                            <span class="tag label label-info"> Pdf</span>
                                                            <span class="tag label label-warning"> JPG</span>
                                                            <span class="tag label label-info"> PNG</span>
                                                            <span class="tag label label-info"> Docx</span>
                                                            <span class="tag label label-info"> Txt</span>
                                                            <span class="tag label label-info"> Xls</span>
                                                            <span class="tag label label-info"> Word</span>
                                                        </div>

                                                    </div>



                                                </div>
                                                <!-- label here -->
                                                <!-- drop file here -->
                                                <div class="col-sm-8">
                                                    <div class="border-gray">
                                                        <figure>
                                                            <img src="data/gallery/04.jpg" class="img-thumbnail" width="80px" height="80px" /> 
                                                            <figcaption>1.Gallery</figcaptin>
                                                        </figure>
                                                        <figure>
                                                            <img src="data/gallery/04.jpg" class="img-thumbnail" width="80px" height="80px" /> 
                                                            <figcaption>2.Gallery</figcaptin>
                                                        </figure>

                                                    </div>

                                                    <!--  <form action="#" class="dropzone" id="dropzoneForm">
                                                         <div class="fallback">
                                                             <input name="file" type="file" multiple />
                                                         </div>
                                                     </form> -->                                                          
                                                </div>
                                                <!-- drop file here -->
                                            </div>
                                            <!-- 1st row end here -->                             

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>


            </div>

            <div id="step-4">

                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Job History</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Manager</option>
                                                            <option value="2">Designer</option>
                                                            <option value="3">HR</option>
                                                        </select>
                                                        <label>Position</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">IT</option>
                                                            <option value="2">Design</option>
                                                            <option value="3">HR</option>
                                                        </select>
                                                        <label>Department</label>
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Manager</option>
                                                            <option value="2">VP</option>
                                                            <option value="3">HR</option>
                                                        </select>
                                                        <label>Job Title</label>
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Client">
                                                        <label>Client Name</label>         
                                                    </div>  
                                                </div>
                                                <div class="clearfix"></div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker">
                                                        <label>Start Date</label>         
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker">
                                                        <label>End Date</label>         
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12 padding-top-10">
                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                </div>

                                            </div>
                                            <!-- 1st row end here -->                             

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>



            </div>

            <div id="step-5">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Work Experience</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">                                           

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Company">
                                                        <label>Company Name</label>         
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="URL">
                                                        <label>Website</label>         
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Title">
                                                        <label>Designation</label>         
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker">
                                                        <label>From Date</label>         
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker">
                                                        <label>To Date</label>         
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Name">
                                                        <label>Reference Name</label>         
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Contact">
                                                        <label>Reference Contact </label>         
                                                    </div> 
                                                </div> 
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="email" placeholder="email">
                                                        <label>Reference Email</label>         
                                                    </div> 
                                                </div>
                                                <div class="clearfix"></div>

                                                <div class="col-sm-12">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Reason">
                                                        <label>Reason For Leaving</label>         
                                                    </div> 
                                                </div> 

                                                <div class="clearfix"></div>


                                                <div class="col-sm-12 padding-top-10">
                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                </div>

                                            </div>
                                            <!-- 1st row end here -->                             

                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>

            </div>

            <div id="step-9">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">
                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Skills</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">

                                                <div class="col-sm-6 ">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Skill">
                                                        <label>Skill Title</label>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker"> 
                                                        <label>Experience</label>           
                                                    </div>  
                                                </div> 
                                                <div class="clearfix"></div> 

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <select>
                                                            <option value="1">Expert</option>
                                                        </select>
                                                        <label>Competency Level</label>
                                                    </div> 
                                                </div> 

                                                <div class="col-sm-6">
                                                    <div class="input-field">
                                                        <input type="text" placeholder="Date" class="datepicker"> 
                                                        <label>Year skill last use</label>           
                                                    </div>  
                                                </div>

                                                <div class="clearfix"></div>

                                                <div class="col-sm-12 padding-top-10">
                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                </div>
                                            </div>
                                            <!-- 1st row end here -->
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>

                </div>                                                
            </div>    

            <div id="step-6">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Education</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <div class="col-sm-12">

                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Education Level</th>
                                                                <th>School/ Institute</th>
                                                                <th>Course Name</th>
                                                                <th>From Date</th>
                                                                <th>To Date</th>
                                                                <th>Percentage</th>
                                                                <th>&nbsp;</th>
                                                                <th>&nbsp;</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Education Lavel">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="School Name">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Course Name">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Percentage">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-plus-square padding-top-15"></i>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-minus-square padding-top-15"> </i>
                                                                </td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>

                                            </div>
                                            <!-- 1st row end here -->                             
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>

            </div>

            <div id="step-7">
                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Certification</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-1">
                                        <form>
                                            <!-- 1st row start here -->
                                            <div class="row">
                                                <div class="col-sm-12">

                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Course Name</th>
                                                                <th>Description</th>
                                                                <th>Course Level</th>
                                                                <th>Course Offered by</th>
                                                                <th>Certification name</th>
                                                                <th>Issued Date</th>
                                                                <th>&nbsp;</th>
                                                                <th>&nbsp;</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Course Name">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Description">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Course Level">   
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Course Offered by"> 
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Certification name"> 
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Issued Date" class="datepicker">
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-plus-square padding-top-15"></i>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-minus-square padding-top-15"> </i>
                                                                </td>
                                                            </tr>

                                                        </tbody>
                                                    </table>
                                                </div>

                                            </div>
                                            <!-- 1st row end here -->                             
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>                                                                                                               
            </div>

            <div id="step-8">

                <div class="row"> 
                    <div class="col-sm-12">
                        <div class="w-panel-bg">

                            <!--  panel start here -->
                            <div class="panel panel-default">
                                <div class="panel-heading all-padding-10">
                                    <div class="p-title">Passport Visa</div>
                                </div>
                                <div class="panel-body all-padding-0">
                                    <div class="office-info-2">

                                        <ul class="nav nav-tabs primary ">
                                            <li class="active">
                                                <a href="#p-passport" data-toggle="tab">
                                                    Passport
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#p-visa" data-toggle="tab">
                                                    Visa
                                                </a>
                                            </li>

                                        </ul>

                                        <div class="tab-content primary no-border">
                                            <div class="tab-pane fade in active" id="p-passport">

                                                <div class="row">
                                                    <div class="col-sm-8">
                                                        <form>
                                                            <!-- 1st row start here -->
                                                            <div class="row">

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Passport">
                                                                        <label>Full Name</label>         
                                                                    </div>  
                                                                </div>  

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Passport">
                                                                        <label>Passport Number</label>         
                                                                    </div>  
                                                                </div> 
                                                                <div class="clearfix"></div>

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                        <label>Passport Issued Date</label>         
                                                                    </div> 
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                        <label>Passport Expiry Date</label>         
                                                                    </div> 
                                                                </div> 
                                                                <div class="clearfix"></div>

                                                                <div class="col-sm-12 padding-top-10">
                                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                                </div>

                                                            </div>
                                                            <!-- 1st row end here -->                             

                                                        </form>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <form action="#">
                                                            <div class="col-sm-12">
                                                                <div class="file-field input-field">
                                                                    <div class="btn btn-primary btn-sm margin-top-10">File
                                                                        <input type="file" multiple>
                                                                    </div>
                                                                    <div class="file-path-wrapper">
                                                                        <input class="file-path" type="text" placeholder="Upload one or more files">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 padding-top-10">
                                                                <button class="btn btn-warning2 btn-sm">Upload</button>

                                                            </div>


                                                        </form>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="tab-pane fade" id="p-visa">

                                                <div class="row">
                                                    <div class="col-sm-8">
                                                        <form>
                                                            <!-- 1st row start here -->
                                                            <div class="row">

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Visa">
                                                                        <label>Visa Number</label>         
                                                                    </div>  
                                                                </div>  

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Passport">
                                                                        <label>Visa Type</label>         
                                                                    </div>  
                                                                </div> 
                                                                <div class="clearfix"></div>

                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                        <label>Visa Issued Date</label>         
                                                                    </div> 
                                                                </div>
                                                                <div class="col-sm-6">
                                                                    <div class="input-field">
                                                                        <input type="text" placeholder="Date" class="datepicker">
                                                                        <label>Visa Expiry Date</label>         
                                                                    </div> 
                                                                </div> 
                                                                <div class="clearfix"></div>

                                                                <div class="col-sm-12 padding-top-10">
                                                                    <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                                                                    <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                                                </div>

                                                            </div>
                                                            <!-- 1st row end here -->                             

                                                        </form>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <form action="#">
                                                            <div class="col-sm-12">
                                                                <div class="file-field input-field">
                                                                    <div class="btn btn-primary btn-sm margin-top-10">File
                                                                        <input type="file" multiple>
                                                                    </div>
                                                                    <div class="file-path-wrapper">
                                                                        <input class="file-path" type="text" placeholder="Upload one or more files">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 padding-top-10">
                                                                <button class="btn btn-warning2 btn-sm">Upload</button>

                                                            </div>


                                                        </form>
                                                    </div>
                                                </div>

                                            </div>                                                 


                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!--  panel end here -->
                        </div>
                    </div>
                </div>                                                                   
            </div>


        </div>
        <!-- End SmartWizard Content -->    
    </div>          
</div>

<script>
    $.ajax({
        url: 'getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });

    /*on load set dpartment & jobtitle names*/
    if ($("#jobtitle_id option:selected").text() != "") {
        $('#jobtitle_name').val($("#jobtitle_id option:selected").text());
    }
    if ($("#department_id option:selected").text() != "") {
        $('#department_name').val($("#department_id option:selected").text());
    }
    var department_id = $("select#department_id option:selected").val();
    $.ajax({
        type: "POST",
        url: '<?php echo base_url(); ?>employee/getReportingManager',
        data: {'department_id': department_id},
        success: function (data) {
//            $('select[name="reporting_manager"]').show();
            $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
            $('#reporting_manager').material_select();
        }
    });

    var jobtitle_id = $("select#jobtitle_id option:selected").val();

    $.ajax({
        type: "POST",
        url: '<?php echo base_url(); ?>employee/getPositionName',
        data: {'jobtitle_id': jobtitle_id},
        success: function (data) {
            $('.select-wrapper ul li').html();
            if (data) {
                $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                $('#position_id').material_select();
            }
        }
    });

</script>

<script>
    $(document).ready(function () {

        var emprole = '';

        //to set reporting manager name
        $("#reporting_manager").change(function () {
            $('#reporting_manager_name').val();
            if ($("#reporting_manager option:selected").text() != "") {
                $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
            }
        });

        $("#position_id").change(function () {
            $('#position_name').val();
            if ($("#position_id option:selected").text() != "") {
                $('#position_name').val($("#position_id option:selected").text());
            }
        });

        $("#emp_status_id").change(function () {
//            alert('hi');
            $('#emp_status_name').val();
            if ($("#emp_status_id option:selected").text() != "") {
                $('#emp_status_name').val($("#emp_status_id option:selected").text());
            }
        });

        $("#holiday_group_id").change(function () {
            $('#holiday_group_name').val();
            if ($("#holiday_group_id option:selected").text() != "") {
                $('#holiday_group_name').val($("#holiday_group_id option:selected").text());
            }
        });

        $("#prefix_id").change(function () {
            $('#prefix_name').val();
            if ($("#prefix_id option:selected").text() != "") {
                $('#prefix_name').val($("#prefix_id option:selected").text());
            }
        });

        $("#emprole_id").change(function () {
            $('#emprole_name').val();
            if ($("#emprole_id option:selected").text() != "") {
                $('#emprole_name').val($("#emprole_id option:selected").text());
            }
        });

        //to get reporting manager 
        $("#department_id").change(function () {


            if ($("#department_id option:selected").text() != "") {
                $('#department_name').val($("#department_id option:selected").text());
            }

            //if manager
            if ($("#emprole_id option:selected").val()) {
                emprole = $("#emprole_id option:selected").val();
            }


            $('#reporting_manager_name').val('');
            var department_id = $("select#department_id option:selected").val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getReportingManager',
                data: {'department_id': department_id, 'emprole': emprole},
                success: function (data) {
//                    $('select[name="reporting_manager"]').show();
                    $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);
                    $('#reporting_manager').material_select();

                }
            });
        });

        //to get position
        $("#jobtitle_id").change(function () {

            if ($("#jobtitle_id option:selected").text() != "") {
                $('#jobtitle_name').val($("#jobtitle_id option:selected").text());
            }
            var jobtitle_id = $("select#jobtitle_id option:selected").val();

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getPositionName',
                data: {'jobtitle_id': jobtitle_id},
                success: function (data) {
                    if (data) {
                        $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                        $('#position_id').material_select();
                    }
                }
            });
        });

    });

</script>