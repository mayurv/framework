<?php if (isset($project_allocation_details)) { ?>
    <?php foreach ($project_allocation_details as $result) { ?>
        <div style="top:7%;" class="modal fade" id="edit_project_allocation_<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Project Allocation</h4>
                    </div>
                    <div class="modal-body">
                        <div>
                            <?php
                            echo form_open('employee/empProjectAllocation/' . $result['id'], array('id' => 'form_edit_project_' . $result['id']));
                            ?>
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <div class="row">      

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('project_id'), 'project_id', array('for' => 'project_id')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'project_id',
                                        'name' => 'project_id',
                                        'class' => 'browser-default',
                                        'data-error' => '.errorPA1'), $project_list, set_value('project_id', $result['project_id']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorPA1"></div>
                                    </div> 
                                    <?php echo form_error('project_id'); ?> 
                                </div> 


                                <div class="clearfix"></div>


                                <div class="clearfix"></div>
                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('percentage_allocation'), 'percentage_allocation', array('for' => 'percentage_allocation')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'range',
                                            'min' => '0',
                                            'max' => '100',
                                            'name' => 'percentage_allocation',
                                            'id' => 'percentage_allocation',
                                            'value' => set_value('visa_type', $result['percentage_allocation']),
                                            'placeholder' => 'Percentage Project Allocation',
                                            'data-error' => '.errorPA2'
//                                            'class' => 'validate'
                                        ));
                                        ?>
                                        <div class="errorPA2"></div>
                                        <?php echo form_error('percentage_allocation'); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>

                                <input type="hidden" name="emp_id" value="<?php echo $user_summary['user_id'] ?>">

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button type="submit" class="btn btn-warning2 btn-sm " onclick="return validate_project_form(<?php echo $result['id'] ?>)">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                             
                            <?php echo form_close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>  
<?php } ?>