<!-- Experience Details -->




<div class="modal fade" id="work-exp-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Work Experience</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <?php
                    echo form_open_multipart('employee/experience/add/' . $user_summary['user_id'], array('id' => 'form_validate_experience_id', 'class' => 'form_validate_experience_id'));
                    ?>
                    <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                    <!-- 1st row start here -->
                    <div class="row">      

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'id' => 'company_name',
                                    'name' => 'company_name',
                                    'placeholder' => 'Company',
                                    'data-error' => '.errorTxtexp1'
                                ));
                                ?>
                                <?php echo form_label(lang('company_name'), 'company_name', array('for' => 'company_name')); ?>
                                <div class="errorTxtexp1"></div>
                                <?php echo form_error('company_name'); ?>
                            </div> 
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'id' => 'website_url',
                                    'name' => 'website_url',
                                    'placeholder' => 'URL',
                                    'data-error' => '.errorTxtexp2'
                                ));
                                ?>
                                <?php echo form_label(lang('website'), 'website', array('for' => 'website')); ?>
                                <div class="errorTxtexp2"></div>
                                <?php echo form_error('website'); ?>        
                            </div> 
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'id' => 'designation',
                                    'name' => 'designation',
                                    'placeholder' => 'Designation',
                                    'data-error' => '.errorTxtexp3'
                                ));
                                ?>
                                <?php echo form_label(lang('designation'), 'designation', array('for' => 'designation')); ?>
                                <div class="errorTxtexp3"></div>
                                <?php echo form_error('designation'); ?>
                            </div> 
                        </div> 

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'from_date',
                                    'name' => 'from_date',
                                    'class' => 'from_date',
                                    'placeholder' => 'Date',
                                    'data-error' => '.errorTxtexp4'
                                ));
                                ?>
                                <?php echo form_label(lang('from_date'), 'from_date', array('for' => 'designation')); ?>
                                <div class="errorTxtexp4"></div>
                                <?php echo form_error('from_date'); ?>

                            </div> 
                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'to_date',
                                    'name' => 'to_date',
                                    'class' => 'to_date',
                                    'placeholder' => 'Date',
                                    'data-error' => '.errorTxtexp5'
                                ));
                                ?>
                                <?php echo form_label(lang('to_date'), 'to_date', array('for' => 'to_date')); ?>
                                <div class="errorTxtexp5"></div>
                                <?php echo form_error('to_date'); ?>

                            </div> 
                        </div> 
                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'id' => 'reference_name',
                                    'name' => 'reference_name',
                                    'placeholder' => 'Reference Name',
                                    'data-error' => '.errorTxtexp6'
                                ));
                                ?>
                                <?php echo form_label(lang('reference_name'), 'reference_name', array('for' => 'reference_name')); ?>
                                <div class="errorTxtexp6"></div>
                                <?php echo form_error('reference_name'); ?>
                            </div> 
                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'id' => 'reference_contact',
                                    'name' => 'reference_contact',
                                    'placeholder' => 'Reference Contact',
                                    'data-error' => '.errorTxtexp7'
                                ));
                                ?>
                                <?php echo form_label(lang('reference_contact'), 'reference_contact', array('for' => 'reference_contact')); ?> 
                                <div class="errorTxtexp7"></div>
                                <?php echo form_error('reference_contact'); ?>
                            </div> 
                        </div> 

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'email',
                                    'id' => 'reference_email',
                                    'name' => 'reference_email',
                                    'placeholder' => 'Reference Email',
                                    'data-error' => '.errorTxtexp8'
                                ));
                                ?>
                                <?php echo form_label(lang('reference_email'), 'reference_email', array('for' => 'reference_email')); ?>
                                <div class="errorTxtexp8"></div>
                                <?php echo form_error('reference_email'); ?>
                            </div>

                        </div>
                        <div class="clearfix"></div>

                        <div class="col-sm-12">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'reason_leaving',
                                    'name' => 'reason_leaving',
                                    'placeholder' => 'Reason',
                                    'data-error' => '.errorTxtexp9'
                                ));
                                ?>
                                <?php echo form_label(lang('reason_leaving'), 'reason_leaving', array('for' => 'reference_contact')); ?>
                                <div class="errorTxtexp9"></div>
                                <?php echo form_error('reason_leaving'); ?>

                            </div> 
                        </div> 


                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'company_location',
                                    'name' => 'company_location',
                                    'class' => 'autocomplete',
                                    'placeholder' => 'Company Location',
                                    'data-error' => '.errorTxtexp10'
                                ));
                                ?>
                                <?php echo form_label(lang('company_location'), 'company_location', array('for' => 'company_location')); ?>
                                <div class="errorTxtexp10"></div>
                                <?php echo form_error('company_location'); ?>

                            </div> 
                        </div> 

                        <div class="col-sm-6">
                            <div class="input-field">

                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'id' => 'remark',
                                    'name' => 'remark',
                                    'placeholder' => 'Remark',
                                    'data-error' => '.errorTxtexp11'
                                ));
                                ?>
                                <?php echo form_label(lang('remark'), 'remark', array('for' => 'remark')); ?>
                                <div class="errorTxtexp11"></div>
                                <?php echo form_error('remark'); ?>

                            </div> 
                        </div>

                        <!--                        <div class="col-sm-6">
                                                    <div class="file-field input-field">
                                                        <div class="btn btn-primary btn-sm margin-top-10">Browse
                                                            <input name="profile_image" type="file" multiple>
                                                        </div>
                                                        <div class="file-path-wrapper">
                                                            <input class="file-path" multiple type="text" placeholder="Upload one or more files">
                                                        </div>
                                                    </div>
                                                </div>-->
                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('tag'), 'tag'); ?>
                            <?php
                            echo form_dropdown(array('id' => 'tag', 'name' => 'tag', 'class' => 'browser-default', 'data-error' => '.errorTxt12'), $tag_type);
                            ?>
                            <div class="input-field">
                                <div class="errorTxt12"></div>
                            </div> 
                            <?php echo form_error('tag'); ?>                                             
                        </div>

                        <div class="col-sm-6">
                            <div class="file-field input-field">
                                <div class="btn btn-default btn-sm margin-top-10">Browse
                                    <?php
                                    echo form_input(array(
                                        'type' => 'file',
                                        'id' => 'document',
                                        'name' => 'document',
                                        'class' => 'form-control',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                        'data-error' => '.errorTxtexp30'
                                    ));
                                    ?>
                                </div>


                                <div class="file-path-wrapper">
                                    <?php
                                    echo form_input(array(
                                        'id' => 'document',
                                        'name' => 'document',
                                        'class' => 'file-path',
//                                        'placeholder' => 'Upload one or more files',
                                        'placeholder' => '( pdf, doc, docx)',
//                                            'value' => set_value('education_doc', $result['education_doc']),
                                    ));
                                    ?>
                                </div>
                                <div class="errorTxtexp30"></div>
                            </div>      
                        </div>


                        <div class="clearfix"></div>
                        <!--<input name="tag_name" value="" id="tag_name">-->

                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" class="btn btn-warning2 btn-sm">Submit</button>
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>
                    <!-- 1st row end here -->                      
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- work experience modal end -->
<script>
    $(document).ready(function () {
        $('.from_date').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date()
        });
        $(".to_date").click(function () {
            $('.datepicker').pickadate();
            var date = new Date($('#from_date').val());
            $(".to_date").removeClass('datepicker');
            console.log(date);
            var fromDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            $('.to_date').pickadate({
                min: new Date(fromDate),
                selectYears: true,
                selectMonths: true,
                max: new Date()
            });
        });


    });
</script>

<script type="text/javascript">
    $(function () {

        function split(val) {
            return val.split(/,\s*/);
        }
        function extractLast(term) {
            return split(term).pop();
        }
        $("#company_location").autocomplete({
            source: function (request, response) {

                $.getJSON("<?php echo base_url(); ?>/employee/getAutocompleteLocation", {//Url of controller
                    term: extractLast(request.term)
                }, response);

            },
        });
    });

</script>
<style>
    .ui-autocomplete{ z-index: 99999 !important;}
</style> 

