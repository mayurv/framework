<?php // var_dump($language_list);die;  ?>
<!--Personal & Contact information modal start -->
<div class="modal fade" id="personal-info-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Personal & Contact information</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">
                    <?php
//                        var_dump($personal_detail);die;
                    $action = 'add/';
                    if ($personal_detail != NULL && !empty($personal_detail))
                        $action = 'edit/';
                    echo form_open_multipart('employee/contact/' . $action . $user_summary['user_id'], array('id' => 'form_communication_id'));
                    ?>
                    <?php
                    echo form_input(array('type' => 'hidden', 'name' => 'associate_id', 'value' => $user_summary['user_id']));
                    ?>
                    <?php
                    if ($personal_detail != NULL && !empty($personal_detail)) {
                        echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => 'edit'));
                    }
                    ?>
                    <!-- 1st row start here -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="p-title margin-bottom-20">Personal Details</div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-sm-6">
                            <?php echo form_label(lang('gender_id'), 'gender_id', array('for' => 'gender_id')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'gender_id', 'name' => 'gender_id'), $gender, set_value('gender_id', $personal_detail['gender_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtCom1'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtCom1"></div>
                            </div>
                            <?php echo form_error('gender_id'); ?>
                        </div>  

                        <div class="col-sm-6">
                            <?php echo form_label(lang('marital_status'), 'marital_status', array('for' => 'marital_status')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'marital_status', 'name' => 'marital_status'), $marital_list, set_value('marital_status', $personal_detail['marital_status_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtCom2'));
                            ?>
                            <div class="input-field">
                                <div class="errorTxtCom2"></div>
                            </div>  
                            <?php echo form_error('marital_status'); ?>
                        </div>

                        <div class="clearfix"></div>

                        <?php if ($personal_detail['marital_status_id'] == '2') { ?>
                            <div id="anniversary_id" style="display:block">
                            <?php } else { ?>    
                                <div id="anniversary_id" style="display:none">
                                <?php } ?>
                                <div class="col-sm-12">
                                    <?php echo form_label(lang('anniversary'), 'anniversary', array('for' => 'anniversary')); ?>
                                    <i class="fa fa-calendar"></i>
                                    <?php
                                    echo form_input(array(
                                        'type' => 'text',
                                        'name' => 'anniversary',
                                        'id' => 'anniversary',
                                        'class' => 'anniversary_cl',
                                        'value' => set_value('anniversary_date', date('d F, Y', strtotime($personal_detail['anniversary_date']))),
                                        'placeholder' => 'Anniversary Date',
                                        'required' => 'required'
                                    ));
                                    ?>

                                    <?php echo form_error('anniversary_date'); ?>
                                </div>
                            </div>


                            <div class="clearfix"></div>

                            <!--Child details-->
                            <?php if ($personal_detail['marital_status_id'] == '2') { ?>
                                <div id="child_id" style="display:block">
                                <?php } else { ?>    
                                    <div id="child_id" style="display:none">
                                    <?php } ?>

                                    <div class="col-sm-12">

                                        <label>Child Details</label>
                                        <div class="row ">
                                            <div class="col-sm-5">
                                                <p class=""><label>Name</label></p>
                                            </div>
                                            <div class="col-sm-5">
                                                <p class=""><label>Date of Birth</label></p>
                                            </div>
                                            <div class="col-sm-2">
                                                <p class=""><label>Remove</label></p>
                                            </div>
                                        </div>

                                        <?php // if (isset($language_details)) { ?>



                                        <div id="myDivChild"></div>
                                        <div id="theValueChild">
                                            <?php if (isset($child_details)) { ?>
                                                <?php foreach ($child_details as $details) { ?>
                                                    <!--child_dob-u--->
                                                    <div id="<?php echo 'ch-u-' . $details['id'] ?>">
                                                        <div class="row"> 

                                                            <div class="col-sm-5">
                                                                <?php
                                                                echo form_input(array(
                                                                    'name' => 'child_name-u-' . $details['id'],
                                                                    'id' => 'dob',
                                                                    'value' => set_value('child_name', $details['child_name']),
                                                                    'placeholder' => 'Child Name',
                                                                        //'data-error' => '.errorTxtCom5'
                                                                ));
                                                                ?>
                                                                <!--<div class="errorTxtCom5"></div>-->
                                                                <?php // echo form_error('dob'); ?>                                             

                                                            </div>

                                                            <div class="col-sm-5">


                                                                <?php
                                                                echo form_input(array(
                                                                    'type' => 'text',
                                                                    'name' => 'child_dob-u-' . $details['id'],
                                                                    'id' => 'child_dob-u-' . $details['id'],
                                                                    'value' => set_value('dob', date('d F, Y', strtotime($details['child_dob']))),
                                                                    'class' => 'child1'
//                                                                        'placeholder' => 'DOB',
                                                                        //'data-error' => '.errorTxtCom5'
                                                                ));
                                                                ?>
                                                                <!--<div class="errorTxtCom5"></div>-->
                                                                <?php // echo form_error('dob'); ?>                                             

                                                            </div>
                                                            <div class="col-sm-2">
                                                                <i class='fa fa-trash text-ccc margin-right-15' onclick="deleteChDIv(<?php echo $details['id'] ?>);"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            <?php } ?>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="btn btn-default btn-sm margin-bottom-20" onclick="addChild();">Add</div>
                                                <input type="hidden" id="child_count" value="" name="child_count"> 
                                            </div>
                                        </div>

                                    </div>
                                    <div class="clearfix"></div>
                                </div>


                                <div class="col-sm-6">
                                    <?php echo form_label(lang('nationality_id'), 'nationality_id', array('for' => 'nationality_id')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'nationality_id', 'name' => 'nationality_id'), $nationality_list, set_value('nationality_id', $personal_detail['nationality_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtCom3'));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtCom3"></div>
                                    </div>  
                                    <?php echo form_error('nationality_id'); ?>
                                </div> 


                                <div class="col-sm-6">    

                                    <div class="input-field">

                                        <?php echo form_label(lang('dob'), 'dob', array('for' => 'dob')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'dob',
                                            'id' => 'dob',
                                            'class' => 'dob',
                                            'value' => set_value('dob', date('d F, Y', strtotime($personal_detail['dob']))),
                                            'placeholder' => 'DOB',
                                            'data-error' => '.errorTxtCom5'
                                        ));
                                        ?>
                                        <div class="errorTxtCom5"></div>
                                        <?php echo form_error('dob'); ?>                                             
                                    </div>  
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('bloodgroup'), 'bloodgroup', array('for' => 'bloodgroup')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'blood_group_id', 'name' => 'blood_group_id'), $blood_groups, set_value('blood_group_id', $personal_detail['blood_group_id']), array('class' => 'browser-default', 'data-error' => '.errorTxtCom51'));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtCom51"></div>
                                    </div>  
                                    <?php echo form_error('blood_group_id'); ?>   
                                </div>



                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('identity_mark'), 'identity_mark', array('for' => 'identity_mark')); ?>
                                        <?php
                                        echo form_input(array(
                                            'name' => 'identity_mark',
                                            'value' => set_value('identity_mark', $personal_detail['identity_mark']),
                                            'placeholder' => 'Identity',
                                            'data-error' => '.errorTxtCom6'
                                        ));
                                        ?>
                                        <div class="errorTxtCom6"></div>
                                        <?php echo form_error('identity_mark'); ?>                                             
                                    </div>  
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('hobbies'), 'hobbies', array('for' => 'hobbies')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'hobbies', 'multiple' => 'multiple', 'name' => 'hobbies[]'), $hobbies, set_value('hobbies_id', $hobbies_detail), array('class' => 'browser-default', 'data-error' => '.errorTxtCom7'));
                                    ?>
                                    <?php echo form_error('hobbies'); ?>   
                                    <div class="input-field">
                                        <div class="errorTxtCom7"></div>
                                    </div>  
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="file-field input-field">
                                        <div class="btn btn-default btn-sm margin-top-5">Upload Profile Picture
                                            <?php
                                            echo form_input(array(
                                                'type' => 'file',
                                                'name' => 'profile_image',
                                                'id' => 'profile_image',
                                                'class' => 'form-control',
                                                'value' => set_value('profile_image', $personal_detail['profile_image']),
                                                'data-error' => '.errorTxtCom30'
                                            ));
                                            ?>

                                        </div>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'hidden',
                                            'name' => 'document_id',
                                            'class' => 'form-control',
                                            'value' => set_value('document_id', $personal_detail['document_id']),
                                        ));
                                        ?>

                                        <div class="file-path-wrapper">
                                            <?php
                                            echo form_input(array(
                                                'name' => 'profile_image',
                                                'id' => 'profile_image',
                                                'class' => 'file-path',
//                                                'placeholder' => 'Upload one or more files',
                                                'placeholder' => 'type (jpg, jpeg, png)',
                                                'value' => set_value('profile_image', $personal_detail['profile_image']),
                                            ));
                                            ?>
                                        </div>
                                        <div class="errorTxtCom30"></div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>


                                <!-- language bind here -->
                                <div class="col-sm-12">
                                    <div class="p-title margin-bottom-10">Language Known</div>
                                    <div class="row ">
                                        <div class="col-sm-3">
                                            <p class=""><label>Language</label></p>
                                        </div>
                                        <div class="col-sm-3">
                                            <p class=""><label>Proficiency</label></p>
                                        </div>
                                        <div class="col-sm-1">
                                            <p class=""><label>Read</label></p>
                                        </div>
                                        <div class="col-sm-1">
                                            <p class=""><label>Write</label></p>
                                        </div>
                                        <div class="col-sm-1">
                                            <p class=""><label>Speak</label></p>
                                        </div>
                                        <div class="col-sm-3"></div>

                                    </div>



                                    <?php if (isset($language_details)) { ?>

                                        <div id="myDiv2">
                                            <div id="myNaNDiv2">
                                                <!--Update Edit language--> 
                                                <?php
                                                $i = 1;
                                                $lang_cnt = count($language_details);
                                                ?>                                                
                                                <?php foreach ($language_details as $details) { ?>
                                                    <div id="<?php echo 'remove' . $details['id']; ?>">

                                                        <div class="row margin-bottom-10">
                                                            <div class="col-sm-3"> 
                                                                <?php
                                                                echo form_dropdown(array(
                                                                    'id' => 'language_id-u-' . $details['id'],
                                                                    'name' => 'language_id-u-' . $details['id'],
                                                                    'class' => 'browser-default',
                                                                    'data-error' => '.errorTxtedu1'), $language_list, set_value('language_id', $details['language_id']));
                                                                ?>	                                            
                                                            </div> 
                                                            <div class="col-sm-3"> 
                                                                <?php
                                                                echo form_dropdown(array('id' => 'proficiency_id-u-' . $details['id'],
                                                                    'name' => 'proficiency_id-u-' . $details['id'],
                                                                    'class' => 'browser-default',
                                                                    'data-error' => '.errorTxtedu1'), $proficiency_list, set_value('proficiency_id', $details['proficiency_id']));
                                                                ?>                                           
                                                            </div>
                                                            <div class="col-sm-1"> 
                                                                <?php
                                                                $st = '';
                                                                if ($details['read'] == '1')
                                                                    $st = "'checked' => 'TRUE'";
                                                                ?>
                                                                <?php echo form_checkbox(array('id' => 'optionu-' . $details['id'] . '[1]', 'name' => 'optionu-' . $details['id'] . '[1]', 'class' => 'margin-left-25', 'checked' => $st)); ?>
                                                            </div>
                                                            <div class="col-sm-1"> 
                                                                <?php
                                                                $st1 = '';
                                                                if ($details['write'] == '1')
                                                                    $st1 = $st = "'checked' => 'TRUE'";
                                                                ?>
                                                                <?php echo form_checkbox(array('id' => 'optionu-' . $details['id'] . '[2]', 'name' => 'optionu-' . $details['id'] . '[2]', 'class' => 'margin-left-25', 'checked' => $st1)); ?>
                                                            </div>
                                                            <div class="col-sm-1"> 
                                                                <?php
                                                                $st2 = '';
                                                                if ($details['speak'] == '1')
                                                                    $st2 = $st = "'checked' => 'TRUE'";
                                                                ?>
                                                                <?php echo form_checkbox(array('id' => 'optionu-' . $details['id'] . '[3]', 'name' => 'optionu-' . $details['id'] . '[3]', 'class' => 'margin-left-25', 'checked' => $st2)); ?>
                                                            </div>
                                                            <div class="col-sm-2">
                                                                <i class="fa fa-trash text-ccc" onclick="deleteDiv(<?php echo $details['id'] ?>)"></i>
                                                            </div>
                                                        </div>
                                                    </div>

                                                <?php } ?>

                                            </div>
                                        </div>
                                    <?php } else { ?>
                                        <div id="myDiv1">
                                            <div id="myNaNDiv1">
                                                <div class="row margin-bottom-10">
                                                    <div class="col-sm-3"> 
                                                        <?php
                                                        echo form_dropdown(array('id' => 'language_id-1', 'name' => 'language_id-1', 'class' => 'browser-default', 'data-error' => '.errorTxtedu1'), $language_list);
                                                        ?>	                                            
                                                    </div> 
                                                    <div class="col-sm-3"> 
                                                        <?php
                                                        echo form_dropdown(array('id' => 'proficiency_id-1', 'name' => 'proficiency_id-1', 'class' => 'browser-default', 'data-error' => '.errorTxtedu1'), $proficiency_list);
                                                        ?>                                           
                                                    </div>
                                                    <div class="col-sm-1"> 

                                                        <?php echo form_checkbox(array('id' => 'option-1[]', 'name' => 'option-1[1]', 'class' => 'margin-left-25', 'value' => '0')); ?>
                                                    </div>
                                                    <div class="col-sm-1"> 
                                                        <?php echo form_checkbox(array('id' => 'option-1[]', 'name' => 'option-1[2]', 'class' => 'margin-left-25', 'value' => '0')); ?>
                                                    </div>
                                                    <div class="col-sm-1"> 
                                                        <?php echo form_checkbox(array('id' => 'option-1[]', 'name' => 'option-1[3]', 'class' => 'margin-left-25', 'value' => '0')); ?>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <!--<i class="fa fa-remove text-danger" onclick="removeDiv('myNaNDiv');"></i>-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div id="myDiv"></div>
                                    <div id="theValue">&nbsp;</div>

                                    <div class="btn btn-default btn-sm margin-bottom-10" onclick="add();">Add</div>
                                    <input hidden id="not_in_id" value="" name="language_count"> 
                                    <input hidden id="langcount" value="<?php echo count($language_list) ?>" > 
                                    <input hidden id="emplangcount" value="<?php $empcnt = count($language_details); echo $empcnt == 0 ? 1 : $empcnt ?>" > 
                                    <div class="lang-cls text-danger"></div>
                                </div>

                                <!-- language bind here -->                       



                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="p-title margin-bottom-10">Communication Details</div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6 ">
                                    <div class="input-field">
                                        <?php echo form_label(lang('email'), 'email', array('for' => 'email')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'id' => 'personal_email',
                                            'name' => 'personal_email',
                                            'value' => set_value('personalemail', $communication_detail['personalemail']),
                                            'id' => 'email',
                                            'placeholder' => 'Email',
                                            'data-error' => '.errorTxtCom9'
                                        ));
                                        ?>
                                        <div class="errorTxtCom9"></div>
                                        <?php echo form_error('email'); ?> 
                                    </div>
                                </div>  

                                <div class="col-sm-6 ">
                                    <div class="input-field">
                                        <?php echo form_label(lang('mobile_number'), 'mobile_number', array('for' => 'mobile_number')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'mobile_number',
                                            'id' => 'mobile_number',
                                            'value' => set_value('mobile_number', $communication_detail['mobile_number']),
                                            'id' => 'mobile_number',
                                            'placeholder' => 'Mobile',
                                            'data-error' => '.errorTxtCom10'
                                        ));
                                        ?>
                                        <div class="errorTxtCom10"></div>
                                        <?php echo form_error('mobile_number'); ?>
                                        <div class="validnumbererror" ></div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="p-title">Permanent Address</div>
                                </div>
                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="input-field">
                                        <?php echo form_label(lang('street_address'), 'street_address', array('for' => 'street_address')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'perm_address',
                                            'id' => 'perm_address',
                                            'value' => set_value('perm_streetaddress', $communication_detail['perm_streetaddress']),
                                            'placeholder' => 'Permanent address',
                                            'data-error' => '.errorTxtCom11'
                                        ));
                                        ?>
                                        <div class="errorTxtCom11"></div>
                                        <?php echo form_error('perm_address'); ?>    
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('country_id'), 'country_id', array('for' => 'country_id')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'country_id', 'name' => 'country_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom12'), $country_list, set_value('perm_country', $communication_detail['perm_country']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtCom12"></div>
                                    </div> 
                                    <?php echo form_error('country_id'); ?> 
                                </div> 

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('state_id'), 'state_id', array('for' => 'state_id')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'state_id', 'name' => 'state_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom13'), $state_list, set_value('perm_state', $communication_detail['perm_state']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtCom13"></div>
                                    </div>
                                    <?php echo form_error('state_id'); ?> 
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('city_id'), 'city_id', array('for' => 'city_id')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'city_id', 'name' => 'city_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom14'), $city_list, set_value('perm_city', $communication_detail['perm_city']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtCom14"></div>
                                    </div> 
                                    <?php echo form_error('city_id'); ?> 
                                </div> 

                                <div class="col-sm-6">
                                    <div class="input-field">
                                        <?php echo form_label(lang('postalcode'), 'postalcode', array('for' => 'postalcode')); ?>
                                        <?php
                                        echo form_input(array(
                                            'type' => 'text',
                                            'name' => 'postalcode',
                                            'id' => 'postalcode',
                                            'value' => set_value('perm_pincode', $communication_detail['perm_pincode']),
                                            'placeholder' => 'Postal code',
                                            'data-error' => '.errorTxtCom15'
//                                        'value' => 'submit'
                                        ));
                                        ?>
                                        <div class="errorTxtCom15"></div>
                                        <?php echo form_error('postalcode'); ?>  
                                    </div>
                                </div>

                                <div class="clearfix"></div>


                                <div class="col-sm-12">
                                    <?php
                                    $ch = '';
                                    $hideDiv = 'none';
                                    if (isset($communication_detail)) {
                                        if ($communication_detail['same_check'] == '1') {
                                            $ch = "'checked'=>'TRUE'";
                                            $hideDiv = 'none';
                                            $chval = 1;
                                        } else {
                                            $ch = "";
                                            $hideDiv = 'block';
                                            $chval = 0;
                                        }
                                    } else {
                                        $ch = "";
                                        $hideDiv = 'block';
                                        $chval = 0;
                                    }
                                    ?>

                                    <?php echo form_checkbox(array('id' => 'check_status', 'name' => 'check_status', 'value' => $chval, 'style' => 'left: 0 !important; opacity: 0 !important;', 'checked' => $ch)); ?>
                                    <?php echo form_label(lang('check_status'), 'check_status', array('for' => 'check_status', 'style' => 'font-size:12px !important')); ?>
                                    <?php echo form_error('check_status'); ?> 
                                </div>
                                <div class="clearfix"></div>

                                <div class="curr_add_id margin-bottom-20 " style="display: <?php echo $hideDiv ?>">
                                    <div class="col-sm-12">
                                        <div class="p-title margin-top-10">Current Address</div>
                                    </div>
                                    <div class="clearfix"></div>


                                    <div class="col-sm-12">
                                        <div class="input-field">
                                            <?php echo form_label(lang('street_address'), 'street_address', array('for' => 'street_address')); ?>
                                            <?php
                                            echo form_input(array(
                                                'type' => 'text',
                                                'name' => 'curr_address',
                                                'id' => 'curr_address',
                                                'value' => set_value('current_streetaddress', $communication_detail['current_streetaddress'] ? $communication_detail['current_streetaddress'] : $communication_detail['perm_streetaddress']),
                                                'placeholder' => 'Current address',
                                                'data-error' => '.errorTxtCom50'
                                            ));
                                            ?>
                                            <div class="errorTxtCom50"></div>
                                            <?php echo form_error('curr_address'); ?>
                                        </div>
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-sm-6">
                                        <?php echo form_label(lang('country_id'), 'country_id', array('for' => 'country_id')); ?>

                                        <?php
                                        echo form_dropdown(array('id' => 'c_country_id', 'name' => 'c_country_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom51'), $country_list, set_value('current_country', $communication_detail['current_country'] ? $communication_detail['current_country'] : $communication_detail['perm_country']));
                                        ?>
                                        <div class="input-field">
                                            <div class="errorTxtCom51"></div>
                                        </div> 
                                        <?php echo form_error('country_id'); ?> 
                                    </div> 

                                    <div class="col-sm-6">
                                        <?php echo form_label(lang('state_id'), 'state_id', array('for' => 'state_id')); ?>

                                        <?php
                                        echo form_dropdown(array('id' => 'c_state_id', 'name' => 'c_state_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom52'), $state_list, set_value('current_state', $communication_detail['current_state'] ? $communication_detail['current_state'] : $communication_detail['perm_state']));
                                        ?>
                                        <div class="input-field">
                                            <div class="errorTxtCom52"></div>
                                        </div> 
                                        <?php echo form_error('state_id'); ?> 
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-sm-6">
                                        <?php echo form_label(lang('city_id'), 'city_id', array('for' => 'city_id')); ?>
                                        <?php
                                        echo form_dropdown(array('id' => 'c_city_id', 'name' => 'c_city_id', 'class' => 'browser-default', 'data-error' => '.errorTxtCom53'), $city_list, set_value('current_city', $communication_detail['current_city'] ? $communication_detail['current_city'] : $communication_detail['perm_city']));
                                        ?>
                                        <div class="input-field">
                                            <div class="errorTxtCom53"></div>
                                        </div> 
                                        <?php echo form_error('city_id'); ?>
                                    </div> 

                                    <div class="col-sm-6">
                                        <div class="input-field">
                                            <?php echo form_label(lang('postalcode'), 'postalcode', array('for' => 'postalcode')); ?>
                                            <?php
                                            echo form_input(array(
                                                'type' => 'text',
                                                'id' => 'c_postalcode',
                                                'name' => 'c_postalcode',
                                                'value' => set_value('current_pincode', $communication_detail['current_pincode'] ? $communication_detail['current_pincode'] : $communication_detail['perm_pincode']),
                                                'placeholder' => 'Postal code',
                                                'data-error' => '.errorTxtCom54'
//                                        'value' => '411001'
                                            ));
                                            ?>
                                            <div class="errorTxtCom54"></div>
                                            <?php echo form_error('postalcode'); ?>                                      
                                        </div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">
                                    <div class="p-title margin-top-10">Emergency Contact</div>
                                </div>
                                <div class="clearfix"></div>


                                <div class="row">

                                    <div class="col-sm-12 margin-top-10">
                                        <input type="hidden" name="emergency_contact_count" id="emergency_contact_count" value="">
                                        <div class="col-sm-3">   
                                            <div class="input-field">
                                                <?php echo form_label(lang('emergency_number'), 'emergency_number', array('for' => 'emergency_number')); ?>
                                                <?php
                                                echo form_input(array(
                                                    'type' => 'text',
                                                    'id' => 'emergency_number',
                                                    'name' => 'emergency_number',
                                                    'data-error' => '.errorTxtSkill5',
                                                    'placeholder' => 'Contact Number',
                                                    'data-error' => '.errorTxtCom20',
                                                ));
                                                ?>
                                                <div class="errorTxtCom20"></div>
                                                <div class="validnumbererror" ></div>
                                                <?php echo form_error('emer_number'); ?>
                                            </div>


                                        </div>

                                        <div class="col-sm-3">
                                            <div class="input-field">
                                                <?php echo form_label(lang('emergency_name'), 'emergency_name', array('for' => 'emergency_name')); ?>
                                                <?php
                                                echo form_input(array(
                                                    'type' => 'text',
                                                    'id' => 'emergency_name',
                                                    'name' => 'emergency_name',
                                                    'data-error' => '.errorTxtSkill5',
                                                    'placeholder' => 'Emergency Name',
                                                    'data-error' => '.errorTxtCom21',
                                                ));
                                                ?>
                                                <div class="errorTxtCom21"></div>
                                                <?php echo form_error('emer_number'); ?>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="input-field">
                                                <?php echo form_label(lang('emergency_email'), 'emergency_email', array('for' => 'emergency_email')); ?>
                                                <?php
                                                echo form_input(array(
                                                    'type' => 'email',
                                                    'id' => 'emergency_email',
                                                    'name' => 'emergency_email',
                                                    'data-error' => '.errorTxtSkill5',
                                                    'placeholder' => 'Emergency Email',
                                                    'data-error' => '.errorTxtCom22',
                                                ));
                                                ?>
                                                <div class="errorTxtCom22"></div>
                                                <?php echo form_error('emer_number'); ?>
                                            </div>

                                        </div>
                                        <div class="col-sm-2 ">
                                            <label class="margin-top-5">Preference</label>
                                            <?php echo form_checkbox(array('id' => 'preference_id', 'name' => 'preference_id', 'placeholder' => 'Preference', 'style' => 'margin-left:25px !important; top: 25px;')); ?>
                                            <div class="input-field">
                                                <?php // echo form_label(lang('preference'), 'preference', array('for' => 'preference')); ?>

                                                <!--<div class="errorTxtCom22"></div>-->
                                                <?php echo form_error('preference'); ?>
                                            </div>                                        
                                        </div>
                                        <div class="col-sm-1">
                                            <!--<p><label>Action</label></p>-->
                                            <i class="fa fa-plus text-info add-row margin-top-20" title="Add"> </i>
                                        </div>
                                    </div>
                                </div>

                                <div class="clearfix"></div>

                                <div class="col-sm-12">




                                    <?php if (isset($emergency_contact_details)) { ?>
                                        <div class="emergencyu">
                                            <?php foreach ($emergency_contact_details as $eme_result) {
                                                ?>
                                                <div class="row <?php echo $eme_result['id']; ?>">


                                                    <div class="col-sm-3">
                                                        <?php // echo $eme_result['emergency_number'];    ?>
                                                        <div class="input-field margin-top-0">
                                                            <input data-error="" type='number'  name='emergency_number-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_number'] ?>' required="required">
                                                            <div class=""></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <div class="input-field margin-top-0">
                                                            <?php // echo $eme_result['emergency_name'];    ?>
                                                            <input data-error="" maxlength="25" minlength="2" type='text' name='emergency_name-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_name'] ?>' required="required">
                                                            <div class=""></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3">
                                                        <?php // echo $eme_result['emergency_email'];    ?>
                                                        <div class="input-field margin-top-0">
                                                            <input data-error="" type='email' id="emergency_email_up" name='emergency_email-u-<?php echo $eme_result['id'] ?>' value='<?php echo $eme_result['emergency_email'] ?>' required="required">
                                                            <!--<input-->

                                                            <div class=""></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-1">
                                                        <?php
                                                        $pre = '';
                                                        $data = "preferenceChecked('preference_u_" . $eme_result['id'] . "')";
                                                        if ($eme_result['preference'] == '1')
                                                            $pre = "'checked' => 'TRUE'";
                                                        ?>
                                                        <?php
                                                        echo form_checkbox(array('id' => 'preference_u_' . $eme_result['id'],
                                                            'name' => 'preference_u_' . $eme_result['id'],
                                                            'class' => 'margin-left-25',
                                                            'checked' => $pre,
                                                            'value' => $eme_result['preference'] ? $eme_result['preference'] : '0',
                                                            'onclick' => $data
                                                        ));
                                                        ?>
                                                    </div>
                                                    <div class="col-sm-2">
                                                        <i class="fa fa-trash text-ccc" onclick="deleteEmDiv(<?php echo $eme_result['id'] ?>)"></i>
                                                    </div>

                                                </div>
                                                <div class="clearfix"></div>
                                            <?php }
                                            ?>
                                        </div>
                                    <?php } ?>  
                                    <div class="emergency"></div>
                                </div>



                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button class="btn btn-warning2 btn-sm">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>

                            </div>
                            <!-- 1st row end here -->
                            <?php echo form_close(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--Personal & Contact information modal end -->
<script type="text/javascript">

    $(document).on("click", ".datepicker", function () {

        $('.child').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });
    });

</script>

<script type="text/javascript">
    /*child date of birth*/
    $(document).ready(function () {

        $(".anniversary_cl").click(function () {
            $('.anniversary_cl').pickadate({
                selectYears: true,
                selectMonths: true,
                max: new Date(),
            });
        });
        $(".dob").click(function () {
            $('.dob').pickadate({
                selectYears: true,
                selectMonths: true,
                max: new Date(),
            });
        });
        $(".child1").click(function () {
            $('.child1').pickadate({
                selectYears: true,
                selectMonths: true,
                max: new Date(),
            });
        });
    });
</script>

<!--Emergency contact-->
<script type="text/javascript">
    $(document).ready(function () {
        var i = <?php echo $emergency_contact_details ? count($emergency_contact_details) : 0 ?>;
        $("#emergency_contact_count").val(i);
        $(".add-row").click(function () {

            var preference = 0;
            var checked = '';
            /*to check preference*/
            if ($("#preference_id").is(":checked")) {
//                        alert('is check');
                preference = 1;
                checked = 'checked';
            }

            i = $("#emergency_contact_count").val();
            if (i == 5) {
                alert('Warning : Only upto 5 emergency contact can be add ');
                return false;
            }

            i++;

            var number = $("#emergency_number").val();
            var name = $("#emergency_name").val();
            var email = $("#emergency_email").val();


            if (number == '' || name == '' || email == '') {
                alert('Emergencey contact fields can not be null!');
                return false;
            }

            //            show_detail
            $(".show_detail").show();
            var number = $("#emergency_number").val();
            var name = $("#emergency_name").val();
            var email = $("#emergency_email").val();
            $("#emergency_contact_count").val(i);
//                    functionName = 'preferenceChecked('+ "id" +i+')';
            functionName = "preferenceChecked(" + i + ")";
            var markup = "<div class='row " + i + "'>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_number-" + i + "' value='" + number + "'>" + number + "</div>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_name-" + i + "' value='" + name + "'>" + name + "</div>\n\
                            <div class='col-sm-3'><input type='hidden' name='emergency_email-" + i + "' value='" + email + "'>" + email + "</div>\n\
                            <div class='col-sm-1'><input type='hidden' name='preference_" + i + "' id='pre" + i + "' value='" + preference + "'><input type='checkbox' class='margin-left-25' id='" + i + "'   value='" + preference + "' " + checked + " onclick='" + functionName + "'  ></div>\n\
                            <div class='col-sm-2'><i class='fa fa-trash text-ccc' onclick='deleteEmDiv(" + i + ")'></i></div></div>";
            $(".emergency").append(markup);
            $("#emergency_number").val('');
            $("#emergency_name").val('');
            $("#emergency_email").val('');
        });



        // Find and remove selected table rows
        $(".delete-row").click(function () {
            i = $("#emergency_contact_count").val();
            if (i > 0)
                i--;

            $("table tbody").find('input[name="record"]').each(function () {
                if ($(this).is(":checked")) {
                    $("#emergency_contact_count").val(i);
                    $(this).parents("tr").remove();
                }
            });
        });
        /*contact address*/
        $("#check_status").click(function () {


            var add = $("#perm_address").val();
            $("#curr_address").val(add);
            $("#c_country_id").val($("#country_id option:selected").val());
            $("#c_state_id").val($("#state_id option:selected").val());
            $("#c_city_id").val($("#city_id option:selected").val());
            $("#c_postalcode").val($("#postalcode").val());




            var isChecked = $("#check_status").val();
            if (isChecked == 0) {
                $(".curr_add_id").hide();
                $("#check_status").val('1');
            } else {
                $(".curr_add_id").show();
                $("#check_status").val('0')
            }

        });

    });



</script>

<!--Language details-->
<script>

    var $ctra = 1;
    var $ctrachild = 1;
    var i = 0;
    var cur_sele = <?php echo $language_details ? 0 : 1 ?>;
    $('#not_in_id').val(cur_sele);

    var cur_child_sele = <?php echo $child_details ? count($child_details) : 0 ?>;
//            alert(cur_child_sele);
    $('#child_count').val(cur_child_sele);
    //    function add() {
    //
    //
    //
    //
    //
    //    }

    function removeDiv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            //        if()
            cur_sele--;
            $('#not_in_id').val(cur_sele);

            emplangcount = parseInt($('#emplangcount').val()) - 1;
            $('#emplangcount').val(emplangcount);
            var ni = document.getElementById('myDiv');
            ni.removeChild(document.getElementById(dId));
            return false;
        }
    }

    /* Delete language */
    function deleteDiv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            //        if()

            $("div").remove("#remove" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_emp_language',
                data: {'emp_lang_id': dId},
                success: function (data) {
                }
            });
            return false;
        }
    }


    function deleteEmDiv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            //        if()
            i = $("#emergency_contact_count").val();
            i--;

            $("#emergency_contact_count").val(i);
            $("div").remove("." + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_emergency_contact',
                data: {'emergency_id': dId},
                success: function (data) {
                }
            });
            return false;
        }
    }

    /* Add Language Details */
    function add()
    {

        var list = <?php echo json_encode($language_list); ?>;

        var i = <?php echo $language_details ? count($language_details) : 0 ?>;

        //to get total language count
        cur_sele++;
        //        cur_sele =  $('#not_in_id').val(cur_sele);

        var ni = document.getElementById('myDiv');
        var numi = document.getElementById('theValue');
        var num = (document.getElementById('theValue').value - 1) + 2;
        numi.value = num;
        var newdiv = document.createElement('div');
        var divIdName = 'my' + num + 'Div';
        newdiv.setAttribute('id', divIdName);
        //var cur_sele = $('#language_id').val();
        //if (cur_sele) {


        //}

        //        var not_in_langiage_id = $('#not_in_id').val();
        $('#not_in_id').val(cur_sele);
        $.ajax({
            type: "POST",
            data: {associate_id: <?php echo $user_summary['user_id'] ?>},
            url: '<?php echo base_url(); ?>employee/getAllLanguage',
            success: function (data) {

                langcount = $('#langcount').val();
                emplangcount = $('#emplangcount').val();

                if (langcount == emplangcount) {
                    $('.lang-cls').html('No more languages.');
//                    $( ".lang-cls" ).hide( 1000 );
                    return false;
                }
                emplangcount = parseInt(emplangcount) + 1;
                $('#emplangcount').val(emplangcount);


//                if (data.empty == 'empty')
//                {
//                    return false;
//                }
//                var list = data.language_list;
                newdiv.innerHTML = "<div class='row margin-bottom-10' ><div " + "class=col-sm-3 " + "> \n\
                        <select id='language_id-" + cur_sele + "' name='language_id-" + cur_sele + "' " + " class=browser-default " + "> " + data.language_list + " </select> </div> \n\
                        <div " + "class=col-sm-3 " + "> <select id='proficiency_id-" + cur_sele + "'  name='proficiency_id-" + cur_sele + "' " + " class=browser-default " + "> " + data.proficiency_list + " </select> </div>"
                        + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[1]' size=20 > </div>" + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[2]' size=20 > </div>" + "<div " + "class=col-sm-1 " + "> \n\
                        <input type='checkbox' class='margin-left-25' name='option-" + cur_sele + "[3]' size=20 > </div>" +
                        "<div " + "class=col-sm-2 " + "><i class='fa fa-trash text-ccc' onclick=\"removeDiv('" + divIdName + "');\"></i></div></div>";
                if ($ctra < 100) {
                    ni.appendChild(newdiv);
                    $ctra++;
                }
                $total = $ctra;

            }
        });
    }
    /*Add childer details*/
    function addChild()
    {
        if (cur_child_sele > 4)
            return false;

        var i = <?php echo $child_details ? count($child_details) : 0 ?>;
        //to get total language count
        cur_child_sele = $('#child_count').val();
        cur_child_sele++;
        //        cur_sele =  
        //        cur_sele =  


        var ni = document.getElementById('myDivChild');
        var numi = $('#theValueChild').val();//document.getElementById('');
        var num = (document.getElementById('theValueChild').value - 1) + 2;
        numi.value = num;
        var newdiv = document.createElement('div');
        var divIdName = 'my' + num + 'DivChild';
        newdiv.setAttribute('id', divIdName);

        $('#child_count').val(cur_child_sele);

        newdiv.innerHTML = "<div id='ch-" + cur_child_sele + "'><div class='row' >\n\
                                    <div class='col-sm-5'><input placeholder='Child Name' id='child_name-" + cur_child_sele + "' name='child_name-" + cur_child_sele + "'></div>\n\
                                    <div class='col-sm-5'><input type='text' class='datepicker child' id='child_dob-" + cur_child_sele + "' name='child_dob-" + cur_child_sele + "' placeholder='Date of Birth'></div>\n\
                                    <div class='col-sm-2'><i class='fa fa-trash text-ccc' onclick=\"removeChDiv('" + cur_child_sele + "');\"></i></div>\n\
                                    </div></div>";

        if ($ctrachild < 100) {
            ni.appendChild(newdiv);
//                    $("#child_dob-1").addClass("datepicker");
            $ctrachild++;
        }
        $total = $ctrachild;

    }

    function removeChDiv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            //        if()
//                alert(dId);
            cur_child_sele = $('#child_count').val();
            cur_child_sele--;
            $('#child_count').val(cur_child_sele);
            $('#ch-' + dId).remove();
//                var ni = document.getElementById('myDivChild');
//                ni.removeChild(document.getElementById(dId));
            return false;
        }
    }

    function deleteChDIv(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            //        if()
            i = $("#child_count").val();
            i--;
            var child_id = dId;
            $("#child_count").val(i);
            $('#ch-u-' + dId).remove();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_child',
                data: {'child_id': dId},
                success: function (data) {
                }
            });
            return false;
        }
    }
    /*Checkbox cheked*/
    function preferenceChecked(prefId) {
//        alert(prefId);
        if ($('#' + prefId).is(":checked")) {
            $('#pre' + prefId).val('1');
            $('#' + prefId).val('1');
        }
        else {
            $('#' + prefId).val('0');
            $('#pre' + prefId).val('0');
        }
    }

</script>

<!--City country State-->
<script>

    $('select[name="country_id"]').change(function () {
        var country_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getStateList',
            data: {'country_id': country_id},
            success: function (data) {
                if (data) {
                    $('select[name="state_id"]').html(data.content).trigger('liszt:updated').val(country_id);
                    $('#state_id').material_select();
                }
            }
        });
    });

    $('select[name="state_id"]').change(function () {
        var state_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getCityList',
            data: {'state_id': state_id},
            success: function (data) {
                if (data) {
                    $('select[name="city_id"]').html(data.content).trigger('liszt:updated').val(state_id);
                    $('#city_id').material_select();
                }
            }
        });
    });

    $('select[name="c_country_id"]').change(function () {
        var country_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getStateList',
            data: {'country_id': country_id},
            success: function (data) {
                if (data) {
                    $('select[name="c_state_id"]').html(data.content).trigger('liszt:updated').val(country_id);
                    $('#c_state_id').material_select();
                }
            }
        });
    });
    $('select[name="c_state_id"]').change(function () {
        var state_id = $(this).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/getCityList',
            data: {'state_id': state_id},
            success: function (data) {
                if (data) {
                    $('select[name="c_city_id"]').html(data.content).trigger('liszt:updated').val(state_id);
                    $('#c_city_id').material_select();
                }
            }
        });
    });

</script>
<!--End of country city state-->

<script>
    $('select[name="marital_status"]').change(function () {
        var ms_name = $('#marital_status option:selected').text();//$(this).val();
        //        alert(country_id);
        if (ms_name == 'Married') {
            $('#anniversary_id').show();
            $('#child_id').show();
        } else {
            $('#anniversary_id').hide();
            $('#child_id').hide();
        }
        return false;
    });


    /*Emergency nubmer validation*/
    $('#emergency_number').focusout(function () {
        $('.validnumbererror').html('');
        var emergency_num = $(this).val();
        var associate_id = '<?php echo $user_summary['user_id'] ?>';
        if (emergency_num != '') {
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/checkEmergencyNumber',
                data: {'emergency_num': emergency_num, 'associate_id': associate_id},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    if (parsed.isValid == 1) {
//                    alert('number Already Exist');
                        $('.validnumbererror').html('Contact number already exist.');
                        $('#emergency_number').val('');
                        $('#emergency_number').addClass('error');
                        $("#emergency_number").focus();
                    }
                }
            });
        }

    });

    $('#mobile_number').focusout(function () {
        $('.validnumbererror').html('');
        var mobile_num = $(this).val();
        if (mobile_num != '') {
            var associate_id = '<?php echo $user_summary['user_id'] ?>';

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/checkMobileNumber',
                data: {'mobile_num': mobile_num, 'associate_id': associate_id},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    if (parsed.isValid == 1) {
//                    alert('number Already Exist');
                        $('.validnumbererror').html('Contact number already exist.');
                        $('#mobile_number').val('');
                        $('#mobile_number').addClass('error');
                        $("#mobile_number").focus();
                    }
                }
            });
        }

    });

</script>
