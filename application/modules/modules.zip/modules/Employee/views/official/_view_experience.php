<!-- 1st document here -->
<div class="exp_display">
    <?php $i = 1; ?>
    <?php if (isset($experience_details)) { ?>
        <?php foreach ($experience_details as $result) { ?>
            <div id="<?php echo $result['id']; ?>">
                <div class="col-sm-3"> 
                    <div class="work-exp-bg">                    
                        <div class="close-right margin-top-5">
                            <i class="fa fa-trash text-ccc" onclick="deleteExpCard(<?php echo $result['id'] ?>)" title="delete"></i>
                        </div>
                        <!-- title start here -->
                        <div class="work-exp-title">
                            <a title="Company Name" data-toggle="modal"  href="#work-exp-Modal-v-<?php echo $result['id'] ?>"> <i class="fa fa-pencil"></i> <?php echo $result['comp_name'] ? $result['comp_name'] : ''; ?> </a>
                        </div>
                        <!-- title end here -->
                        <div class="work-exp-description margin-bottom-10">
                            <p title="Designation"><?php echo $result['designation'] ? $result['designation'] : ''; ?></p>
                            <p title="from/To Date"><?php echo date('M Y', strtotime($result['from_date'])); ?> To <?php echo date('M Y', strtotime($result['to_date'])); ?></p>
                            <p title="Company URL"><a href="<?php echo $result['comp_website'] ? $result['comp_website'] : ''; ?>" target="_blank"><?php echo $result['comp_website'] ? $result['comp_website'] : ''; ?></a></p>
                            <div class="border-bottom margin-top-10 margin-bottom-10"></div>
                            <p class="text-bold" >Reference</p>

                            <p title="Reference Name"> <?php echo $result['reference_name'] ? $result['reference_name'] : ''; ?></p>
                            <p title="Reference Email"><a href="mailto: <?php echo $result['reference_email'] ? $result['reference_email'] : ''; ?>"><?php echo $result['reference_email'] ? $result['reference_email'] : ''; ?></a></p>
                        </div>
                        <?php if (isset($result['document'])) { ?>
                            <span class="pull-right view-file-right pull-right"> 
                                <!--rel="prettyPhoto"-->
                                <!--<i class="fa fa-map-marker text-ccc" data-toggle="modal" href="#experience_id<?php echo $result['id']; ?>" title="Map" > </i>-->
                                <!--<a target="_blank" href="" ><i class="fa fa-eye text-ccc" title="View"></i></a>-->
                                <a target="_blank" href="<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/experience/<?php echo $result['document'] ?>" ><i class="fa fa-eye text-ccc" title="View"></i> </a>
                            </span>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php if ($i == 4) { ?>
                <div class="clearfix"></div>
            <?php } ?>
            <?php
            $i++;
        }
        ?>
    <?php } else { ?>
        <?php $this->load->view('official/_no_data_found'); ?>    
    <?php } ?>
</div>
<!-- 1st document here -->

<?php // if (isset($experience_details)) { ?>
    <?php // foreach ($experience_details as $result) { ?>
        <!-- modal start -->
<!--        <div class="modal fade" id="experience_id<?php echo $result['id']; ?>" role="dialog" style="top:7%;">
            <div class="modal-dialog ">

                <div class="modal-content">   
                   <button type="button" class="close margin-right-10" data-dismiss="modal">&times;</button>

                    <div class="modal-body">
                        <iframe class="fadeInUp" frameborder="0" width='570' height='450'  src='<?php echo base_url(); ?>assets/uploads/<?php echo $associate_slug; ?>/documents/experience/<?php echo $result['document'] ?>'></iframe>
                    </div>

                </div>
            </div>
        </div>-->
        <!-- modal end -->
    <?php // } ?>
<?php // } ?>

<script>

    function deleteExpCard(dId) {

        if (confirm('Are you sure, you want to delete this?')) {
//        if()
            $("div").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_experience',
                data: {'experience_id': dId},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>