<!-- skill experience modal start -->
<div class="modal fade" id="passport-visa-Modal-2" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Passport & Visa</h4>
            </div>
            <div class="modal-body">
                <div class="user-modal-slim">                   
                    <?php echo form_open_multipart('employee/visa/add/' . $user_summary['user_id'], array('id' => 'form_validate_visa_id', 'class' => 'form_validate_visa_id')); ?>
                    <!-- 1st row start here -->
                    <div class="row">                

                        <div class="col-sm-12">
                            <?php echo form_label(lang('country_id'), 'country_id', array('for' => 'country_id')); ?>

                            <?php
                            echo form_dropdown(array('id' => 'country_id', 'name' => 'country_id', 'class' => 'browser-default', 'data-error' => '.errorTxtpass8'), $country_list);
                            ?>
                            <div class="input-field">
                                <div class="errorTxtpass8"></div>
                            </div> 
                            <?php echo form_error('country_id'); ?> 
                        </div> 

                        <div class="clearfix"></div>


                        <div class="col-sm-12">
                            <div class="input-field">
                                <?php echo form_label(lang('visa_type'), 'visa_type', array('for' => 'visa_type')); ?>
                                <?php
                                echo form_input(array(
                                    'type' => 'text',
                                    'name' => 'visa_type',
                                    'id' => 'visa_type',
                                    'placeholder' => 'Visa Type',
                                    'data-error' => '.errorTxtpass5'
                                ));
                                ?>
                                <div class="errorTxtpass5"></div>
                                <?php echo form_error('visa_type'); ?>
                            </div>
                        </div>


                        <div class="clearfix"></div>
                        <!--
                                                <div class="col-sm-6">
                                                    <div class="input-field">
                        <?php echo form_label(lang('visa_number'), 'visa_number', array('for' => 'visa_number')); ?>
                        <?php
                        echo form_input(array(
                            'type' => 'text',
                            'name' => 'visa_number',
                            'id' => 'visa_number',
                            'placeholder' => 'Visa Number',
                            'data-error' => '.errorTxtpass4'
                        ));
                        ?>
                                                        <div class="errorTxtpass4"></div>
                        <?php echo form_error('visa_number'); ?>
                                                    </div>
                                                </div>-->



                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('visa_issue_date'), 'visa_issue_date', array('for' => 'visa_issue_date')); ?>
                                <?php
                                echo form_input(array(
//                                            'type' => 'text',
                                    'name' => 'visa_issue_date',
                                    'id' => 'visa_issue_date',
                                    'class' => 'visa_issue_date',
                                    'placeholder' => 'Visa Issue Date',
                                    'data-error' => '.errorTxtpass6'
                                ));
                                ?>
                                <div class="errorTxtpass6"></div>
                                <?php echo form_error('visa_issue_date'); ?>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="input-field">
                                <?php echo form_label(lang('visa_expiry_date'), 'visa_expiry_date', array('for' => 'visa_expiry_date')); ?>
                                <?php
                                echo form_input(array(
//                                            'type' => 'text',
                                    'name' => 'visa_expiry_date',
                                    'id' => 'visa_expiry_date',
                                    'class' => 'visa_expiry_date',
                                    'placeholder' => 'Visa Expiry Date',
                                    'data-error' => '.errorTxtpass7'
                                ));
                                ?>
                                <div class="errorTxtpass7"></div>
                                <?php echo form_error('visa_expiry_date'); ?>
                            </div>

                        </div>


                        <div class="col-sm-12">

                            <div class="file-field input-field">
                                <div class="btn btn-default btn-sm margin-top-10">Browse
                                    <?php
                                    echo form_input(array(
                                        'type' => 'file',
                                        'id' => 'visa_document',
                                        'name' => 'visa_document',
                                        'class' => 'form-control',
                                        'data-error' => '.errorTxtpass9'
                                    ));
                                    ?>
                                </div>

                                <div class="file-path-wrapper">
                                    <?php
                                    echo form_input(array(
                                        'id' => 'visa_document',
                                        'name' => 'visa_document',
                                        'class' => 'file-path',
                                        'placeholder' => '( pdf, png, jpeg, jpg)',
                                    ));
                                    ?>
                                </div>
                                <div class="errorTxtpass9"></div>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="file-field input-field">
                                <?php echo form_checkbox(array('id' => 'multi_entry', 'name' => 'multi_entry', 'value' => '0', 'style' => 'left: 0 !important; opacity: 0 !important;')); ?>
                                <?php echo form_label(lang('multi_entry'), 'multi_entry', array('for' => 'multi_entry', 'style' => 'font-size:12px !important; top: 0 !important ')); ?>
                                <?php echo form_error('multi_entry'); ?> 
                            </div>
                        </div>

                        <div class="col-sm-12 padding-top-10 text-right">
                            <button type="submit" class="btn btn-warning2 btn-sm" >Submit</button>
                            
                            <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                        </div>
                    </div>

                    <!-- 1st row end here -->                              

                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Passport Visa modal end -->  

<script>
    $(document).ready(function () {
        $("#multi_entry").click(function () {

            var isChecked = $("#multi_entry").val();
            if (isChecked == 0) {
                $("#multi_entry").val('1');
            } else {
                $("#multi_entry").val('0')
            }

        });
    });</script>

<!--Pickdate Validation-->
<script>
    $(document).ready(function () {

        //Passport  passport_issue_date
        $('.passport_issue_date').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date()
        });
        $(".passport_expiry_date").click(function () {
            $('.datepicker').pickadate();
            var date = new Date($('#passport_issue_date').val());
            $(".passport_expiry_date").removeClass('datepicker');
            var expiryDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            $('.passport_expiry_date').pickadate({
                min: new Date(expiryDate),
                selectYears: true,
                selectMonths: true,
            });
        });
        //Visa

        $('.visa_issue_date').pickadate({
            selectYears: true,
            selectMonths: true,
            max: new Date()
        });
        $(".visa_expiry_date").click(function () {
            $('.datepicker').pickadate();
            var date = new Date($('#visa_issue_date').val());
            $(".visa_expiry_date").removeClass('datepicker');
            var expiryDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
            $('.visa_expiry_date').pickadate({
                min: new Date(expiryDate),
                selectYears: true,
                selectMonths: true,
            });
        });
    });
</script>