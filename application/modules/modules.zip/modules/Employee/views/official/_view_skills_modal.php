
<!--<script type="text/javascript" src="<?php echo base_url(); ?>plugins/material-css/js/jquery-validation/jquery.custom_validate.js"></script>-->
<!--material js file here-->
<!-- Skills Details -->
<?php if (isset($skills_details)) { ?>
    <?php foreach ($skills_details as $result) { ?>

        <div class="modal fade" id="skill-exp-Modal-v-<?php echo $result['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Skills</h4>
                    </div>
                    <div class="modal-body">
                        <div class="user-normal-slim">
                            <?php
                            echo form_open_multipart('employee/skills/edit/' . $user_summary['user_id'] . '/' . $result['id'], array('id' => 'form_edit_skills_id_' . $result['id'], 'class' => 'form_edit_skills_id_' . $result['id']));
                            ?>
                            <?php // echo form_input(array('type' => 'hidden', 'name' => 'action', 'value' => $action)) ?>
                            <!-- 1st row start here -->
                            <div class="row">

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('skills_id'), 'skills_id', array('for' => 'skills_id')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'skills_id', 'name' => 'skills_id', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill1'), $skills_list, set_value('skill_id', $result['skill_id']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtSkill1"></div>
                                    </div>
                                    <?php echo form_error('skills_id'); ?>                                             
                                </div>
                                <div class="clearfix"></div> 

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('years_exp'), 'years_exp', array('for' => 'years_exp')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'years_exp', 'name' => 'years_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill2'), $yearsexp, set_value('years_exp', $result['years_exp']));
                                    ?>
                                    <div class="input-field">
                                    <div class="errorTxtSkill2"></div>
                                    </div>
                                    <?php echo form_error('yearsofexp'); ?>
                                </div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('months_exp'), 'months_exp', array('for' => 'months_exp')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'months_exp', 'name' => 'months_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill3'), $monthsexp, set_value('months_exp', $result['months_exp']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtSkill3"></div>
                                        <?php echo form_error('months_exp'); ?>
                                    </div> 
                                    <?php echo form_error('months_exp'); ?>
                                </div>

                                <div class="clearfix"></div> 

                                <div class="col-sm-12">
                                    <?php echo form_label(lang('competency_level'), 'competency_level', array('for' => 'competency_level')); ?>

                                    <?php
                                    echo form_dropdown(array('id' => 'competency_level', 'name' => 'competency_level', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill4'), $compentency_level, set_value('competencylevelid', $result['competencylevelid']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtSkill4"></div>
                                        <?php echo form_error('competency_level'); ?>
                                    </div>
                                    

                                </div>


                                <div class="clearfix"></div> 

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('last_years_exp'), 'last_years_exp', array('for' => 'last_years_exp')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'last_years_exp', 'name' => 'last_years_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill6'), $years_list, set_value('last_years_exp', $result['last_years_exp']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtSkill6"></div>
                                        <div class="last_years_exp"></div>
                                    </div> 
                                    
                                    <?php echo form_error('last_years_exp'); ?>
                                </div>

                                <div class="col-sm-6">
                                    <?php echo form_label(lang('last_months_exp'), 'last_months_exp', array('for' => 'last_months_exp')); ?>
                                    <?php
                                    echo form_dropdown(array('id' => 'last_months_exp', 'name' => 'last_months_exp', 'class' => 'browser-default', 'data-error' => '.errorTxtSkill7'), $months_list, set_value('last_months_exp', $result['last_months_exp']));
                                    ?>
                                    <div class="input-field">
                                        <div class="errorTxtSkill6"></div>
                                    </div> 
                                    <?php echo form_error('last_months_exp'); ?>
                                </div>


                                <div class="clearfix"></div>

                                <div class="col-sm-12 padding-top-10 text-right">
                                    <button class="btn btn-warning2 btn-sm" onclick="return validate_form(<?php echo $result['id'] ?>)">Submit</button>
                                    <!--<button type="reset" class="btn btn-default btn-sm">Cancel</button>-->
                                </div>
                            </div>
                            <!-- 1st row end here -->                          
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<!-- Skills modal end -->
<script>

    $(document).ready(function () {
        $(".close").on('click', function () {

            $("div .error").html('');
            $('input').removeClass('error');
            $("div").removeClass("error");
            $('#last_years_exp').prop('selectedIndex',0);
            $('#last_months_exp').prop('selectedIndex',0);


        });




    });
</script>
<!--pickdate validation-->
<script>
    $(document).ready(function () {
        $('.year_last_use').pickadate({
//  min: new Date(2017,3,20),
            selectYears: true,
            selectMonths: true,
            max: new Date(),
        });
    });
</script>