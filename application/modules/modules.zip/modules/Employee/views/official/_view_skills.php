<!-- 1st document here -->
<div class="skill_display">
    <?php $i = 1; ?>
    <?php if (isset($skills_details)) { ?>
        <?php foreach ($skills_details as $result) { ?>
            <!-- 1st document here -->

            <div id="<?php echo $result['id']; ?>">
                <div class="col-sm-3"> 
                    <div class="skill-exp-bg ">

                        <div class="close-right margin-top-5">
                            <i class="fa fa-trash text-ccc" onclick="deleteCard(<?php echo $result['id'] ?>)" title="Delete"></i>
                        </div>
                        <!--Card-->
                        <div class="emp-icon-left-skill" title="Nationality">

                            <span><i class="text-skill-icon <?php echo $skill_icon[$result['skill_id']] ?>" style="font-size:40px"></i></span>
                        </div> 
                        <div class="emp-content-right-skills" >
                            <a  class="text-ccc" title="<?php echo $result['skill_id'] ? $skills_list[$result['skill_id']] : '' ?>"data-toggle="modal" class="text-primary" href="#skill-exp-Modal-v-<?php echo $result['id'] ?>">
                                <i class="fa fa-pencil"></i> <?php echo $result['skill_id'] ? $skills_list[$result['skill_id']] : '' ?>
                            </a>
                            <p title="Experience"><?php echo $result['years_exp'] ? $yearsexp[$result['years_exp']] : '0' ?> | <?php echo $result['months_exp'] ? $monthsexp[$result['months_exp']] : '0' ?></p>
                            <p title="Last Use"><?php echo $result['last_months_exp'] ? $months_list[$result['last_months_exp']] : 'NA' ?> 
                                <?php echo $result['last_years_exp'] ? $years_list[$result['last_years_exp']] : 'NA' ?></p>

                        </div>
                        <!--Card-->

                        <div class=" text-center margin-bottom-10">
                            <p title="Compentency Level"> <small>
                                    <?php
                                    for ($i = 1; $i <= 5; $i++) {
                                        if ($i <= $result['competencylevelid']) {
                                            ?>
                                            <i class="fa fa-star text-star"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-star text-light-cl"></i>
                                            <?php
                                        }
                                    }
                                    ?></small>
                            </p>
                        </div>


                    </div>
                </div>
            </div>
            <!-- 1st document here -->

            <?php if ($i == 4) { ?>
                <div class="clearfix"></div>
            <?php } ?>
            <?php
            $i++;
        }
        ?>
    <?php } else { ?>
        <?php $this->load->view('official/_no_data_found'); ?>    
    <?php } ?>
</div>
<!-- 1st document here -->

<script>
    function deleteCard(dId) {

        if (confirm('Are you sure, you want to delete this?')) {

//        if()
            $("div").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_skills',
                data: {'skills_id': dId},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>