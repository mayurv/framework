<!--wizard javascript end here --> 
<div class="col-sm-12">
    <div class="main-bg padding-lt-rt-top">

        <!-- Smart Wizard -->
        <div id="wizard" class="swMain">
            <ul>
                <li>
                    <a href="#step-1">
                        &nbsp;                                                

                        <div class="sw-lbl-bottom">Official </div>
                    </a>
                </li>
                <li>
                    <a href="#step-2">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Personal </div>
                    </a>
                </li>                
                <!--                <li>
                                    <a href="#step-4">
                                        &nbsp; 
                
                                        <div class="sw-lbl-bottom-2">Job History </div>
                                    </a>
                                </li>-->
                <li>
                    <a href="#step-5">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Experience </div>
                    </a>
                </li>
                <li>
                    <a href="#step-9">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Skills </div>
                    </a>
                </li>
                <li>
                    <a href="#step-6">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Education </div>
                    </a>
                </li>
                <li>
                    <a href="#step-7">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Certification </div>
                    </a>
                </li>
                <li>
                    <a href="#step-8">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Visa</div>
                    </a>
                </li>  
                <li>
                    <a href="#step-3">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Documents </div>
                    </a>
                </li>
                <li>
                    <a href="#step-4">
                        &nbsp; 

                        <div class="sw-lbl-bottom">Job History </div>
                    </a>
                </li>
            </ul>

            <!-- official information -->
            <div id="step-1"> 
                <?php $this->load->view('_official'); ?>
            </div>
            <!-- official information -->

            <div id="step-2">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>     

            <div id="step-3">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>



            <div id="step-5">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>

            <div id="step-9">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>    

            <div id="step-6">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>

            <div id="step-7">
                <div class="col-sm-12">
                    No data found!
                </div>
            </div>

            <div id="step-8">
                <div class="col-sm-12">
                    No data found!
                </div>

            </div>


        </div>
        <!-- End SmartWizard Content -->    
    </div>          
</div>
<!--All Modal here-->
<?php // $this->load->view('_document'); ?>  
<?php //$this->load->view('_communication'); ?>   
<?php ////$this->load->view('_experience'); ?>  
<?php //$this->load->view('_skills'); ?>  
<?php //$this->load->view('_certification'); ?>  
<?php //$this->load->view('_education'); ?>  
<?php //$this->load->view('_visa'); ?>  
<!--All Modal here-->

<script>
    $.ajaxSetup({cache: false});
</script>
<style>
    .main-bg-blur{z-index:1;opacity:0.4;filter: alpha(opacity = 50);}
</style>
<script>
    $(document).ready(function () {
        $(".btn-warning2").click(function () {
//            $(".main-bg").append('<i style="z-index:0"data-vp-add-class="visible rollIn" class="fa ion-loading-c icon-sm icon-rounded icon-primary inviewport animated animated-delay-600ms visible rollIn"></i>');
//            $(".main-bg").addClass("main-bg-blur");
        });

    });


</script>
<script>
    $(document).keydown(function (e) {
        if (e.keyCode == 39) {
            showErrorMessage('Ops! Something went wrong');
            alert('Alert');
            return false;
        }
    });


    $(document).keydown(function (e) {
        if (e.keyCode == 37) {
            return false;
        }
        if (e.keyCode == 39) {
            return false;
        }
    });
//    $(window).load(function () {
    $(window).on('load', function () {

        $("div").remove(".actionBar");
        $( "#prefix_id" ).focus();
    });
</script>

