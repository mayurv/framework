<?php $i = 1; ?>
<?php // var_dump($balnce_leaves);die; ?>
<div class="user-back-slim">
    <!-- 1st row start here -->
    <div class="row">
        <!-- col-sm-6 -->
        <div class="col-sm-4 ">
            <?php // var_dump($associate_slug);?>
            <!-- user information -->
            <div class="row">
                <div class="col-sm-12">
                    <!-- user information -->
                    <div class="media-middle margin-right-10 center-img">  
                        <?php if (isset($user_summary['profileimg']) && $user_summary['profileimg'] != '') { ?>
                            <img class="img-responsive img-circle official-img" src="<?php echo base_url() . 'assets/uploads/' . $user_summary['profileimg']; ?>">  
                        <?php } else { ?>
                            <img class="img-responsive img-circle official-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                        <?php } ?>
                    </div>
                    <div class="official-bg border-bottom">
                        <div class="media-body">                          

                            <div class="emp-heading">
                                <h4 class="media-heading text-bold text-primary-main margin-bottom-0"><?php echo $user_summary['userfullname']; ?>  

                                    <span><?php if ($user_summary['isactive'] == '1') { ?>
                                            <i class="fa fa-circle text-success font-size-6" title="Active"></i>
                                        <?php } else { ?>
                                            <i class="fa fa-circle text-warning font-size-6" title="In-Active"></i>
                                        <?php } ?>
                                    </span>
                                </h4>
                            </div>
                            <div class="emp-p-text">
                                <p><small><?php echo $user_summary['employeeId']; ?></small></p>
                                <p class="text-bold"> <?php echo $user_summary['department_name']; ?>, 
                                    <?php echo $user_summary['position_name']; ?></p>
                            </div>

                            <div class="emp-office-bg"> 
                                <!--email id here-->
                                <div class="emp-icon-left"> 
                                    <i class="fa fa-envelope" title="Official Email"></i>
                                </div>
                                <div class="emp-content-right"> 
                                    <a href="mailto: <?php echo $user_summary['emailaddress']; ?>"> <?php echo $user_summary['emailaddress']; ?></a>
                                </div>
                                <!--email id here-->
                                
                                <!--reporting manager  here-->
                                <div class="emp-icon-left"> 
                                    <i class="fa fa-user" title="Manager"></i>
                                </div>
                                <div class="emp-content-right"> 
                                    <?php echo $user_summary['reporting_manager_name']; ?>
                                </div>
                                <!--reporting manager  here-->
                                
                                <!--emp status  here-->
                                <div class="emp-icon-left"> 
                                    <i class="fa fa-clock-o" title="Employment Status"></i>
                                </div>
                                <div class="emp-content-right"> 
                                    <?php echo $user_summary['emp_status_name']; ?>
                                </div>
                                <!--emp status  here-->                                
                                <!--Date of Joining  here-->
                                <div class="emp-icon-left"> 
                                    <i class="fa fa-calendar" title="Date of Joining"></i>
                                </div>
                                <div class="emp-content-right"> 
                                    <?php echo date('Y M d', strtotime($user_summary['date_of_joining'])); ?>
                                </div>
                                <!--Date of Joining here-->
                                <!--Experience here-->
                                <div class="emp-icon-left" title="Total Experience"> 
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <div class="emp-content-right"> 
                                    <?php echo $yearsexp[$user_summary['years_exp']]; ?> <?php echo $monthsexp[$user_summary['months_exp']]; ?>
                                </div>
                                <!--Experience here-->

                                <!--Visa-->

                                <?php if (isset($passport_details['passport_number'])) { ?>
                                    <div class="emp-icon-left" title="Passport"> 
                                        <i class="fa fa-plane text-info"></i>
                                    </div>
                                    <div class="emp-content-right text-info" title="Passport Number"> 
                                        <?php echo $passport_details['passport_number'] ?>
                                        <small class="text-light-gray" title="Passport Expiry"><?php echo date('Y', strtotime($passport_details['passport_expiry_date'])) ?>  <?php echo date('F', strtotime($passport_details['passport_expiry_date'])); ?></small>
                                    </div>
                                <?php } else { ?>
                                    <div class="emp-icon-left" title="Passport"> 
                                        <i class="fa fa-plane text-light-gray"></i>
                                    </div>
                                    <div class="emp-content-right text-light-gray"> 
                                        NA
                                    </div>
                                <?php } ?>
                                <!--Visa-->
                            </div>

                            <div class="text-center">
                                <a href="#" class="btn btn-default btn-sm margin-top-5 margin-bottom-5" title="Policy">Policy</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- user information -->
        </div>
        <!-- col-sm-6 -->

        <!-- col-sm-8 -->
        <div class="col-sm-8">

            <div class="row">
                <div class="col-sm-12">
                    <!--leave details here-->
                    <div class="off-leave-bg"> 
                        <span class="text-bold all-padding-15">Leaves</span>
                        <!--<div class="off-leave-title">Leave Details</div>-->
                        <?php // var_dump($leaves)?>
                        <ul>
                            <?php if (isset($leaves)) { ?>
                                <?php foreach ($leaves as $list) { ?>
                                    <li>
                                        <p class="off-leave-heading"><?php echo $list['leavetype'] ?></p>                                       
                                        <p class="off-leave-allot">
                                            <span class="text-light-gray" title="Used"><span class="font-size-18"><?php echo $list['used_leaves'] ?></span></span>/
                                            <span class="text-default" title="Alloted"><small><?php echo $list['alloted_leaves'] ?> </small></span>
                                        </p>
                                        <p class="off-leave-balance"><span class="badge badge-secondary" title="Balanced"><?php echo $list['alloted_leaves'] - $list['used_leaves'] ?></span></p>
                                    </li>
                                <?php } ?>
                            <?php } ?>

                            <?php if (isset($balnce_leaves)) { ?>
                                <?php foreach ($balnce_leaves as $list) { ?>
                                    <li>
                                        <p class="off-leave-heading">Total</p>                                       
                                        <p class="off-leave-allot">                                    
                                            <span class="font-size-18 text-light-gray" title="Used"><?php echo $list['bal'] ?></span>/
                                            <span class="text-default" title="Alloted"><small><?php echo $list['tot'] ?> </small></span>
                                        </p>
                                        <p class="off-leave-balance"><span class="badge badge-secondary" title="Balanced"><?php echo $list['tot'] - $list['bal'] ?></span></p>
                                    </li>
                                <?php } ?>
                            <?php } ?>        

                        </ul>               
                    </div>
                    <!--leave details here--> 
                </div>
                <div class="clearfix"></div>
                <!--project allocatiion atart-->    
                <div class="col-sm-12 margin-top-20">
                    <div class="off-leave-bg all-padding-15">
                        <span class="text-bold">Project Allocation</span>
                        <span class="pull-right">
                            <a data-toggle="modal" href="#project_allocation" title="Allocate Project">
                                <button class="btn btn-xs btn-default"><i class="fa fa-plus-circle text-ccc "></i> Allocate</button>
                            </a>
                        </span>
                        <?php if (isset($project_allocation_details)) { ?>
                            <table class="table data-table table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Project Name</th>
                                        <th>% Allocation</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($project_allocation_details as $result) { ?>
                                        <tr id="pa_<?php echo $result['id'] ?>">
                                            <td>
                                                <?php echo $result['name'] ?>
                                            </td>

                                            <td>
                                                <?php echo $result['percentage_allocation'] ?>
                                            </td>

                                            <td>
                                                <a data-toggle="modal" href="#edit_project_allocation_<?php echo $result['id'] ?>" title="Edit">  
                                                    <i class="fa fa-pencil text-ccc "></i>
                                                </a>
                                            </td>
                                            <td>
                                                <a data-toggle="modal" href="#" onclick="delete_allocation(<?php echo $result['id'] ?>)" title="Delete">  
                                                    <i class="fa fa-trash text-ccc "></i>
                                                </a>
                                            </td>
                                        </tr>                
                                    <?php } ?>
                                </tbody>
                            </table>
                        <?php } ?>
                    </div>
                </div>
                <!--project allocatiion end-->
            </div>
        </div> 
        <!-- col-sm-8 -->
    </div>
    <!-- 1st row end here -->                        
</div>

<script>
    function delete_allocation(dId) {
        if (confirm('Are you sure, you want to delete this?')) {
            $("tr").remove("#pa_" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/delete_allocation',
                data: {'project_id': dId},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>