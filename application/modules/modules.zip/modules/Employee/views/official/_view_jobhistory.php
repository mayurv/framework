<!-- 1st document here -->
<?php if (isset($jobhistroy_details)) { ?>
    <?php foreach ($jobhistroy_details as $result) { ?>
        <div class="col-sm-4"> 
            <div class="work-exp-bg">
                <!-- title start here -->
                <div class="work-exp-title">
                    <div class="pull-left">
                        <p class="text-bold text-primary-2">
                            <?php echo $result['comp_name'] ? $result['comp_name'] : ''; ?>
                        </p>
                    </div>

                    <div class="pull-right">
                        <a data-toggle="modal" href="#work-exp-Modal-v-<?php echo $result['id'] ?>">  
                            <i class="fa fa-pencil-square-o text-info font-size-18"></i>
                        </a>
                        <a data-toggle="modal" href="#work-exp-Modal-v-<?php echo $result['id'] ?>">  
                            <i class="fa fa-remove-square-o text-info font-size-18"></i>
                        </a>
                    </div>
                </div>
                <!-- title end here -->
                <div class="bottom-border"></div>
                <div class="work-exp-description">

                    <p> <span class="text-bold">
                            <?php echo $result['comp_name'] ? $result['comp_name'] : ''; ?>
                        </span></p>
                    <p><a href="http://<?php echo $result['comp_website'] ? $result['comp_website'] : ''; ?>" target="_blank">http://<?php echo $result['comp_website'] ? $result['comp_website'] : ''; ?></a></p>
                    <p class="text-bold"><?php echo $result['designation'] ? $result['designation'] : ''; ?></p>
                    <p><?php echo $result['from_date'] ? $result['from_date'] : ''; ?> To <?php echo $result['to_date'] ? $result['to_date'] : ''; ?></p>
                    <p><span class="text-bold">Reason:</span><?php echo $result['reason_for_leaving'] ? $result['reason_for_leaving'] : ''; ?></p>
                    <?php if (isset($result['reference_name']))  ?>
                    <p class="text-bold padding-top-10"> Reference Details</p>

                    <p> <?php echo $result['reference_name'] ? $result['reference_name'] : ''; ?></p>
                    <p> <?php echo $result['reference_contact'] ? $result['reference_contact'] : ''; ?></p>
                    <p><a href="mailto: <?php echo $result['reference_email'] ? $result['reference_email'] : ''; ?>"><?php echo $result['reference_email'] ? $result['reference_email'] : ''; ?></a></p>
                    </p>

                </div>
            </div>
        </div>
    <?php } ?>
<?php } else { ?>
    <?php $this->load->view('official/_no_data_found'); ?>    
<?php } ?>
<!-- 1st document here -->