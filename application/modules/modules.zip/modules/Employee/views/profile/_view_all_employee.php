<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php $i = 1; ?>
</div>
<!-- left side col-sm-9 here -->
<div class="row">

    <div class="col-sm-12">
        <div class="main-bg all-padding-15">

            <!-- add button -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-right"> 
                        <a class="fa fa-plus" data-toggle="modal" href="#addModal-1"> 
                            Add Associate
                        </a>
                    </div>
                </div>
            </div>
            <!-- add button -->
            <!-- search button -->
            <div class="row"> 
                <div class="col-sm-8">
                    <form>

                        <div class="input-field all-margin">
                            <input type="text" class="search-input" id="search_val" name="search_val" placeholder="Search">
                            <div class="search-i-bg"> 
                                <i class="fa fa-search text-primary"></i>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

            <!-- search button -->
            <?php // var_dump($personal_detail);die;?>
            <!-- card display -->

            <div class="row">
                <?php $this->load->view('employee/_view_card_display');?>


                <div class="clearfix"> </div>

            </div>
            <!-- card display -->


        </div>          
    </div>
    <!-- left side col-sm-9 here -->

    <!-- right side col-sm-3 here -->
    <!--    <div class="col-sm-3">
            <div class="main-bg margin-bottom-15">
                 <div class="event-heading">Event</div> 
                <div class="r3_notification db_box"> 
                    <h3 class="text-primary">Event</h3>                                  
                    <ul class="notification-widget">
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                        <li class="status-offline">                                                
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>assets/images/diwali.jpg" alt="user-image" class="img-responsive">
                            </div>
                            <div>
                                <span>
                                    <strong>Diwali </strong>
                                </span>
                                <span class="desc small">
                                    Lorem Ipsum is simply dummy text of the printing industry.
                                </span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>  
    
            <div class="main-bg">
                 <div class="article-heading">Article</div> 
                <div class="r3_notification db_box">      
                    <h3 class="text-primary">Article</h3>   
                    <ul class="notification-widget">
    
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>                                                                                
                        <li class="unread status-available">                                          
                            <div class="user-img">
                                <img src="<?php echo base_url(); ?>data/profile/avatar-2.png" alt="user-image" class="img-circle">
                            </div>
                            <div>
                                <span class="name">
                                    <strong>Article one</strong>
                                    <span class="time small">10/12/2016</span>
                                </span>
                                <span class="desc small">
                                    Sometimes it takes a lifetime to win a battle.
                                </span>
                            </div>                                            
                        </li>                                            
                    </ul>
                </div>
            </div>  
    
        </div>-->
    <!-- right side col-sm-3 here -->
</div>

<!-- modal start -->
<div class="modal fade" id="addModal-1" tabindex="-1" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">User Registration</h4>
            </div>
            <div class="modal-body">
                <?php echo form_open('employee/addofficial/', array('id' => 'form_communication_id')); ?>
                <input name="form_action" type="hidden"  value="1"/>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="p-title margin-bottom-20">Mode of Employment</div>
                    </div>
                    <input type="hidden" id="directid" name="direct"  value="1"/>
                    <div class="col-sm-6">
                        <input name="group1" type="radio" id="test1" value="1" checked=""/>

                        <label for="test1">Direct</label>
                    </div> 
                    <div class="col-sm-6">
                        <input name="group1" type="radio" id="test2" value="0"/>
                        <label for="test2">Interview</label>
                    </div>                                                       

                    <div class="clearfix"> </div>
                    <div id="dropId" style="display: none;">
                        <?php // var_dump($candidates);die;   ?>
                        <div class="col-sm-12">
                            <?php echo form_label(lang('candidate_id'), 'candidate_id', array('for' => 'candidate_id')); ?>
                            <?php
                            echo form_dropdown(array('id' => 'candidate_id', 'name' => 'candidate_id', 'class' => 'browser-default', 'data-error' => '.errorTxt12'), $candidates);
                            ?>
                            <div class="input-field">
                                <div class="errorTxt12"></div>
                            </div>
                            <?php echo form_error('skills_id'); ?>  
                        </div>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-sm-12 padding-top-10">
                        <button type="submit" class="btn btn-default btn-sm">Submit</button>
                        <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>

        </div>
    </div>
</div>
<!-- modal end -->

<script>
    $(document).ready(function () {
        $("#directid").val('direct');
        $("#test2").click(function () {
            $("#directid").val('0');
            $("#test1").val('0');
            $("#test2").val('1');
            $("#dropId").show();
        });
        $("#test1").click(function () {

            $("#directid").val('direct');
            $("#test1").val('1');
            $("#test2").val('0');
            $("#dropId").hide();
        });

        $("#check_status").click(function () {

            var isChecked = $("#check_status").val();
            if (isChecked == 0) {
                $(".curr_add_id").hide();
                $("#check_status").val('1');
            } else {
                $(".curr_add_id").show();
                $("#check_status").val('0')
            }

        });
    });
</script>
<style>
    .main-bg-blur{z-index:1;opacity:0.4;filter: alpha(opacity = 50);}
</style>
<script>
    $(document).ready(function () {
        $(".btn").click(function () {
//            $(".main-bg").append('<i style="z-index:0"data-vp-add-class="visible rollIn" class="fa ion-loading-c icon-sm icon-rounded icon-primary inviewport animated animated-delay-600ms visible rollIn"></i>');
//            $(".main-bg").addClass("main-bg-blur");
        });


    });

</script>

<script>
    $(document).ready(function () {

        $("#id_search").click(function () {
            alert('alsadh');
        });

//    $("#search_id").keypress(function () {
        $(".search-i-bg").click(function () {
            alert('press');
            var search_key = $('#search_val').val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/searchData',
                data: {'search_key': search_key},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    $('.card_display').html('');
                    $('.card_display').html(parsed.associate_list);
                }
            });
        });
    });
</script>