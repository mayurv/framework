<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of _adduser
 *
 * @author Mayur V
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php foreach ($css_files as $file): ?>
        <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
    <?php endforeach; ?>
    <?php foreach ($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</head>
<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="col-md-2">
    <div>
        <p><a href="<?php echo base_url(); ?>adduser" disabled="disabled">Official</a></p>
    </div>
    <div  disabled>
        <p><a href="<?php echo base_url(); ?>document">Document</a></p>
    </div>
    <div  disabled>
        <p><a href="<?php echo base_url(); ?>leaves">Leaves</a></p>
    </div>

    <p><a href="<?php echo base_url(); ?>holidays">Holiday</a></p>
    <p><a href="<?php echo base_url(); ?>personal">Personal</a></p>
    <p><a href="<?php echo base_url(); ?>contact">Contact</a></p>
    <p><a href="<?php echo base_url(); ?>skills">Skills</a></p>
    <p><a href="<?php echo base_url(); ?>jobhistory">Job History</a></p>
    <p><a href="<?php echo base_url(); ?>experience">Experience</a></p>
    <p><a href="<?php echo base_url(); ?>education">Education</a></p>
    <p><a href="<?php echo base_url(); ?>certificate">Certificate</a></p>
    <p><a href="<?php echo base_url(); ?>visa">Visa</a></p>
</div>

<div class="col-md-10">
    <?php if (isset($output)) echo $output; ?>
</div>
<script>
    $.ajax({
        url: 'getEmployeeId',
        success: function (data) {
            if (data) {
                $('#field-emplyeeid').val();
            }
        }
    });
</script>

<!--Start Remove Success Message-->
<?php
if ($this->uri->segment(3))
    if ($this->uri->segment(3) == 'success') {
        echo '<script> $( document ).ready(function() {
        setInterval(function(){ $("#list-report-success").remove(); }, 3000); });'
        . '</script>';
    }
?>
<!--End Remove Success Message-->