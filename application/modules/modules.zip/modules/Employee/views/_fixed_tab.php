<div class="content-body" style="height: 500px !important;">
    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <!--hr/employee/addofficial/-->
                    <?php // echo $c_emp_summary->user_id ?>
                    <tr><th scope="row" ><a href="<?php echo base_url(); ?>" disabled="disabled">Official</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/contactinfo/<?php echo $c_emp_summary->user_id ?>">Personal / Contact</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/document/<?php echo $c_emp_summary->user_id ?>">Document</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/skills/<?php echo $c_emp_summary->user_id ?>">Skills</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/jobhistory/<?php echo $c_emp_summary->user_id ?>">Job History</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/experience/<?php echo $c_emp_summary->user_id ?>">Experience</a>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/education/<?php echo $c_emp_summary->user_id ?>">Education</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/certificate/<?php echo $c_emp_summary->user_id ?>">Certificate</a></th>
                        <th scope="row"><a href="<?php echo base_url(); ?>employee/visa/<?php echo $c_emp_summary->user_id ?>">Visa</a></th></tr>
                </thead>
            </table>
        </div>
    </div>
</div>
