<div class="candidate-ls ">
    <div class="col-sm-9 border-left">
    <h4><i class="fa fa-users"> </i>  Candidate List</h4>
    <div class="post-list" id="postList" >
        <table id="dt-activate-associate1"  class="table table-responsive ">
            <thead>
                <tr>
                    <!--<th class="text-center"><i class="fa fa-slack"></i></th>-->
                    <th>Associate Name</th>
                    <th>Joining Date</th>
                    <th>Profile Completed</th>
                    <th>Official Status</th>
                    <th>Portal Access Status</th>
                </tr>
            </thead>
            <div class="pull-right"> 

            </div>
            <tbody >
                <?php foreach ($employee as $result) { ?>
                    <tr id="deleteLeaveRow_<?php echo $result->user_id ?>">

                        <td>
                            <i><?php if (isset($result->profileimg) && $result->profileimg != '') { ?>
                                    <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $result->profileimg; ?>">  
                                <?php } else { ?>
                                    <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                <?php } ?></i>                               
                            <p><a href="employee/view_user/<?php echo $result->user_id; ?>"><?php echo $result->userfullname; ?> </a> 
                                <small class="text-light-gray"> <?php echo $result->employeeId; ?></small>
                            </p>
                            <p>
                                <small >
                                    <?php echo $result->department_name ?>, 
                                    <?php echo $result->position_name ?>
                                </small>

                            </p>
                        </td>                        
                        <td>
                            <p><?php echo date("j F, Y", strtotime($result->date_of_joining)); ?></p>

                            <p>
                                <small class="text-light-gray" title="Created At"><?php echo date("j F, Y h:m A", strtotime($result->createddate)) ?></small>
                            </p>
                        </td>
                        <td>
                            <p><small class="text-light-gray"><?php echo $result->profile_completion ?>%</small> </p>
                            <p><div class="progress">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $result->profile_completion ?>%">

                                </div> 
                            </div></p>
                        </td>

                        <td><?php echo $status[$result->isactive] ?></td>
                        <td>
                            <div class="switch">
                                <label>      
                                    <?php
                                    $ch = '';
                                    $hideDiv = 'none';
                                    $function = 'activateAssociate(' . $result->user_id . ')';
                                    if ($result->active == '1') {
                                        $ch = "'checked'=>'TRUE'";
                                        $hideDiv = 'none';
                                        $chval = 1;
                                    } else {
                                        $ch = "";
                                        $hideDiv = 'block';
                                        $chval = 0;
                                    }
                                    ?>

                                    <?php echo form_checkbox(array('id' => 'portalStatus_' . $result->user_id, 'name' => 'portalStatus', 'value' => $chval, 'checked' => $ch, 'onclick' => $function)); ?>
                                    <span class="lever"></span>                                    
                                </label>
                            </div>

                        </td>                        
                    </tr>  
                <?php } ?>
            </tbody>
        </table>
    </div>
</div> 
</div>
