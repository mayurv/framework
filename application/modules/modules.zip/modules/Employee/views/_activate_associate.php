<?php // var_dump($department_list);die;                            ?>
<!--Activate Associate-->
<div class="main-bg all-padding-15"> 
    <div class="col-sm-8">
        <h4 class="text-bold">Activate Associate</h4>
    </div>
    <div class="clearfix"></div>
    <div class="col-sm-3">

        <h4><i class="fa fa-building  "> </i>  Departments</h4>
<!--        Active <span class="btn btn-success btn-xs"> <?php echo count($employee) ?> </span>
        InActive <span class="btn btn-secondary btn-xs"> 5 </span>-->
        <div class="activate-slim">

<!--<canvas id="assoPie" style="height:40px; padding:5px;"></canvas>-->

            <table class="table table-dept-bg table-hover">

                <?php $width = count($department_list) / 100 * 100; ?>
                <?php foreach ($department_list as $dept_id => $deptData) { ?>
                    <?php $count = 0; ?>
                    <tr class="border-bottom bordered-table">

                        <td>
                            <span title="<?php echo $deptData ?>">
                                <a href="#" onclick="filterCandAct('<?php echo $dept_id ?>')"><?php echo $deptData ?></a>
                                <?php foreach ($employee as $result) { ?>                                            
                                    <?php if ($result->department_name == $deptData) { ?>
                                        <?php $count = $count + 1; ?>
                                    <?php } ?>     
                                <?php } ?> 

                            </span>
                        </td>
                        <td >
                            <?php if ($count == 0) { ?>
                                <label class="btn btn-xs btn-gray" >
                                    <?php echo $count; ?>
                                </label>
                            <?php } else { ?> 
                                <label class="btn btn-xs btn-info" >
                                    <?php echo $count; ?>
                                </label>
                            <?php } ?>    
                        </td>                   
                    </tr>
                <?php } ?>                        
                <tr class="border-size-lg">
                    <td><span title="All">
                            <a href="#" class="text-bold" onclick="filterCandAct('')">All</a>
                        </span>
                    </td>
                    <td>
                        <label class="btn btn-warning btn-xs" >
                            <?php echo count($employee) ?>
                        </label>
                    </td>
                </tr>


            </table>
        </div>


    </div>
    <div class="candidate-ls">
        <div class="col-sm-9 border-left">

            <div class="col-sm-8"><h4><i class="fa fa-users"> </i>  Associate List</h4></div>


            <div class="post-list" id="postList">
                <div class="activate-slim table-responsive">
                    <table id="dt-activate-associate" class="table table-responsive table-hover">
                        <thead>
                            <tr>
                                <!--<th class="text-center"><i class="fa fa-slack"></i></th>-->
                                <th>Associate Name</th>
                                <th>Joining Date</th>
                                <th>Profile Completed</th>
                                <th>Official Status</th>
                                <th>Portal Access Status</th>
                            </tr>
                        </thead>
                        <div class="pull-right"> 

                        </div>
                        <tbody >
                            <?php foreach ($employee as $result) { ?>
                                <tr id="deleteLeaveRow_<?php echo $result->user_id ?>">

                                    <td>
                                        <i><?php if (isset($result->profileimg) && $result->profileimg != '') { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() . 'assets/uploads/' . $result->profileimg; ?>">  
                                            <?php } else { ?>
                                                <img class="img-responsive img-circle img-inline-aw" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                                            <?php } ?></i>                               
                                        <p><a href="<?php echo base_url()?>employee/view_user/<?php echo $result->user_id; ?>"><?php echo $result->userfullname; ?> </a> 
                                            <small class="text-light-gray"> <?php echo $result->employeeId; ?></small>
                                        </p>
                                        <p>
                                            <small >
                                                <?php echo $result->department_name ?>, 
                                                <?php echo $result->position_name ?>
                                            </small>

                                        </p>
                                    </td>                        
                                    <td>
                                        <p><?php echo date("j F, Y", strtotime($result->date_of_joining)); ?></p>

                                        <p>
                                            <small class="text-light-gray" title="Created At"><?php echo date("j F, Y h:m A", strtotime($result->createddate)) ?></small>
                                        </p>
                                    </td>
                                    <td>
                                        <p><small class="text-light-gray"><?php echo $result->profile_completion ?>%</small> </p>
                                        <p><div class="progress">
                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $result->profile_completion ?>%">

                                            </div> 
                                        </div></p>
                                    </td>

                                    <td><?php echo $status[$result->isactive] ?></td>
                                    <td>
                                        <div class="switch">
                                            <label>      
                                                <?php
                                                $ch = '';
                                                $hideDiv = 'none';
                                                $function = 'activateAssociate(' . $result->user_id . ')';
                                                if ($result->active == '1') {
                                                    $ch = "'checked'=>'TRUE'";
                                                    $hideDiv = 'none';
                                                    $chval = 1;
                                                } else {
                                                    $ch = "";
                                                    $hideDiv = 'block';
                                                    $chval = 0;
                                                }
                                                ?>

                                                <?php echo form_checkbox(array('id' => 'portalStatus_' . $result->user_id, 'name' => 'portalStatus', 'value' => $chval, 'checked' => $ch, 'onclick' => $function)); ?>
                                                <span class="lever"></span>                                    
                                            </label>
                                        </div>

                                    </td>                        
                                </tr>  
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php // $this->load->view('_activate_associate_filter');?>
<script>
    $(document).ready(function () {
        $('.activate-slim').slimscroll({
            width: '100%',
            height: '440px',
            axis: 'both'
        });
    });
</script>
<script>


    function activateAssociate(associateId) {
        var isChecked = $("#portalStatus_" + associateId).val();
        if (isChecked == 0) {
            $("#portalStatus_" + associateId).val('1');
        } else {
            $("#portalStatus_" + associateId).val('0')
        }
        var portal_status = $("#portalStatus_" + associateId).val();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/activate',
            data: {'associate_id': associateId, 'portal_status': portal_status},
            success: function (data) {
                var parsed = $.parseJSON(data);
                if (parsed.active == '1')
                    showSuccess("Associate Activated Successfully");
                else
                    showSuccess("Associate Deactivated Successfully");
            }
        });
    }

</script>
<script>


    function filterCandAct(dept_id) {
        return false;
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>employee/filterActAssoList/' + dept_id,
            data: {'dept_id': dept_id},
            success: function (data) {

                var parsed = $.parseJSON(data);
                if (parsed.content == null) {
                    $('.candidate-ls').html('<div class="margin-left-20">No Result Found !</div>');
                } else {
                    $('.candidate-ls').html('');

                    $('.candidate-ls').html(parsed.content);
                }
            }
        });
    }
</script>
<!--Leave chart-->
<!--<script src="<?php echo base_url('frontend/plugins/chartjs/Chart.min.js'); ?>"></script>-->
<?php // var_dump($leaves);die;  ?>
<!--<script>
            $(function () {

            // Get context with jQuery - using jQuery's .get() method.
            var pieChartCanvas = $("#assoPie").get(0).getContext("2d");
                    var pieChart = new Chart(pieChartCanvas);
                    var PieData = [
<?php // foreach ($department_list as $deptData) { ?>
<?php $count = 0; ?>

<?php // foreach ($employee as $result) { ?>
<?php // if ($result->department_name == $deptData) { ?>
<?php $count = $count + 1; ?>
<?php // } ?>
<?php // } ?>

                        {
                        value: <?php // echo $count  ?>,
                                color: "#<?php // echo $count  ?>37ab7",
                                highlight: "<?php // echo $deptData  ?>",
                                label: "<?php // echo $deptData  ?>",
                                title: "<?php // echo $deptData  ?>",
                        },
<?php // } ?>

                    ];
                    var pieOptions = {
                    //Boolean - Whether we should show a stroke on each segment
                    segmentShowStroke: true,
                            //String - The colour of each segment stroke
                            segmentStrokeColor: "#a8c944",
                            //Number - The width of each segment stroke
                            segmentStrokeWidth: 1,
                            //Number - The percentage of the chart that we cut out of the middle
                            percentageInnerCutout: 0, // This is 0 for Pie charts
                            //Number - Amount of animation steps
                            animationSteps: 100,
                            //String - Animation easing effect
                            animationEasing: "easeOutBounce",
                            //Boolean - Whether we animate the rotation of the Doughnut
                            animateRotate: true,
                            //Boolean - Whether we animate scaling the Doughnut from the centre
                            animateScale: false,
                            //Boolean - whether to make the chart responsive to window resizing
                            responsive: true,
                            // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
                            maintainAspectRatio: true,
                            //String - A legend template
                            legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>"
                    };
                    //Create pie or douhnut chart
                    // You can switch between pie and douhnut using the method below.
                    pieChart.Doughnut(PieData, pieOptions);
                    barChartOptions.datasetFill = false;
                    barChart.Bar(barChartData, barChartOptions);
            });
            
</script>-->



