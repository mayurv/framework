<div class="col-sm-2" > 
    <!-- user bg -->
    <div class="user-bg">
        <div class="media">            
            <div class="">
                <h5 class="text-bold text-primary-main text-center">
                    <a href="#" >
                        PHP Interview
                    </a>

                </h5>
                <p class="text-center line-hgt" > Add Candidate <small class="text-light-gray">10/5</small></p>
                <p class="text-center line-hgt" > <span title="Designation"> <?php echo $result->position_name; ?></span>, <span title="Department"> <?php echo $result->department_name; ?></span></p>                                                                                               
                
                <div class="progress">
                    <div class="progress-bar progress-bar-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 50%" title="Profile Completion : 50%">
                        <span class="text-white"></span>
                    </div>
                </div>
            </div>
        </div>
     
    </div>

    <!-- user bg -->                                        
</div>