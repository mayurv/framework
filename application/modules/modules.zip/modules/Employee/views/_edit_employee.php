<?php
/*
 * MindLink HRMS
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */
?>
<head>
    <link href="<?php echo base_url(); ?>assets/css/color-2.css" rel="stylesheet" type="text/css"/>
    <link href="<?php echo base_url(); ?>assets/css/hrms-custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<div class="">
    <input type="text" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php ?>
</div>
<div class="container">
    <div class="content-body">
        <?php // $this->load->view('_fixed_tab');?>
        <div class="row">
            <div class="col-md-12">
                <?php echo form_open('employee/addofficial'); ?>
                <form acion="employee/addofficial" method="post"> 
                    <div class="form-group col-sm-6">
                        <?php echo form_label(lang('employeeid'), 'employeeid', array('class' => 'form-label')); ?>
                        <br>
                        <div class="controls">
                            <?php
                            echo form_input(array(
                                'name' => 'employeeid',
                                'id' => 'employeeid',
                                'class' => 'form-control',
                                'placeholder' => $user_summary->employeeId,
                                'disabled' => 'disabled',
//                        
                            ));
                            ?>
                        </div>
                        <br>

                        <?php echo form_label(lang('prefix_id'), 'prefix_id', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($prefix as $category)
                            $options[$category['id']] = $category['prefix'];
                        echo form_dropdown(array('id' => 'prefix_id', 'name' => 'prefix_id'), $options,$user_summary->prefix_id);
                        ?>
                        
                        <br>
                        <?php echo form_label(lang('firstname'), 'firstname', array('class' => 'form-label')); ?>:
                        <?php
                        echo form_input(array(
                            'type' => 'text',
                            'name' => 'firstname',
                            'class' => 'form-control',
                            'value' => $user_summary->firstname,
                        ));
                        ?>
                        <br>
                        <?php echo form_label(lang('lastname'), 'lastname', array('class' => 'form-label')); ?>:
                        <?php
                        echo form_input(array(
                            'type' => 'text',
                            'name' => 'lastname',
                            'class' => 'form-control',
                            'value' => $user_summary->lastname,
                        ));
                        ?>

                        <?php echo form_label(lang('modeofemp'), 'modeofemp', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($empmode_list as $category)
                            $options[$category['id']] = $category['mode'];
                        echo form_dropdown(array('id' => 'modeofemp_id', 'name' => 'modeofemp_id'), $options, $employee_mode);
                        ?>
                        <br>


                        <?php echo form_label(lang('emprole'), 'emprole', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($emprole_list as $category)
                            $options[$category['id']] = $category['rolename'];

                        echo form_dropdown(array('id' => 'emprole_id', 'name' => 'emprole_id'), $options, $employee_role);
                        ?>
                        <br>

                        <?php echo form_label(lang('email'), 'email', array('class' => 'form-label')); ?>:
                        <?php
                        echo form_input(array(
                            'type' => 'text',
                            'name' => 'email',
                            'class' => 'form-control',
                            'value' => $user_summary->emailaddress,
                            'disabled' => 'disabled'
                        ));
                        ?>
                        <br>

                        <?php echo form_label(lang('department_id'), 'department_id', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($department_list as $category)
                            $options[$category['id']] = $category['deptname'];

                        echo form_dropdown(array('id' => 'department_id', 'name' => 'department_id'), $options, $department);
                        ?>
                        <br>

                        <?php echo form_label(lang('reportind_manager'), 'reportind_manager', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
//                        var_dump($rep_manager_list);die;
                        foreach ($rep_manager_list as $category)
                            $options[$category['id']] = $category['userfullname'];

                        echo form_dropdown(array('id' => 'reporting_manager', 'name' => 'reporting_manager'), $options, $user_summary->reporting_manager);
                        ?>
                        <br>


                        <?php // echo form_dropdown('prefix_id', $prefix, $prefix, array('class' => 'form-control input-sm m-bot15', 'disabled' => 'disabled'));   ?>                                                                
                    </div>

                    <div class="col-md-6">
                        <?php echo form_label(lang('jobtitle'), 'jobtitle', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($jobtitle_list as $category)
                            $options[$category['id']] = $category['jobtitlename'];

                        echo form_dropdown(array('id' => 'jobtitle_id', 'name' => 'jobtitle_id'), $options);
                        ?>
                        <br>

                        <?php echo form_label(lang('position_id'), 'position_id', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($position_list[0] as $category)
                            $options[$category['id']] = $category['positioname'];

                        echo form_dropdown(array('id' => 'position_id', 'name' => 'position_id'), $options, $user_summary->position_id);
                        ?>
                        <br>

                        <?php echo form_label(lang('emp_status_id'), 'emp_status_id', array('class' => 'form-label')); ?>:
                        <?php
                        $options = array();
                        foreach ($emp_status_list as $category)
                            $options[$category['id']] = $category['emp_status'];
                        echo form_dropdown(array('id' => 'emp_status_id', 'name' => 'emp_status_id'), $options);
                        ?>
                        <br>
                        <?php echo form_label(lang('date'), 'date_of_joining', array('class' => 'form-label')); ?>:

                        <?php
                        echo form_input(array(
                            'name' => 'date_of_joining',
                            'id' => 'date_of_joining',
                            'data-format' => 'yyyy-mm-dd',
                            'class' => 'form-control datepicker',
                            'value' => $user_summary->date_of_joining
                        ));
                        ?>                        
                        <?php echo form_label(lang('date'), 'date_of_leaving', array('class' => 'form-label')); ?>:

                        <?php
                        echo form_input(array(
                            'name' => 'date_of_leaving',
                            'id' => 'date_of_leaving',
                            'data-format' => 'yyyy-mm-dd',
                            'class' => 'form-control datepicker',
                            'value' => $user_summary->date_of_leaving ? $user_summary->date_of_leaving : ''
                        ));
                        ?>

                        <br>
                        <div class="row text-center">
                            <?php echo form_label(lang('expericence'), 'expericence', array('class' => 'form-label')); ?>:
                        </div>
                        <div class="col-md-6">
                            <div class="col-md-6">
                                <?php echo form_label(lang('yearsofexp'), 'yearsofexp', array('class' => 'form-label')); ?>:
                                <?php
                                echo form_input(array(
                                    'name' => 'yearsofexp',
                                    'id' => 'yearsofexp',
                                    'class' => 'form-control',
                                    'placeholder' => '(eg. 1)',
                                    'value' => $user_summary->years_exp
                                ));
                                ?>
                            </div>
                            <div class="col-md-6">
                                <?php echo form_label(lang('monthsofexp'), 'monthsofexp', array('class' => 'form-label')); ?>:

                                <?php
                                echo form_input(array(
                                    'name' => 'monthsofexp',
                                    'id' => 'monthsofexp',
                                    'class' => 'form-control',
                                    'placeholder' => 'eg. 2)',
                                    'value' => $user_summary->months_exp
                                ));
                                ?>
                            </div>
                            <div class="col-md-12">
                                <?php echo form_label(lang('contactnumber'), 'contactnumber', array('class' => 'form-label')); ?>:

                                <?php
                                echo form_input(array(
                                    'name' => 'contactnumber',
                                    'id' => 'contactnumber',
                                    'class' => 'form-control',
                                    'placeholder' => '8888888888',
                                    'value' => $user_summary->contactnumber ? $user_summary->contactnumber : ''
                                ));
                                ?>
                            </div>

                            <div class="form-group col-sm-6">
                                <?php echo form_label(lang('isactive'), 'isactive', array('class' => 'form-label')); ?>:
                                <?php
                                $options = array();
                                $status = array('In-Active', 'Active');
                                foreach ($status as $category)
                                    $options[$category['id']] = $category;
                                echo form_dropdown(array('id' => 'isactive', 'name' => 'isactive'), $status, $user_summary->isactive);
                                ?>
                            </div>


                        </div>
                        <div class="col-md-6">
                            <?php echo form_label(lang('leave_limit'), 'emp_leave_limit', array('class' => 'form-label')); ?>:
                            <?php
                            if (!empty($leaves))
                                $allot = $leaves->emp_leave_limit ? $leaves->emp_leave_limit : '';
                            else
                                $allot = '';
                            echo form_input(array(
                                'name' => 'emp_leave_limit',
                                'id' => 'emp_leave_limit',
                                'class' => 'form-control',
                                'placeholder' => 'Number of leave limit',
                                'value' => $allot
                            ));
                            ?>
                            <?php echo form_label(lang('emp_used_leave'), 'emp_used_leave', array('class' => 'form-label')); ?>:

                            <?php
                            if (!empty($leaves))
                                $allot = $leaves->used_leaves ? $leaves->used_leaves : '';
                            else
                                $allot = '';
                            
                            echo form_input(array(
                                'name' => 'emp_used_leave',
                                'id' => 'emp_used_leave',
                                'class' => 'form-control',
                                'placeholder' => $allot,
                                'disabled' => 'disabled'
                            ));
                            ?>
                            <?php echo form_label(lang('emp_leave_year'), 'emp_leave_year', array('class' => 'form-label')); ?>:
                            <?php 
                            echo form_input(array(
                                'name' => 'emp_leave_year',
                                'id' => 'emp_leave_year',
                                'class' => 'form-control',
                                'placeholder' => $leaves->alloted_year,
                                'disabled' => 'disabled'
                            ));
                            
                            ?>
                        </div>
                        <div class="col-md-6">
                            <?php echo form_label(lang('holiday_group_id'), 'holiday_group_id', array('class' => 'form-label')); ?>:

                            <?php
                            $options = array();
                            foreach ($holiday_group as $category)
                                $options[$category['id']] = $category['groupname'];
                            echo form_dropdown(array('id' => 'holiday_group_id', 'name' => 'holiday_group_id'), $options, $user_summary->holiday_group);
                            ?>
                        </div>
                        
                        <div class="col-md-6">
                            <?php echo form_label(lang('profileimage'), 'profileimage', array('class' => 'form-label')); ?>:<?php echo $user_summary->profileimg;?>
                            <input type="file" name="profileimage" size="20" value="<?php echo $user_summary->profileimg?>"/>
                        </div>
                    </div>

                    <input type="submit" name="submit" value="edit">
                </form>
                <?php form_close(); ?>
            </div>
        </div>
    </div>
</div>

<?php ?>

<script>
    $(document).ready(function () {
        
        var emprole = '';

        //to set reporting manager name
        $("#reporting_manager").change(function () {
            $('#reporting_manager_name').val();
            if ($("#reporting_manager option:selected").text() != "") {
                $('#reporting_manager_name').val($("#reporting_manager option:selected").text());
            }
        });
        
        $("#position_id").change(function () {
            $('#position_name').val();
            if ($("#position_id option:selected").text() != "") {
                $('#position_name').val($("#position_id option:selected").text());
            }
        });
        
        $("#emp_status_id").change(function () {
//            alert('hi');
            $('#emp_status_name').val();
            if ($("#emp_status_id option:selected").text() != "") {
                $('#emp_status_name').val($("#emp_status_id option:selected").text());
            }
        });
        
        $("#holiday_group_id").change(function () {
            $('#holiday_group_name').val();
            if ($("#holiday_group_id option:selected").text() != "") {
                $('#holiday_group_name').val($("#holiday_group_id option:selected").text());
            }
        });
        
        $("#prefix_id").change(function () {
            $('#prefix_name').val();
            if ($("#prefix_id option:selected").text() != "") {
                $('#prefix_name').val($("#prefix_id option:selected").text());
            }
        });
        
        $("#emprole_id").change(function () {
            $('#emprole_name').val();
            if ($("#emprole_id option:selected").text() != "") {
                $('#emprole_name').val($("#emprole_id option:selected").text());
            }
        });

        //to get reporting manager 
        $("#department_id").change(function () {
            

            if ($("#department_id option:selected").text() != "") {
                $('#department_name').val($("#department_id option:selected").text());
            }
            
            //if manager
            if ($("#emprole_id option:selected").val()) {
                emprole = $("#emprole_id option:selected").val();
            }
            

            $('#reporting_manager_name').val('');
            var department_id = $("select#department_id option:selected").val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getReportingManager',
                data: {'department_id': department_id,'emprole': emprole},
                success: function (data) {
                    $('select[name="reporting_manager"]').show();
                    $('select[name="reporting_manager"]').html(data.content).trigger('liszt:updated').val(reporting_manager);

                }
            });
        });

        //to get position
        $("#jobtitle_id").change(function () {

            if ($("#jobtitle_id option:selected").text() != "") {
                $('#jobtitle_name').val($("#jobtitle_id option:selected").text());
            }
            var jobtitle_id = $("select#jobtitle_id option:selected").val();

            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>employee/getPositionName',
                data: {'jobtitle_id': jobtitle_id},
                success: function (data) {
                    if (data) {
                        $('select[name="position_id"]').show();
                        $('select[name="position_id"]').html(data.content).trigger('liszt:updated').val(position_id);
                    }
                }
            });
        });

    });

</script>
