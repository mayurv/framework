<div class="container">
    <h1>Embed</h1>
                         


        <div class="col-md-6">.GoogleMap 
            
            
        </div>
    </div>
</div>