<!-- card display -->

<div class="">
    <input type="hidden" id="user_id" value="<?php isset($id) ? $id : ''; ?>">
    <?php $i = 1; ?>
</div>

<div class="card_display card-slim">
    <div class="loader" style="display: none"></div>
    <?php foreach ($employee as $result) { ?>
        <?php
        
        if ($result->isactive == '1')
            $boxshadow = 'box-shadow-success';
        else if ($result->isactive < '1')
            $boxshadow = 'box-shadow-warning';
        else
            $boxshadow = 'box-shadow-danger';
        ?>
        <!-- col-sm-4 here -->
        <div class="col-sm-2" > 
            <!-- user bg -->
            <div class="user-bg <?php echo $boxshadow ?>" title="<?php echo $status[$result->isactive] ?>">
                <div class="media">
                    <div class="margin-right-10 text-center">   
                        <?php if (isset($result->profileimg) && $result->profileimg != '') { ?>
                            <img class="img-responsive img-circle center-img media-object margin-top-0" src="<?php echo base_url() . 'assets/uploads/' . $result->profileimg; ?>">  
                        <?php } else { ?>
                            <img class="media-object margin-top-0 center-img" src="<?php echo base_url() ?>assets/images/male-profile.png">                             
                        <?php } ?>
                    </div>
                    <div class="">
                        <h5 class="text-bold  text-center">
                            <a class="text-primary" href="<?php echo base_url() ?>employee/view_user/<?php echo $result->user_id; ?>" >
                                <?php if (strlen($result->firstname) > 10 || strlen($result->lastname) > 12) { ?>
                                    <?php echo $result->firstname . ' ' . substr($result->lastname, 0, 1); ?>
                                <?php } else { ?>
                                    <?php echo $result->userfullname; ?>
                                <?php } ?>
                            </a>

                        </h5>
                        <p class="text-center line-hgt" > <?php echo $result->employeeId; ?></p>
                        <p class="text-center line-hgt" > <span title="Designation"> <?php echo $result->position_name; ?></span>, <span title="Department"> <?php echo $result->department_name; ?></span></p>                                                                                               
                        <?php
                        if ($result->isactive == '1')
                            $color = 'progress-bar-success';
                        else if ($result->isactive < '1')
                            $color = 'progress-bar-warning';
                        else
                            $color = 'progress-bar-danger';
                        ?>
                        <div class="progress">
                            <div class="progress-bar <?php echo $color ?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $result->profile_completion; ?>%" title="Profile Completion : <?php echo $result->profile_completion; ?>%">
                                <span class="text-white"></span>
                            </div>
                        </div>



                    </div>
                </div>
                <!--                            <div class="text-right margin-top-5">
                                                <a href="<?php // echo base_url()                ?>employee/view_user/<?php echo $result->user_id; ?>">
                                                    <button class="btn btn-warning2 btn-xs">View</button>
                                                </a>
                                            </div>-->
            </div>

            <!-- user bg -->                                        
        </div>
        <!-- col-sm-4 here -->


        <?php if ($i == 6) { ?>
            <div class="clearfix"></div>
        <?php } ?>    
        <?php
        $i++;
    }
    ?>

</div>


<div class="clearfix"> </div>
<script>
    $(document).ready(function () {
        $('.card-slim').slimscroll({
            width: '100%',
            height: '450px',
            axis: 'both'
        });
    });
</script>


