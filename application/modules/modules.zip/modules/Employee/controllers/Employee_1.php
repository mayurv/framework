<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of default
 *
 * @author admin
 */
class Employee extends MY_Controller {

//put your code here

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups', 'leave','experiencedetails'));
        $this->load->model(array('city', 'country', 'state'));
        $this->load->library('grocery_CRUD');
        $this->load->language(array('profile_lang'));
//        $this->load->language(array('common_lang'));

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        $this->template->set_master_template('template.php');

        if ($this->ion_auth->is_admin()) {
            //$data['account'] = $this->user_model->get_by_id($this->session->userdata('user_id'));
            // var_dump($data['account'] );
        }
    }

    public function index() {

        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $user_id = $this->session->userdata('user_id');

        $user_data = $this->employeesummary->get_by_id($user_id);

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//        var_dump($user_groups)
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
//        var_dump($data['mainmenu']);die;

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_apply_leave', '', TRUE);
//        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function upload_file() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $user_id = $this->session->userdata('user_id');

        if (isset($user_id))
            $user_data = $this->employeesummary->get_by_id($user_id);

//        echo 'hi';
//        echo '<pre>',  print_r($user_data);die;
//        var_dump($user_data->userfullname);
//        die;
//        die;
        $targetDir = "uploads/";
        $fileName = $_FILES['file']['name'];
        $targetFile = $targetDir . $fileName;

        if (!empty($_FILES)) {
            $filename = $this->handleUpload($user_data);
            echo json_encode(true);
            die;
        }
//        var_dump($data);
//        die;
//        if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
//            //insert file information into db table
////        $conn->query("INSERT INTO files (file_name, uploaded) VALUES('".$fileName."','".date("Y-m-d H:i:s")."')");
//        }
    }

    function handleUpload($user_data) {

        if (!empty($_FILES)) {



            // Validate the file type
            $fileTypes = array('jpg', 'jpeg', 'gif', 'png'); // File extensions
            $fileParts = pathinfo($_FILES['file']['name']);

            if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
                //$this->session->set_error_flashdata('msg', 'Oops! An Error Occurred.');
                $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
                return false;
            }

            $user_slug = $user_data->userfullname;

            $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
//            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'users'
//                    . DIRECTORY_SEPARATOR . $user_slug.DIRECTORY_SEPARATOR .'articles';
//            
            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents';


            if (!file_exists($targetPath)) {
                mkdir($targetPath, 0777, true);
            }

            $tempFile = $_FILES['file']['tmp_name'];
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

            //$rand = randString(4);
//            $targetURL .= '/' . $user_slug . '.' . $ext;
//            $targetPath .= DIRECTORY_SEPARATOR . $user_slug . '.' . $ext;

            $rand = randString(4);
            $targetURL .= '/' . $user_slug . $rand . '.' . $ext;
            $targetPath .= DIRECTORY_SEPARATOR . $user_slug . $rand . '.' . $ext;

            move_uploaded_file($tempFile, $targetPath);

            $data['image'] = $targetURL;


            return $targetPath;
            //  return true;
        }
    }

    public function profile() {

        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        //common
        //profile
        
        $data['profile_summary'] = $this->employeesummary->employee_profile_data_by_id($user_id);
        $data['communication_detail'] = $this->employeesummary->employee_communication_data_by_id(82);
        if (isset($data['communication_detail'])) {
            $data['perm_contry'] = $this->country->get_name_by_id($data['communication_detail']->perm_country);
            $data['perm_state'] = $this->state->get_name_by_id($data['communication_detail']->perm_state);
            $data['perm_city'] = $this->city->get_name_by_id($data['communication_detail']->perm_city);

            $data['contry'] = $this->country->get_name_by_id($data['communication_detail']->current_country);
            $data['state'] = $this->state->get_name_by_id($data['communication_detail']->current_state);
            $data['city'] = $this->city->get_name_by_id($data['communication_detail']->current_city);

            $data['address_detail'] = $data['communication_detail']->current_streetaddress . ', ' . $data['city'] . ', ' . $data['state'] . ', Pincode-' . $data['communication_detail']->current_pincode;
            $data['perm_address_detail'] = $data['communication_detail']->perm_streetaddress . ', ' . $data['city'] . ', ' . $data['state'] . ', Pincode-' . $data['communication_detail']->perm_pincode;
        }
        $data['prefix'] = $this->employeesummary->prefix_name_by_id($data['profile_summary']->prefix_id);
        $data['company_rpfile'] = $this->employeesummary->get_employee_summary_data($user_id);
        $data['employee_mode'] = $this->employeesummary->employee_mode_name_by_id($data['profile_summary']->prefix_id);
        $data['employee_role'] = $this->employeesummary->employee_role_name_by_id($data['profile_summary']->emprole);
        $data['department'] = $this->employeesummary->department_name_by_id($data['profile_summary']->department_id);
        $data['jobtitle'] = $this->employeesummary->jobtitle_name_by_id($data['profile_summary']->department_id);

        //personal details
        $data['personal_detail'] = $this->employeesummary->get_personal_detail_by_id($user_id);

        if (isset($data['personal_detail'])) {

            if ($data['personal_detail']->genderid == '1')
                $data['personal_detail']->genderid = 'Male';
            else
                $data['personal_detail']->genderid = 'Female';

            if ($data['personal_detail']->maritalstatusid)
                $data['personal_detail']->maritalstatusid = $this->employeesummary->get_marital_status_by_id($data['personal_detail']->maritalstatusid);

            if ($data['personal_detail']->nationalityid)
                $data['personal_detail']->nationalityid = $this->employeesummary->get_nationality_by_id($data['personal_detail']->nationalityid);

            if ($data['personal_detail']->languageid)
                $data['personal_detail']->languageid = $this->employeesummary->get_language_by_id($data['personal_detail']->languageid);
            
        }

//        var_dump($data['communication_detail']);die;

        $user_data = $this->employeesummary->get_by_id($user_id);

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//        var_dump($user_groups)
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
//        var_dump($data['mainmenu']);die;

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_view_profile', (isset($data) ? $data : NULL));
//        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function save_exp_data() {
//        var_dump($_POST);die;
        if(isset($_POST)){
            $data = array(
                'user_id'=>  $this->session->userdata('user_id'),
                'comp_name'=>  $this->input->post('expcompanynm'),
                'comp_website'=>  $this->input->post('expcompanyurl'),
                'createddate'=>date('Y-m-d')
//                ' 	from_date'=>  $this->input->post('expcompanynm'),
//                'comp_name'=>  $this->input->post('expcompanynm'),
            );
            
            $res = $this->db->insert('main_empexperiancedetails',$data);
                        $this->experiencedetails->insert($data);
            var_dump($res);die;
//            $this->expsum->insert();
        }
    }

    public function apply_leave() {

        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $data['user'] = $this->employeesummary->employee_profile_data_by_id($user_id);

//        var_dump($user_data);die;

        $data['leave_day_type'] = array('0' => 'Select Leave Day', '1' => 'Full Day', '2' => 'Half Day');
        $data['leave_type'] = array('0' => 'Select Leave Type', '1' => 'Seek', '2' => 'Casual leave');

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//        var_dump($user_groups)
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
//        var_dump($data['mainmenu']);die;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

//            var_dump($this->input->post('leave_date'));

            if ($this->input->post('leave_date')) {

                $from_to_date = $this->input->post('leave_date');
                $from_to_date_array = explode('- ', $from_to_date);

//                $from_date = str_replace("/", "-", $from_to_date_array[0]);
//                $to_date = str_replace("/", "-", $from_to_date_array[1]);

                $date = str_replace('/', '-', $from_to_date_array[0]);
                $to_date = date('Y-m-d', strtotime($date));

                $date = str_replace('/', '-', $from_to_date_array[1]);
                $from_date = date('Y-m-d', strtotime($date));


                /* for weekend days calculation */

                $datetime1 = new DateTime($from_date);
                $datetime2 = new DateTime($to_date);
                $interval = $datetime1->diff($datetime2);
                $woweekends = 0;
                for ($i = 0; $i <= $interval->d; $i++) {
                    $modif = $datetime1->modify('+1 day');
                    $weekday = $datetime1->format('w');

                    if ($weekday != 0 && $weekday != 6) { // 0 for Sunday and 6 for Saturday
                        $woweekends++;
                    }
                }
                $no_of_days = $woweekends;
                 echo json_encode(array('content' => (isset($no_of_days) ? $no_of_days : NULL)));
            die;
            }




            $dataleaverequest = array(
                'user_id' => $this->session->userdata('user_id'),
                'leaveday' => $this->input->post('leave_day_type'),
                'leavetypeid' => $this->input->post('leave_type'),
                'leavestatus' => $this->input->post('leave_status'),
                'from_date' => $from_date,
                'to_date' => $to_date,
                'no_of_days' => $no_of_days, //'2', //$this->input->post('no_of_days'),
                'rep_mang_id' => $this->input->post('reportind_manager'),
                'reason' => $this->input->post('leave_reason'),
                'createdby' => $this->session->userdata('user_id'),
                'createddate' => date('Y-m-d H:i:s')
            );

//            
//            var_dump($dataleaverequest);
//            die;
////            
            $this->leave->insert($dataleaverequest);

            unset($_POST);

//            var_dump($dataleaverequest);die;
//            echo 'done';die;
//            $this->input->post('todo');
        }


        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_apply_leave', (isset($data) ? $data : NULL));
//        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function leave_summary() {

        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $data['user'] = $this->employeesummary->employee_profile_data_by_id($user_id);

//        var_dump($user_data);die;




        $data['leave_day_type'] = array('0' => 'Select Leave Day', '1' => 'Full Day', '2' => 'Half Day');
        $data['leave_type'] = array('0' => 'Select Leave Type', '1' => 'Seek', '2' => 'Casual leave');

        /* Menu */
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
//        var_dump($user_groups)
        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
//        var_dump($data['mainmenu']);die;


        $data['leave_summary_data'] = $this->leave->get_leave_request_employee_summary($user_id);
//        var_dump($data['leave_summary_data']);die;
//            $dataleaverequest = array(
//                'user_id' => $this->session->userdata('user_id'),
//                'leaveday' => $this->input->post('leave_day_type'),
//                'leavetypeid' => $this->input->post('leave_type'),
//                'leavestatus' => $this->input->post('leave_status'),
//                'from_date' => '2016-11-17', //$this->input->post('leave_day_type'),
//                'to_date' => '2016-11-20', //$this->input->post('leave_day_type'),
//                'no_of_days' => '2', //$this->input->post('no_of_days'),
//                'rep_mang_id' => $this->input->post('reportind_manager'),
//                'createdby' => $this->session->userdata('user_id'),
//                'createddate' => date('Y-m-d H:i:s')
//            );
//
//            $this->leave->insert($dataleaverequest);




        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', '', TRUE);
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_view_leave_summary', (isset($data) ? $data : NULL));
//        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function summary() {

        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//            echo json_encode(array('content' => (isset($_POST) ? $_POST : NULL)));
            echo '<pre>', print_r($_POST);
            die;
            die;
        }
    }
}