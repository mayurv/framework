<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Employee extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave', 'employeesholiday', 'interviewdetails', 'years','months', 'holidaydates', 'workstation'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language', 'proficiency', 'employeelanguage', 'emergencycontact', 'emphobbies', 'empchilddetails', 'numbers'));
        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa', 'leavetypesAllocation'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang',));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        } elseif (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

//        $this->output->cache(1);

        if (!$this->ion_auth->logged_in()) {
            redirect('auth', 'refresh');
        }

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

//        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);
        //to get current login user data
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        //to get all data
        //to get main menu, sub menu
        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);


//        var_dump($data);die;
        $user_id = $this->session->userdata('user_id');

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['employee'] = $this->employeesummary->get_all();
        $dataMenu['candidates'] = $this->employeesummary->get_candidate_list();

        //$this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', '_view_all_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    /*
     * Add Associate
     */

    public function addofficial() {


//        $this->output->delete_cache();
//        $this->db->cache_on();
//        $this->output->cache(1);
//        var_dump($_POST['direct']);die;
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata(lang('not_access'), $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
        $data['candidate_details'] = NULL;
        if (isset($_POST['form_action'])) {
            if ($_POST['direct'] != 'direct') {
                $candidate_id = $_POST['candidate_id'];
                $data['candidate_details'] = $this->interviewdetails->as_array()->get_by('id', $candidate_id);
            }
        }
//        echo $this->db->last_query();die;
//        var_dump($data['candidate_details']);die;
        //curent user id
        $data['rep_manager_list'] = array('' => 'Select Manager');
        $data['position_list'] = array('' => 'Select Designation');
        $data['user_summary'] = NULL;
        $data['communication_detail'] = NULL;
        $data['nationality_list'] = NULL;
        $data['language_list'] = NULL;
        $data['leaves'] = NULL;


        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
//        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['astatus'] = array('0' => 'In-Active', '1' => 'Active');
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->workstation->dropdown('work_station_code'));
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = $this->numbers->get_years();
        $data['monthsexp'] = $this->numbers->get_months();
//        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
//        

        /* communication */
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = (array('' => 'Select Hobbies') + $this->hobbies->dropdown('hobbies_title'));

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "add") {
//            var_dump($_POST);die;

            $config = array(
//                array('field' => 'email',
//                    'label' => 'email',
//                    'rules' => 'trim|required|max_length[50]|valid_email|is_unique[main_users.email]'),
//                array('field' => 'firstname',
//                    'label' => 'First Name',
//                    'rules' => 'trim|alpha|min_length[2]|max_length[25]|required'),
//                array('field' => 'lastname',
//                    'label' => 'Last Name',
//                    'rules' => 'trim|alpha|min_length[2]|max_length[25]|required'),
//                array('field' => 'prefix_id',
//                    'label' => 'Prefix',
//                    'rules' => 'required'),
//                array('field' => 'modeofemp_id',
//                    'label' => 'Mode of Employment',
//                    'rules' => 'required'),
//                array('field' => 'emprole_id',
//                    'label' => 'Role',
//                    'rules' => 'required'),
//                array('field' => 'department_id',
//                    'label' => 'Department',
//                    'rules' => 'required'),
//                array('field' => 'reporting_manager',
//                    'label' => 'Manager',
//                    'rules' => 'required'),
//                array('field' => 'jobtitle_id',
//                    'label' => 'Job Title',
//                    'rules' => 'required'),
//                array('field' => 'position_id',
//                    'label' => 'Position',
//                    'rules' => 'required'),
//                array('field' => 'emp_status_id',
//                    'label' => 'Employment Status',
//                    'rules' => 'required'),
//                array('field' => 'date_of_joining',
//                    'label' => 'Date of Joining',
//                    'rules' => 'required'),
//                array('field' => 'yearsofexp',
//                    'label' => 'Years of Experience',
//                    'rules' => 'required'),
//                array('field' => 'monthsofexp',
//                    'label' => 'Months of Experience',
//                    'rules' => 'required')
            );

//            $this->form_validation->set_rules($config);
//            if ($this->form_validation->run() == TRUE) {
            /* For update group_id */
            $emprole = $this->input->post('emprole_id');
            $group_id = $this->groups->get_group_id_by_role_id($emprole);

            /* Password Generate */
            $passFormatData = array(
                'employeeid' => $this->input->post('employeeid'),
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'date_of_joining' => $this->input->post('date_of_joining')
            );

            $dataPass = $this->generatePassword($passFormatData);
            /* Generate Unique Slug */
            $user_slug = $this->user_unique_slug($passFormatData);

            $date = $this->input->post('date_of_joining');
            $date = str_replace(',', '', $date);
            $date_of_join = date('Y-m-d H:m:s', strtotime($date));

            $dataUserRegistration = array(
                'group_id' => $group_id,
                'emprole' => $this->input->post('emprole_id'),
                'userfullname' => $this->input->post('firstname') . ' ' . $this->input->post('lastname'),
                'empipaddress' => $this->input->ip_address(),
                'password' => $dataPass['password'],
                'password1' => $dataPass['password1'],
                'email' => $this->input->post('email'),
                'contactnumber' => $this->input->post('contactnumber'),
                'reporting_manager' => $this->input->post('reporting_manager'), //                    
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'prefix_id' => $this->input->post('prefix_id'),
                'employeeId' => $this->input->post('employeeid'),
                'modeofentry' => $this->input->post('modeofemp_id'),
                'department_id' => $this->input->post('department_id'),
                'emp_status_id' => $this->input->post('emp_status_id'),
                'position_id' => $this->input->post('position_id'),
                'jobtitle_id' => $this->input->post('jobtitle_id'),
                'date_of_joining' => $date_of_join,
                'years_exp' => $this->input->post('yearsofexp'),
                'months_exp' => $this->input->post('monthsofexp'),
//                'profileimg' => $this->input->post('profileimage'),
                'salt' => $user_slug,
                'createdby' => $this->session->userdata('user_id'),
                'createddate' => date('Y-m-d H:i:s')
            );



            /* Make Unique directory */
            $this->_mkdir_user_directiory($passFormatData);

            /* file upload */
            if (isset($_FILES['cv_doc']['name']) && $_FILES['cv_doc']['name'] != '') {
//                if (isset($_FILES['cv_doc'])) {
                $targetDir = "uploads/";
                $fileName = $_FILES['cv_doc']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['cv_doc']['name'])) {
                    $uploded_file_path = $this->handleUpload($dataUserRegistration['salt']);
                    if ($uploded_file_path != '')
                        $dataUserRegistration['user_cv'] = $uploded_file_path;
                }
            }


            $insertAssoId = $this->users->insert($dataUserRegistration);

            /* work station allocation */
            $workstnId = $this->input->post('work_status');
            $workStationUpdate = array(
                'is_alloted' => '1',
                'user_id' => $insertAssoId,
                'isactive' => '1'
            );

            $this->workstation->update($workstnId, $workStationUpdate);
//                echo $this->db->last_query();die;

            if (isset($_FILES['cv_doc']['name']) && $_FILES['cv_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['cv_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $dataDocumentDetail = array(
                    'user_id' => $insertAssoId,
                    'name' => $dataUserRegistration['user_cv'],
                    'attachments' => '/cv/' . $this->input->post('cv_doc'),
                    'tag' => 'cv',
                    'document_type' =>'2',
                    'type' => $dataDocumentDetail['type'],
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $dataUserEmployeeSummary['document_id'] = $this->documents->insert($dataDocumentDetail);
            }

//            if (isset($_FILES['cv_doc']['name']) && $_FILES['cv_doc']['name'] != '') {
//
//                $fileExt = pathinfo($_FILES['cv_doc']['name']);
////                    var_dump($fileExt);
//                $dataDocumentDetail['type'] = $fileExt['extension'];
//
//                $dataDocumentDetail = array(
//                    'user_id' => $insertAssoId,
//                    'name' => $dataUserRegistration['user_cv'],
//                    'attachments' => '/cv/' . $dataUserRegistration['user_cv'],
//                    'tag' => 'cv',
//                    'type' => $dataDocumentDetail['type'],
//                    'createdby' => $user_id,
//                    'createddate' => date('Y-m-d H:m:s'),
//                );
//                $dataUserEmployeeSummary['document_id'] = $this->documents->insert($dataDocumentDetail);
//            }


            if (isset($insertAssoId)) {
                /* employee data */
                $dataUserEmployee = $dataUserRegistration;
                unset($dataUserEmployee['group_id']);
                unset($dataUserEmployee['emprole']);
                unset($dataUserEmployee['userfullname']);
                unset($dataUserEmployee['empipaddress']);
                unset($dataUserEmployee['password']);
                unset($dataUserEmployee['password1']);
                unset($dataUserEmployee['email']);
                unset($dataUserEmployee['contactnumber']);
                unset($dataUserEmployee['firstname']);
                unset($dataUserEmployee['lastname']);
                unset($dataUserEmployee['employeeId']);
                unset($dataUserEmployee['modeofentry']);
                unset($dataUserEmployee['profileimg']);
                unset($dataUserEmployee['salt']);
                unset($dataUserEmployee['user_cv']);
                $dataUserEmployee['reporting_manager_twoup'] = $this->input->post('reporting_manager_two');
                $dataUserEmployee['work_station'] = $this->input->post('work_status');
                $dataUserEmployee['user_id'] = $insertAssoId;

//                    var_dump($dataUserEmployee);die;
                $this->employees->insert($dataUserEmployee);
                /* end employeedata */
                $slug = $this->users->get_slug_by_id($insertAssoId);

                /* Upload profile picture */
                if (isset($_FILES['profile_image']['name']) && $_FILES['profile_image']['name'] != '') {
                    $targetDir = "uploads/";
                    $fileName = $_FILES['profile_image']['name'];
                    $targetFile = $targetDir . $fileName;

                    $fileExt = pathinfo($_FILES['profile_image']['name']);
                    $dataDocumentDetail['type'] = $fileExt['extension'];

                    $uploded_file_path = $this->handleUploadCommon($slug);
                    if ($uploded_file_path != '')
                        $dataUserEmployeeSummary['profileimg'] = $uploded_file_path;

                    if (isset($_FILES)) {
                        $dataDocumentDetail = array(
                            'user_id' => $insertAssoId,
                            'name' => $dataUserEmployeeSummary['profileimg'],
                            'attachments' => '/profile/' . $dataUserEmployeeSummary['profileimg'],
                            'tag' => 'profile',
                            'document_type' =>'5',
                            'type' => $dataDocumentDetail['type'],
                            'createdby' => $user_id,
                            'createddate' => date('Y-m-d H:m:s'),
                        );
                        $this->documents->insert($dataDocumentDetail);
                    }
                }


//                var_dump($dataUserEmployeeSummary);die;
                /* employee summary data */
                $dataUserEmployeeSummary = array(
                    'profileimg' => $slug . '/profile/' . $dataUserEmployeeSummary['profileimg'],
                    'document_id' => $dataUserEmployeeSummary['document_id'],
                    'user_id' => $insertAssoId,
                    'work_station' => $this->input->post('work_status'),
                    'holiday_group' => $this->input->post('holiday_group_id'),
                    'prefix_name' => $this->input->post('prefix_name'),
                    'emailaddress' => $this->input->post('email'),
                    'emprole_name' => $this->input->post('emprole_name'),
                    'reporting_manager_name' => $this->input->post('reporting_manager_name') ? $this->input->post('reporting_manager_name') : '',
                    'reporting_manager_twoup' => $this->input->post('reporting_manager_two'),
                    'reporting_manager_twoup_name' => $this->input->post('reporting_manager_twoup_name') ? $this->input->post('reporting_manager_twoup_name') : '',
                    'department_name' => $this->input->post('department_name') ? $this->input->post('department_name') : '',
                    'jobtitle_name' => $this->input->post('jobtitle_name') ? $this->input->post('jobtitle_name') : '',
                    'position_name' => $this->input->post('position_name') ? $this->input->post('position_name') : '',
                    'holiday_group_name' => $this->input->post('holiday_group_name') ? $this->input->post('holiday_group_name') : '',
                    'emp_status_name' => $this->input->post('emp_status_name') ? $this->input->post('emp_status_name') : '',
                    'profile_completion' => 30,
                    'isactive' => $this->input->post('isactive'),
                );

                $dataUserEmployeeSummary = array_merge($dataUserRegistration, $dataUserEmployeeSummary);

                unset($dataUserEmployeeSummary['group_id']);
//                    unset($dataUserEmployeeSummary['user_cv']);
                unset($dataUserEmployeeSummary['email']);
                unset($dataUserEmployeeSummary['password1']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['empipaddress']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['salt']);


                $this->employeesummary->insert($dataUserEmployeeSummary);
                /* end employee summary data */


                /* to make entry in group */
                $datagrp = array('user_id' => $insertAssoId, 'group_id' => $group_id);
                $res = $this->usergroups->insert_main_user_groups($datagrp);
                /* to make enrty in employees */



                /* leaves & holidays */
//                    $dataleave['user_id'] = $insertAssoId;
//                    $dataleave['alloted_year'] = $this->input->post('emp_leave_year'); //2016;
//                    $dataleave['emp_leave_limit'] = $this->input->post('emp_leave_limit');
//                    $dataleave['createddate'] = date('Y-m-d H:m:s');
//                    $dataleave['createdby'] = $this->session->userdata('user_id');
//                    $this->employeesummary->insert_leaves($dataleave);
//                    unset($dataleave);
//                    
                //       add leaves
                $current_year = date("Y");
                $cur_year_id = $this->years->get_current_yearId($current_year);
                $leave_list = $this->leavetypesAllocation->get_leavetypesAllocationList($cur_year_id);

                if (count($leave_list) != 0) {
                    $cnt = count($leave_list);
                    for ($i = 0; $i < $cnt; $i++) {

                        $dataAllotedLeaveType[$i]['user_id'] = $insertAssoId;
                        $dataAllotedLeaveType[$i]['alloted_year'] = $leave_list[$i]['year_id'];

                        if ($leave_list[$i]['leavetype'] == 1) {

                            $dataAllotedLeaveType[$i]['alloted_leaves'] = 0;
                        } else
                            $dataAllotedLeaveType[$i]['alloted_leaves'] = $leave_list[$i]['leavepreallocated'];

                        $dataAllotedLeaveType[$i]['leavetype'] = $leave_list[$i]['leavetype'];
                        $dataAllotedLeaveType[$i]['createdby'] = $user_id;
                        $dataAllotedLeaveType[$i]['createddate'] = date('Y-m-d H:m:s');
                    }

                    if (isset($dataAllotedLeaveType))
                        foreach ($dataAllotedLeaveType as $dataResult) {

                            $this->employeesleave->insert($dataResult);
                        }
                }
                // end add leaves

                $dataholiday['user_id'] = $insertAssoId;
                $dataholiday['holiday_group_id'] = $this->input->post('holiday_group_id');
                $dataholiday['createddate'] = date('Y-m-d H:m:s');
                $dataholiday['createdby'] = $this->session->userdata('user_id');
                $this->employeesummary->insert_holiday_group($dataholiday);
                unset($dataholiday);
                /* end leaves & holidays */

                /* set session data */
                $session_data = array(
                    'associate_email' => $dataUserRegistration['email'],
                    'associate_id' => $insertAssoId //everyone likes to overwrite id so we'll use user_id
                );
                $this->session->set_userdata($session_data);
                /* end set session data */
            }
            $data['empId'] = $this->_get_employeeid();
            //}//end of post

            $this->session->set_flashdata('msg', 'Record added successfully');
        }

        /* header data */
        if (isset($user_id)) {
            $data['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $data['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $data['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        
        //Get Menu & Sub Menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_add_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
        if (isset($insertAssoId))
            redirect('employee/view_user/' . $insertAssoId, 'refresh');
//        
    }

    /* Unique Slug Generation */

    public function user_unique_slug($uniqueSlugData) {
        return strtolower($uniqueSlugData['employeeid'] . '-' . $uniqueSlugData['firstname']);
    }

    /* Create user directory */

    public function _mkdir_user_directiory($mkdirUserData) {

        $user_slug = $this->user_unique_slug($mkdirUserData);
//        var_dump($user_slug); die;
        /* to create registered user folder directory */
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents';
        $targetPathProf = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/profile';
        if (!file_exists($targetPath) || !file_exists($targetPathProf)) {
            mkdir($targetPath, 0777, true);
            mkdir($targetPathProf, 0777, true);
            return true;
        } else
            return false;
        /* end of make directory */
    }

    /* Password Generarting */

    private function generatePassword($passFormatData) {

        $params['salt_prefix'] = $this->config->item('salt_prefix', 'ion_auth');
        $this->load->library('bcrypt', $params);


        $this->load->library('encrypt');

        $key = 'super-secret-key';
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-=+;:,.?";
        $password = substr(str_shuffle($chars), 0, 4);
        $post_array['password1'] = strtolower($passFormatData['employeeid']) . '@' . $password;
        $salt = $this->store_salt ? $this->salt() : FALSE;
        $post_array['password'] = $this->hash_password($post_array['password1'], $salt);

        return $post_array;
    }

    /* Autogenerate Employee ID  */

    public function _get_employeeid() {

        $this->load->model(array('employees'));
        $curId = $this->employees->get_employee_id();

        $new_var = (int) substr($curId->employeeId, 4, strpos($curId->employeeId, "-"));
        $new_id = $new_var + 1;
        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

    /* Get Position by jobtitle */

    function get_position_by_jt_id($jtid) {
        return $this->employees->get_position_by_jt_id($jtid);
    }

    /*
     * View Associate
     */

    public function view_user($associate_id) {

//         $this->output->delete_cache();
//        $this->output->clear_page_cache('employee/v');
//        $this->db->cache_on();
//        $this->output->cache(1);
//        
        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
//        $data['empid'] = $empId;
//        $data['associate_id'] = $associate_id;
        $data['user_summary'] = NULL;
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
//        var_dump($data['user_summary']);die;
        $data['holiday'] = NULL;
        $data['leaves'] = NULL;
        $data['communication_detail'] = NULL;
        $data['personal_detail'] = NULL;


        $data['action'] = 'add';
        $data = $this->get_all_view_data($associate_id);

        /* set session data */
        $session_data = array(
            'associate_email' => $data['user_summary']['emailaddress'],
            'associate_id' => $associate_id //everyone likes to overwrite id so we'll use user_id
        );
        $this->session->set_userdata($session_data);
        /* end set session data */

        /* Holiday List */
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_holidayList($cur_year_id);
        /* end holiday list */

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        //var_dump($data['current_employee']);die;
        //to get main menu, sub menu
        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', '/official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    /*
     * Edit Associate
     */

    public function edit($associate_id) {

        $data['empId'] = NULL;
        $data['user_summary'] = NULL;
        $data['user_communication_details'] = NULL;
//        $date_of_leaving = '0000-00-00 00:00:00';
        $data['marital_list'] = NULL;
        $date_of_leaving = NULL;
        $dataUserRegistration['user_cv'] = NULL;

        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }


        $data['action'] = 'edit';
        $this->form_validation->set_rules('firstname', 'First name', 'trim|required');
        /* to get all data */
        $data = $this->get_all_view_data($associate_id);

        /* edit employee */
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "edit") {

            /* For update group_id */

            $document_id = $this->input->post('document_id');
            $emprole = $this->input->post('emprole_id');
            $group_id = $this->groups->get_group_id_by_role_id($emprole);
            $user_slug = $this->employees->get_user_slug_by_id($associate_id);
//            var_dump($user_slug);die;
            $date_join = $this->input->post('date_of_joining');
            $date_join = str_replace(',', '', $date_join);
            $date_of_join = date('Y-m-d H:m:s', strtotime($date_join));

            if (($this->input->post('date_of_leaving'))) {
                $date_leaving = $this->input->post('date_of_leaving');
                $date_leaving = str_replace(',', '', $date_leaving);
                $date_of_leaving = date('Y-m-d H:m:s', strtotime($date_leaving));
            } else
                $date_of_leaving = NULL;
//            var_dump($date_of_leaving);die;
            $dataUserRegistration = array(
                'group_id' => $group_id,
                'emprole' => $this->input->post('emprole_id'),
                'userfullname' => $this->input->post('firstname') . ' ' . $this->input->post('lastname'),
                'empipaddress' => $this->input->ip_address(),
                'email' => $this->input->post('email'),
                'contactnumber' => $this->input->post('contactnumber'),
                'reporting_manager' => $this->input->post('reporting_manager'),
                'firstname' => $this->input->post('firstname'),
                'lastname' => $this->input->post('lastname'),
                'prefix_id' => $this->input->post('prefix_id'),
                'employeeId' => $this->input->post('employeeid'),
                'modeofentry' => $this->input->post('modeofemp_id'),
                'department_id' => $this->input->post('department_id'),
                'emp_status_id' => $this->input->post('emp_status_id'),
                'position_id' => $this->input->post('position_id'),
                'jobtitle_id' => $this->input->post('jobtitle_id'),
                'date_of_joining' => $date_of_join, //$this->input->post('date_of_joining'),
                'date_of_leaving' => $date_of_leaving, //$this->input->post('date_of_joining'),
                'years_exp' => $this->input->post('yearsofexp'),
                'months_exp' => $this->input->post('monthsofexp'),
//                'profileimg' => $this->input->post('profileimage'),
                'modifiedby' => $this->session->userdata('user_id'),
                'modifieddate' => date('Y-m-d H:i:s'),
//                'salt' => $user_slug['salt']
            );

//            var_dump($_FILES);die;
            /* file upload */

            if (isset($_FILES['cv_doc']['name'])) {
                $targetDir = "uploads/";
                $fileName = $_FILES['cv_doc']['name'];
                $targetFile = $targetDir . $fileName;
            }

            if (isset($_FILES['cv_doc']['name'])) {
                if (!empty($_FILES['cv_doc']['name'])) {

                    $uploded_file_path = $this->handleUpload($user_slug);
//                    var_dump($uploded_file_path);die;
                    if ($uploded_file_path != '')
                        $dataUserRegistration['user_cv'] = $uploded_file_path;
                }
            }


            if (isset($_FILES['cv_doc']['name']) && $_FILES['cv_doc']['name'] != '') {
                $fileExt = pathinfo($_FILES['cv_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                if (empty($document_id)) {

                    echo "not empty";
                    die;
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataUserRegistration['user_cv'],
                        'attachments' => '/cv/' . $this->input->post('cv_doc'),
                        'tag' => 'cv',
                        'document_type' =>'2',
                        'type' => $dataDocumentDetail['type'],
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $dataUserRegistration['document_id'] = $this->documents->insert($dataDocumentDetail);
                } else {
//                    echo "not empty";die;
                    $dataDocumentDetail = array(
//                        'user_id' => $associate_id,
                        'name' => $dataUserRegistration['user_cv'],
                        'attachments' => '/cv/' . $dataUserRegistration['user_cv'],
                        'tag' => 'cv',
                        'document_type' =>'2',
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $this->documents->update_document($document_id, $dataDocumentDetail);
                }
            }

            $updateAssoId = $this->users->update($associate_id, $dataUserRegistration);

            if (isset($updateAssoId)) {
                /* employee data */
                $dataUserEmployee = $dataUserRegistration;
                unset($dataUserEmployee['group_id']);
                unset($dataUserEmployee['emprole']);
                unset($dataUserEmployee['userfullname']);
                unset($dataUserEmployee['empipaddress']);
                unset($dataUserEmployee['password']);
                unset($dataUserEmployee['password1']);
                unset($dataUserEmployee['email']);
                unset($dataUserEmployee['contactnumber']);
                unset($dataUserEmployee['firstname']);
                unset($dataUserEmployee['lastname']);
                unset($dataUserEmployee['employeeId']);
                unset($dataUserEmployee['modeofentry']);
                unset($dataUserEmployee['profileimg']);
                unset($dataUserEmployee['salt']);
                unset($dataUserEmployee['user_cv']);
//                $dataUserEmployee['work_station'] = $this->input->post('work_status');
//                var_dump($dataUserEmployee);die;

                $this->employees->update($associate_id, $dataUserEmployee);
                /* end employeedata */

                /* employee summary data */
                $dataUserEmployeeSummary = array(
//                    'work_station' => $this->input->post('work_status'),
                    'holiday_group' => $this->input->post('holiday_group_id'),
                    'prefix_name' => $this->input->post('prefix_name'),
                    'emailaddress' => $this->input->post('email'),
                    'emprole_name' => $this->input->post('emprole_name'),
                    'reporting_manager_name' => $this->input->post('reporting_manager_name') ? $this->input->post('reporting_manager_name') : '',
                    'reporting_manager_twoup' => $this->input->post('reporting_manager_two') ? $this->input->post('reporting_manager_two') : '',
                    'reporting_manager_twoup_name' => $this->input->post('reporting_manager_twoup_name') ? $this->input->post('reporting_manager_twoup_name') : '',
                    'department_name' => $this->input->post('department_name') ? $this->input->post('department_name') : '',
                    'jobtitle_name' => $this->input->post('jobtitle_name') ? $this->input->post('jobtitle_name') : '',
                    'position_name' => $this->input->post('position_name') ? $this->input->post('position_name') : '',
                    'holiday_group_name' => $this->input->post('holiday_group_name') ? $this->input->post('holiday_group_name') : '',
                    'emp_status_name' => $this->input->post('emp_status_name') ? $this->input->post('emp_status_name') : '',
                    'profile_completion' => 30,
                    'isactive' => $this->input->post('isactive')
                );

                $dataUserEmployeeSummary = array_merge($dataUserEmployeeSummary, $dataUserRegistration);
                unset($dataUserEmployeeSummary['group_id']);
                unset($dataUserEmployeeSummary['email']);
                unset($dataUserEmployeeSummary['password1']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['empipaddress']);
                unset($dataUserEmployeeSummary['password']);
                unset($dataUserEmployeeSummary['salt']);

//                var_dump($dataUserEmployeeSummary);die;

                $this->employeesummary->update($associate_id, $dataUserEmployeeSummary);
//                echo $this->db->last_query();die;
                /* end employee summary data */

                /* to make entry in group */
                $datagrp = array('group_id' => $group_id);
                $res = $this->usergroups->update($associate_id, $datagrp);

                /* to make enrty in employees */

                /* Update leaves & holidays */
                $dataleave = array(
                    'alloted_year' => $this->input->post('emp_leave_year'),
                    'emp_leave_limit' => $this->input->post('emp_leave_limit'),
                    'modifieddate' => date('Y-m-d H:m:s'),
                    'modifiedby' => $this->session->userdata('user_id'),
                );

                $this->employeesleave->update($associate_id, $dataleave);
                unset($dataleave);

                $dataholiday = array(
                    'holiday_group_id' => $this->input->post('holiday_group_id'),
                    'modifieddate' => date('Y-m-d H:m:s'),
                    'modifiedby' => $this->session->userdata('user_id'),
                );
                $this->employeesholiday->update($associate_id, $dataholiday);
                unset($dataholiday);
                $this->session->set_flashdata('msg', 'Record updated successfully');
                /* end leaves & holidays */
            }
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    /*
     * Add contact information
     */

    public function contact($action = 'add', $associate_id = NULL) {

//        var_dump($_FILES);die;

        $hobbies_data = array();

        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

//        var_dump($data['user_summary']);
////            echo 'no file';
//        die;
//        var_dump($_FILES);
//        echo 'no file';
//        die;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {

//            var_dump($_POST);
//            var_dump($associate_id);
//            die;

            /* insert Hobbies */
            $hobbies = $this->input->post('hobbies');
            if (isset($hobbies)) {
                foreach ($hobbies as $key => $val) {
                    $dataHobbiesDetail[$key]['user_id'] = $associate_id;
                    $dataHobbiesDetail[$key]['hobbies_id'] = $val;
                    $dataHobbiesDetail[$key]['createddate'] = $user_id;
                    $dataHobbiesDetail[$key]['createdby'] = date('Y-m-d H:m:s');
                }
            }
            if (isset($dataHobbiesDetail)) {
                foreach ($dataHobbiesDetail as $dtatHobb)
                    $this->emphobbies->insert($dtatHobb);
            }

            /* End insert hobbies */

//            die;
//            var_dump($_POST);
//            die;
            $associate_id = $this->input->post('associate_id');
            $dob = $this->input->post('dob');
            $dob = str_replace(',', '', $dob);
            $date_of_birth = date('Y-m-d', strtotime($dob));

            $anniversarydate = $this->input->post('anniversary');
            $anniversarydate = str_replace(',', '', $anniversarydate);
            $anniversarydate = date('Y-m-d', strtotime($anniversarydate));



            /* Add Associate language known */
            $language_count = $this->input->post('language_count');
            if (isset($language_count)) {
                for ($i = 1; $i <= $language_count; $i++) {
//                    $language_count;
                    $dataAssociateLanguage[$i]['user_id'] = $associate_id;
                    $dataAssociateLanguage[$i]['language_id'] = $this->input->post('language_id-' . $i);
                    $dataAssociateLanguage[$i]['proficiency_id'] = $this->input->post('proficiency_id-' . $i);
                    if ($this->input->post('option-' . $i)) {
                        foreach ($this->input->post('option-' . $i) as $key => $value) {
                            if ($key == 1)
                                $dataAssociateLanguage[$i]['read'] = 1;

                            if ($key == 2)
                                $dataAssociateLanguage[$i]['write'] = 1;

                            if ($key == 3)
                                $dataAssociateLanguage[$i]['speak'] = 1;
                        }
                    }
                    $dataAssociateLanguage[$i]['createdby'] = $user_id;
                    $dataAssociateLanguage[$i]['createddate'] = date('Y-m-d H:m:s');
                }
            }
//            var_dump($dataAssociateLanguage);
//            die;

            /* Add Associate Emergency Contact */
            $emergency_contact_count = $this->input->post('emergency_contact_count');
            if (isset($emergency_contact_count)) {
                for ($i = 1; $i <= $emergency_contact_count; $i++) {
//                    $language_count;
                    for ($j = 1; $j <= 10; $j++) {

                        if (($this->input->post('emergency_number-' . $j))) {

                            $dataEmergencyDetails[$i]['user_id'] = $associate_id;
                            $dataEmergencyDetails[$i]['emergency_number'] = $this->input->post('emergency_number-' . $i);
                            $dataEmergencyDetails[$i]['emergency_name'] = $this->input->post('emergency_name-' . $i);
                            $dataEmergencyDetails[$i]['emergency_email'] = $this->input->post('emergency_email-' . $i);
                            $dataEmergencyDetails[$i]['preference'] = $this->input->post('preference_' . $i);
                            $dataEmergencyDetails[$i]['createdby'] = $user_id;
                            $dataEmergencyDetails[$i]['createddate'] = date('Y-m-d H:m:s');
                        }
                    }
                }
            }
            if (isset($dataEmergencyDetails)) {
                foreach ($dataEmergencyDetails as $dataResult) {
                    $this->emergencycontact->insert($dataResult);
                }
            }

            /* insert child details */

            $child_count = $this->input->post('child_count');
            if (isset($child_count) && $child_count != '0') {
                for ($i = 1; $i <= $child_count; $i++) {
//                    $language_count;
                    for ($j = 1; $j <= 10; $j++) {

                        $dataChildsDetail[$i]['user_id'] = $associate_id;
                        $dataChildsDetail[$i]['child_name'] = $this->input->post('child_name-' . $i);
                        $dataChildsDetail[$i]['child_dob'] = date("Y-m-d", strtotime($this->input->post('child_dob-' . $i)));
                        $dataChildsDetail[$i]['createdby'] = $user_id;
                        $dataChildsDetail[$i]['createddate'] = date('Y-m-d H:m:s');
                    }
                }
            }

            if (isset($dataChildsDetail)) {
                foreach ($dataChildsDetail as $dtatChild)
                    $this->empchilddetails->insert($dtatChild);
            }

            /* End of insert child details */

//            die;
            $dataPersonalDetail = array(
                'user_id' => $this->input->post('associate_id'),
                'gender_id' => $this->input->post('gender_id'),
                'marital_status_id' => $this->input->post('marital_status'),
                'nationality_id' => $this->input->post('nationality_id'),
                'language_id' => $this->input->post('language_id'),
                'dob' => $date_of_birth,
                'anniversary_date' => $anniversarydate,
                'blood_group_id' => $this->input->post('blood_group_id'),
                'identity_mark' => $this->input->post('identity_mark'),
//                'hobbies_id' => $hobbies_data,
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );





            $this->personaldetails->insert($dataPersonalDetail);
//            $this->employeesummary->update($associate_id, $dataEmployeeSumary);

            if (isset($dataAssociateLanguage)) {
                $alredy_exist = $this->employeelanguage->is_exist($associate_id, $dataAssociateLanguage);
//                var_dump($alredy_exist);
//                die;
                foreach ($dataAssociateLanguage as $dataResult) {

                    $this->employeelanguage->insert($dataResult);
                }
            }

            /* Communication Details */
            $check_status = $this->input->post('check_status');



            $dataCommunicationDetail = array(
                'user_id' => $this->input->post('associate_id'),
                'personalemail' => $this->input->post('personal_email'),
                'mobile_number' => $this->input->post('mobile_number'),
                'perm_streetaddress' => $this->input->post('perm_address'),
                'perm_country' => $this->input->post('country_id'),
                'perm_state' => $this->input->post('state_id'),
                'perm_city' => $this->input->post('city_id'),
                'perm_pincode' => $this->input->post('postalcode'),
                'emergency_number' => $this->input->post('emergency_number'),
                'emergency_name' => $this->input->post('emergency_name'),
                'emergency_email' => $this->input->post('emergency_email')
            );

            if ($check_status == '1') {
                $dataCommunicationDetail_curr = array(
                    'same_check' => 1,
                    'current_streetaddress' => $this->input->post('perm_address'),
                    'current_country' => $this->input->post('country_id'),
                    'current_state' => $this->input->post('state_id'),
                    'current_city' => $this->input->post('city_id'),
                    'current_pincode' => $this->input->post('postalcode'),
                );
            } else {
                $dataCommunicationDetail_curr = array(
                    'same_check' => 0,
                    'current_streetaddress' => $this->input->post('curr_address'),
                    'current_country' => $this->input->post('c_country_id'),
                    'current_state' => $this->input->post('c_state_id'),
                    'current_city' => $this->input->post('c_city_id'),
                    'current_pincode' => $this->input->post('c_postalcode')
                );
            }
            $dataCommunicationDetail = array_merge($dataCommunicationDetail, $dataCommunicationDetail_curr);
//            $data['personal_detail'] = $this->personaldetails->as_array()->get_by('user_id', $associate_id);
//            $data['communication_detail'] = $this->communication->as_array()->get_by('user_id', $associate_id);

            $this->communication->insert($dataCommunicationDetail);

            $curcompletion = $this->employeesummary->get_comp_status($associate_id);
            $curcompletion = $curcompletion + 20;
            $profileStatus = array('profile_completion' => $curcompletion);
            $this->employeesummary->update($associate_id, $profileStatus);
            $this->session->set_flashdata('msg', 'Record addedd successfully');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'edit') {

//            var_dump($_POST);
////            var_dump($associate_id);
//            die;

            /* Associate language known */
            $language_count = $this->input->post('language_count');
            $alredy_exist = $this->employeelanguage->is_exist($associate_id);
            $alredy_exist_em = $this->emergencycontact->is_exist($associate_id);
//            var_dump($alredy_exist_em);die;
            /* Lnaguage for insert */

            if (isset($language_count) && $language_count != '0') {

                for ($i = 1; $i <= $language_count; $i++) {
//                    $language_count;
                    for ($j = 1; $j <= 10; $j++) {

                        if (($this->input->post('language_id-' . $j))) {

                            $dataAssociateLanguage[$i]['user_id'] = $associate_id;
                            $dataAssociateLanguage[$i]['language_id'] = $this->input->post('language_id-' . $i);
                            $dataAssociateLanguage[$i]['proficiency_id'] = $this->input->post('proficiency_id-' . $i);


                            if (($this->input->post('option-' . $i)))
                                foreach ($this->input->post('option-' . $i) as $key => $value) {
                                    if ($key == 1)
                                        $dataAssociateLanguage[$i]['read'] = 1;

                                    if ($key == 2)
                                        $dataAssociateLanguage[$i]['write'] = 1;

                                    if ($key == 3)
                                        $dataAssociateLanguage[$i]['speak'] = 1;
                                }
                            $dataAssociateLanguage[$i]['createdby'] = $user_id;
                            $dataAssociateLanguage[$i]['createddate'] = date('Y-m-d H:m:s');
                        }
                    }
                }
            }

            /* update */
//            var_dump($alredy_exist);die;
            if (isset($alredy_exist) && $alredy_exist != '') {
                foreach ($alredy_exist as $id => $val) {
//                    var_dump($this->input->post('optionu-' . $id));
                    $dataAssociateLanguageUpdate[$id]['user_id'] = $associate_id;
                    $dataAssociateLanguageUpdate[$id]['language_id'] = $this->input->post('language_id-u-' . $id);
                    $dataAssociateLanguageUpdate[$id]['proficiency_id'] = $this->input->post('proficiency_id-u-' . $id);

                    $current_option = $this->input->post('optionu-' . $id);
//                    var_dump($current_option); die;
                    if (isset($current_option)) {
                        $dataAssociateLanguageUpdate[$id]['read'] = 0;
                        $dataAssociateLanguageUpdate[$id]['write'] = 0;
                        $dataAssociateLanguageUpdate[$id]['speak'] = 0;
                        foreach ($current_option as $key => $value) {
                            if ($key == 1)
                                $dataAssociateLanguageUpdate[$id]['read'] = 1;

                            else if ($key == 2)
                                $dataAssociateLanguageUpdate[$id]['write'] = 1;

                            else if ($key == 3)
                                $dataAssociateLanguageUpdate[$id]['speak'] = 1;
                        }
                    }
                    $dataAssociateLanguageUpdate[$id]['modifiedby'] = $user_id;
                    $dataAssociateLanguageUpdate[$id]['modifieddate'] = date('Y-m-d H:m:s');
                }
            }

            if (isset($dataAssociateLanguageUpdate)) {

                foreach ($dataAssociateLanguageUpdate as $key => $dataResult) {

                    $this->employeelanguage->update($key, $dataResult);
                }
            }

            /* insert new languages */
            if (isset($dataAssociateLanguage)) {
                foreach ($dataAssociateLanguage as $dataResult) {
                    $this->employeelanguage->insert($dataResult);
                }
            }
//            var_dump($dataAssociateLanguageUpdate);
            /* End of language */



//            / update /
            if (isset($alredy_exist_em) && $alredy_exist_em != '') {
                foreach ($alredy_exist_em as $id) {
//                    var_dump($this->input->post('optionu-' . $id));
//                    $dataEmergencyUpdateDetails[$id]['user_id'] = $associate_id;
//                    echo $this->input->post('preference_u_' . $id);
                    $dataEmergencyUpdateDetails[$id]['emergency_number'] = $this->input->post('emergency_number-u-' . $id);
                    $dataEmergencyUpdateDetails[$id]['emergency_name'] = $this->input->post('emergency_name-u-' . $id);
                    $dataEmergencyUpdateDetails[$id]['emergency_email'] = $this->input->post('emergency_email-u-' . $id);
                    if ($this->input->post('preference_u_' . $id))
                        $dataEmergencyUpdateDetails[$id]['preference'] = $this->input->post('preference_u_' . $id);
                    else
                        $dataEmergencyUpdateDetails[$id]['preference'] = '0';

                    $dataEmergencyUpdateDetails[$id]['modifiedby'] = $user_id;
                    $dataEmergencyUpdateDetails[$id]['modifieddate'] = date('Y-m-d H:m:s');
                }
            }
            foreach ($dataEmergencyUpdateDetails as $key => $val)
                $this->emergencycontact->update($key, $val);
//            echo $this->db->last_query();die;





            /* Associate Emergency Contact */
            $emergency_contact_count = $this->input->post('emergency_contact_count');
            if (isset($emergency_contact_count)) {
                for ($i = 1; $i <= $emergency_contact_count; $i++) {
//                    $language_count;
                    for ($j = 1; $j <= 10; $j++) {

                        if (($this->input->post('emergency_number-' . $j))) {

                            $dataEmergencyDetails[$i]['user_id'] = $associate_id;
                            $dataEmergencyDetails[$i]['emergency_number'] = $this->input->post('emergency_number-' . $j);
                            $dataEmergencyDetails[$i]['emergency_name'] = $this->input->post('emergency_name-' . $j);
                            $dataEmergencyDetails[$i]['emergency_email'] = $this->input->post('emergency_email-' . $j);
                            $dataEmergencyDetails[$i]['preference'] = $this->input->post('preference_' . $j);
                            $dataEmergencyDetails[$i]['createdby'] = $user_id;
                            $dataEmergencyDetails[$i]['createddate'] = date('Y-m-d H:m:s');
                        }
                    }
                }
            }

            if (isset($dataEmergencyDetails)) {
                foreach ($dataEmergencyDetails as $dataResult) {
                    $this->emergencycontact->insert($dataResult);
                }
            }

            /* update & insert */
//            var_dump($alredy_exist);die;
            $alredy_exist_ch = $this->empchilddetails->is_exist($associate_id);

            if (isset($alredy_exist_ch) && $alredy_exist_ch != '') {
                foreach ($alredy_exist_ch as $id => $val) {
//                    var_dump($this->input->post('optionu-' . $id));
                    if ($this->input->post('child_name-u-' . $id)) {
                        $dataChildsUpdateDetail[$id]['child_name'] = $this->input->post('child_name-u-' . $id);
                        $dataChildsUpdateDetail[$id]['child_dob'] = date("Y-m-d", strtotime($this->input->post('child_dob-u-' . $id)));
                        $dataChildsUpdateDetail[$id]['modifiedby'] = $user_id;
                        $dataChildsUpdateDetail[$id]['modifieddate'] = date('Y-m-d H:m:s');
                        $this->empchilddetails->update($id, $dataChildsUpdateDetail[$id]);
//                        echo $this->db->last_query();
                    }
                }
            }
            /* insert child details */
            $child_count = $this->input->post('child_count');
            if (isset($child_count) && $child_count != '0') {
                for ($i = 1; $i <= $child_count; $i++) {
//                    $language_count;
                    for ($j = 1; $j <= 10; $j++) {
                        if ($this->input->post('child_name-' . $i)) {
                            $dataChildsDetail[$i]['user_id'] = $associate_id;
                            $dataChildsDetail[$i]['child_name'] = $this->input->post('child_name-' . $i);
                            $dataChildsDetail[$i]['child_dob'] = date("Y-m-d", strtotime($this->input->post('child_dob-' . $i)));
                            $dataChildsDetail[$i]['createdby'] = $user_id;
                            $dataChildsDetail[$i]['createddate'] = date('Y-m-d H:m:s');
                        }
                    }
                }
            }
            /* isert */
            if (isset($dataChildsDetail)) {
                foreach ($dataChildsDetail as $dtatChild)
                    $this->empchilddetails->insert($dtatChild);
            }
            /* update */
//            if (isset($dataChildsUpdateDetail)) {
//
//                foreach ($dataChildsUpdateDetail as $key => $dataChResult) {
//
//                    $this->empchilddetails->update($key, $dataChResult);
//                }
//            }


            $associate_id = $this->input->post('associate_id');

            $dob = $this->input->post('dob');
            $dob = str_replace(',', '', $dob);
            $date_of_birth = date('Y-m-d', strtotime($dob));

            $anniversarydate = $this->input->post('anniversary');
            $anniversarydate = str_replace(',', '', $anniversarydate);
            $anniversarydate = date('Y-m-d', strtotime($anniversarydate));

            $document_id = $this->input->post('document_id');


            /* update & insert hobbies */
            $hobbies = $this->input->post('hobbies');
            if (isset($hobbies)) {
                $checkIsExistHobbies = $this->emphobbies->is_exist($associate_id);
                $this->emphobbies->delete_all($associate_id);
                foreach ($hobbies as $key => $value) {
                    $dataHobbiesDetail[$key]['user_id'] = $associate_id;
                    $dataHobbiesDetail[$key]['hobbies_id'] = $value;
                    $dataHobbiesDetail[$key]['createdby'] = $user_id;
                    $dataHobbiesDetail[$key]['createddate'] = date('Y-m-d H:m:s');
                }
            }
//            var_dump($dataHobbiesDetail);die;

            /* insert new hobbies */
            if (isset($dataHobbiesDetail)) {
                foreach ($dataHobbiesDetail as $dtatHobb)
                    $this->emphobbies->insert($dtatHobb);
            }
            /* End Update */

//            var_dump($dataHobbiesDetailUpdate);
//            var_dump($dataHobbiesDetail);
//            var_dump($checkIsExistHobbies);
//            die;
//            /* insert new hobbies */
//            if (isset($hobbies)) {
//                foreach ($hobbies as $key => $val) {
//
//                    $dataHobbiesDetail[$key]['hobbies_id'] = $val;
//                    $dataHobbiesDetail[$key]['modifiedby'] = $user_id;
//                    $dataHobbiesDetail[$key]['modifieddate'] = date('Y-m-d H:m:s');
//                    $this->emphobbies->insert_or_update($key, $dataHobbiesDetail);
//                }
//            }
//            /* update hobbies */
//            if (isset($hobbies)) {
//                foreach ($hobbies as $key => $val) {
//
//                    $dataHobbiesDetail[$key]['hobbies_id'] = $val;
//                    $dataHobbiesDetail[$key]['modifiedby'] = $user_id;
//                    $dataHobbiesDetail[$key]['modifieddate'] = date('Y-m-d H:m:s');
//                    $this->documents->update($key, $dataHobbiesDetail);
//                }
//            }
//            var_dump($hobbies_data);
//            die;
            $dataPersonalDetail = array(
//                'user_id' => $this->input->post('associate_id'),
                'gender_id' => $this->input->post('gender_id'),
                'marital_status_id' => $this->input->post('marital_status'),
                'nationality_id' => $this->input->post('nationality_id'),
//                'language_id' => $this->input->post('language_id'),
                'dob' => $date_of_birth,
                'anniversary_date' => $anniversarydate,
                'blood_group_id' => $this->input->post('blood_group_id'),
                'identity_mark' => $this->input->post('identity_mark'),
//                'hobbies_id' => $hobbies_data,
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );



//            var_dump($dataPersonalDetail);
            $this->personaldetails->update($associate_id, $dataPersonalDetail);
//            echo $this->db->last_query();die;

            /* Communication Details */
            $check_status = $this->input->post('check_status');
//            var_dump($check_status);die;


            $dataCommunicationDetail = array(
//                'user_id' => $this->input->post('associate_id'),
                'personalemail' => $this->input->post('personal_email'),
                'mobile_number' => $this->input->post('mobile_number'),
                'perm_streetaddress' => $this->input->post('perm_address'),
                'perm_country' => $this->input->post('country_id'),
                'perm_state' => $this->input->post('state_id'),
                'perm_city' => $this->input->post('city_id'),
                'perm_pincode' => $this->input->post('postalcode'),
                'emergency_number' => $this->input->post('emergency_number'),
                'emergency_name' => $this->input->post('emergency_name'),
                'emergency_email' => $this->input->post('emergency_email')
            );

            if ($check_status == '1') {
                $dataCommunicationDetail_curr = array(
                    'same_check' => 1,
                    'current_streetaddress' => $this->input->post('perm_address'),
                    'current_country' => $this->input->post('country_id'),
                    'current_state' => $this->input->post('state_id'),
                    'current_city' => $this->input->post('city_id'),
                    'current_pincode' => $this->input->post('postalcode'),
                );
            } else {
                $dataCommunicationDetail_curr = array(
                    'same_check' => 0,
                    'current_streetaddress' => $this->input->post('curr_address'),
                    'current_country' => $this->input->post('c_country_id'),
                    'current_state' => $this->input->post('c_state_id'),
                    'current_city' => $this->input->post('c_city_id'),
                    'current_pincode' => $this->input->post('c_postalcode')
                );
            }
            $dataCommunicationDetail = array_merge($dataCommunicationDetail, $dataCommunicationDetail_curr);

            $this->communication->update($associate_id, $dataCommunicationDetail);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        //to get all data
        $data = $this->get_all_view_data($associate_id);

        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function experience($action = 'add', $associate_id = NULL, $modal_id = NULL) {


//        var_dump($action);
//        var_dump($associate_id);
//        var_dump($modal_id);
//        die;
        $from_date = null;
        $to_date = null;
        $dataExperienceDetail['document'] = null;
        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

//        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;


        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {
//            echo 'here';die;
            if (isset($_POST['from_date'])) {
                $from_date = $this->input->post('from_date');
                $from_date = str_replace(',', '', $from_date);
                $from_date = date('Y-m-d', strtotime($from_date));
            }
            if (isset($_POST['to_date'])) {
                $to_date = $this->input->post('to_date');
                $to_date = str_replace(',', '', $to_date);
                $to_date = date('Y-m-d', strtotime($to_date));
            }
            $dataExperienceDetail = array(
                'user_id' => $associate_id,
                'comp_name' => $this->input->post('company_name'),
                'company_location' => $this->input->post('company_location'),
                'comp_website' => $this->input->post('website_url'),
                'designation' => $this->input->post('designation'),
                'from_date' => $from_date,
                'to_date' => $to_date,
                'reason_for_leaving' => $this->input->post('reason_leaving'),
                'reference_email' => $this->input->post('reference_email'),
                'reference_name' => $this->input->post('reference_name'),
                'reference_contact' => $this->input->post('reference_contact'),
                'remark' => $this->input->post('remark'),
                'tag_id' => $this->input->post('tag'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES['document']['name']) && $_FILES['document']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['document']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['document']['name'])) {
                    $uploded_file_path = $this->handleUploadExp($slug);
                    if ($uploded_file_path != '')
                        $dataExperienceDetail['document'] = $uploded_file_path;
                }
            }

            if (isset($_FILES['document']['name']) && $_FILES['document']['name'] != '') {

                $fileExt = pathinfo($_FILES['document']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $dataDocumentDetail = array(
                    'user_id' => $associate_id,
                    'name' => $dataExperienceDetail['document'],
                    'attachments' => '/experience/' . $dataExperienceDetail['document'],
                    'tag' => 'experience',
                    'document_type' =>'1',
                    'type' => $dataDocumentDetail['type'],
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $dataExperienceDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
            }

//            var_dump($dataExperienceDetail);die;

            $checkIsExist = $this->experiencedetails->is_exist($associate_id);
            /* if already entry exist */
            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
            $this->experiencedetails->insert($dataExperienceDetail);
            $this->session->set_flashdata('msg', 'Record added successfully');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'edit' && isset($modal_id)) {
//            var_dump($_FILES);
//            var_dump($_POST);
//            die;

            $from_date = $this->input->post('from_date');
            $from_date = str_replace(',', '', $from_date);
            $from_date = date('Y-m-d', strtotime($from_date));

            $to_date = $this->input->post('to_date');
            $to_date = str_replace(',', '', $to_date);
            $to_date = date('Y-m-d', strtotime($to_date));

            $dataExperienceDetail = array(
//                'user_id' => $associate_id,
                'comp_name' => $this->input->post('company_name'),
                'company_location' => $this->input->post('company_location'),
                'comp_website' => $this->input->post('website_url'),
                'designation' => $this->input->post('designation'),
                'from_date' => $from_date,
                'to_date' => $to_date,
                'reason_for_leaving' => $this->input->post('reason_leaving'),
                'reference_name' => $this->input->post('reference_name'),
                'reference_contact' => $this->input->post('reference_contact'),
                'remark' => $this->input->post('remark'),
                'tag_id' => $this->input->post('tag'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            /* Upload exp document  */
            if (isset($_FILES['document']['name']) && $_FILES['document']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['document']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['document']['name'])) {
                    $uploded_file_path = $this->handleUploadExp($slug);
                    if ($uploded_file_path != '')
                        $dataExperienceDetail['document'] = $uploded_file_path;
                }
            }

//            var_dump($dataExperienceDetail);die;

            $checkIsExist = $this->experiencedetails->is_exist($associate_id);
            /* if already entry exist */
            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }


            if (isset($_FILES['document']['name']) && $_FILES['document']['name'] != '') {

                $fileExt = pathinfo($_FILES['document']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $document_id = $this->input->post('document_id');
                if ($document_id == '') {
//                    var_dump($document_id);die;
                    $dataDocumentDetail = array(
//                    'user_id' => $associate_id,
                        'name' => $dataExperienceDetail['document'],
                        'attachments' => '/experience/' . $dataExperienceDetail['document'],
                        'tag' => 'experience',
                        'document_type' =>'1',
                        'type' => $dataDocumentDetail['type'],
                        'modifiedby' => $user_id,
                        'modifieddate' => date('Y-m-d H:m:s'),
                    );
                    $dataEducationDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
                } else {
//                    var_dump('sles');die;
                    $dataDocumentDetail = array(
//                    'user_id' => $associate_id,
                        'name' => $dataExperienceDetail['document'],
                        'attachments' => '/experience/' . $dataExperienceDetail['document'],
                        'tag' => 'experience',
                        'document_type' =>'1',                        
                        'modifiedby' => $user_id,
                        'modifieddate' => date('Y-m-d H:m:s'),
                    );
                    $this->documents->update_document($document_id, $dataDocumentDetail);
                }
//                echo $this->db->last_query();
                $this->experiencedetails->update($modal_id, $dataExperienceDetail);
//                echo $this->db->last_query();
//                die;
            }
            $this->experiencedetails->update($modal_id, $dataExperienceDetail);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        //to get all data
        $data = $this->get_all_view_data($associate_id);
        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    public function skills($action = 'add', $associate_id = NULL, $modal_id = NULL) {


//        var_dump($action);
//        var_dump($associate_id);die;


        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        //$data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {

//            var_dump($_POST);die;
//            $last_use = $this->input->post('year_last_use');
//            $last_use = str_replace(',', '', $last_use);
//            $last_use = date('Y-m-d', strtotime($last_use));

            $dataSkillsDetail = array(
                'user_id' => $associate_id,
                'skill_id' => $this->input->post('skills_id'),
                'years_exp' => $this->input->post('years_exp'),
                'months_exp' => $this->input->post('months_exp'),
                'competencylevelid' => $this->input->post('competency_level'),
                'last_years_exp' => $this->input->post('last_years_exp'),
                'last_months_exp' => $this->input->post('last_months_exp'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );
            $checkIsExist = $this->employeeskills->is_exist($associate_id);
//            var_dump($checkIsExist);die;
            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
            $this->employeeskills->insert($dataSkillsDetail);
            $this->session->set_flashdata('msg', 'Record added successfully');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'edit' && isset($modal_id)) {

//            var_dump($_POST);die;
//            $last_use = $this->input->post('year_last_use');
//            $last_use = str_replace(',', '', $last_use);
//            $last_use = date('Y-m-d', strtotime($last_use));

            $dataSkillsDetail = array(
//                'user_id' => $associate_id,
                'skill_id' => $this->input->post('skills_id'),
                'years_exp' => $this->input->post('years_exp'),
                'months_exp' => $this->input->post('months_exp'),
                'competencylevelid' => $this->input->post('competency_level'),
                'last_years_exp' => $this->input->post('last_years_exp'),
                'last_months_exp' => $this->input->post('last_months_exp'),
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );
            $checkIsExist = $this->employeeskills->is_exist($associate_id);
//            var_dump($checkIsExist);die;
            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
            $this->employeeskills->update($modal_id, $dataSkillsDetail);
            $this->session->set_flashdata('msg', 'Record updated successfully');
//            echo $this->db->last_query();die;
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        //to get all data
        $data = $this->get_all_view_data($associate_id);

        //to get main menu, sub menu 
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    public function education($action = 'add', $associate_id = NULL, $modal_id = NULL) {


//        var_dump($associate_id);
//        var_dump($action);
//        var_dump($_POST);die;

        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

//echo 'out';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {

//            var_dump($_FILES);die;
            $from_date = $this->input->post('from_date');
            $from_date = str_replace(',', '', $from_date);
            $from_date = date('Y-m-d', strtotime($from_date));

            $to_date = $this->input->post('to_date');
            $to_date = str_replace(',', '', $to_date);
            $to_date = date('Y-m-d', strtotime($to_date));

            $dataEducationDetail = array(
                'user_id' => $associate_id,
                'educationlevel' => $this->input->post('education_level'),
                'institution_name' => $this->input->post('institute_name'),
                'course' => $this->input->post('course_name'),
                'grade' => $this->input->post('grade'),
                'from_date' => $from_date,
                'to_date' => $to_date,
                'percentage' => $this->input->post('percentage'),
                'remark' => $this->input->post('remark'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES['education_doc']['name']) && $_FILES['education_doc']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['education_doc']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['education_doc']['name'])) {
                    $uploded_file_path = $this->handleUploadEdu($slug);
                    if ($uploded_file_path != '')
                        $dataEducationDetail['education_doc'] = $uploded_file_path;
                }
            }

//            var_dump($dataExperienceDetail);die;

            if (isset($_FILES['education_doc']['name']) && $_FILES['education_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['education_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $dataDocumentDetail = array(
                    'user_id' => $associate_id,
                    'name' => $dataEducationDetail['education_doc'],
                    'attachments' => '/education/' . $dataEducationDetail['education_doc'],
                    'tag' => 'education',
                    'document_type' =>'4',
                    'type' => $dataDocumentDetail['type'],
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $dataEducationDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
            }
            $checkIsExist = $this->educationdetails->is_exist($associate_id);


            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
            $this->educationdetails->insert($dataEducationDetail);
            $this->session->set_flashdata('msg', 'Record added successfully');
//            echo $this->db->last_query();die;
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action == 'edit' && isset($modal_id)) {
//            echo $_SERVER['REQUEST_METHOD'];
//            die;
//            echo 'els';die;
            $from_date = $this->input->post('from_date');
            $from_date = str_replace(',', '', $from_date);
            $from_date = date('Y-m-d', strtotime($from_date));

            $to_date = $this->input->post('to_date');
            $to_date = str_replace(',', '', $to_date);
            $to_date = date('Y-m-d', strtotime($to_date));

            $document_id = $this->input->post('document_id');

            $dataEducationDetail = array(
//                'user_id' => $associate_id,
                'educationlevel' => $this->input->post('education_level'),
                'institution_name' => $this->input->post('institute_name'),
                'course' => $this->input->post('course_name'),
                'grade' => $this->input->post('grade'),
                'from_date' => $from_date,
                'to_date' => $to_date,
                'percentage' => $this->input->post('percentage'),
                'remark' => $this->input->post('remark'),
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES['education_doc']['name'])) {
                $targetDir = "uploads/";
                $fileName = $_FILES['education_doc']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['education_doc']['name'])) {
                    $uploded_file_path = $this->handleUploadEdu($slug);
                    if ($uploded_file_path != '')
                        $dataEducationDetail['education_doc'] = $uploded_file_path;
                }
            }

//            var_dump($dataExperienceDetail);die;

            if (isset($_FILES['education_doc']['name']) && $_FILES['education_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['education_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                if (empty($document_id)) {
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataEducationDetail['education_doc'],
                        'attachments' => '/education/' . $dataEducationDetail['education_doc'],
                        'tag' => 'education',
                        'document_type' =>'4',
                        'type' => $dataDocumentDetail['type'],
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $dataEducationDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
                } else {
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataEducationDetail['education_doc'],
                        'attachments' => '/education/' . $dataEducationDetail['education_doc'],
                        'tag' => 'education',
                        'document_type' =>'4',                        
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $this->documents->update_document($document_id, $dataDocumentDetail);
                }
            }


            $checkIsExist = $this->educationdetails->is_exist($associate_id);

            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
            $this->educationdetails->update($modal_id, $dataEducationDetail);
            $this->session->set_flashdata('msg', 'Record updated successfully');
//            echo $this->db->last_query();
//            die;
        }
//        

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        //to get all data
        $data = $this->get_all_view_data($associate_id);

        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

//        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    public function certification($action = 'add', $associate_id = NULL, $modal_id = NULL) {


//         var_dump($action);
//        var_dump($associate_id);
//        var_dump($modal_id);die;

        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {

            $issue_date = $this->input->post('issue_date');
            $issue_date = str_replace(',', '', $issue_date);
            $issue_date = date('Y-m-d', strtotime($issue_date));

            $dataCertificationDetail = array(
                'user_id' => $associate_id,
                'course_name' => $this->input->post('course_name'),
                'description' => $this->input->post('description'),
                'course_level' => $this->input->post('course_level'),
                'course_offered_by' => $this->input->post('course_off_by'),
                'certification_name' => $this->input->post('certification_name'),
                'issued_date' => $issue_date,
                'remark' => $this->input->post('remark'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES)) {
                $targetDir = "uploads/";
                $fileName = $_FILES['cert_doc']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['cert_doc']['name'])) {
                    $uploded_file_path = $this->handleUploadCert($slug);
                    if ($uploded_file_path != '')
                        $dataCertificationDetail['cert_doc'] = $uploded_file_path;
                }
            }

//            var_dump($dataExperienceDetail);die;
            $checkIsExist = $this->certificationdetails->is_exist($associate_id);

            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }

            $this->certificationdetails->insert($dataCertificationDetail);
            if (isset($_FILES['cert_doc']['name']) && $_FILES['cert_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['cert_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $dataDocumentDetail = array(
                    'user_id' => $associate_id,
                    'name' => $dataCertificationDetail['cert_doc'],
                    'attachments' => '/certification/' . $dataCertificationDetail['cert_doc'],
                    'tag' => 'certification',
                    'type' => $dataDocumentDetail['type'],
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $this->documents->insert($dataDocumentDetail);
                $this->session->set_flashdata('msg', 'Record added successfully');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && $action = 'edit' && $modal_id) {

            $issue_date = $this->input->post('issue_date');
            $issue_date = str_replace(',', '', $issue_date);
            $issue_date = date('Y-m-d', strtotime($issue_date));

            $dataCertificationUpdateDetail = array(
//                'user_id' => $associate_id,
                'course_name' => $this->input->post('course_name'),
                'description' => $this->input->post('description'),
                'course_level' => $this->input->post('course_level'),
                'course_offered_by' => $this->input->post('course_off_by'),
                'certification_name' => $this->input->post('certification_name'),
                'issued_date' => $issue_date,
                'remark' => $this->input->post('remark'),
                'modifiedby' => $user_id,
                'modifieddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES['cert_doc']['name'])) {
                $targetDir = "uploads/";
                $fileName = $_FILES['cert_doc']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['cert_doc']['name'])) {
                    $uploded_file_path = $this->handleUploadCert($slug);
                    if ($uploded_file_path != '')
                        $dataCertificationUpdateDetail['cert_doc'] = $uploded_file_path;
                }
            }

            if (isset($_FILES['cert_doc']['name']) && $_FILES['cert_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['cert_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
                $document_id = $this->input->post('document_id');
//                var_dump($document_id);die;
                if (empty($document_id)) {
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataCertificationUpdateDetail['cert_doc'],
                        'attachments' => '/certification/' . $dataCertificationUpdateDetail['cert_doc'],
                        'tag' => 'certification',
                        'document_type' =>'3',
                        'type' => $dataDocumentDetail['type'],
                        'modifiedby' => $user_id,
                        'modifieddate' => date('Y-m-d H:m:s'),
                    );
                    $dataCertificationUpdateDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
                } else {
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataCertificationUpdateDetail['cert_doc'],
                        'attachments' => '/certification/' . $dataCertificationUpdateDetail['cert_doc'],
                        'tag' => 'certification',
                        'document_type' =>'3',
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $this->documents->update_document($document_id, $dataDocumentDetail);
//                    echo $this->db->last_query();
                }
            }

//            var_dump($dataCertificationUpdateDetail);die;
            $checkIsExist = $this->certificationdetails->is_exist($associate_id);

            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }

            $res = $this->certificationdetails->update($modal_id, $dataCertificationUpdateDetail);


//            if (isset($_FILES['cert_doc']['name']) && $_FILES['cert_doc']['name'] != '') {
//                $dataDocumentDetail = array(
//                    'user_id' => $associate_id,
//                    'name' => $dataCertificationUpdateDetail['cert_doc'],
//                    'attachments' => '/certification/' . $dataCertificationUpdateDetail['cert_doc'],
//                    'tag' => 'certification',
//                    'createdby' => $user_id,
//                    'createddate' => date('Y-m-d H:m:s'),
//                );
//                $this->documents->insert($dataDocumentDetail);
//                
//            }
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data = $this->get_all_view_data($associate_id);
//        var_dump($data);die;
        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    public function visa($action = 'add', $associate_id = NULL, $modal_id = NULL) {

        $this->load->helper('date');

        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        //$data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {

//            var_dump($_POST);
//            var_dump($_FILES);die;

            $issuedate = $this->input->post('visa_issue_date');
            $issuedate = str_replace(',', '', $issuedate);
            $visa_issue_date = date('Y-m-d', strtotime($issuedate));

            $visaexpirydate = $this->input->post('visa_expiry_date');
            $visaexpirydate = str_replace(',', '', $visaexpirydate);
            $visa_expiry_date = date('Y-m-d', strtotime($visaexpirydate));

            $dataVisaDetail = array(
                'user_id' => $associate_id,
                'country_id' => $this->input->post('country_id'),
                'passport_number' => $this->input->post('passport_number'),
                'passport_issue_date' => $passport_date,
                'passport_expiry_date' => $expiry_date,
                'visa_number' => $this->input->post('visa_number'),
                'visa_type' => $this->input->post('visa_type'),
                'visa_issue_date' => $visa_issue_date,
                'visa_expiry_date' => $visa_expiry_date,
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s')
            );
//            var_dump($dataVisaDetail);die;
            //visa_document
            /* Upload Visa Document */
            if (isset($_FILES['visa_document'])) {
                $targetDir = "uploads/";
                $fileName = $_FILES['visa_document']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['visa_document']['name'])) {
                    $uploded_file_path = $this->handleUploadVisa($slug);
                    if ($uploded_file_path != '')
                        $dataVisaDetail['visa_document'] = $uploded_file_path;
                }
            }

            if (isset($_FILES['visa_document']['name']) && $_FILES['visa_document']['name'] != '') {

                $fileExt = pathinfo($_FILES['visa_document']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                $dataDocumentDetail = array(
                    'user_id' => $associate_id,
                    'name' => $dataVisaDetail['visa_document'],
                    'attachments' => '/visa/' . $dataVisaDetail['visa_document'],
                    'tag' => 'visa',
                    'document_type' =>'6',
                    'type' => $dataDocumentDetail['type'],
                    'createdby' => $user_id,
                    'createddate' => date('Y-m-d H:m:s'),
                );
                $dataVisaDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
            }


            //Transfering data to Model
            $checkIsExist = $this->visa->is_exist($associate_id);

            if (($checkIsExist) == FALSE) {
                $curcompletion = $this->employeesummary->get_comp_status($associate_id);
                $curcompletion = $curcompletion + 10;
                $profileStatus = array('profile_completion' => $curcompletion);
                $this->employeesummary->update($associate_id, $profileStatus);
            }
//            var_dump($dataVisaDetail);die;
            $this->visa->insert($dataVisaDetail);
            $this->session->set_flashdata('msg', 'Record added successfully');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'edit' && isset($modal_id)) {

            $passdate = $this->input->post('passport_issue_date');
            $passdate = str_replace(',', '', $passdate);
            $passport_date = date('Y-m-d', strtotime($passdate));

            $expirydate = $this->input->post('passport_expiry_date');
            $expirydate = str_replace(',', '', $expirydate);
            $expiry_date = date('Y-m-d', strtotime($expirydate));

            $issuedate = $this->input->post('visa_issue_date');
            $issuedate = str_replace(',', '', $issuedate);
            $visa_issue_date = date('Y-m-d', strtotime($issuedate));

            $visaexpirydate = $this->input->post('visa_expiry_date');
            $visaexpirydate = str_replace(',', '', $visaexpirydate);
            $visa_expiry_date = date('Y-m-d', strtotime($visaexpirydate));

            $document_id = $this->input->post('document_id');

            $dataVisaDetail = array(
                'user_id' => $associate_id,
                'country_id' => $this->input->post('country_id'),
                'passport_number' => $this->input->post('passport_number'),
                'passport_issue_date' => $passport_date,
                'passport_expiry_date' => $expiry_date,
                'visa_number' => $this->input->post('visa_number'),
                'visa_type' => $this->input->post('visa_type'),
                'visa_issue_date' => $visa_issue_date,
                'visa_expiry_date' => $visa_expiry_date,
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s')
            );

            //visa_document
            /* Upload Visa Document */
            if (isset($_FILES['visa_document']['name']) && $_FILES['visa_document']['name'] != '') {
                $targetDir = "uploads/";
                $fileName = $_FILES['visa_document']['name'];
                $targetFile = $targetDir . $fileName;

                if (!empty($_FILES['visa_document']['name'])) {
                    $uploded_file_path = $this->handleUploadVisa($slug);
                    if ($uploded_file_path != '')
                        $dataVisaDetail['visa_document'] = $uploded_file_path;
                }
            }


            if (isset($_FILES['visa_document']['name']) && $_FILES['visa_document']['name'] != '') {

                $fileExt = pathinfo($_FILES['visa_document']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];

                if (empty($document_id)) {
                    $dataDocumentDetail = array(
                        'user_id' => $associate_id,
                        'name' => $dataVisaDetail['visa_document'],
                        'attachments' => '/visa/' . $dataVisaDetail['visa_document'],
                        'tag' => 'visa',
                        'document_type' =>'6',
                        'type' => $dataDocumentDetail['type'],
                        'createdby' => $user_id,
                        'createddate' => date('Y-m-d H:m:s'),
                    );
                    $dataVisaDetail['document_id'] = $this->documents->insert($dataDocumentDetail);
                } else {
                    $dataDocumentDetail = array(
//                        'user_id' => $associate_id,
                        'name' => $dataVisaDetail['visa_document'],
                        'attachments' => '/visa/' . $dataVisaDetail['visa_document'],
                        'tag' => 'visa',
                        'document_type' =>'6',
                        'type' => $dataDocumentDetail['type'],
                        'modifiedby' => $user_id,
                        'modifieddate' => date('Y-m-d H:m:s'),
                    );
                    $this->documents->update_document($document_id, $dataDocumentDetail);
                }
            }

            $this->visa->update($modal_id, $dataVisaDetail);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        //to get all data
        $data = $this->get_all_view_data($associate_id);

        //to get main menu, sub menu 
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    /* add document module */

    public function document($action = 'add', $associate_id = NULL, $modal_id = NULL) {



        $slug = $this->users->get_slug_by_id($associate_id);

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['associate_id'] = $associate_id;

//echo 'out';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action == 'add') {
            //common_doc
            $tag = $this->input->post('document_type');
            $tagData = (array('' => 'Select Tag')) + array('1' => 'Education', '2' => 'Experience', '3' => 'Certification', '4' => 'Visa', '5' => 'Personal');
            foreach ($tagData as $key => $value) {
                if ($key == $tag)
                    $tag_title = $value;
            }

            $dataDocumentDetail = array(
                'user_id' => $associate_id,
                'name' => $this->input->post('document_title'),
                'tag' => strtolower($tag_title),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
            );

            /* Upload profile picture */
            if (isset($_FILES['common_doc']['name']) && $_FILES['common_doc']['name'] != '') {

                $fileExt = pathinfo($_FILES['common_doc']['name']);
                $dataDocumentDetail['type'] = $fileExt['extension'];
//                
                $targetDir = "uploads/";
                $fileName = $_FILES['common_doc']['name'];
                $targetFile = $targetDir . $fileName;
                if (!empty($_FILES['common_doc']['name'])) {
                    $uploded_file_path = $this->handleUploadAll($slug, $dataDocumentDetail);
                    if ($uploded_file_path != '')
                        $dataDocumentDetail['attachments'] = '/common/' . $uploded_file_path;
                }
            }

            $this->documents->insert($dataDocumentDetail);
            $this->session->set_flashdata('msg', 'Record added successfully');
//            echo $this->db->last_query();die;
        }

        /* header data */
        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        //to get all data
        $data = $this->get_all_view_data($associate_id);

        //to get main menu, sub menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

//        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_view_employee', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
//        redirect('employee/view_user/' . $data['user_summary']['user_id'], 'refresh');
    }

    public function contact_bk($empId = NULL) {

        //local Variable
        $data['user_summary'] = NULL;
        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        $data['prefix'] = $this->employees->get_prefix_name();
        $data['marital_list'] = $this->common->get_all_marital_status();
        $data['nationality_list'] = $this->common->get_all_nationality_name();
        $data['language_list'] = $this->common->get_all_language_name();
        $data['country_list'] = $this->country->as_array()->get_all();
        $data['state_list'] = $this->state->as_array()->get_all();
        $data['city_list'] = $this->city->as_array()->get_all();
//        var_dump($data['country']);
//        die;

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "add") {
            
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "edit") {
            
        }

//        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $id);
//        var_dump($data['user_summary']);
//        die;
        //Get Menu & Sub Menu
        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header');
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('content', 'official/_communication', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function contactinfo($empId) {

        //curent user id
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        if (!$this->ion_auth->in_group('hr')) {
            $this->session->set_flashdata('message', $this->ion_auth->errors());
            redirect('/', 'refresh');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $this->input->post('action') == "add") {


            $dob = str_replace("/", "-", $this->input->post('dob'));
            $dob = str_replace(',', '', $dob);
            $dob = date('Y-m-d', strtotime($dob));
//            var_dump($_POST);die;

            $dataPersonalArray = array(
                'user_id' => $this->input->post('associate_id'),
                'genderid' => $this->input->post('gender'),
                'maritalstatusid' => $this->input->post('marital_status'),
                'nationalityid' => $this->input->post('nationality_name'),
                'languageid' => $this->input->post('language_name'),
                'dob' => $dob,
                'bloodgroup' => $this->input->post('blood_group'),
                'createdby' => $user_id,
                'createddate' => date('Y-m-d H:m:s'),
                'isactive' => 1
            );
//            var_dump($dataPersonalArray);die;
            $res = $this->personaldetails->insert($dataPersonalArray);
//            var_dump($res);die;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {

            $data['gender'] = $this->common->get_all_gender();
            $data['marital_status'] = $this->common->get_all_marital_status();
            $data['nationality_name'] = $this->common->get_all_nationality_name();
            $data['language_name'] = $this->common->get_all_language_name();


//            var_dump($data['marital_status']);die;
        }

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();
        //to get main menu, sub menu
        $dataMenu['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $dataMenu['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);

        $data['c_emp_summary'] = $this->employeesummary->employee_summary_by_id($empId);

        $this->template->set_master_template('template.php');
        $this->template->write_view('header', 'snippets/header', (isset($dataMenu) ? $dataMenu : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));

        //to check is entry already exists or not
        $data['result'] = $this->employeesummary->is_contact_information_already_exist($empId);

        if (isset($data['result']['personal']) && isset($data['result']['communication'])) {

            $data['personal_detail'] = $this->employeesummary->get_personal_detail_by_id($empId);

            if (isset($data['personal_detail'])) {

                if ($data['personal_detail']->genderid == '1')
                    $data['personal_detail']->genderid = 'Male';
                else
                    $data['personal_detail']->genderid = 'Female';

                if ($data['personal_detail']->maritalstatusid)
                    $data['personal_detail']->maritalstatusid = $this->employeesummary->get_marital_status_by_id($data['personal_detail']->maritalstatusid);

                if ($data['personal_detail']->nationalityid)
                    $data['personal_detail']->nationalityid = $this->employeesummary->get_nationality_by_id($data['personal_detail']->nationalityid);

                if ($data['personal_detail']->languageid)
                    $data['personal_detail']->languageid = $this->employeesummary->get_language_by_id($data['personal_detail']->languageid);

                if ($data['personal_detail']->bloodgroup) {
                    $blood_group = array('0' => 'Select Blood Group', '1' => 'A +', '2' => 'A -', '3' => 'O +', '4' => 'O -', '5' => 'B +', '6' => 'B -', '7' => 'Ab +', '8' => 'AB -');
                    var_dump($blood_group);
                    die;
                    foreach ($blood_group as $bg) {
                        if ($data['personal_detail']->bloodgroup = $bg)
                            $data['personal_detail']->bloodgroup = $bg;
                    }
                    $data['personal_detail']->bloodgroup = $this->employeesummary->get_language_by_id($data['personal_detail']->languageid);
                }
            }

            $this->template->write_view('content', '_view_contactinfo', (isset($data) ? $data : NULL));
        } else
            $this->template->write_view('content', '_add_contactinfo', (isset($data) ? $data : NULL));

//        if(isset($result['communication']))
//        var_dump($res);die;



        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    function getRepMan() {
        $this->load->model(array('employees'));
        if (isset($_GET['department_id'])) {
            $deptid = $_GET['department_id'];
//        $country_id = $this->input->get('country_id');
            $department = $this->employees->get_repman_by_id($deptid);
        }
//        $st = '';
//        foreach ($states as $state) {
//            $st .= '<option value="' . $state->id . '">' . $state->name . '</option>';
//        }
//        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $department));
    }

    function getPosition() {
        $this->load->model(array('employees'));

        if (isset($_GET['jobtitle_id'])) {

            $jobtitle_id = $_GET['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
            $st = '';
//            $st = '<option value="">Select Position</option>';
            foreach ($jobtitle as $title) {
                $st .= '<option value="' . $title->position_id . '">' . $title->positioname . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    function getEmployeeId() {

        $empid = $this->employees->get_employee_id();

        if (isset($empid)) {
            $st = '<input type="text" name="employeeId" id="field-employeeId" value="MWX-' . $empid . '" />';
        } else {
            $st = 'MWX-001';
        }

        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getPositionName() {

        if (isset($_POST['jobtitle_id'])) {

            $jobtitle_id = $_POST['jobtitle_id'];
            $jobtitle = $this->employees->get_position_by_id($jobtitle_id);
//            var_dump($jobtitle);die;
//            $st = '';
            $st = '<option value="">Select Designation</option>';
            $li = '';
            foreach ($jobtitle as $title) {
                $st .= ' <option value="' . $title['position_id'] . '">' . $title['positioname'] . '</option>';
            }
//            $st .='</select>';
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st, 'li' => $li));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => '', 'li' => ''));
        }
    }

    function getEmployementStatus() {

        $employmentstatus = $this->employees->get_employement_name();
        $st = '<option value="">Select Employment Status</option>';
//            $st .= '<option value=""  selected="selected">Select Position</option>';
        foreach ($employmentstatus as $title) {
            $st .= '<option value="' . $title->emp_status_id . '">' . $title->emp_status . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('content' => $st));
    }

    function getReportingManager() {

//        $this->db->flush_cache();
//echo '<pre>', print_r($_POST);die;
        if (isset($_POST)) {

//            echo '<pre>', print_r($_POST);die;
            $department_id = $_POST['department_id'];

            $rep_manager = $this->employeesummary->get_all_rep_mang_by_dept_id($_POST);
//            echo '<pre>', print_r($rep_manager);die;
//            
//            var_dump($rep_manager);die;
            $st = '';
            $st = '<option value="">Select Manager</option>';
            foreach ($rep_manager as $title) {
                if (!empty($_POST['reporting_manager_id']) && $title['id'] != $_POST['reporting_manager_id'])
                    $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
                else if (isset($_POST['reporting_manager_id']) == FALSE)
                    $st .= '<option value="' . $title['id'] . '">' . $title['userfullname'] . '</option>';
            }

            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    public function hash_password($password, $salt = false, $use_sha1_override = FALSE) {
        if (empty($password)) {
            return FALSE;
        }

        // bcrypt
        if ($use_sha1_override === FALSE && $this->hash_method == 'bcrypt') {
            return $this->bcrypt->hash($password);
        }


        if ($this->store_salt && $salt) {
            return sha1($password . $salt);
        } else {
            $salt = $this->salt();
            return $salt . substr(sha1($salt . $password), 0, -$this->salt_length);
        }
    }

    public function salt() {

        $raw_salt_len = 16;

        $buffer = '';
        $buffer_valid = false;

        if (function_exists('mcrypt_create_iv') && !defined('PHALANGER')) {
            $buffer = mcrypt_create_iv($raw_salt_len, MCRYPT_DEV_URANDOM);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && function_exists('openssl_random_pseudo_bytes')) {
            $buffer = openssl_random_pseudo_bytes($raw_salt_len);
            if ($buffer) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid && @is_readable('/dev/urandom')) {
            $f = fopen('/dev/urandom', 'r');
            $read = strlen($buffer);
            while ($read < $raw_salt_len) {
                $buffer .= fread($f, $raw_salt_len - $read);
                $read = strlen($buffer);
            }
            fclose($f);
            if ($read >= $raw_salt_len) {
                $buffer_valid = true;
            }
        }

        if (!$buffer_valid || strlen($buffer) < $raw_salt_len) {
            $bl = strlen($buffer);
            for ($i = 0; $i < $raw_salt_len; $i++) {
                if ($i < $bl) {
                    $buffer[$i] = $buffer[$i] ^ chr(mt_rand(0, 255));
                } else {
                    $buffer .= chr(mt_rand(0, 255));
                }
            }
        }

        $salt = $buffer;

        // encode string with the Base64 variant used by crypt
        $base64_digits = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        $bcrypt64_digits = './ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $base64_string = base64_encode($salt);
        $salt = strtr(rtrim($base64_string, '='), $base64_digits, $bcrypt64_digits);

        $salt = substr($salt, 0, $this->salt_length);

        return $salt;
    }

    public function getMenuList() {
        //variables
        $k = 1;
        $menuobj = new ArrayObject();
        $i = 1;

        /* start of get menu list */
        $this->data['users'] = $this->ion_auth->users()->result();

        $current_user_id = $this->ion_auth->get_user_id();
        foreach ($this->data['users'] as $user) {
            if ($user->id == $current_user_id)
                $user_role_id = $user->emprole;
        }

        $this->data['group_id'] = $this->menu->get_group_id_by_role($user_role_id);

        $this->data['menu'] = $this->menu->get_allmenu_by_group_id($this->data['group_id'][0]->group_id);
        $data['submenu'] = $this->menu->get_submenu_by_group_id($this->data['group_id'][0]->group_id);
//        $data['submenu'] = $this->menu->get_submenu_by_group_id1($this->data['group_id'][0]->group_id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($this->data['group_id'][0]->group_id);
//
//        for ($i = 0; $i < count($data['mainmenu']); $i++) {
//            foreach ($data['submenu'] as $sub) {
//
//                if ($data['mainmenu'][$i]->id == $sub->parent) {
//                    if ($k == 1) {
//                        $menuobj->append(array('menu',$data['mainmenu'][$i]->menuName,$data['mainmenu'][$i]->iconPath));
//                        $k++;
//                    }
//                    $menuobj->append(array('submenu',$sub->menuName,$sub->url));
//                }               
//            }
//            $k = 1;//restrict repetative menu
//        }
//        $menulist = (array)$menuobj;
        return $this->data;
        /* end of get menu list */
    }

    public function activity_log($data) {
        
    }

    public function upload_file($file) {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $user_id = $this->session->userdata('user_id');

        if (isset($user_id))
            $user_data = $this->employeesummary->get_by_id($user_id);

//        echo 'hi';
//        echo '<pre>',  print_r($user_data);die;
//        var_dump($user_data->userfullname);
//        die;
//        die;
        $targetDir = "uploads/";
        $fileName = $_FILES['file']['name'];
        $targetFile = $targetDir . $fileName;

        if (!empty($_FILES)) {
            $filename = $this->handleUpload($user_data['salt']);
            echo json_encode(true);
            die;
        }
//        var_dump($data);
//        die;
//        if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
//            //insert file information into db table
////        $conn->query("INSERT INTO files (file_name, uploaded) VALUES('".$fileName."','".date("Y-m-d H:i:s")."')");
//        }
    }

    function handleUpload($salt) {
//var_dump($salt);die;

        if (!empty($_FILES)) {

//             Validate the file type
            $fileTypes = array('doc', 'docx', 'pdf'); // File extensions
            $fileParts = pathinfo($_FILES['cv_doc']['name']);

            if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
                //$this->session->set_error_flashdata('msg', 'Oops! An Error Occurred.');
                $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
                return false;
            }

            $ext = pathinfo($_FILES['cv_doc']['name'], PATHINFO_EXTENSION);
            $targetURL = '/assets/uploads/' . $salt . '/documents'; // Relative to the root
            $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $salt . '/documents/cv';

            if (!file_exists($targetPath)) {
                mkdir($targetPath, 0777, true);
            }
            $tempFile = $_FILES['cv_doc']['tmp_name'];

            $dptnme = $this->input->post('department_name');
            $dptnme = str_replace("/", "-", $dptnme);

            $assid = $this->input->post('employeeid');

            $cvname = 'mwx-' . $dptnme . '-cv-' . $assid;
            $upload_path = $cvname . '.' . $ext;

//            $upload_path = 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents' . DIRECTORY_SEPARATOR . $cvname . '.' . $ext;
            $targetPath .= DIRECTORY_SEPARATOR . $cvname . '.' . $ext;
            $upload_status = move_uploaded_file($tempFile, $targetPath);
            $dataDocumentDetail['type'] = $fileParts['extension'];
//            var_dump($upload_path);die;
            if (isset($upload_status))
                return $upload_path;
//                return $upload_path;
        }
    }

    function handleUploadCommon($slug) {
        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['profile_image']['name']);

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/profile';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $tempFile = $_FILES['profile_image']['tmp_name'];
        $fileName = $_FILES['profile_image']['name'];
//        var_dump($fileName);die;
        $fileName = $slug . '-profile-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
//        var_dump($targetPath);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadExp($slug) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['document']['name']);

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents/experience';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $tempFile = $_FILES['document']['tmp_name'];
        $fileName = $_FILES['document']['name'];
//        var_dump($fileName);die;
        $fileName = $slug . '-exp-' . $fileName;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
//        var_dump($fileName);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadEdu($slug) {

        $fileTypes = array('jpeg', 'png', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['education_doc']['name']);

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['education_doc']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents/education';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $tempFile = $_FILES['education_doc']['tmp_name'];
        $fileName = $_FILES['education_doc']['name'];
        $fileName = $slug . '-edu-' . $fileName;

        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadCert($slug) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['cert_doc']['name']);

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['cert_doc']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents/certification';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }

        $tempFile = $_FILES['cert_doc']['tmp_name'];
        $fileName = $_FILES['cert_doc']['name'];
        $fileName = $slug . '-cert-' . $fileName;

//        var_dump($fileName);die;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
//        var_dump($targetPath);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    function handleUploadVisa($slug) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['visa_document']['name']);

        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['visa_document']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents/visa';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }


        $tempFile = $_FILES['visa_document']['tmp_name'];
        $fileName = $_FILES['visa_document']['name'];
        $fileName = $slug . '-visa-' . $fileName;

        //        var_dump($fileName);die;
        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
//        var_dump($targetPath);die;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    /* to upload common document */

    function handleUploadAll($slug, $docData) {

        $fileTypes = array('jpeg', 'png', 'doc', 'docx', 'pdf', 'jpg'); // File extensions
        $fileParts = pathinfo($_FILES['common_doc']['name']);


        if (!in_array(strtolower($fileParts['extension']), $fileTypes)) {
            $data['flashdata'] = array('type' => 'error', 'msg' => 'File type not supported.');
            return false;
        }

        $user_slug = $slug;
        $ext = pathinfo($_FILES['common_doc']['name'], PATHINFO_EXTENSION);
        $targetURL = '/assets/uploads/' . $user_slug . '/documents'; // Relative to the root
        $targetPath = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $user_slug . '/documents/common';

        if (!file_exists($targetPath)) {
            mkdir($targetPath, 0777, true);
        }


        $tempFile = $_FILES['common_doc']['tmp_name'];
        $fileName = $_FILES['common_doc']['name'];
        $fileName = $slug . '-' . strtolower($docData['tag']) . '-' . strtolower($docData['name']) . '-' . $fileName;

//        var_dump($fileName);die;
//        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
//        if (!file_exists($targetPath)) {
//            mkdir($targetPath, 0777, true);
//        }

        $targetPath .= DIRECTORY_SEPARATOR . $fileName;
        $upload_status = move_uploaded_file($tempFile, $targetPath);
        $dataDocumentDetail['type'] = $fileParts['extension'];
        if (isset($upload_status))
            return $fileName;
    }

    public function get_all_view_data($associate_id) {

//        echo "<pre>"; print_r($this->session->all_userdata()); die;
        $data['current_login_user_details'] = NULL;
//        $this->output->cache(1);
        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['tabId'] = $this->employeesummary->get_tab_id($associate_id);
//        var_dump($data['user_summary']);die;
        $data['user_main_details'] = $this->users->as_array()->get_by('id', $associate_id);
        $data['associate_slug'] = $this->users->get_slug_by_id($associate_id);
//        var_dump($data['current_login_user_details']);die;
        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->workstation->dropdown('work_station_code'));
        $data['work_station_all'] = (array('' => 'Select WorkStation') + $this->workstation->get_workstation_list());
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = $this->numbers->get_years();
        $data['monthsexp'] = $this->numbers->get_months();
//        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
//        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
        $data['department_id'] = $data['user_summary']['department_id'];
        $data['emprole'] = $data['user_summary']['emprole'];

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        $data['position_list'] = $this->employees->get_all_position_by_id($data['user_summary']['jobtitle_id']);

        //Associate Holiday & Leaves
        $data['holiday'] = $this->employeesholiday->get_by_id($associate_id);
//        $data['leaves'] = $this->employeesleave->get_by_id($associate_id);
        $data['leaves'] = $this->leavetypesAllocation->get_leaveList($associate_id);
        $data['balnce_leaves'] = $this->leavetypesAllocation->get_balanceLeaves($associate_id);
//         var_dump($data['city_list']);die;
//        var_dump($data['balnce_leaves']);die;
        //Associate Communication & Personal Details
        $data['personal_detail'] = $this->personaldetails->get_by_id($associate_id);
//        echo $this->db->last_query();die;
        $data['communication_detail'] = $this->communication->get_by_id($associate_id);
//        var_dump($data['yearsexp']);
//        var_dump($data['yearsexp']);die;
//        var_dump($associate_id);die;
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['child_details'] = $this->empchilddetails->get_by_id($associate_id);

        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = $this->hobbies->dropdown('hobbies_title');
        $data['hobbies_detail'] = $this->emphobbies->get_by_id($associate_id);
//        echo $this->db->last_query();die;
        $data['language_list'] = $this->language->dropdown('languagename');
        $data['proficiency_list'] = $this->proficiency->dropdown('proficiency_title');
        $data['language_details'] = $this->employeelanguage->get_by_id($associate_id);
        $data['emergency_contact_details'] = $this->emergencycontact->get_by_id($associate_id);

//        var_dump($data['hobbies']);
//        var_dump($data['hobbies_detail']);
//        die;

        /* Holiday List */
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['holiday_list'] = $this->holidaydates->get_holidayList($cur_year_id);
        /* end holiday list */

        /* Document */
        $data['document_details'] = $this->documents->get_by_id($associate_id);
        $data['document_type'] = array('1' => 'Education', '2' => 'Experience', '3' => 'Certification', '4' => 'Visa', '5' => 'Personal', '6' => 'Other',);

        /* job history */
        $data['jobhistroy_details'] = NULL;
//        var_dump($data['document_details']);die;
        /* Experience */
        $data['tag_type'] = (array('' => 'Select Tag')) + $this->tag->dropdown('tag_name');
        $data['experience_details'] = $this->experiencedetails->get_by_id($associate_id);



        /* Skills */
        $data['skills_details'] = $this->employeeskills->get_by_id($associate_id);
        $data['skills_list'] = (array('' => 'Select Skills')) + $this->skills->dropdown('skill_title');
        $data['skill_icon'] =  $this->skills->dropdown('skill_icon');
        $data['compentency_level'] = (array('' => 'Select Level')) + $this->compentencylevel->dropdown('competencylevel');
        $data['years_list'] =  $this->years->dropdown('yearcode');
        $data['months_list'] = $this->months->dropdown('monthcode');

        /* education */
        $data['education_details'] = $this->educationdetails->get_by_id($associate_id);
        $data['education_level'] = (array('' => 'Select Level')) + $this->educationlevel->dropdown('educational_level');
//        var_dump($data['skills_list']);die;
        /* education */
        $data['certification_details'] = $this->certificationdetails->get_by_id($associate_id);

//        echo $this->db->last_query();
        $data['visa_details'] = $this->visa->get_by_id($associate_id);
//        $
//        var_dump($data['certification_details']);
//        die;
        return $data;
    }

    public function getAllLanguage() {
        $language_list = $this->common->get_all_language_name();
        $proficiency_list = $this->proficiency->as_array()->get_all();
//        echo '<pre>',  print_r($proficiency_list);die;
        $st_lang = '';
        foreach ($language_list as $language) {
            $st_lang .= '<option value="' . $language['id'] . '">' . $language['languagename'] . '</option>';
        }

        $st_prof = '';
        foreach ($proficiency_list as $proficiency) {
            $st_prof .= '<option value="' . $proficiency['id'] . '">' . $proficiency['proficiency_title'] . '</option>';
        }
        $this->output->set_header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('language_list' => $st_lang, 'proficiency_list' => $st_prof));
    }

    //    Function to get State list by country id 

    function getStateList() {

        if (isset($_POST)) {

            $country_id = $_POST['country_id'];


            $states = $this->state->get_StateListById($country_id);
            $st = '';
            foreach ($states as $state) {
                //  var_dump($state);die;
                $st .= '<option value="' . $state['id'] . '">' . $state['statename'] . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    //    Function to get City list by state id 

    function delete_emp_language() {
        if (isset($_POST)) {
//            $associate_id = $this->session->userdata('associate_id');
            $emp_lang_id = $_POST['emp_lang_id'];
            $this->employeelanguage->delete($emp_lang_id);
            return true;
        }
    }

    function delete_emergency_contact() {
        if (isset($_POST)) {
//            $associate_id = $this->session->userdata('associate_id');
            $emergency_id = $_POST['emergency_id'];
            $this->emergencycontact->delete($emergency_id);
            return true;
        }
    }

    function getCityList() {

        if (isset($_POST)) {


            $state_id = $_POST['state_id'];


            $cities = $this->city->get_CityListById($state_id);
            $st = '<option>Select</option>';
            foreach ($cities as $city) {
                //  var_dump($state);die;
                $st .= '<option value="' . $city['id'] . '">' . $city['cityname'] . '</option>';
            }
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => $st));
        } else {
            $this->output->set_header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('content' => ''));
        }
    }

    /* Soft Delete */

    function delete_experience() {
        if (isset($_POST)) {
            $experience_id = $_POST['experience_id'];
            $this->experiencedetails->delete($experience_id);
            $this->session->set_flashdata('delete', 'Record deleted successfully');
            echo json_encode(array('delete' => 'Record deleted successfully'));
            return true;
        }
    }

    function delete_skills() {
        if (isset($_POST)) {
            $skills_id = $_POST['skills_id'];
            $this->employeeskills->delete($skills_id);
            echo json_encode(array('delete' => 'Record deleted successfully'));
            return true;
        }
    }

    function delete_education() {
        if (isset($_POST)) {
            $education_id = $_POST['education_id'];
            echo json_encode(array('delete' => 'Record deleted successfully'));
            $this->educationdetails->delete($education_id);
            return true;
        }
    }

    function delete_certification() {
        if (isset($_POST)) {
            $certification_id = $_POST['certification_id'];
            echo json_encode(array('delete' => 'Record deleted successfully'));
            $this->certificationdetails->delete($certification_id);
            return true;
        }
    }

    function delete_visa() {
        if (isset($_POST)) {
            $visa_id = $_POST['visa_id'];
            $document_id = $_POST['document_id'];
            $this->visa->delete($visa_id);
            if (isset($document_id) && $document_id != '' && $document_id != '0')
                $this->documents->delete($document_id);

            echo json_encode(array('delete' => 'Record deleted successfully'));
            return true;
        }
    }

    /* Delete Child Details */

    function delete_child() {
        if (isset($_POST)) {
            $child_id = $_POST['child_id'];
            $this->empchilddetails->delete($child_id);
        }
    }

    function checkEmailExist() {
        if (isset($_POST)) {
            $email_id = $_POST['email_id'];
            $result = $this->users->check_email($email_id);
            if ($result == TRUE) {
                echo json_encode(array('email' => strtolower($email_id)));
                die;
            } else {
                $firstname = trim($_POST['firstname']);
                $lastname = substr(trim($_POST['lastname']), 0, 2);
                $ne_email_id = trim($firstname) . "." . trim($lastname) . "@mindworx.in";
                $result = $this->users->check_email($ne_email_id);
                if ($result == TRUE) {
                    echo json_encode(array('email' => strtolower($ne_email_id)));
                    die;
                } else {
                    $firstname = trim($_POST['firstname']);
                    $lastname = substr(trim($_POST['lastname']), 0, 2) . substr(trim($_POST['firstname']), 0, 2);
                    $ne1_email_id = $firstname . "." . $lastname . "@mindworx.in";
                    $result = $this->users->check_email($ne1_email_id);
                    if ($result == TRUE) {
                        echo json_encode(array('email' => strtolower($ne1_email_id)));
                        die;
                    } else {
                        $firstname = trim($_POST['firstname']);
                        $lastname = substr(trim($_POST['lastname']), 0, 2) . substr(trim($_POST['firstname']), 0, 2);
                        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        $rand = $characters[rand(0, strlen($characters))];
                        $ne2_email_id = $firstname . "." . $lastname . $rand . "@mindworx.in";
                        echo json_encode(array('email' => strtolower($ne2_email_id)));
                        die;
                    }
                }
            }
        }
    }
    
    /*Location auto Complete*/
    public function locationAutoComplete() {
        if (isset($_POST)) {
            $cityName = $this->city->get_city_name();
//            echo '<pre>',  print_r($cityName);die;
        }
    }


}
