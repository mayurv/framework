
    <div class="row">
                <div class="col-sm-12 goal-white-bg">
                <div class="all-padding-15">
                    
        <h2> Associate Goal</h2>

        <!--1st dashboard here start --> 
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
              <a href="<?php echo base_url()?>appraisal/goals" target="">
            <div class="info-box goal-box">
              <span class="info-box-icon bg-aqua goal-white-bg goal-box-icon">
                <button type="button" class="btn btn-success btn-circle btn-lg all-padding-0">
                  <i class="fa fa-cogs fa-lg"></i>
                </button>
              </span>

              <div class="info-box-content padding-top-25">
                <span class="info-box-number font-w-500"><?php echo $goal_count ?></span>
                <span class="info-box-text text-nouppercase">Goals</span>                
              </div>
              <!-- /.info-box-content -->
            </div>
          </a>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-xs-12">
              <a href="<?php echo base_url()?>appraisal/goals_feedback" target="">
            <div class="info-box goal-box">
              <span class="info-box-icon bg-aqua goal-white-bg goal-box-icon">
                <button type="button" class="btn btn-info btn-circle btn-lg all-padding-0">
                  <i class="fa fa-comments fa-lg"></i>
                </button>
              </span>

              <div class="info-box-content padding-top-25">                
                <span class="info-box-number font-w-500">0</span>
                <span class="info-box-text text-nouppercase">Feedback requests</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </a>
          </div>
          <!-- /.col -->
          <!-- fix for small devices only -->
          <div class="clearfix visible-sm-block"></div>

          <div class="col-md-3 col-sm-6 col-xs-12">
              <a href="<?php echo base_url()?>appraisal/review" target="_blank">
            <div class="info-box goal-box">
              <span class="info-box-icon bg-aqua goal-white-bg goal-box-icon">
                <button type="button" class="btn btn-warning btn-circle btn-lg all-padding-0">
                  <i class="fa fa-coffee fa-lg"></i>
                </button>
              </span>

              <div class="info-box-content padding-top-25">
                <span class="info-box-number font-w-500">0</span>
                <span class="info-box-text text-nouppercase">Reviews</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </a>
          </div>
          <!-- /.col -->
          <div class="col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo base_url()?>appraisal/developmentplan" target="_blank">
            <div class="info-box goal-box">
              <span class="info-box-icon bg-aqua goal-white-bg goal-box-icon">
                <button type="button" class="btn btn-primary btn-circle btn-lg all-padding-0">
                  <i class="fa fa-book fa-lg"></i>
                </button>
              </span>

              <div class="info-box-content padding-top-25">
                <span class="info-box-number font-w-500">0</span>
                <span class="info-box-text text-nouppercase">Development plans</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </a>
          </div>
          <!-- /.col -->
      </div>
      <!--1st dashboard here end --> 

      <!-- 2nd timeline start here -->
        <div class="row">
          <!-- 1st col-sm-6 start here --> 
          <div class="col-sm-6 margin-top-10">
            <!-- 1st inner row start here -->
              <div class="row"> 
                <div class="col-sm-10">                  
                  <span class="info-box-number font-w-500">Recent Goals</span>
                </div>
                <div class="col-sm-2">
                  <div class="pull-right">
                    <div class="btn-group">
                      <button class="dropdown-toggle btn btn-default btn-sm" data-toggle="dropdown">
                      <i class="fa fa-gear fa-lg"></i>
                      </button>
                      <ul class="dropdown-menu dropdown-menu-right">
                        <li>
                          <a class="needs-loading" data-remote="true" href="#">
                            <i class="fa fa-plus-circle"></i>
                          Add news
                          </a>
                          <a href="#">
                            <i class="fa fa-info-circle"></i>
                          All news
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  </div>
              </div>
            <!-- 1st inner row end here -->
            <hr />

            <?php foreach($recent_goal as $result) { 
                //var_dump($result);
                ?>
            <!-- 2nd inner row start here -->
            <div class="row"> 
              <div class="col-sm-12"> 
                 <div class="box box-solid">
                    <div class="box-header">
                      <!--<h3 class="box-title">Associate Goals</h3>-->
                      
                      <div class="pull-right"><small>Posted on <?php echo date('d,F Y',strtotime($result['createddate'])) ?></small></div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <p class="text-bold"> <?php echo $result['name']?></p>
                      <p>
                        <?php echo $result['description']?>
                      </p>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <small><i class="fa fa-clock-o"></i> Last updated on <?php echo date('d,F Y',strtotime($result['modifieddate'])) ?> </small>
                    </div>                    
                  </div>
                  <!-- /.box -->                
              </div>
            </div>
            <!-- 2nd inner row end here -->
<?php } ?>

          </div>
          <!-- 1st col-sm-6 end here -->

          <!-- 2nd col-sm-6 start here -->
          <div class="col-sm-6 margin-top-10">
                        <!-- 1st inner row start here -->
              <div class="row"> 
                <div class="col-sm-10">                  
                  <span class="info-box-number font-w-500">Performance timeline</span>
                </div>
                <div class="col-sm-2">
                  <div class="pull-right">
                    <div class="btn-group">
                      <button class="dropdown-toggle btn btn-default btn-sm" data-toggle="dropdown">
                        <i class="fa fa-gear fa-lg"></i>
                      </button>
                      <ul class="dropdown-menu dropdown-menu-right">
                        <li>
                          <a class="needs-loading" data-remote="true" href="#">
                            <i class="fa fa-plus-circle"></i>
                          Add news
                          </a>
                          <a href="#">
                            <i class="fa fa-info-circle"></i>
                          All news
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  </div>
              </div>
            <!-- 1st inner row end here -->
            <hr />

          </div>
          <!-- 2nd col-sm-6 end here -->

        </div>
      <!-- 2nd timeline end here -->

                    
                </div>
                </div>
            </div>
