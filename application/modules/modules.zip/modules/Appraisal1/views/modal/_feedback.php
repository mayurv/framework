<!-- Modal -->
        <div class="modal fade" id="feedback-provide" role="dialog">
            <div class="modal-dialog modal-lg">
                <form class="formValidate" id="formValidate" method="get" action="#">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Feedback Questions</h4>
                        </div>
                        <div class="modal-body all-padding-20">
                            <div class="goal-modal-bg">
                                <div class="table-responsive table-condensed table-striped">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="col-md-3">Question</th>
                                                <th class="col-md-3">Your response</th>
                                                <th class="col-md-3">Rating</th>
                                                <th class="col-md-3">Potential</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                   <p class="text-justify">Did the person demonstrate the ability to analyze, investigate & interpret data, issues & situations? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td>
                                                    <p class="text-justify">Did the person demonstrate the ability to provide and gather information and effectively communicate with the team? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td>
                                                    <p class="text-justify">Was the person able to plan, organize and prioritize work balancing resources, skills, priorities and timescales to achieve objectives? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td>
                                                    <p class="text-justify">Was the person able to evaluate or judge the best course of action and to make decisions at the appropriate speed? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <p class="text-justify">Did the person respond and adapt to changing circumstances and manage to solve problems and provide solutions in a climate of ambiguity? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <p class="text-justify">Did the person respond and adapt to changing circumstances and manage to solve problems and provide solutions in a climate of ambiguity?</p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td>
                                                    <p>Was the person able to work ethically according to the company values? </p>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12">
                                                        <div class="input-field margin-top-0">                                                
                                                            <textarea id="goaldesc" name="goaldesc" class="materialize-textarea validate" placeholder="Click here to provide your comments. Comments are saved automatically." data-error=".errorTxt-g2">
                                                            </textarea>
                                                            <div class="errorTxt-g2"></div>
                                                        </div>
                                                    </div>
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Significantly underperforms</option>
                                                            <option value="2">2 - Needs improvement</option>
                                                            <option value="3">3 - Meets expectations</option>
                                                            <option value="3">4 - Exceeds expectations</option>
                                                            <option value="3">5 - Top performer</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>

                                                <td>
                                                    <div class="col-sm-12 padding-top-15">

                                                        <select class="error browser-default margin-bottom-20" id="teamselect" name="teamselect" data-error=".errorTxt-g3">
                                                            <option value="" disabled selected>Select Your Option</option>
                                                            <option value="1">1 - Low potential</option>
                                                            <option value="2">2 - Below average potential</option>
                                                            <option value="3">3 - Average potential</option>
                                                            <option value="3">4 - Above average potential</option>
                                                            <option value="3">5 - High potential</option>                                              
                                                        </select>
                                                        <div class="input-field">
                                                            <div class="errorTxt-g3"></div>
                                                        </div>
                                                    </div>    
                                                </td>
                                            </tr>

                                        </tbody>

                                    </table>
                                </div>
                                
                                <div class="box box-solid goal-box-border">
                                    <div class="box-header with-border bg-danger">
                                        <p>Submit your feedback</p>
                                    </div>
                                    <!-- /.box-header -->
                                    <div class="box-body">
                                        <p> Are you ready to submit your feedback? The feedback will be finalised and checked. Once submitted you cannot change your feedback.</p>
                                    </div>
                                    <!-- /.box-body -->
                                </div>
                                
                            </div>
                        </div>
                        <div class="modal-footer"> 
                            
                            <div class="input-field">
                                <div class="text-right">                                    
                                    <button class="btn btn-info"><i class="fa fa-comments margin-right-5"></i>Submit your feedback</button>                      
                                </div>
                            </div>          
                        </div>
                    </div>
                </form>
            </div>    
        </div>