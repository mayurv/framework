<div class="row">
    <!--<div class="col-sm-12 white-bg">-->
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">
<div class="row">
    <div class="col-sm-8">
        <h3> Associate Feedback Overview</h3>
    </div>
    <div class="col-sm-4">
        <div class="pull-right">
            <a class="btn btn-info btn-sm btn-radius-3" data-remote="true" data-toggle="modal" data-target="#internal-feedback">
                <i class='fa fa-comments fa-lg margin-right-5'></i>
                Request feedback
            </a>
        </div>
    </div>
</div>

<div class="row">
            <!--1st dashboard here start --> 
            <div class="row">
                <div class="col-sm-3">
                    <div class="box box-solid goal-box">
                        <div class="box-body all-padding-20 text-center">
                            <i class="fa fa-flag fa-5x"></i>
                            <hr class="goal-line">
                            <h2 class="font-w-500">2.00</h2>
                            <p class="text-uppercase">Average feedback rating</p>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!--1st end here-->

                    <!--2nd start-->
                    <div class="box box-solid bg-success">
                        <div class="box-body all-padding-20 text-center text-white">
                            <i class="fa fa-comments fa-5x"></i>
                            <hr class="goal-line">
                            <h2 class="font-w-500">1</h2>
                            <p class="text-uppercase">Feedback report received</p>
                            <small>Filter feedback received</small>
                        </div>
                        <!-- /.box-body -->
                    </div>
                    <!--2nd end here-->

                    <!--3rd start-->
                    <div class="box box-solid bg-info">
                        <div class="box-body all-padding-20 text-center text-white">
                            <i class="fa fa-comment-o fa-5x"></i>
                            <hr class="goal-line">
                            <h2 class="font-w-500">1</h2>
                            <p class="text-uppercase">Feedback report requested</p>
                            <small>Filter feedback pending</small>
                        </div>
                        <!-- /.box-body -->
                    </div>

                    <!--3rd end-->



                </div>
                <!-- /.col-->

                <div class="col-sm-9">                                    

                    <div class="row"> 
                        <div class="col-sm-12 margin-bottom-15">
                            <h3 class="font-w-500 margin-top-bottom-15">Feedback requested or received </h3>
                            <p>This list contains feedback requests that have been provided (green) and requested/still pending (white)</p>
                        </div>                                                
                    </div>

                    <div class="box box-solid collapsed-box goal-box-border">
                        <div class="box-header with-border bg-success">

                            <div class="row">
                                <div class="col-sm-6">
                                    <h3 class="box-title font-size-16 font-w-500">
                                        <i class="fa fa-comments margin-right-5"></i>Self Feedback
                                    </h3>
                                </div>
                                <div class="col-sm-6">                                                            
                                    <div class="box-tools pull-right">
                                        <span class="margin-right-10"><small>
                                                <a href="<?php echo base_url() ?>/appriasal/goals_report"> 
                                                    <i class="fa fa-search fa-xs"></i>
                                                    Open feedback report</a></small>
                                        </span>
                                        <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                            <i class="fa fa-angle-down fa-lg"></i> <span class="tooltiptext">Expand</span>
                                        </button>  
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-12 margin-top-bottom-10">
                                    <div class="pull-left">


                                        <a class="btn btn-default btn-md" href="<?php echo base_url() ?>/appraisal/goals_report">
                                            <i class="fa fa-search fa-xs"></i>
                                            Open feedback report
                                        </a></div>

                                    <div class="pull-right padding-top-10">
                                        <small>
                                            <i class="fa fa-clock-o"></i> Received on 6th April 2017
                                        </small>
                                        <div class="label label-gray margin-left-5">
                                            <i class="fa fa-comments fa-xs"></i>
                                            Received
                                        </div>
                                    </div>



                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 margin-top-bottom-15">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="col-md-6">Where did the individual perform well?</th>
                                                <th class="col-md-6">What are the areas for growth for the individual?</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>sdesadfs</td>
                                                <td>asedasdfsdf</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <div class="margin-top-10">
                                        <span>Overall rating:</span>
                                        <span class="badge badge-primary margin-left-10"><a href="#">2</a></span>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <div class="row"> 
                                <div class="col-sm-12"> 
                                    <p class="small margin-top-10">
                                        <span>
                                            <i class="fa fa-clock-o"></i>
                                            Feedback received about 1 hour ago 
                                        </span>
                                        <span class="pull-right padding-bottom-5">
                                            <a href="#">
                                                <i class="fa fa-folder-open-o"></i>
                                                Archive feedback
                                            </a>
                                        </span>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- /.box -->

                    <div class="box box-solid collapsed-box goal-box-border">
                        <div class="box-header with-border bg-gray-light">

                            <div class="row">
                                <div class="col-sm-6">
                                    <h3 class="box-title font-size-16 font-w-500">
                                        <i class="fa fa-comments margin-right-5"></i>
                                        Feedback requested from Balram K
                                    </h3>
                                </div>
                                <div class="col-sm-6">
                                    <div class="box-tools pull-right">
                                        <span class="margin-right-10"><small>
                                                <i class="fa fa-exclamation-circle fa-xs"></i>
                                                Send reminder email</small>
                                        </span>

                                        <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                            <i class="fa fa-angle-down fa-lg"></i> <span class="tooltiptext">Expand</span>
                                        </button>  
                                    </div>


                                </div>
                            </div>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-12 margin-bottom-10">
                                    <div class="alert-warning h-bg-violet all-padding-15">
                                        <div class="media">
                                            <div class="media-left">
                                                <span class="icon-wrap icon-circle alert-icon">
                                                    <i class="fa fa-flag fa-2x"></i>
                                                </span>
                                            </div>
                                            <div class="media-body">
                                                <h4>Whoah!
                                                </h4>
                                                <p class="alert-message">
                                                    This feedback is still pending. Maybe you should send a reminder to the provider?
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="row margin-top-bottom-15">
                                <div class="col-sm-6">
                                    <p class="text-bold">Your self assessment:</p>
                                    <p class="margin-bottom-10">
                                        <em>dxfgdfgdfg</em>
                                    </p>
                                    <p class="text-bold">Your message to Balram:</p>
                                    <p class="margin-bottom-10">
                                        <em>dxfdgdfg</em>
                                    </p>
                                </div>
                                <div class="col-sm-6">
                                    <div class="pull-right">
                                        <small>
                                            <i class="fa fa-clock-o"></i> 
                                            Requested on 6th April 2017 | Delete feedback request 
                                        </small>
                                        <div class="label label-gray margin-left-5">
                                            <i class="fa fa-comment-o fa-xs"></i>
                                            <small>Requested</small>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                    

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <div class="row"> 
                                <div class="col-sm-12"> 
                                    <p class="small margin-top-10">
                                        <span>
                                            <i class="fa fa-clock-o"></i>
                                            Feedback requested about 17 hours ago 
                                        </span>                                                                
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>                                         
                    <!-- /.box -->
                    <div class="row">
                        <div class="col-sm-12 margin-bottom-30">                                                    
                            <h3 class="font-w-500">Feedback requested from you or drafted by you</h3>
                            <p>
                                <em>
                                    This is feedback that you have started but not yet submitted to the user 
                                </em>
                            </p>
                        </div>
                    </div>

                    <div class="box box-solid collapsed-box goal-box-border">
                        <div class="box-header with-border bg-gray-light">

                            <div class="row">
                                <div class="col-sm-6">
                                    <h3 class="box-title font-size-16 font-w-500">
                                        <i class="fa fa-comments margin-right-5"></i>
                                        Feedback request for Balram K
                                    </h3>
                                    <span class="badge badge-danger margin-left-10">Due by 24th April 2017</span>
                                </div>
                                <div class="col-sm-6">
                                    <div class="box-tools pull-right">
                                        <span class="margin-right-10"><small>
                                                <i class="fa fa-pencil fa-xs"></i>
                                                Provide your feedback</small>
                                        </span>

                                        <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                            <i class="fa fa-angle-down fa-lg"></i> <span class="tooltiptext">Expand</span>
                                        </button>  
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="row">
                                <div class="col-sm-12 margin-top-bottom-10">
                                    <div class="pull-left">
                                        <button class="btn btn-default btn-md" data-toggle="modal" data-target="#feedback-provide">
                                            <i class="fa fa-pencil fa-xs"></i>
                                            Provide your feedback
                                        </button>
                                    </div>

                                    <div class="pull-right padding-top-10">
                                        <small>
                                            <i class="fa fa-clock-o"></i>
                                            Last updated on 6th April 2017 | Delete draft 
                                        </small>
                                        <div class="label label-gray margin-left-5">
                                            <i class="fa fa-comments fa-xs"></i>
                                            Draft
                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <div class="row"> 
                                <div class="col-sm-12"> 
                                    <p class="small margin-top-10">
                                        <span>
                                            <i class="fa fa-clock-o"></i>
                                            Feedback updated at about 18 hours ago 
                                        </span>

                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--box-->
                </div>
                <!-- /.col -->


            </div>
            <!--1st dashboard here end -->
        </div>
    </div>
</div>
        </div>

<?php $this->load->view('modal/_request_feedback') ?>

<?php $this->load->view('modal/_add_goal'); ?>
<?php $this->load->view('modal/_edit_goal'); ?>


<script>
    $("[data-widget='collapse']").click(function () {
        //Find the box parent        
        var box = $(this).parents(".box").first();
        //Find the body and the footer
        var bf = box.find(".box-body, .box-footer");
        if (!box.hasClass("collapsed-box")) {
            box.addClass("collapsed-box");
            bf.slideUp('slow');
        } else {
            box.removeClass("collapsed-box");
            bf.slideDown('slow');
        }
    });
</script>


