<div class="row">
    <!--<div class="col-sm-12 white-bg">-->
    <div class="col-sm-12 white-bg">
        <div class="all-padding-15">

            <div class="row">
                <div class="col-sm-8">
                    <h3> Associate Goal Overview</h3>
                </div>
                <div class="col-sm-4">
                    <div class="pull-right">
                        <a class="btn btn-info btn-sm btn-radius-3" data-remote="true" data-toggle="modal" data-target="#new-goal">
                            <i class="fa fa-plus-circle fa-lg margin-right-5"></i>
                            Create your first individual goal                   
                        </a>
                    </div>
                </div>
            </div>
<?php if(isset($my_goals)) { ?>
            <!--1st dashboard here start --> 
            <div class="row">
                <div class="col-sm-3">
                    <?php foreach ($my_goals as $r => $data) { ?>
                        <div class="box box-solid <?php echo $data['user_status'] == 1 ? 'bg-success' : 'bg-warning' ?>">
                            <div class="box-body all-padding-20 text-center text-white">
                                <i class="fa fa-check fa-5x"></i>
                                <hr class="goal-line">
                                <h2 class="font-w-500"><?php echo $r+1 ?></h2>
                                <p class="text-uppercase"><?php echo $data['user_status'] == 1 ? 'Goal Complete' : 'Goal Inprogress' ?></p>
                                <small>
                                    Filter in progress goals
                                </small>
                            </div>
                            <!-- /.box-body -->
                        </div>
                    <?php } ?>
                </div>
                <!-- /.col-->

                <div class="col-sm-9">                                    

                    <div class="row"> 
                        <div class="col-sm-6"><h5 class="font-w-500 margin-top-bottom-15">Average goals</h5></div>
                        <div class="col-sm-6"> 
                            <br />
                            <div class="progress progress-goals">
                                <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                    <span>80%</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php foreach ($my_goals as $data) {
                       ?>

                        <div class="row"> 
                            <div class="col-sm-12"><hr class="margin-top-5" /></div>
                        </div>


                        <div class="box box-solid goal-box-border">
                            <div class="box-header with-border bg-gray-light">

                                <div class="row">
                                    <div class="col-sm-6">
                                        <h4 class="box-title font-size-16 font-w-500"><?php echo $data['name'] ?></h4>
                                    </div>
                                    <div class="col-sm-6">

                                        <div class="row"> 
                                            <div class="col-sm-7">                                                             
                                                <div class="progress margin-top-10">
                                                    <div class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                                        <span>40%</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-5">
                                                <div class="box-tools pull-right">
                                                    <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                                        <i class="fa fa-folder-open fa-lg"></i> Show Goal   <span class="tooltiptext">Open in new window</span>                                                          
                                                    </button>  

                                                    <button  class="btn btn-default btn-sm tooltip" data-widget="collapse">
                                                        <i class="fa fa-angle-down fa-lg"></i> <span class="tooltiptext">Expand</span>
                                                    </button>  
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-sm-12 margin-bottom-10">
                                        <div class="pull-right">
                                            <small>
                                                <i class="fa fa-clock-o"></i> <?php echo date('d M Y',strtotime($data['createddate'])); ?>
                                                | <a data-remote="true" data-toggle="modal" data-target="#edit_goal_<?php echo $data['id'] ?>">Edit goal</a>

                                            </small> |
                                            <div class="label label-gray margin-left-5">
                                                <i class="fa fa-check-circle fa-xs"></i>
                                               <?php echo $data['user_status'] == 1 ? 'Complete' : 'Inprogress' ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Attribute</th>
                                                    <th>
                                                        <span>Description</span>
                                                    
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Goal name</td>
                                                    <td><?php echo $data['name'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Goal description</td>
                                                    <td><?php echo $data['description'] ?></td>
                                                </tr>

                                                <tr>
                                                    <td>When is the goal due to be achieved?</td>
                                                    <td>
                                                        <span><?php echo date('d M Y',strtotime($data['completion_date'])); ?></span>
                                                                         
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><p>Goal update</p></td>
                                                    <td>
                                                        <div class="row"> 
                                                            <div class="col-sm-10"> 
                                                                <div class="label label-gray margin-bottom-5 tooltip">Complete 
                                                                    <span class="tooltiptext">Click to set goal status</span>
                                                                </div>
                                                                <div class="label label-gray margin-bottom-5 tooltip">In Progress
                                                                    <span class="tooltiptext">Click to set goal status</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Goal progress</td>
                                                    <td>
                                                        <div id="unranged-value1" style="width: 250px; margin: 0px"></div> 
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>                      
                        </div>
                    <?php } ?>
                </div>
                <!-- /.col -->


            </div>
            <!--1st dashboard here end -->
            
         <?php   } ?>
        </div>
    </div>
</div>

<?php $this->load->view('modal/_add_goal'); ?>
<?php $this->load->view('modal/_edit_goal'); ?>

<script type="text/javascript">
    $(document).ready(function () {
<?php if (($this->session->flashdata())) { ?>
            showSuccess("<?php echo $this->session->flashdata('msg'); ?>");
<?php } ?>
    });
</script>