<div class="main-bg all-padding-15 margin-bottom-35">
    <h4>Monthly Biomatric Report</h4>
    <div class="row  ">
        <div class="col-sm-2">   
            <form action="<?php echo base_url() ?>attendance/monthly_report" method="post" id="form_submit_month_bio">
                <?php
                echo form_dropdown(array('id' => 'drop_year_id', 'name' => 'drop_year_id', 'class' => 'browser-default', 'data-error' => '.errorYear1'), $years_list, set_value('year_id', $current_year_id));
                ?>
                <div class="input-field">
                    <div class="errorYear1"></div>
                </div>
            </form>

        </div>
        <div class="col-sm-12">        
            
                
            </div>
            <table id="example-1" class="table table-bordered table-striped dt-responsive display" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>File Name</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>File Name</th>
                        <th>Action</th>
                    </tr>
                </tfoot>

                <tbody>
                    
                    <?php
                    $i = 1;
//                    var_dump($month_list);die;
                    foreach ($month_list as $result) {
                        ?>
                        <tr>
                            <td><?php echo $i ?></td>
                            <td><?php echo ($result['description']) ?></td>
                            <td>January Attendance File</td>
                            <td>                             
                                <form action="<?php echo base_url() ?>attendance/monthly_report" method="post" enctype="multipart/form-data" id="importFrm">
                                    <button type="submit" class="btn btn-primary btn-sm" name="importSubmit" id="importSubmit<?php echo ($result['month_id']) ?>" value="Generate" onclick="importSubmitFun('<?php echo ($result['month_id']); ?>')">Generate</button>
                                    <input name="month_id" value="<?php echo $result['id'] ?>" hidden>
                                    <input id="year_id<?php echo $result['id'] ?>" name="year_id" value="<?php echo $years_list[$current_year_id] ?>" hidden>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $i++;
                    }
                    ?>



                </tbody>
            </table>
            
        </div>
    </div>
</div>  

<script>

    function importSubmitFun(importId) {
        var year_id = $("#drop_year_id").val(); 
        $("#year_id"+importId).val(year_id);
    }
//    $("#year_id").change(function () {
//        var year_id = $("#year_id").val();
//        
//        $.ajax({
//            type: "POST",
//            url: '<?php echo base_url(); ?>attendance/monthly_report/'+year_id,
//            success: function (data) {
//                
//            }
//        });
//        return false;
//    });

</script>