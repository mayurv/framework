<div class="panel panel-default">
    <div class="panel-heading">

        <a href="javascript:void(0);" onclick="$('#importFrm').slideToggle();">Import CSV</a>
    </div>
    <div class="panel-body">
        <form action="<?php echo base_url() ?>attendance/importPunchData" method="post" enctype="multipart/form-data" id="importFrm">
            <input type="file" name="file" />
            <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
        </form>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>date</th>
                <th>emp_id</th>
                <th>emp_name</th>
<!--                <th>company</th>
                <th>dept</th>
                <th>category</th>
                <th>designation</th>
                <th>grade</th>
                <th>team</th>
                <th>shift</th>-->
                <th>in_time</th>
                <th>out_time</th>
                <th>duration</th>
<!--                <th>late_by</th>
                <th>early_by</th>-->
                <th>status</th>
                <th>punch_rec</th>
<!--                <th>overtime</th>-->

            </tr>
        </thead>
        <tbody>
            <?php foreach ($attandance_punches as $row) { ?>
                <tr>
                    <td><?php echo $row['date']; ?></td>
                    <td><?php echo $row['emp_id']; ?></td>
                    <td><?php echo $row['emp_name']; ?></td>
    <!--                    <td><?php echo $row['company']; ?></td>
                    <td><?php echo $row['dept']; ?></td>
                    <td><?php echo $row['category']; ?></td>
                    <td><?php echo $row['designation']; ?></td>
                    <td><?php echo $row['grade']; ?></td>
                    <td><?php echo $row['team']; ?></td>
                    <td><?php echo $row['shift']; ?></td>-->
                    <td><?php echo $row['in_time']; ?></td>
                    <td><?php echo $row['out_time']; ?></td>
                    <td><?php echo $row['duration']; ?></td>
    <!--                    <td><?php echo $row['late_by']; ?></td>
                    <td><?php echo $row['early_by']; ?></td>-->
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>In</th>
                                    <th>Out</th>
                                    <th>In Hrs</th>
                                    <th>Out Hrs</th>
                                </tr>
                            </thead>
                            <?php
                            $test_name_array = $row['punch_rec'];

                            //   var_dump($test_name_array);
                            $pieces = explode(" ", $test_name_array);

                            foreach ($pieces as $key => $value) {
                                $exp_key = explode(':', $value);

                                if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                    //
                                    if ($exp_key[2] == 'in(AC)') {
                                        $arr_inresult[] = $value;
                                    }
                                }
                            }
                            $count = count($arr_inresult);

                            foreach ($pieces as $key => $value) {
                                $exp_key = explode(':', $value);
                                if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                    if ($exp_key[2] == 'out(AC)') {
                                        $arr_outresult[] = $value;
                                    }
                                }
                            }

                            foreach ($pieces as $key => $value) {
                                $exp_key = explode(':', $value);

                                if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                    if ($exp_key[2] == '(AC)') {
                                        $arr_missoutresult[] = $value;
                                    }
                                }
                            }
                            $falg = 0;
                            for ($i = 0; $i < $count; $i++) {
                                echo '<tr>';

                                if (isset($arr_inresult[$i])) {
                                    echo '<td>';
                                    echo $arr_inresult[$i];
                                    echo '</td>';
                                } else {
                                    echo '<td>';
                                    echo '<span  class="bg-warning">in missing</span>';
                                    echo '</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                }
                                if (isset($arr_outresult[$i])) {
                                    echo '<td>';
                                    echo $arr_outresult[$i];
                                    echo '</td>';
                                } else {
                                    echo '<td>';
                                    echo '<span  class="bg-warning">out missing</span>';
                                    echo '</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                }

                                if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
                                    $instring = explode(':in(AC)', $arr_inresult[$i]);
                                    $stratString = $instring[0] . ':00';


                                    $outstring = explode(':out(AC)', $arr_outresult[$i]);
                                    $endString = $outstring[0] . ':00';

                                    $start_time = new DateTime($stratString);
                                    $end_time = new DateTime($endString);
                                    $duration = $start_time->diff($end_time);

                                    echo '<td>';
                                    echo $duration->format("%H : %I");
                                     echo '</td>';
                                    $total_inhrs[$i] = $duration->format("%H : %I");
                                }




                                if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
                                    if (isset($arr_inresult[$i])) {
                                        $instring1 = explode(':in(AC)', $arr_inresult[$i]);
                                        $firdtString = (string) $instring1[0];
                                        $stratString1 = $instring1[0] . ':00';

                                        $arr_outresult[-1] = '00:00:out(AC)';

                                        $outstring1 = explode(':out(AC)', $arr_outresult[$i - 1]);
                                        $endString1 = $outstring1[0] . ':00';

                                        $start_time1 = new DateTime($stratString1);
                                        $end_time1 = new DateTime($endString1);
                                        $duration1 = $start_time1->diff($end_time1);

                                        $val = $duration1->format("%H:%I");
                                        if ((trim($firdtString) == trim($val))) {

                                            echo '<td>';
                                            echo '--';
                                            echo '</td>';
                                        } else {
                                            echo '<td>';
                                            echo $duration1->format('%H:%I');

                                            $total_outhrs[$i] = $duration1->format("%H : %I");
                                            echo '</td>';
                                        }
                                    }
                                }

                                echo '</tr>';
                            }

                            echo '<tr>';
                            echo '<td>Total Hrs</td>';
                            echo '<td></td>';

                            echo '<td>';
                            $time = 0;

                            foreach ($total_inhrs as $time_val) {
                                $time += explode_time($time_val);
                            }
                            echo second_to_hhmm($time);
                            echo '</td>';
                            echo '<td>';
                            $time1 = 0;

                            foreach ($total_outhrs as $time_val1) {
                                $time1 +=explode_time($time_val1);
                            }
                            echo second_to_hhmm($time1);
                            echo '</td>';
                            echo '</tr>';



                            for ($i = 0; $i < $count; $i++) {

                                if (isset($arr_missoutresult[$i])) {
                                    echo '<tr>';
                                    echo '<td>';
                                    echo '<span  class="bg-danger">';
                                    echo isset($arr_missoutresult[$i]) ? $arr_missoutresult[$i] : '';
                                    echo '</span>';
                                    echo '</td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                    echo '<td></td>';
                                    echo '</tr>';
                                }
                            }
                            ?>


                        </table>
                    </td>
    <!--                    <td><?php echo $row['overtime']; ?></td>-->

                </tr>
                <?php
                $arr_inresult = array();
                $arr_outresult = array();
                $arr_missoutresult = array();
                $total_outhrs = array();
                $total_inhrs = array();
            }
            ?>
            
        </tbody>
    </table>

</div>

<?php

function explode_time($time) { //explode time and convert into seconds
    $time = explode(':', $time);
    $time = $time[0] * 3600 + $time[1] * 60;
    return $time;
}

function second_to_hhmm($time) { //convert seconds to hh:mm
    $hour = floor($time / 3600);
    $minute = strval(floor(($time % 3600) / 60));
    if ($minute == 0) {
        $minute = "00";
    } else if ($minute <= 9) {
        $minute = '0' . $minute;
    } else {
        $minute = $minute;
    }

    // echo $minute;
    $time = $hour . ":" . $minute;
    // var_dump($time);
    return $time;
}
?>


