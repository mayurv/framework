<div class="white-bg all-padding-15">
    <!--row start here -->
    <div class="row">
        <!-- left side col-sm-12 here -->
        <div class="col-sm-12">
            <?php // var_dump($month_date)?>
            <h4>Punch Report for <?php echo date('F Y',  strtotime($month_date)) ?></h4>
            <div class="main-bg all-padding-15">
                <div class="row">
                    <div class="col-sm-12">                                        
                        <table id="biomatric_month" class="table table-bordered table-striped dt-responsive display" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                   <!--<th>Date</th>-->
                                                    <th>Emp ID</th>
                                                    <th>Name</th>
                                                    <th>Present</th>
                                                    <th>Absent</th>
                                                    <th>cl</th>
                                                    <th>pl</th>
                                                    <th>sl</th>                                                    
                                                    <th>Cli</th>
                                                    <th>WH</th>
                                                    <th>Week off</th>                                                    
                                                    <th>Week off Pre</th>
                                                    <th>Holiday</th>
                                                    <th>Holiday Pret</th>
                                                    <th>Duration</th>
                                                    <th>Total hrs</th>
                                                    <th>In hrs</th>
                                                    <th>Out hrs</th>
                                                    
                                                </tr>
                                            </thead>

                                            <tfoot>
                                                <tr>
<!--                                                    <th>Date</th>-->
                                                   <th>Emp ID</th>
                                                    <th>Name</th>
                                                    <th>Present</th>
                                                    <th>Absent</th>
                                                    <th>cl</th>
                                                    <th>pl</th>
                                                    <th>sl</th>                                                    
                                                    <th>Cli</th>
                                                    <th>WH</th>
                                                    <th>Week off</th>                                                    
                                                    <th>Week off Pre</th>
                                                    <th>Holiday</th>
                                                    <th>Holiday Pret</th>
                                                     <th>Duration</th>
                                                    <th>Total hrs</th>
                                                    <th>In hrs</th>
                                                    <th>Out hrs</th>
                                                </tr>
                                            </tfoot>

                                            <tbody>
                                                <?php foreach($month_punch_report as $result) { ?> 
                                                <tr>                                                                                        
                                                    <!--<td><?php //echo  date('d M y',strtotime($result['date'])) ?></td>-->
                                                    <td><?php echo  $result['emp_id'] ?></td>
                                                    <td><?php echo  $result['emp_name'] ?></td> 
                                                    <td><?php echo  $result['present_days'] ?></td>
                                                    <td><?php echo  $result['absent_days'] ?></td>
                                                    <td><?php echo  $result['cl'] ?></td>
                                                    <td><?php echo  $result['pl'] ?></td>
                                                    <td><?php echo  $result['sl'] ?></td>                                                    
                                                    <td><?php echo  $result['cli'] ?></td>
                                                    <td><?php echo  $result['wh'] ?></td>
                                                    <td><?php echo  $result['week_off'] ?></td>                                                    
                                                    <td><?php echo  $result['week_off_present'] ?></td>
                                                    <td><?php echo  $result['holiday'] ?></td>
                                                    <td><?php echo  $result['holiday_present'] ?></td>
                                                    <td><?php echo  $result['duration'] ?></td>
                                                    <td><?php echo  $result['total_hours'] ?></td>
                                                    <td><?php echo  $result['in_hrs'] ?></td>
                                                    <td><?php echo  $result['out_hrs'] ?></td>
                                               
                                                    
                                                </tr> 
                                                 <?php } ?>
                                                
                                            </tbody>
                                        </table>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- left side col-sm-12 here -->
    </div>
    <!--row end here -->
</div>




