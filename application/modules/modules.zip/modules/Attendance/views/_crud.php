<div class="panel panel-default">
    <div class="panel-heading">
       
        <a href="javascript:void(0);" onclick="$('#importFrm').slideToggle();">Import CSV</a>
    </div>
    <div class="panel-body">
        <form action="<?php echo base_url()?>attendance/importData" method="post" enctype="multipart/form-data" id="importFrm">
            <input type="file" name="file" />
            <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
        </form>
    </div>
    
    <table class="table table-bordered">
                <thead>
                    <tr>
                      <th>Employee Code</th>
<th>Present Days</th>
<th>Absent Days</th>
<th>Normal Working Hours</th>
<th>OT Hours</th>
<th>OT Days</th>
<th>CL</th>	
<th>PL</th>	
<th>SL</th>	
<th>Total Leave</th>	
<th>Late Coming Days</th>	
<th>Late Coming Hours</th>	
<th>Early Going Days</th>
<th>Early Going Hours</th>	
<th>Weekly Off</th>
<th>Weekly Off Present</th>
<th>Holiday</th>	
<th>Holiday Present</th>
<th>Total HRS</th>
<th>Actual Working HRS</th>	
<th>Difference</th>
<th>Diff in Days</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($attandance as $row) { ?>
                    <tr>
                      <td><?php echo $row['emp_id']; ?></td>
<td><?php echo $row['present_days']; ?></td>
<td><?php echo $row['absent_days']; ?></td>
<td><?php echo $row['working_hrs']; ?></td>
<td><?php echo $row['ot_hrs']; ?></td>
<td><?php echo $row['ot_days']; ?></td>
<td><?php echo $row['cl']; ?></td>
<td><?php echo $row['pl']; ?></td>
<td><?php echo $row['sl']; ?></td>
<td><?php echo $row['total_leave']; ?></td>
<td><?php echo $row['late_coming']; ?></td>
<td><?php echo $row['late_coming_hrs']; ?></td>
<td><?php echo $row['early_going']; ?></td>
<td><?php echo $row['early_going_hrs']; ?></td>
<td><?php echo $row['week_off']; ?></td>
<td><?php echo $row['week_off_present']; ?></td>
<td><?php echo $row['holiday']; ?></td>
<td><?php echo $row['holiday_present']; ?></td>
<td><?php echo $row['total_hrs']; ?></td>
<td><?php echo $row['actual_hrs']; ?></td>

<td>
    <?php 
    $str=-(str_replace(':', '','4:30:10'));
    $comp =  str_replace(':', '',$row['difference_hrs']); ?>

    <?php if($row['difference_hrs'] < 0 && $comp < $str) { ?>
                <lable class="label-danger"><?php echo $row['difference_hrs']; ?></lable>
    <?php }     
    else if(0> ($comp) && ($comp)>$str)  { ?>
                <lable class="label-purple"><?php echo $row['difference_hrs']; ?></lable>
    <?php } else { ?>
                <lable class=""><?php echo $row['difference_hrs']; ?></lable>
    <?php } ?>

</td>
<td>
    <?php if($row['diff_days'] < 0 && $comp < $str) { ?>
   <lable class="label-danger"><?php echo $row['diff_days']; ?></lable>
    <?php }   else { ?>
                <lable class=""><?php echo $row['diff_days']; ?></lable>
    <?php } ?>
</td>
                      
                    </tr>
                <?php } ?>
                    <?php // } else { ?>
                    <!--<tr><td colspan="5">No member(s) found.....</td></tr>-->
                    <?php // } ?>
                </tbody>
            </table>
    
</div>


