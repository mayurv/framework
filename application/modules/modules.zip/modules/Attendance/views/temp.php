<?php

$test_name_array = $line[16];


$pieces = explode(" ", $test_name_array);
//var_dump($pieces);

foreach ($pieces as $key => $value) {
    $exp_key = explode(':', $value);

    if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
        //
        if ($exp_key[2] == 'in(AC)') {
            $arr_inresult[] = $value;
        }
    }
}
if (isset($arr_inresult)) {
    //   echo '11';
    $count = count($arr_inresult);


    foreach ($pieces as $key => $value) {
        $exp_key = explode(':', $value);
        if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
            if ($exp_key[2] == 'out(AC)') {
                $arr_outresult[] = $value;
            }
        }
    }

    foreach ($pieces as $key => $value) {
        $exp_key = explode(':', $value);

        if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
            if ($exp_key[2] == '(AC)') {
                $arr_missoutresult[] = $value;
            }
        }
    }

    $falg = 0;
    for ($i = 0; $i < $count; $i++) {
  
        if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
            $instring = explode(':in(AC)', $arr_inresult[$i]);
            $stratString = $instring[0] . ':00';

            $outstring = explode(':out(AC)', $arr_outresult[$i]);
            $endString = $outstring[0] . ':00';

            $start_time = new DateTime($stratString);
            $end_time = new DateTime($endString);
            $duration = $start_time->diff($end_time);
            $total_inhrs[$i] = $duration->format("%H : %I");
        }


        if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
            if (isset($arr_inresult[$i])) {
                $instring1 = explode(':in(AC)', $arr_inresult[$i]);
                $firdtString = (string) $instring1[0];
                $stratString1 = $instring1[0] . ':00';

                $arr_outresult[-1] = '00:00:out(AC)';

                $outstring1 = explode(':out(AC)', $arr_outresult[$i - 1]);
                $endString1 = $outstring1[0] . ':00';

                $start_time1 = new DateTime($stratString1);
                $end_time1 = new DateTime($endString1);
                $duration1 = $start_time1->diff($end_time1);

                     $total_outhrs[$i] = $duration1->format("%H : %I");
                   
                }
            }
        }


    $time = 0;

    foreach ($total_inhrs as $time_val) {
        $time += explode_time($time_val);
    }
    echo second_to_hhmm($time);
  
    $time1 = 0;

    foreach ($total_outhrs as $time_val1) {
        $time1 +=explode_time($time_val1);
    }
    echo second_to_hhmm($time1);
  

}