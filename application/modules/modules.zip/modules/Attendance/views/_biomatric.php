<div class="white-bg all-padding-15">
    <!--row start here -->
    <div class="row">
        <!-- left side col-sm-12 here -->
        <div class="col-sm-12">
            <h4>Attendance Report</h4>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">File Upload</div>
                        <div class="panel-body">
                            <form class="formValidate" id="formValidate" method="post" enctype="multipart/form-data" id="importFrm"  action="<?php echo base_url() ?>/attendance/biomatric">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="input-field">
                                            <?php echo form_label(lang('fdate'), 'fdate', array('for' => 'fdate')); ?>
                                            <?php
                                            echo form_input(array(
                                                'id' => 'fdate',
                                                'name' => 'fdate',
                                                'placeholder' => 'Select Date',
                                                'data-format' => 'yyyy-mm-dd',
                                                'class' => 'fdate',
                                                'data-error' => '.addOpening4',
                                            ));
                                            ?>   
                                            <div class="addOpening4"></div>                                
                                            <?php echo form_error('interview_date'); ?> 
                                        </div> 
                                    </div>  
                                    <div class="col-sm-4">
                                        <div class="file-field input-field">
                                            <div class="btn btn-sm margin-top-5"><span>File Upload</span>
                                                <input type="file" name="file" />
                                            </div>
                                            <div class="file-path-wrapper padding-left-0">
                                                <input class="file-path validate" type="text" placeholder="Upload files">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4 padding-top-20">                                                    
                                        <button type="submit" name="importSubmit" class="btn btn-warning2 btn-sm">Submit</button>
                                        <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-bg all-padding-15">
                <div class="row">
                    <div class="col-sm-12">                                        
                        <table id="biomatric-records" class="table table-bordered table-striped dt-responsive display" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Uploaded By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Uploaded By</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>

                            <tbody>
                                <?php $i=1;
                                foreach($biomatric as $result) { 
                                   
                                    ?>
                                <tr id="<?php echo $result['b_self_id']; ?>">
                                    <td><?php echo $i?></td>
                                    <td><a href="<?php echo base_url() ?>attendance/month_biomatric/<?php echo  date('Ymd',strtotime($result['date'])) ?>"><?php echo date('d F Y',strtotime($result['date']))?></a></td>
                                    <td><?php echo $result['userfullname'] ?> on <?php echo date('d F Y',strtotime($result['createdat']))?></td>
                                    <td>                                    
                                        <span class="leave-app-ac-icon">
                                            <i onclick="deleteRecord(<?php echo $result['b_self_id'] ?>)" class="fa fa-trash-o text-ccc" title="Delete"></i>
                                        </span>
                                    </td>
                                </tr>
                                <?php 
                                $i++;
                                } ?>
                            </tbody>
                        </table>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- left side col-sm-12 here -->
    </div>
    <!--row end here -->
</div>

<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
        $(".fdate").click(function () {
            $('.fdate').pickadate({
                selectYears: true,
                selectMonths: true,
               // min: new Date(),
               max : new Date(),
            });
        });
    });
</script>

<script>
    function deleteRecord(dId) {

        if (confirm('Are you sure, you want to delete this?')) {

//        if()
            $("tr").remove("#" + dId);
            $.ajax({
                type: "POST",
                url: '<?php echo base_url(); ?>attendance/delete_biomaticrecord',
                data: {'b_self_id': dId},
                success: function (data) {
                    var parsed = $.parseJSON(data);
                    showSuccess(parsed.delete);
                }
            });
            return false;
        }
    }
</script>
