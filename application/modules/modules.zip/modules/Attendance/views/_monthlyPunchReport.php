<div class="main-bg all-padding-15 margin-bottom-35">
    <h4>Monthly Punch Report</h4>


    <div class="row">
        <div class="col-sm-2">   
            <form action="<?php echo base_url() ?>attendance/monthlyPunch_report" method="post" id="form_submit_month_bio">
                <?php
                echo form_dropdown(array('id' => 'drop_year_id', 'name' => 'drop_year_id', 'class' => 'browser-default', 'data-error' => '.errorYear1'), $years_list, set_value('year_id', $current_year_id));
                ?>
                <div class="input-field">
                    <div class="errorYear1"></div>
                </div>
            </form>

        </div>
        <div class="col-sm-12">  

            <table id="FlagsExport" class="table table-bordered table-striped dt-responsive display" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>File Name</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>File Name</th>
                        <th>Action</th>
                    </tr>
                </tfoot>

                <tbody>
                    <?php
                    $i = 1;
                    foreach ($month_list as $result) {
                        ?>
                        <tr>
                            <td><?php echo $i ?></td>
                            <td><a href="<?php echo base_url() ?>attendance/show_monthlyPunchRecords/<?php echo ($result['month_id']) ?>"><?php echo ($result['description']) ?></a></td>
                            <td>January Attendance File</td>
                            <td>                             
                                <form action="<?php echo base_url() ?>attendance/monthlyPunch_report" method="post" enctype="multipart/form-data" id="importFrm">
                                    <button type="submit" class="btn btn-primary btn-sm" name="importSubmit" id="importSubmit<?php echo ($result['month_id']) ?>" value="Generate" onclick="importSubmitFun('<?php echo ($result['month_id']); ?>')">Generate</button>
                                    <input name="month_id" value="<?php echo $result['id'] ?>" type="hidden">
                                    <!--<input name="year_id" value="<?php echo '2017' ?>" type="hidden">-->
                                    <input id="year_id<?php echo $result['id'] ?>" name="year_id" value="<?php echo $years_list[$current_year_id] ?>" hidden>
                                </form>
                            </td>
                        </tr>
                        <?php
                        $i++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  

<script>
    function importSubmitFun(importId) {
        var year_id = $("#drop_year_id").val();
        $("#year_id" + importId).val(year_id);
    }
</script>
<!--<link type="text/css" href="https://cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css" rel="stylesheet">-->
<link type="text/css" href="https://cdn.datatables.net/buttons/1.1.2/css/buttons.dataTables.min.css" rel="stylesheet">
<!--<script type="text/javascript" src="jquery-1.12.0.min.js"></script>-->
 
<!--<script type="text/javascript" src="https://cdn.datatables.net/tabletools/2.2.4/js/dataTables.tableTools.min.js"></script>-->
<script type="text/javascript" src="https://cdn.datatables.net/tabletools/2.2.2/swf/copy_csv_xls_pdf.swf"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.1.2/js/buttons.print.min.js"></script>
 
<script type="text/javascript">
    $(document).ready(function() {
        $('#FlagsExport').DataTable({
            "pageLength": 50,
            dom: 'Bfrtip',
            buttons: ['copy','csv','excel','pdf','print']
        });
    });
</script>
