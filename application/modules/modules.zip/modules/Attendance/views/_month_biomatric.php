<div class="white-bg all-padding-15">
    <!--row start here -->
    <div class="row">
        <!-- left side col-sm-12 here -->
        <div class="col-sm-12">
            <h4>Attendance Report for <?php echo date('d, F Y',strtotime($month_date)) ?></h4>
            <div class="main-bg all-padding-15">
                <div class="row">
                    <div class="col-sm-12">                                        
                        <table id="biomatric_month" class="table table-bordered table-striped dt-responsive display" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Emp ID</th>
                                                    <th>Emp Name</th>
                                                     <th>In</th>
                                                    <th>Out</th>
                                                    <th>Present Days</th>
                                                    <th>Absent Days</th>
                                                    <th>cl</th>
                                                    <th>pl</th>
                                                    <th>sl</th>                                                    
                                                    <th>Cli</th>
                                                    <th>WH</th>
                                                    <th>Total Leave</th>
                                                    <th>Week off</th>                                                    
                                                    <th>Week off Present</th>
                                                    <th>Holiday</th>
                                                    <th>Holiday Present</th>
                                                    <th>Total hrs</th>
                                                </tr>
                                            </thead>

                                            <tfoot>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Emp ID</th>
                                                    <th>Emp Name</th>  
                                                    <th>In</th>
                                                    <th>Out</th>
                                                    <th>Present Days</th>
                                                    <th>Absent Days</th>
                                                    <th>cl</th>
                                                    <th>pl</th>
                                                    <th>sl</th>                                                    
                                                    <th>Client</th>
                                                    <th>Working hrs</th>
                                                    <th>Total Leave</th>
                                                    <th>Week off</th>                                                    
                                                    <th>Week off Present</th>
                                                    <th>Holiday</th>
                                                    <th>Holiday Present</th>
                                                    <th>Total hrs</th>
                                                </tr>
                                            </tfoot>

                                            <tbody>
                                                <?php foreach($month_biomatric as $result) { ?> 
                                                <tr>                                                                                        
                                                    <td><?php echo  date('d M y',strtotime($result['date'])) ?></td>
                                                    <td><?php echo  $result['emp_id'] ?></td>
                                                    <td><?php echo  $result['emp_name'] ?></td> 
                                                    <th><?php echo  $result['in'] ?></th>
                                                    <th><?php echo  $result['out'] ?></th>
                                                    <td><?php echo  $result['present_days'] ?></td>
                                                    <td><?php echo  $result['absent_days'] ?></td>
                                                    <td><?php echo  $result['cl'] ?></td>
                                                    <td><?php echo  $result['pl'] ?></td>
                                                    <td><?php echo  $result['sl'] ?></td>                                                    
                                                    <td><?php echo  $result['cli'] ?></td>
                                                    <td><?php echo  $result['wh'] ?></td>
                                                    <td><?php echo  $result['total_leave'] ?></td>
                                                    <td><?php echo  $result['week_off'] ?></td>                                                    
                                                    <td><?php echo  $result['week_off_present'] ?></td>
                                                    <td><?php echo  $result['holiday'] ?></td>
                                                    <td><?php echo  $result['holiday_present'] ?></td>
                                                    <td><?php echo  $result['total_hrs'] ?></td>
                                                </tr> 
                                                 <?php } ?>
                                                
                                            </tbody>
                                        </table>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>                                   
        </div>
        <!-- left side col-sm-12 here -->
    </div>
    <!--row end here -->
</div>

<script type="text/javascript">
    /* Date picker validation Fucntions */
    $(document).ready(function () {
        $(".fdate").click(function () {
            $('.fdate').pickadate({
                selectYears: true,
                selectMonths: true,
               // min: new Date(),
            });
        });
    });
</script>
