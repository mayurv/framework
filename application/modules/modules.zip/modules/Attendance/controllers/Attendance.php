<?php

/*
 * MindLink is Human Resource Management Software
 * 
 * An open source application development framework for PHP 5.6.19 or newer
 * @package		CodeIgniter 3.1.2
 * @author		Mindworx Team
 * @copyright           © Copyright 2016. All rights reserved, MindWorx Software Services Pvt. Ltd.
 * @link		http://demo_ci.com
 */

/*
 * Employee Controller *  
 */

/**
 * @method string add_official()
 * @method void add_document(integer $integer)
 * @method setString(integer $integer)
 */
class Attendance extends MY_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->load->model(array('employeesummary', 'employeesleave', 'interviewdetails'));
        /* communication */
        $this->load->model(array('marital_status', 'nationality', 'language'));

        /* dashboard */
        $this->load->model(array('blogdetail', 'years', 'holidaydates', 'timelinecomment', 'employeeawards', 'leavetypesAllocation'));
        $this->load->model(array('frontend/notification'));
        $this->load->model(array('country', 'state', 'city', 'blood_groups', 'hobbies', 'skills', 'compentencylevel', 'educationlevel', 'documents'));

        $this->load->model(array('employees', 'common', 'personaldetails', 'communication', 'tag', 'experiencedetails', 'employeeskills', 'educationdetails', 'certificationdetails', 'visa'));
        $this->load->model(array('user_model', 'menu', 'groups', 'users', 'usergroups'));
        $this->load->model(array('prefix', 'biomatricrecords', 'punchmonthreport', 'months', 'attendancemonthreport', 'attendancemodel', 'attendancepunchesmodel', 'employment_mode', 'roles', 'department', 'jobTitle', 'holiday_groups', 'employment_status', 'workstation', 'gender',));
//        ,/User_model,/EmployeeSummary'
        $this->load->library('grocery_CRUD');
        $this->load->language(array('general_lang', 'profile_lang', 'attendance_lang'));
        $this->load->language('hr_lang');
        $this->load->helper('form');
//        $this->load->language('validation_lang');
//        $this->lang->load('validation_lang');
        //initialize
        $this->store_salt = $this->config->item('store_salt', 'ion_auth');
        $this->salt_length = $this->config->item('salt_length', 'ion_auth');
        $this->hash_method = $this->config->item('hash_method', 'ion_auth');

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('auth');
        // $this->template->set_master_template('template.php');
        if (!$this->ion_auth->logged_in()) {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
//        $this->db->cache_on();

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
    }

    public function index() {

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['attandance'] = $this->attendancemodel->getlist();
        $data['biomatric'] = $this->biomatricrecords->getlist_byDate();

        $data['title'] = lang('create_menu_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_biomatric', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function month_biomatric($date) {
        $month_date = $date;
        $data['month_biomatric'] = $this->biomatricrecords->get_monthRecordsList($month_date);
        $data['month_date'] = $month_date;


        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }



        $data['title'] = lang('create_menu_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_month_biomatric', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function month_punchrecord($date) {
        $month_date = $date;
        $data['month_punches'] = $this->attendancepunchesmodel->get_monthRecordsList($month_date);
        $data['month_date'] = $month_date;



        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['attandance'] = $this->attendancemodel->getlist();
        $data['biomatric'] = $this->biomatricrecords->getlist_byDate();


        $data['title'] = lang('create_menu_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_month_punchrecords', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function punches() {
        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $data['attandance_punches_list'] = $this->attendancepunchesmodel->getlist_byDate();

        $data['title'] = lang('create_menu_title');
        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_punches', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function biomatric() {

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $last_id = $this->biomatricrecords->get_last_id();
        if ($last_id == null || $last_id == 0)
            $last_id = 1;
        else
            $last_id = $last_id + 1;

        $add_date = date('Y-m-d', strtotime($this->input->post('fdate')));

//            echo $last_id;
//            echo $add_date;


        if (isset($_POST['importSubmit'])) {

            //validate whether uploaded file is a csv file
            $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
            if (!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)) {
                if (is_uploaded_file($_FILES['file']['tmp_name'])) {

                    //open uploaded csv file with read only mode
                    $csvFile = fopen($_FILES['file']['tmp_name'], 'r');

                    //skip first line
                    fgetcsv($csvFile);
                    //   var_dump($_POST);die;
                    //parse data from csv file line by line
                    while (($line = fgetcsv($csvFile)) !== FALSE) {

                        //var_dump($line);die;

                        $normal_time = explode(' Hours ', $line[3]);
                        $normal_hrs = $normal_time[0];
                        $normal_min_calc = explode(' Mins', $normal_time[1]);
                        $normal_min = $normal_min_calc[0];
                        $normal_string = $normal_hrs . ':' . $normal_min . ':00';

                        $ot_time = explode(' Hours ', $line[4]);
                        $ot_hrs = $ot_time[0];
                        $ot_min_calc = explode(' Mins', $ot_time[1]);
                        $ot_min = $ot_min_calc[0];
                        $ot_string = $ot_hrs . ':' . $ot_min . ':00';

                        $actual_hrs = $this->sum_the_time($normal_string, $ot_string);

                        $emp_id = $this->_get_employeeid($line[0]);

                        $emp_name = $this->biomatricrecords->get_empName($emp_id);


                        $attendanceData = array(
                            'date' => $add_date,
                            'b_self_id' => $last_id,
                            'emp_id' => $emp_id,
                            'emp_name' => $emp_name,
                            'present_days' => $line[1],
                            'absent_days' => $line[2],
                            'working_hrs' => $normal_string,
                            'ot_hrs' => $ot_string,
                            'ot_days' => $line[5],
                            'cl' => $line[6],
                            'pl' => $line[7],
                            'sl' => $line[8],
                            'par' => $line[9],
                            'mat' => $line[10],
                            'wh' => $line[11],
                            'cli' => $line[12],
                            'total_leave' => $line[13],
                            'late_coming' => $line[14],
                            'late_coming_hrs' => $line[15],
                            'early_going' => $line[16],
                            'early_going_hrs' => $line[17],
                            'week_off' => $line[18],
                            'week_off_present' => $line[19],
                            'holiday' => $line[20],
                            'holiday_present' => $line[21],
                            'in' => $line[22],
                            'out' => $line[23],
                            'total_hrs' => $actual_hrs,
                            'createdby' => $user_id,
                            'createdat' => date('Y-m-d H:i:s')
                        );
                        // var_dump($attendanceData);

                        $this->biomatricrecords->insert($attendanceData);
                        //  $working_hrs = 0;
                        //insert member data into database
                    }
                    //  die;
                    //close opened csv file
                    fclose($csvFile);

                    $qstring = '?status=succ';
                } else {
                    $qstring = '?status=err';
                }
            } else {
                $qstring = '?status=invalid_file';
            }
        }

        redirect('attendance/');
    }

    public function _get_employeeid($new_id) {

        if ($new_id <= 9)
            return 'MWX-00' . $new_id;
        else if ($new_id > 9 && $new_id <= 99)
            return 'MWX-0' . $new_id;
        else
            return 'MWX-' . $new_id;
    }

    public function monthly_report($year = null) {


        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        
        $year = $_POST['year_id'];
        if ($_POST['year_id'] != null)
            $year = $this->years->get_current_yearId_by_year($year);
        else {
            $year = date("Y");
        }

        $data['month_list'] = $this->months->as_array()->get_all();
        $data['years_list'] = ( $this->years->dropdown('year_id'));


        //VIEW CUREENT SELECTED
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['current_year_id'] = $cur_year_id;
        //END


        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $month = $this->input->post('month_id');

            $dataMonthReport = $this->biomatricrecords->get_RecordsByMonth($month, $year);
            $this->show_monthlyRecordsReport($month, $year, $dataMonthReport);
            return true;
            //var_dump($dataMonthReport);die;
//            foreach ($dataMonthReport as $k => $data) {
//                $data['createdby'] = $user_id;
//                $data['createdat'] = date('Y-m-d H:i:s');
//                $this->attendancemonthreport->insert($data);
//            }
//            redirect('attendance/monthly_report');
        }

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */


        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }

        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_monthlyReport', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function show_monthlyRecordsReport($month, $year, $dataMonthReport = null) {
        $month_date = $year . '-' . $month . '-01';
        $month_date = date('F Y', strtotime($month_date));
        $data['month_biomatric_report'] = $dataMonthReport;
        $data['month_date'] = $month_date;


        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_show_MonthlyReport', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function show_monthlyRecords($date = null, $dataMonthReport = null) {
        $month_date = $date;
        $data['month_biomatric_report'] = $this->attendancemonthreport->get_monthRecordsList($month_date);
        $data['month_date'] = $month_date;


        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_show_MonthlyReport', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function monthlyPunch_report($year = null) {
        
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');
        
        $year = $_POST['year_id'];
        if ($_POST['year_id'] != null)
            $year = $this->years->get_current_yearId_by_year($year);
        else {
            $year = date("Y");
        }
//        var_dump($year);die

        $data['month_list'] = $this->months->as_array()->get_all();
        $data['years_list'] = ( $this->years->dropdown('year_id'));
        //VIEW CUREENT SELECTED
        $current_year = date("Y");
        $cur_year_id = $this->years->get_current_yearId($current_year);
        $data['current_year_id'] = $cur_year_id;
        //END
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $month = $this->input->post('month_id');
//            $year = $this->input->post('year_id');
            $dataMonthReport = $this->attendancepunchesmodel->get_RecordsByMonth($month, $year);
            $this->show_monthlyPunchRecordsReport($month, $year, $dataMonthReport);
            return true;
            //var_dump($dataMonthReport);die;
//            foreach ($dataMonthReport as $k => $data) {
//                $data['createdby'] = $user_id;
//                $data['createdat'] = date('Y-m-d H:i:s');
//                $this->punchmonthreport->insert($data);
//            }
//            redirect('attendance/monthlyPunch_report');
        }

        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */


        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }
        

        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_monthlyPunchReport', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function show_monthlyPunchRecordsReport($month, $year, $dataMonthReport) {
        //echo $date;die;
        $month_date = $year . '-' . $month . '-01';
        $month_date = date('F Y', strtotime($month_date));
        $data['month_date'] = $month_date;

        $data['month_punch_report'] = $dataMonthReport;
        $data['month_date'] = $month_date;


        /* Start Menu Section */
        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');

        $user_groups = $this->ion_auth->get_users_groups($user_id)->result();

        $data['submenu'] = $this->menu->get_submenu_by_group_id($user_groups[0]->id);
        $data['mainmenu'] = $this->menu->get_menuname_by_group_id($user_groups[0]->id);
        /* End Menu Section */

        if (isset($user_id)) {
            $dataHeader['current_login_user_details'] = $this->employeesummary->as_array()->get_by('user_id', $user_id);
//            var_dump($data['current_login_user_details']);die;
            $dataHeader['current_associate_slug'] = $this->users->get_slug_by_id($user_id);
            $dataHeader['current_personal_detail'] = $this->personaldetails->get_by_id($user_id);
        }


        $this->template->write_view('header', 'snippets/header', (isset($dataHeader) ? $dataHeader : NULL));
        $this->template->write_view('sidebar', 'snippets/sidebar', (isset($data) ? $data : NULL));
        $this->template->write_view('content', '_show_MonthlyPunchReport', (isset($data) ? $data : NULL));
        $this->template->write_view('footer', 'snippets/footer', '', TRUE);
        $this->template->render();
    }

    public function importData() {
        if (isset($_POST['importSubmit'])) {
            //validate whether uploaded file is a csv file
            $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
            if (!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)) {
                if (is_uploaded_file($_FILES['file']['tmp_name'])) {

                    //open uploaded csv file with read only mode
                    $csvFile = fopen($_FILES['file']['tmp_name'], 'r');

                    //skip first line
                    fgetcsv($csvFile);

                    //parse data from csv file line by line
                    while (($line = fgetcsv($csvFile)) !== FALSE) {

                        $total_hrs = (float) (($line[1] * 9) );
                        $total_string = $total_hrs . ':00' . ':00';

                        $normal_time = explode(' Hours ', $line[3]);
                        $normal_hrs = $normal_time[0];
                        $normal_min_calc = explode(' Mins', $normal_time[1]);
                        $normal_min = $normal_min_calc[0];
                        $normal_string = $normal_hrs . ':' . $normal_min . ':00';

                        $ot_time = explode(' Hours ', $line[4]);
                        $ot_hrs = $ot_time[0];
                        $ot_min_calc = explode(' Mins', $ot_time[1]);
                        $ot_min = $ot_min_calc[0];
                        $ot_string = $ot_hrs . ':' . $ot_min . ':00';

                        $actual_hrs = $this->sum_the_time($normal_string, $ot_string);
                        $diff_hrs = $this->subtract_the_time($total_string, $actual_hrs);

                        $diff_days = $this->days_conversion($diff_hrs);

                        if ($total_string > $actual_hrs) {
                            $diff_hrs = '-' . ($diff_hrs);
                            $diff_days = '-' . ($diff_days);
                        }
                        $attendanceData = array(
                            'emp_id' => $line[0],
                            'present_days' => $line[1],
                            'absent_days' => $line[2],
                            'working_hrs' => $normal_string,
                            'ot_hrs' => $ot_string,
                            'ot_days' => $line[5],
                            'cl' => $line[6],
                            'pl' => $line[7],
                            'sl' => $line[8],
                            'total_leave' => $line[9],
                            'late_coming' => $line[10],
                            'late_coming_hrs' => $line[11],
                            'early_going' => $line[12],
                            'early_going_hrs' => $line[13],
                            'week_off' => $line[14],
                            'week_off_present' => $line[15],
                            'holiday' => $line[16],
                            'holiday_present' => $line[17],
                            'total_hrs' => $total_hrs,
                            'actual_hrs' => $actual_hrs,
                            'difference_hrs' => $diff_hrs,
                            'diff_days' => $diff_days
                        );
                        // var_dump($attendanceData);

                        $this->attendancemodel->insert($attendanceData);
                        //  $working_hrs = 0;
                        //insert member data into database
                    }
                    // die;
                    //close opened csv file
                    fclose($csvFile);

                    $qstring = '?status=succ';
                } else {
                    $qstring = '?status=err';
                }
            } else {
                $qstring = '?status=invalid_file';
            }
        }

        redirect('attendance/');
    }

    public function importPunchData() {

        $add_date = date('Y-m-d', strtotime($this->input->post('fdate')));
        $last_id = $this->attendancepunchesmodel->get_last_id();

        if ($last_id == null || $last_id == 0)
            $last_id = 1;
        else
            $last_id = $last_id + 1;

        if ($this->session->userdata('user_id'))
            $user_id = $this->session->userdata('user_id');


        $total_inhrs = array();
        $total_outhrs = array();
        if (isset($_POST['importSubmit'])) {

            //validate whether uploaded file is a csv file
            $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
            if (!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)) {
                if (is_uploaded_file($_FILES['file']['tmp_name'])) {

                    //open uploaded csv file with read only mode
                    $csvFile = fopen($_FILES['file']['tmp_name'], 'r');

                    //skip first line
                    fgetcsv($csvFile);
                    while (($line = fgetcsv($csvFile)) !== FALSE) {


                        $test_name_array = $line[16];


                        $pieces = explode(" ", $test_name_array);
                        //var_dump($pieces);

                        foreach ($pieces as $key => $value) {
                            $exp_key = explode(':', $value);

                            if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                //
                                if ($exp_key[2] == 'in(AC)') {
                                    $arr_inresult[] = $value;
                                }
                            }
                        }
                        if (isset($arr_inresult)) {
                            //   echo '11';
                            $count = count($arr_inresult);


                            foreach ($pieces as $key => $value) {
                                $exp_key = explode(':', $value);
                                if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                    if ($exp_key[2] == 'out(AC)') {
                                        $arr_outresult[] = $value;
                                    }
                                }
                            }

                            foreach ($pieces as $key => $value) {
                                $exp_key = explode(':', $value);

                                if (isset($exp_key[2]) && $exp_key[2] != '' && $exp_key[2] != null) {
                                    if ($exp_key[2] == '(AC)') {
                                        $arr_missoutresult[] = $value;
                                    }
                                }
                            }

                            $falg = 0;
                            for ($i = 0; $i < $count; $i++) {


                                if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
                                    $instring = explode(':in(AC)', $arr_inresult[$i]);
                                    $stratString = $instring[0] . ':00';


                                    $outstring = explode(':out(AC)', $arr_outresult[$i]);
                                    $endString = $outstring[0] . ':00';

                                    $start_time = new DateTime($stratString);
                                    $end_time = new DateTime($endString);
                                    $duration = $start_time->diff($end_time);


                                    $total_inhrs[$i] = $duration->format("%H : %I");
                                }

                                if (isset($arr_inresult[$i]) && isset($arr_outresult[$i])) {
                                    if (isset($arr_inresult[$i])) {
                                        $instring1 = explode(':in(AC)', $arr_inresult[$i]);
                                        $firdtString = (string) $instring1[0];
                                        $stratString1 = $instring1[0] . ':00';

                                        $arr_outresult[-1] = '00:00:out(AC)';

                                        $outstring1 = explode(':out(AC)', $arr_outresult[$i - 1]);
                                        $endString1 = $outstring1[0] . ':00';

                                        $start_time1 = new DateTime($stratString1);
                                        $end_time1 = new DateTime($endString1);
                                        $duration1 = $start_time1->diff($end_time1);

                                        $val = $duration1->format("%H:%I");
                                        if ((trim($firdtString) == trim($val))) {
                                            
                                        } else {
                                            $total_outhrs[$i] = $duration1->format("%H:%I");
//                                            echo $total_outhrs[$i];
                                        }
                                    }
                                }
                            }

                            $time = 0;

                            foreach ($total_inhrs as $time_val) {
                                $time += $this->explode_time($time_val);
                            }
                            $in_hrs = $this->second_to_hhmm($time);

                            $time1 = 0;

                            foreach ($total_outhrs as $time_val1) {
                                $time1 +=$this->explode_time($time_val1);
                            }
                            $out_hrs = $this->second_to_hhmm($time1);
//                           var_dump($out_hrs);
                        }



                        $emp_id = $this->_get_employeeid($line[1]);

                        $emp_name = $this->biomatricrecords->get_empName($emp_id);

                        // echo $in_hrs;
                        //parse data from csv file line by line


                        $attendanceData = array(
                            'upload_date' => $add_date,
                            'date' => $line[0],
                            'emp_id' => $line[1],
                            'p_self_id' => $last_id,
                            'emp_name' => $line[2],
                            'company' => $line[3],
                            'dept' => $line[4],
                            'category' => $line[5],
                            'designation' => $line[6],
                            'grade' => $line[7],
                            'team' => $line[8],
                            'shift' => $line[9],
                            'in_time' => $line[10],
                            'out_time' => $line[11],
                            'duration' => $line[12],
                            'late_by' => $line[13],
                            'early_by' => $line[14],
                            'status' => $line[15],
                            'punch_rec' => $line[16],
                            'overtime' => $line[17],
                            'cl' => $line[18],
                            'pl' => $line[19],
                            'sl' => $line[20],
                            'par' => $line[21],
                            'mat' => $line[22],
                            'wh' => $line[23],
                            'cli' => $line[24],
                            'week_off' => $line[25],
                            'week_off_present' => $line[26],
                            'holiday' => $line[27],
                            'holiday_present' => $line[28],                            
                            'in_hrs' => isset($in_hrs) ? $in_hrs : '00:00',
                            'out_hrs' => isset($out_hrs) ? $out_hrs : '00:00',
                            'createdby' => $user_id,
                            'createdat' => date('Y-m-d H:i:s')
                        );
                        //  var_dump($line[16]);

                        $this->attendancepunchesmodel->insert($attendanceData);
                        //  $working_hrs = 0;
                        //insert member data into database
                        $arr_inresult = array();
                        $arr_outresult = array();
                        $arr_missoutresult = array();
                        $total_outhrs = array();
                        $total_inhrs = array();
                    }

                    //   die;
                    //close opened csv file
                    fclose($csvFile);

                    $qstring = '?status=succ';
                } else {
                    $qstring = '?status=err';
                }
            } else {
                $qstring = '?status=invalid_file';
            }
        }

        redirect('attendance/punches');
    }

    function days_conversion($time) {
        $seconds = 0;
        list($hour, $minute, $second) = explode(':', $time);
        if ($minute > 0)
            $minute = $minute;
        else
            $minute = -$minute;

        if ($hour > 0)
            $hour = $hour;
        else
            $hour = -$hour;

        $seconds += $hour * 60;
        $seconds += $minute;

        $days = round(($seconds / 540), 2);



        $days = $this->closest($days);



        $cnt = substr_count($time, '-');
        if ($cnt == 1)
            $days = -$days;



        return $days;
    }

    function closest($number) {
        $array = array('0' => '0', '0.5' => '0.5', '1' => '1', '1.5' => '1.5', '2' => '2', '2.5' => '2.5', '3' => '3', '3.5' => '3.5', '4' => '4', '4.5' => '4.5', '5' => '5', '5.5' => '5.5', '6' => '6');
        //infinite distance to start
        $dist = INF;
        //remember our last value
        $last = false;
        $temp = 0;
        foreach ($array as $v) {
            //get our current distance
            $dist2 = abs($number - $v);
            //check if we are getting further than last number was
            if ($dist2 > $dist) {
                //return our last value
                if ($last > $number) {
                    $last = (float) ($last - 0.5);
                    return $last;
                } else
                    return $last;
            }
            //set our new distance
            $dist = $dist2;
            //set our last value for next iteration
            $last = (float) $v;
        }
        return $last;
    }

    public function closest_m($number) {
        $flag = 0;
        $prev_val = 0;
        $array = array('0' => '0', '0.5' => '0.5', '1' => '1', '1.5' => '1.5', '2' => '2', '2.5' => '2.5', '3' => '3', '3.5' => '3.5', '4' => '4', '4.5' => '4.5', '5' => '5', '5.5' => '5.5', '6' => '6');
        foreach ($array as $val) {
            if ($flag == 0) {
                if ($number <= $val) {
                    $temp = $val;
                    $prev_val = $val - 0.5;
                    $flag = 1;
                    if ($number < $temp)
                        var_dump($prev_val);
                    else
                        var_dump($temp);
                }
            }
        }
    }

    function disp() {
        $test_name_array = '10:33:in(AC) 12:00:out(AC) 12:51:in(AC) 14:25:out(AC) 14:32:in(AC) 16:47:out(AC) 16:59:in(AC) 17:58:out(AC)';
        $pieces = explode(" ", $test_name_array);

        foreach ($pieces as $key => $value) {
            $exp_key = explode(':', $value);
            var_dump($exp_key);
            if ($exp_key[2] == 'in(AC)') {
                $arr_inresult[] = $value;
            }
        }

        foreach ($pieces as $key => $value) {
            $exp_key = explode(':', $value);
            if ($exp_key[2] == 'out(AC)') {
                $arr_outresult[] = $value;
            }
        }

        foreach ($pieces as $key => $value) {
            $exp_key = explode(':', $value);
            if ($exp_key[2] == '(AC)') {
                $arr_missoutresult[] = $value;
            }
        }

        print_r($arr_inresult);
        echo '<br>';
        print_r($arr_outresult);
        print_r($arr_missoutresult);
    }

    public function get_all_view_data($associate_id) {

        $data['user_summary'] = $this->employeesummary->as_array()->get_by('user_id', $associate_id);
        $data['notification'] = $this->notification->get_by_id($data['user_summary']['department_id'], $data['user_summary']['emprole']);

        $data['associate_slug'] = $this->employees->get_user_slug_by_id($associate_id);
        $data['empId'] = $this->_get_employeeid();
        $data['prefix'] = (array('' => 'Choose your option') + $this->prefix->dropdown('prefix'));
        $data['gender'] = (array('' => 'Choose your option') + $this->gender->dropdown('gendername'));
        $data['empmode_list'] = (array('' => 'Select Mode') + $this->employment_mode->dropdown('mode'));
        $data['emprole_list'] = (array('' => 'Select Role') + $this->roles->dropdown('rolename'));
        $data['department_list'] = (array('' => 'Select Department') + $this->department->dropdown('deptname'));
        $data['jobtitle_list'] = (array('' => 'Select Job Code') + $this->jobTitle->dropdown('jobtitlename'));
        $data['holiday_group'] = (array('' => 'Select Holiday Group') + $this->holiday_groups->dropdown('groupname'));
        $data['emp_status_list'] = (array('' => 'Select Employment') + $this->employment_status->dropdown('emp_status'));
        $data['work_station'] = (array('' => 'Select WorkStation') + $this->workstation->dropdown('work_station_code'));
        $data['status'] = array('0' => 'In-Active', '1' => 'Active', '2' => 'Resigned', '3' => 'Left', '4' => 'Suspend', '5' => 'Delete');
        $data['yearsexp'] = array('0 Year', '1 Year', '2 Year', '3 Year', '4 Year', '5 Year', '6 Year', '7 Year', '8 Year', '9 Year', '10 Year');
        $data['monthsexp'] = array('0 Month', '1 Month', '2 Month', '3 Month', '4 Month', '5 Month', '6 Month', '7 Month', '8 Month', '9 Month', '10 Month', '11 Month');
        $data['action'] = 'add';

        $data['country_list'] = (array('' => 'Select Country')) + $this->country->dropdown('countryname');
        $data['state_list'] = (array('' => 'Select State')) + $this->state->dropdown('statename');
        $data['city_list'] = (array('' => 'Select City')) + $this->city->dropdown('cityname');
        $data['department_id'] = $data['user_summary']['department_id'];
        $data['emprole'] = $data['user_summary']['emprole'];

        $data['rep_manager_list'] = $this->employeesummary->get_all_manager($data['department_id'], $data['emprole']);
        $data['position_list'] = $this->employees->get_all_position_by_id($data['user_summary']['jobtitle_id']);

        //Associate Holiday & Leaves
//        $data['holiday'] = $this->employeesholiday->get_by_id($associate_id);
//        $data['leaves'] = $this->employeesleave->get_by_id($associate_id);
//echo $this->db->last_query();die;
        //Associate Communication & Personal Details
        $data['personal_detail'] = $this->personaldetails->get_by_id($associate_id);
//        echo $this->db->last_query();die;
        $data['communication_detail'] = $this->communication->get_by_id($associate_id);
//        var_dump($data['leaves']);die;
//        var_dump($associate_id);die;
        $data['marital_list'] = (array('' => 'Select Marital Status') + $this->marital_status->dropdown('maritalstatusname'));
        $data['nationality_list'] = (array('' => 'Select Nationality') + $this->nationality->dropdown('nationalitycode'));
        $data['language_list'] = (array('' => 'Select Language') + $this->language->dropdown('languagename'));
        $data['blood_groups'] = (array('' => 'Select Blood Group') + $this->blood_groups->dropdown('blood_group'));
        $data['hobbies'] = (array('' => 'Select Hobbies', 'disabled' => 'disabled') + $this->hobbies->dropdown('hobbies_title'));

        /* Document */
        $data['document_details'] = $this->documents->get_by_id($associate_id);

        /* job history */
        $data['jobhistroy_details'] = NULL;
//        var_dump($data['user_summary']);die;
        /* Experience */
        $data['tag_type'] = (array('' => 'Select Tag')) + $this->tag->dropdown('tag_name');
        $data['experience_details'] = $this->experiencedetails->get_by_id($associate_id);
//        var_dump($data['user_summary']['department_id']);die;


        /* Dashboard */
        $data['publish_group'] = (array('0' => 'All Department')) + (array($data['user_summary']['department_id'] => $data['user_summary']['department_name'])) + (array('99' => 'Only Me'));
        $data['timeline_comment'] = $this->timelinecomment->get_by_id($associate_id);
//        $data['comment_data'] = $this->timelinecomment->get_by_id($associate_id);
//        var_dump($data['timeline_comment']);
//        die;
        $data['hall_of_fame'] = $this->employeeawards->hall_of_fame();
        $data['leaves'] = $this->leavetypesAllocation->get_leaveList($associate_id);
        $data['balnce_leaves'] = $this->leavetypesAllocation->get_balanceLeaves($associate_id);

        return $data;
    }

    function hms2sec($hms) {
        list($h, $m, $s) = explode(":", $hms);
        $seconds = 0;
        $seconds += (intval($h) * 3600);
        $seconds += (intval($m) * 60);
        $seconds += (intval($s));
        return $seconds;
    }

    function seconds($seconds) {

        // CONVERT TO HH:MM:SS
        $hours = floor($seconds / 3600);
        $remainder_1 = ($seconds % 3600);
        $minutes = floor($remainder_1 / 60);
        $seconds = ($remainder_1 % 60);

        // PREP THE VALUES
        if (strlen($hours) == 1) {
            $hours = "0" . $hours;
        }

        if (strlen($minutes) == 1) {
            $minutes = "0" . $minutes;
        }

        if (strlen($seconds) == 1) {
            $seconds = "0" . $seconds;
        }

        return $hours . ":" . $minutes . ":" . $seconds;
    }

    function sum_the_time($time1, $time2) {
        $times = array($time1, $time2);
        $seconds = 0;
        foreach ($times as $time) {
            list($hour, $minute, $second) = explode(':', $time);
            $seconds += $hour * 3600;
            $seconds += $minute * 60;
            $seconds += $second;
        }
        $hours = floor($seconds / 3600);
        $seconds -= $hours * 3600;
        $minutes = floor($seconds / 60);
        $seconds -= $minutes * 60;
        // return "{$hours}:{$minutes}:{$seconds}";
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    function subtract_the_time($time1, $time2) {

        list($hours1, $minutes1) = explode(':', $time1);
        $startTimestamp = mktime($hours1, $minutes1);

        list($hours2, $minutes2) = explode(':', $time2);
        $endTimestamp = mktime($hours2, $minutes2);

        if ($startTimestamp > $endTimestamp)
            $seconds1 = $startTimestamp - $endTimestamp;
        else
            $seconds1 = $endTimestamp - $startTimestamp;



        $minutes = floor(($seconds1 / 60) % 60);
        if ($minutes > 0)
            $minutes = (floor(($seconds1 / 60) % 60));
        else
            $minutes = -(floor(($seconds1 / 60) % 60));

        $hours = ($seconds1 / (60 * 60));
        if ($hours < 0)
            $hours = round($hours);
        else
            $hours = floor($hours);

        $seconds = '00';

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    function explode_time($time) { //explode time and convert into seconds
        $time = explode(':', $time);
        $time = $time[0] * 3600 + $time[1] * 60;
        return $time;
    }

    function second_to_hhmm($time) { //convert seconds to hh:mm
        $hour = floor($time / 3600);
        $minute = strval(floor(($time % 3600) / 60));
        if ($minute == 0) {
            $minute = "00";
        } else if ($minute <= 9) {
            $minute = '0' . $minute;
        } else {
            $minute = $minute;
        }

        // echo $minute;
        $time = $hour . ":" . $minute;
        // var_dump($time);
        return $time;
    }

    function delete_biomaticrecord() {
        if (isset($_POST)) {
            $b_self_id = $_POST['b_self_id'];
            $this->biomatricrecords->delete($b_self_id);
            echo json_encode(array('delete' => 'Record deleted successfully'));
            return true;
        }
    }

    function delete_punchrecord() {
        if (isset($_POST)) {
            $p_self_id = $_POST['p_self_id'];
            $this->attendancepunchesmodel->delete($p_self_id);
            echo json_encode(array('delete' => 'Record deleted successfully'));
            return true;
        }
    }

}
